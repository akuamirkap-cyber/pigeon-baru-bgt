import { useState } from "react";
import { Asset3DView, type Asset3DKind } from "./components/MenuAssets3D";

// Clam manual/auto toggle: 0 = auto buka-tutup, 1 = tutup, 2 = buka
type ClamMode = 0 | 1 | 2;

const ASSETS: { kind: Asset3DKind; name: string; glow: string }[] = [
  {
    kind: "crown",
    name: "Mahkota 3D",
    glow: "radial-gradient(circle, rgba(255,238,142,0.5) 0%, rgba(255,204,58,0.16) 44%, rgba(255,204,58,0) 72%)",
  },
  {
    kind: "island",
    name: "Pulau 3D",
    glow: "radial-gradient(circle, rgba(142,248,255,0.46) 0%, rgba(56,214,248,0.15) 44%, rgba(56,214,248,0) 72%)",
  },
  {
    kind: "wheel",
    name: "Setir Kapal 3D",
    glow: "radial-gradient(circle, rgba(255,220,148,0.44) 0%, rgba(245,168,62,0.14) 44%, rgba(245,168,62,0) 72%)",
  },
  {
    kind: "clam",
    name: "Kerang Mutiara 3D",
    glow: "radial-gradient(circle, rgba(255,224,244,0.58) 0%, rgba(246,162,212,0.2) 44%, rgba(246,162,212,0) 72%)",
  },
  {
    kind: "trophy",
    name: "Trofi Emas 3D",
    glow: "radial-gradient(circle, rgba(255,240,146,0.52) 0%, rgba(255,196,46,0.18) 44%, rgba(255,196,46,0) 72%)",
  },
];

const CLAM_MODE_LABEL: Record<ClamMode, string> = {
  0: "Auto",
  2: "Buka",
  1: "Tutup",
};

export default function App() {
  const [clamMode, setClamMode] = useState<ClamMode>(0);

  const cycleClam = () => {
    setClamMode((m) => (m === 0 ? 1 : m === 1 ? 2 : 0));
  };

  return (
    <main className="ocean-stage relative w-screen h-screen overflow-hidden flex items-center justify-center px-3 sm:px-6 lg:px-10 select-none">
      {/* Subtle sunlit underwater rays matching Fish.io aesthetic */}
      <div className="sun-rays pointer-events-none absolute inset-0" aria-hidden="true" />

      {/* All 5 vibrant Pixar-glossy 3D Assets lined up neatly left-to-right with crisp labels */}
      <section
        aria-label="3D Assets Showcase"
        className="relative z-10 w-full max-w-[1440px] flex flex-row items-start justify-center gap-2 sm:gap-4 md:gap-6 lg:gap-7"
      >
        {ASSETS.map((item) => {
          const isClam = item.kind === "clam";
          return (
            <figure
              key={item.kind}
              className="flex-1 min-w-0 max-w-[270px] flex flex-col items-center m-0"
            >
              <div className="relative w-full aspect-square flex items-center justify-center">
                {/* Matching radial aura glow framing each 3D model */}
                <div
                  className="pointer-events-none absolute inset-1 rounded-full"
                  style={{ background: item.glow }}
                  aria-hidden="true"
                />
                {/* Soft ocean floor lift shadow */}
                <div
                  className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 w-[56%] h-4 rounded-full bg-[#032652]/32 blur-md"
                  aria-hidden="true"
                />
                <div className="relative z-10 w-full h-full">
                  <Asset3DView
                    kind={item.kind}
                    label={item.name}
                    customState={isClam ? clamMode : 0}
                    onTap={isClam ? cycleClam : undefined}
                    titleHint={
                      isClam
                        ? "Klik untuk Buka / Tutup / Auto · Seret untuk putar 3D"
                        : `${item.name} — seret untuk putar 3D`
                    }
                  />
                </div>
              </div>

              <figcaption className="asset-label mt-1.5 sm:mt-2.5 text-center font-extrabold tracking-wide text-white text-[clamp(13px,1.72vw,24px)] leading-tight whitespace-nowrap">
                {item.name}
              </figcaption>

              {/* Compact tasteful toggle right under Kerang Mutiara so user can immediately open/close or let it auto-animate */}
              {isClam && (
                <button
                  type="button"
                  onClick={cycleClam}
                  aria-label="Buka atau tutup kerang mutiara"
                  className="mt-2 px-3 py-0.5 rounded-full bg-[#05306b]/65 hover:bg-[#08448f]/85 active:scale-95 border border-pink-200/55 text-[11px] sm:text-[12px] font-bold text-pink-50 tracking-wide shadow cursor-pointer transition-all"
                >
                  {clamMode === 1 ? "🐚 Tutup" : clamMode === 2 ? "✨ Buka" : `✨ ${CLAM_MODE_LABEL[clamMode]} Buka/Tutup`}
                </button>
              )}
            </figure>
          );
        })}
      </section>
    </main>
  );
}

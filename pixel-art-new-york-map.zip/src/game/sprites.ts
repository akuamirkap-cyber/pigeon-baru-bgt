import { G, R, Rng, Spr, drawText, ell, mkCanvas, mulberry32, outline, pick, pix, shade, textW } from './util';

// ============================================================ PEOPLE
export interface Look {
  skin: string;
  hair: string;
  hs: number; // 0 short 1 long 2 cap 3 beanie 4 afro 5 bald
  hat: string;
  shirt: string;
  pants: string;
  shoes: string;
  bottom: number; // 0 pants 1 shorts 2 skirt
  top: number; // 0 tee 1 suit 2 hoodie 3 vest
  acc: number; // 0 none 1 backpack 2 shoulder bag
  bag: string;
  sp: number; // special
}

const SKINS = ['#f6d3b3', '#e8b88f', '#c98e62', '#a36a44', '#6f4a32', '#f1c7a1', '#dba77c'];
const HAIRS = ['#1d1a1a', '#1d1a1a', '#3a2a1e', '#5a3b22', '#8a5a2b', '#c9a15a', '#d9d2c8', '#a8402a', '#e7c66a', '#ff6fb0', '#4a6fd9'];
const SHIRTS = ['#d94a4a', '#4a7fd9', '#4ab06a', '#e8c14a', '#f2f2f2', '#2b2b35', '#e87ab0', '#8a5ad9', '#f08a3c', '#3cc0c0', '#7a8a9a', '#b03a5a', '#2f6b4a', '#f5f0dc', '#5a3a2a'];
const SUITS = ['#2b3040', '#3a3a44', '#22242e', '#4a4038', '#2f3a5a', '#6a6a72'];
const PANTS = ['#2b3a5c', '#1f2430', '#4a4a52', '#6b5a44', '#3a5a8a', '#222229', '#7a6a55', '#33405c'];
const SHOES = ['#2a2220', '#f2f2f2', '#5a3a22', '#c0392b', '#1a1a1a'];
const HATS = ['#c0392b', '#2b5fb0', '#1f1f28', '#e8c14a', '#3f8a4a', '#f2f2f2', '#e8742b', '#8a3fb0'];
const BAGS = ['#c0392b', '#2b5fb0', '#3f8a4a', '#e8c14a', '#5a3a22', '#1f1f28', '#8a3fb0', '#e87ab0'];

export const SP_PLAYER = 0;
export const SP_COP = 1;
export const SP_VENDOR = 2;
export const SP_ELMO = 3;
export const SP_LIBERTY = 4;
export const SP_WORKER = 5;
export const SP_MUSIC = 6;
export const SP_JOG = 7; // 7..10
export const SP_COOKIE = 11;
export const SP_RANDOM = 12;

const base = (o: Partial<Look>): Look => ({
  skin: '#e8b88f', hair: '#3a2a1e', hs: 0, hat: '#c0392b', shirt: '#4a7fd9', pants: '#2b3a5c', shoes: '#2a2220',
  bottom: 0, top: 0, acc: 0, bag: '#c0392b', sp: 0, ...o,
});

const SPECIALS: Look[] = [
  base({ hs: 2, hat: '#e23b3b', shirt: '#2f6fd0', top: 2, pants: '#2b3350', shoes: '#f2f2f2', acc: 1, bag: '#f5c518', sp: 0 }),
  base({ hs: 2, hat: '#18244a', shirt: '#1f2f5a', top: 2, pants: '#141c33', shoes: '#111111', sp: 1, skin: '#c98e62' }),
  base({ hs: 2, hat: '#f2f2f2', shirt: '#f2f2f2', top: 2, pants: '#3a3a44', sp: 2, skin: '#a36a44', hair: '#1d1a1a' }),
  base({ hs: 5, skin: '#e23a2e', hair: '#e23a2e', shirt: '#e23a2e', top: 2, pants: '#e23a2e', shoes: '#e23a2e', sp: 3 }),
  base({ hs: 0, skin: '#9fe0c8', hair: '#5fb59a', shirt: '#5fb59a', top: 2, pants: '#5fb59a', bottom: 2, shoes: '#3e8f7a', sp: 4 }),
  base({ hs: 2, hat: '#f5d020', shirt: '#f08a24', top: 3, pants: '#3a4a6a', shoes: '#5a3a22', sp: 5, skin: '#dba77c' }),
  base({ hs: 3, hat: '#3a2a4a', shirt: '#2b2b35', top: 2, pants: '#33405c', sp: 6, skin: '#6f4a32', hair: '#1d1a1a' }),
  base({ hs: 0, shirt: '#ff5a8a', top: 0, bottom: 1, pants: '#1f1f28', shoes: '#f2f2f2', sp: 7, hair: '#e7c66a', skin: '#f6d3b3' }),
  base({ hs: 1, shirt: '#3cd0c0', top: 0, bottom: 1, pants: '#2b2b35', shoes: '#ff6a3a', sp: 7, hair: '#1d1a1a', skin: '#a36a44' }),
  base({ hs: 2, hat: '#f2f2f2', shirt: '#c8f03c', top: 0, bottom: 1, pants: '#33405c', shoes: '#f2f2f2', sp: 7, skin: '#6f4a32' }),
  base({ hs: 5, shirt: '#f2f2f2', top: 0, bottom: 1, pants: '#b03a3a', shoes: '#3a6ae0', sp: 7, skin: '#e8b88f' }),
  base({ hs: 5, skin: '#3a7ae0', hair: '#3a7ae0', shirt: '#3a7ae0', top: 2, pants: '#3a7ae0', shoes: '#3a7ae0', sp: 3 }),
];

function randLook(r: Rng): Look {
  const top = pick(r, [0, 0, 0, 1, 1, 2, 2]);
  return {
    skin: pick(r, SKINS),
    hair: pick(r, HAIRS),
    hs: pick(r, [0, 0, 0, 1, 1, 1, 2, 2, 3, 4, 5]),
    hat: pick(r, HATS),
    shirt: top === 1 ? pick(r, SUITS) : pick(r, SHIRTS),
    pants: top === 1 ? pick(r, ['#22242e', '#2c3040', '#3a3a44']) : pick(r, PANTS),
    shoes: pick(r, SHOES),
    bottom: top === 1 ? 0 : pick(r, [0, 0, 0, 0, 1, 2]),
    top,
    acc: pick(r, [0, 0, 0, 1, 1, 2]),
    bag: pick(r, BAGS),
    sp: -1,
  };
}

type PF = (c: string, x: number, y: number, w?: number, h?: number) => void;

function hairFB(P: PF, L: Look, front: boolean) {
  const { hair, hat, skin } = L;
  const hl = shade(hair, 1.3);
  switch (L.hs) {
    case 0:
      P(hair, 5, 2, 6, 1);
      P(hair, 4, 3, 8, 2);
      P(hl, 6, 3, 3, 1);
      if (front) {
        P(hair, 4, 5);
        P(hair, 11, 5);
      } else P(hair, 4, 5, 8, 4);
      break;
    case 1:
      P(hair, 5, 2, 6, 1);
      P(hair, 4, 3, 8, 2);
      P(hl, 6, 3, 3, 1);
      P(hair, 3, 4, 1, 7);
      P(hair, 12, 4, 1, 7);
      if (front) {
        P(hair, 4, 5, 1, 2);
        P(hair, 11, 5, 1, 2);
      } else P(hair, 4, 5, 8, 7);
      break;
    case 2:
      P(hat, 5, 2, 6, 1);
      P(hat, 4, 3, 8, 2);
      P(shade(hat, 1.25), 6, 2, 3, 1);
      if (front) {
        P(shade(hat, 0.7), 4, 5, 8, 1);
        P(hair, 4, 6);
        P(hair, 11, 6);
      } else {
        P(hat, 4, 5, 8, 1);
        P(hair, 4, 6, 8, 3);
      }
      break;
    case 3:
      P(hat, 5, 1, 6, 1);
      P(hat, 4, 2, 8, 2);
      P(shade(hat, 1.3), 4, 4, 8, 1);
      if (!front) P(hair, 4, 5, 8, 4);
      break;
    case 4:
      P(hair, 4, 1, 8, 1);
      P(hair, 3, 2, 10, 3);
      P(hl, 5, 2, 3, 1);
      if (front) {
        P(hair, 3, 5, 1, 2);
        P(hair, 12, 5, 1, 2);
      } else P(hair, 3, 5, 10, 4);
      break;
    default:
      P(skin, 5, 3, 6, 1);
      P(shade(skin, 1.12), 6, 3, 2, 1);
      break;
  }
}

function hairSide(P: PF, L: Look) {
  const { hair, hat, skin } = L;
  const hl = shade(hair, 1.3);
  switch (L.hs) {
    case 0:
      P(hair, 5, 2, 6, 1);
      P(hair, 4, 3, 8, 2);
      P(hair, 8, 5, 4, 3);
      P(hair, 10, 8, 2, 1);
      P(hl, 6, 3, 3, 1);
      break;
    case 1:
      P(hair, 5, 2, 6, 1);
      P(hair, 4, 3, 8, 2);
      P(hair, 8, 5, 4, 7);
      P(hl, 6, 3, 3, 1);
      break;
    case 2:
      P(hat, 5, 2, 6, 1);
      P(hat, 4, 3, 8, 2);
      P(shade(hat, 0.7), 2, 5, 6, 1);
      P(hair, 9, 5, 3, 3);
      break;
    case 3:
      P(hat, 5, 1, 6, 1);
      P(hat, 4, 2, 8, 2);
      P(shade(hat, 1.3), 4, 4, 8, 1);
      P(hair, 9, 5, 3, 3);
      break;
    case 4:
      P(hair, 4, 1, 8, 1);
      P(hair, 3, 2, 10, 3);
      P(hair, 8, 5, 5, 4);
      break;
    default:
      P(skin, 5, 3, 6, 1);
      P(skin, 11, 4, 1, 5);
      break;
  }
}

function person(g: G, ox: number, oy: number, dir: number, fr: number, L: Look) {
  const P: PF = (c, x, y, w = 1, h = 1) => {
    g.fillStyle = c;
    g.fillRect(ox + x, oy + y, w, h);
  };
  const { skin, shirt, pants, shoes } = L;
  const sd = shade(shirt, 0.78);
  const leg = L.bottom ? skin : pants;
  const eye = '#20202c';
  const sl = L.top === 0 ? 2 : 9;
  if (dir === 0 || dir === 3) {
    const front = dir === 0;
    const lUp = fr === 1;
    const rUp = fr === 2;
    P(pants, 5, 16, 6, 2);
    P(leg, 5, 18, 2, lUp ? 2 : 3);
    P(shoes, 5, lUp ? 20 : 21, 2, 1);
    P(leg, 9, 18, 2, rUp ? 2 : 3);
    P(shoes, 9, rUp ? 20 : 21, 2, 1);
    if (L.bottom === 2) {
      P(shirt, 4, 16, 8, 3);
      P(sd, 4, 18, 8, 1);
    }
    P(shirt, 5, 10, 6, 6);
    P(sd, 5, 15, 6, 1);
    const la = fr === 1 ? 3 : fr === 2 ? 5 : 4;
    const ra = fr === 1 ? 5 : fr === 2 ? 3 : 4;
    P(sd, 4, 10, 1, Math.min(sl, la));
    if (la > sl) P(skin, 4, 10 + sl, 1, la - sl);
    P(skin, 4, 10 + la, 1, 1);
    P(sd, 11, 10, 1, Math.min(sl, ra));
    if (ra > sl) P(skin, 11, 10 + sl, 1, ra - sl);
    P(skin, 11, 10 + ra, 1, 1);
    if (front) {
      if (L.top === 1) {
        P('#eeeeee', 7, 10, 2, 3);
        P(L.bag, 7, 11, 2, 3);
      } else if (L.top === 2) {
        P(shade(shirt, 1.25), 6, 10, 4, 1);
        P(sd, 6, 13, 4, 2);
      } else if (L.top === 3) {
        P('#ffe14a', 5, 12, 6, 1);
        P('#ffe14a', 5, 14, 6, 1);
      } else P(skin, 7, 10, 2, 1);
      if (L.acc === 2) {
        for (let i = 0; i < 5; i++) P(L.bag, 5 + i, 10 + i);
        P(L.bag, 10, 14, 2, 3);
      }
      if (L.sp === SP_VENDOR) P('#ffffff', 6, 12, 4, 6);
      if (L.sp === SP_COP) P('#f5d020', 6, 11);
      if (L.sp === SP_MUSIC) {
        P('#b5651d', 5, 13, 4, 3);
        P('#6b3e12', 9, 12, 3, 1);
        P('#e8c98a', 6, 14, 2, 1);
      }
    } else {
      if (L.acc === 1) {
        P(L.bag, 5, 10, 6, 5);
        P(shade(L.bag, 0.75), 5, 14, 6, 1);
        P(shade(L.bag, 1.25), 6, 11, 4, 1);
      }
      if (L.top === 3) {
        P('#ffe14a', 5, 12, 6, 1);
        P('#ffe14a', 5, 14, 6, 1);
      }
    }
    P(skin, 4, 4, 8, 6);
    if (front) {
      P(eye, 6, 7, 1, 2);
      P(eye, 9, 7, 1, 2);
    }
    hairFB(P, L, front);
    if (L.sp === SP_ELMO && front) {
      P('#ffffff', 5, 5, 2, 3);
      P('#ffffff', 9, 5, 2, 3);
      P('#111111', 6, 6);
      P('#111111', 9, 6);
      P('#f59a23', 7, 8, 2, 1);
    }
    if (L.sp === SP_LIBERTY) {
      P(L.hair, 4, 1);
      P(L.hair, 6, 1);
      P(L.hair, 9, 1);
      P(L.hair, 11, 1);
      if (front) P('#f5c542', 3, 8, 1, 2);
    }
    if (L.sp === SP_COP && front) P('#f5d020', 7, 3, 2, 1);
  } else {
    P(pants, 6, 16, 4, 2);
    if (fr === 0) {
      P(leg, 6, 18, 3, 3);
      P(shoes, 5, 21, 4, 1);
    } else {
      P(shade(leg, 0.85), 8, 18, 2, 2);
      P(shade(leg, 0.85), 9, 20, 2, 1);
      P(shoes, 9, 21, 3, 1);
      P(leg, 5, 18, 2, 2);
      P(leg, 4, 20, 2, 1);
      P(shoes, 3, 21, 3, 1);
    }
    if (L.bottom === 2) P(shirt, 5, 16, 6, 3);
    P(shirt, 6, 10, 5, 6);
    P(sd, 6, 15, 5, 1);
    if (L.acc === 1) {
      P(L.bag, 11, 10, 2, 5);
      P(shade(L.bag, 0.75), 11, 14, 2, 1);
    }
    if (L.acc === 2) P(L.bag, 7, 14, 3, 3);
    if (L.top === 3) P('#ffe14a', 6, 12, 5, 1);
    const ax = fr === 1 ? 6 : fr === 2 ? 9 : 8;
    P(sd, ax, 10, 2, L.top === 0 ? 2 : 4);
    if (L.top === 0) P(skin, ax, 12, 2, 2);
    P(skin, ax, 14, 2, 1);
    if (L.sp === SP_MUSIC) {
      P('#b5651d', 4, 13, 3, 3);
      P('#6b3e12', 2, 12, 2, 1);
    }
    P(skin, 4, 4, 7, 6);
    P(eye, 5, 7, 1, 2);
    hairSide(P, L);
    if (L.sp === SP_ELMO) {
      P('#ffffff', 4, 5, 2, 3);
      P('#111111', 4, 6);
      P('#f59a23', 3, 8, 1, 1);
    }
    if (L.sp === SP_LIBERTY) {
      P(L.hair, 5, 1);
      P(L.hair, 8, 1);
      P(L.hair, 10, 1);
    }
  }
}

export interface PeopleAtlas {
  c: HTMLCanvasElement;
  n: number;
  per: number;
}

export function buildPeople(seed: number, n = 96): PeopleAtlas {
  const r = mulberry32(seed);
  const looks: Look[] = [...SPECIALS];
  while (looks.length < n) looks.push(randLook(r));
  const per = 12;
  const { c, g } = mkCanvas(per * 48, Math.ceil(looks.length / per) * 96);
  const tmp = mkCanvas(48, 24);
  looks.forEach((L, i) => {
    const X = (i % per) * 48;
    const Y = Math.floor(i / per) * 96;
    for (let f = 0; f < 3; f++) {
      person(g, X + f * 16, Y, 0, f, L);
      person(g, X + f * 16, Y + 24, 1, f, L);
      person(g, X + f * 16, Y + 72, 3, f, L);
    }
    tmp.g.clearRect(0, 0, 48, 24);
    for (let f = 0; f < 3; f++) person(tmp.g, f * 16, 0, 1, f, L);
    for (let f = 0; f < 3; f++) {
      g.save();
      g.translate(X + f * 16 + 16, Y + 48);
      g.scale(-1, 1);
      g.drawImage(tmp.c, f * 16, 0, 16, 24, 0, 0, 16, 24);
      g.restore();
    }
  });
  outline(c);
  return { c, n: looks.length, per };
}

// ============================================================ CARS
export interface CarType {
  len: number;
  kind: number; // 0 sedan 1 taxi 2 police 3 bus 4 van
  c: HTMLCanvasElement[]; // N E S W
}

function carH(len: number, body: string, kind: number): HTMLCanvasElement {
  const { c, g } = mkCanvas(len + 2, 24);
  const top = shade(body, 1.1);
  const side = shade(body, 0.85);
  const glass = '#253348';
  const gl2 = '#5a7fa8';
  const mid = len >> 1;
  if (kind >= 3) {
    R(g, top, 1, 2, len, 10);
    R(g, shade(body, 1.22), 2, 3, len - 2, 1);
    R(g, shade(top, 0.88), 6, 5, 8, 4);
    if (kind === 3) R(g, shade(top, 0.88), len - 22, 5, 10, 4);
    R(g, glass, len - 3, 3, 3, 8);
    R(g, side, 1, 12, len, 8);
    if (kind === 3) {
      R(g, glass, 3, 13, len - 8, 4);
      for (let x = 9; x < len - 6; x += 7) R(g, side, x, 13, 1, 4);
      R(g, '#2a5fb8', 1, 18, len, 1);
    } else {
      R(g, glass, len - 11, 13, 8, 4);
      R(g, shade(body, 0.7), 5, 14, 12, 4);
      R(g, shade(body, 1.2), 7, 15, 8, 1);
    }
    R(g, shade(body, 0.55), 1, 20, len, 1);
    R(g, '#17181d', 6, 18, 7, 4);
    R(g, '#17181d', len - 14, 18, 7, 4);
    R(g, '#8a8d96', 8, 19, 3, 2);
    R(g, '#8a8d96', len - 12, 19, 3, 2);
    R(g, '#fff3b0', len - 1, 16, 2, 2);
    R(g, '#e03a3a', 1, 16, 1, 2);
  } else {
    R(g, top, 1, 7, len, 6);
    R(g, shade(body, 1.25), 8, 3, len - 16, 7);
    R(g, glass, len - 9, 4, 3, 8);
    R(g, gl2, len - 9, 4, 1, 3);
    R(g, glass, 6, 4, 2, 8);
    R(g, glass, 9, 10, len - 18, 3);
    R(g, gl2, 10, 10, 3, 1);
    R(g, side, mid, 10, 1, 3);
    R(g, side, 1, 13, len, 5);
    R(g, shade(body, 0.6), 1, 17, len, 1);
    R(g, shade(body, 0.7), mid, 13, 1, 4);
    if (kind === 1) {
      R(g, '#ffffff', mid - 3, 1, 6, 3);
      R(g, '#222222', mid - 2, 2, 4, 1);
      for (let x = 4; x < len - 2; x += 2) R(g, '#222222', x, 14, 1, 1);
    }
    if (kind === 2) {
      R(g, '#2a4fb0', 1, 14, len, 2);
      R(g, '#e03a3a', mid - 3, 2, 3, 2);
      R(g, '#3a6ae0', mid, 2, 3, 2);
    }
    R(g, '#17181d', 5, 15, 6, 4);
    R(g, '#17181d', len - 10, 15, 6, 4);
    R(g, '#8a8d96', 7, 16, 2, 2);
    R(g, '#8a8d96', len - 8, 16, 2, 2);
    R(g, '#fff3b0', len - 1, 13, 2, 2);
    R(g, '#e03a3a', 1, 13, 1, 2);
  }
  outline(c);
  return c;
}

function carV(len: number, body: string, kind: number, north: boolean): HTMLCanvasElement {
  const { c, g } = mkCanvas(22, len + 6);
  const W = 16;
  const x0 = 3;
  const top = shade(body, 1.1);
  const side = shade(body, 0.8);
  const roof = shade(body, 1.25);
  const glass = '#253348';
  const gl2 = '#5a7fa8';
  R(g, top, x0, 2, W, len);
  R(g, side, x0, len - 2, W, 4);
  if (kind >= 3) {
    R(g, shade(body, 1.22), x0 + 1, 3, W - 2, 1);
    R(g, shade(top, 0.88), x0 + 4, 10, 8, 6);
    if (kind === 3) R(g, shade(top, 0.88), x0 + 4, len - 22, 8, 8);
    if (north) R(g, glass, x0 + 1, 3, W - 2, 3);
    else {
      R(g, glass, x0 + 1, len - 6, W - 2, 4);
      R(g, gl2, x0 + 2, len - 6, 4, 1);
    }
    if (kind === 3) R(g, '#2a5fb8', x0, len, W, 1);
  } else if (!north) {
    R(g, glass, x0 + 1, 5, W - 2, 3);
    R(g, roof, x0 + 1, 8, W - 2, len - 22);
    R(g, glass, x0 + 1, len - 14, W - 2, 5);
    R(g, gl2, x0 + 2, len - 14, 4, 1);
  } else {
    R(g, glass, x0 + 1, 6, W - 2, 4);
    R(g, gl2, x0 + 2, 6, 4, 1);
    R(g, roof, x0 + 1, 10, W - 2, len - 22);
    R(g, glass, x0 + 1, len - 12, W - 2, 4);
  }
  if (north) {
    R(g, '#e03a3a', x0, len - 1, 3, 2);
    R(g, '#e03a3a', x0 + W - 3, len - 1, 3, 2);
    R(g, '#eeeeee', x0 + 6, len, 4, 1);
  } else {
    R(g, '#fff3b0', x0, len - 1, 3, 2);
    R(g, '#fff3b0', x0 + W - 3, len - 1, 3, 2);
    R(g, '#17181d', x0 + 4, len - 1, W - 8, 2);
  }
  R(g, '#17181d', x0 - 1, 6, 1, 6);
  R(g, '#17181d', x0 + W, 6, 1, 6);
  R(g, '#17181d', x0 - 1, len - 10, 1, 6);
  R(g, '#17181d', x0 + W, len - 10, 1, 6);
  const mid = (len >> 1) + 1;
  if (kind === 1) {
    R(g, '#ffffff', x0 + 5, mid - 2, 6, 3);
    R(g, '#222222', x0 + 6, mid - 1, 4, 1);
  }
  if (kind === 2) {
    R(g, '#e03a3a', x0 + 2, mid - 1, 6, 2);
    R(g, '#3a6ae0', x0 + 8, mid - 1, 6, 2);
    R(g, '#2a4fb0', x0, len, W, 1);
  }
  outline(c);
  return c;
}

function flipH(src: HTMLCanvasElement): HTMLCanvasElement {
  const { c, g } = mkCanvas(src.width, src.height);
  g.translate(src.width, 0);
  g.scale(-1, 1);
  g.drawImage(src, 0, 0);
  return c;
}

export function buildCars(): CarType[] {
  const defs: [number, string, number][] = [
    [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32],
    [0, '#c0392b', 32], [0, '#2b5fb0', 32], [0, '#e9e9ee', 32], [0, '#2a2a33', 32], [0, '#7a8a9a', 32], [0, '#3f8a5a', 32], [0, '#8a8f99', 32],
    [2, '#f0f0f4', 32],
    [3, '#e8eaf0', 54],
    [4, '#f0f0f0', 36], [4, '#6b4a2e', 36],
  ];
  return defs.map(([kind, body, len]) => {
    const e = carH(len, body, kind);
    return { len, kind, c: [carV(len, body, kind, true), e, carV(len, body, kind, false), flipH(e)] };
  });
}

// ============================================================ TREES
function tree(r: Rng, rad: number, pal: string[], trunkH: number): Spr {
  const W = rad * 2 + 6;
  const H = rad * 2 + trunkH + 3;
  const { c, g } = mkCanvas(W, H);
  const cx = W / 2;
  const cy = rad + 1;
  const ty = Math.round(cy + rad * 0.5);
  R(g, '#6b4a2e', cx - 2, ty, 4, H - 1 - ty);
  R(g, '#4f351f', cx + 1, ty, 1, H - 1 - ty);
  R(g, '#6b4a2e', cx - 3, H - 2, 6, 1);
  const blobs = [
    [0, -rad * 0.32, rad * 0.72],
    [-rad * 0.48, rad * 0.08, rad * 0.58],
    [rad * 0.48, rad * 0.08, rad * 0.58],
    [0, rad * 0.3, rad * 0.62],
  ];
  for (let y = 0; y < rad * 2 + 2; y++)
    for (let x = 0; x < W; x++) {
      const dx = x + 0.5 - cx;
      const dy = y + 0.5 - cy;
      let inside = false;
      for (const b of blobs) {
        const ex = dx - b[0];
        const ey = dy - b[1];
        if (ex * ex + ey * ey <= b[2] * b[2]) {
          inside = true;
          break;
        }
      }
      if (!inside) continue;
      const tt = (dx * 0.55 + dy) / rad + (r() - 0.5) * 0.4;
      g.fillStyle = tt < -0.5 ? pal[3] : tt < 0.0 ? pal[2] : tt < 0.5 ? pal[1] : pal[0];
      g.fillRect(x, y, 1, 1);
    }
  outline(c, shade(pal[0], 0.55));
  return { c };
}

function pine(): Spr {
  const { c, g } = mkCanvas(24, 40);
  R(g, '#5a3d24', 10, 32, 4, 7);
  for (let t = 0; t < 4; t++) {
    const top = 1 + t * 7;
    for (let i = 0; i < 12; i++) {
      const hw = Math.round(2 + (i * (5 + t * 1.6)) / 11);
      R(g, i > 8 ? '#1f5a3a' : i < 3 ? '#3f9a5a' : '#2c7a48', 12 - hw, top + i, hw * 2, 1);
    }
  }
  outline(c, '#123322');
  return { c };
}

// ============================================================ PROPS
function mk(w: number, h: number, f: (g: G) => void, extra: Partial<Spr> = {}, ol = true): Spr {
  const { c, g } = mkCanvas(w + 2, h + 2);
  g.translate(1, 1);
  f(g);
  g.setTransform(1, 0, 0, 1, 0, 0);
  if (ol) outline(c);
  return { c, ...extra };
}

function umbrella(g: G, cx: number, y: number, rx: number, a: string, b: string) {
  for (let dy = 0; dy < rx * 0.62; dy++) {
    const hw = Math.round(rx * Math.sqrt(1 - Math.pow(1 - (dy + 1) / (rx * 0.62), 2)));
    for (let x = -hw; x <= hw; x++) {
      const seg = Math.floor(((x + rx) / (rx * 2 + 1)) * 6);
      R(g, seg % 2 ? a : b, cx + x, y + dy, 1, 1);
    }
  }
}

function cart(a: string, b: string, label: string, sign: string): Spr {
  return mk(28, 34, (g) => {
    R(g, '#8a8d96', 13, 8, 1, 12);
    umbrella(g, 13, 0, 13, a, b);
    R(g, '#c9ccd2', 3, 18, 22, 11);
    R(g, '#e8eaee', 3, 18, 22, 2);
    R(g, sign, 3, 21, 22, 6);
    drawText(g, label, 3 + ((22 - textW(label)) >> 1), 22, '#ffffff');
    R(g, '#9a9da6', 3, 28, 22, 1);
    ell(g, '#22232a', 7, 30, 2, 2);
    ell(g, '#22232a', 20, 30, 2, 2);
    R(g, '#d94a3a', 5, 16, 2, 2);
    R(g, '#e8c14a', 9, 16, 2, 2);
    R(g, '#f2f2f2', 20, 15, 2, 3);
  });
}

function flag(cols: string[], us = false): Spr {
  return mk(13, 34, (g) => {
    R(g, '#b9bcc4', 1, 1, 1, 33);
    R(g, '#e8c14a', 0, 0, 3, 2);
    if (us) {
      for (let i = 0; i < 7; i++) R(g, i % 2 ? '#f2f2f2' : '#c0392b', 2, 2 + i, 10, 1);
      R(g, '#2b3f8a', 2, 2, 4, 4);
      R(g, '#ffffff', 3, 3, 1, 1);
      R(g, '#ffffff', 5, 4, 1, 1);
    } else {
      const n = cols.length;
      cols.forEach((cc, i) => R(g, cc, 2, 2 + Math.round((i * 7) / n), 10, Math.ceil(7 / n)));
    }
  });
}

export function buildProps() {
  const r = mulberry32(4242);
  const GREEN = ['#2a6234', '#3a8340', '#58a84c', '#84c868'];
  const GREEN2 = ['#24583a', '#2f7a4a', '#46a060', '#72c486'];
  const GREEN3 = ['#3a6a2a', '#55903a', '#78b44a', '#a4d468'];
  const ORANGE = ['#8a3b1d', '#c25a1f', '#e58a2a', '#f5b84a'];
  const RED = ['#7a2420', '#a8342a', '#d0503a', '#e8845a'];
  const YELLOW = ['#9a7a1a', '#c9a224', '#e8c83a', '#f8e878'];
  const PINK = ['#a8507a', '#d977a0', '#f2a6c4', '#ffd8e6'];

  const lamp = mk(12, 36, (g) => {
    R(g, '#2d3838', 4, 6, 2, 27);
    R(g, '#2d3838', 3, 31, 4, 4);
    R(g, '#3d4a4a', 4, 12, 2, 1);
    R(g, '#2d3838', 4, 3, 2, 3);
    R(g, '#2d3838', 5, 1, 5, 2);
    R(g, '#2d3838', 8, 3, 3, 2);
    R(g, '#fff0b0', 8, 5, 3, 2);
  }, { lamps: [10, 7, 44] });

  const tlight = mk(10, 36, (g) => {
    R(g, '#3a3d42', 4, 12, 2, 23);
    R(g, '#3a3d42', 3, 33, 4, 2);
    R(g, '#e8c530', 2, 0, 6, 13);
    R(g, '#1c1d22', 3, 1, 4, 11);
    R(g, '#4a1c1c', 4, 2, 2, 2);
    R(g, '#4a401c', 4, 5, 2, 2);
    R(g, '#1c4026', 4, 8, 2, 2);
  });

  const hydrant = mk(8, 11, (g) =>
    pix(g, 0, 0, ['..rrrr..', '.rllrrr.', '..rrrr..', '..rlrr..', 'rrrlrrrr', 'rrrrrrdd', '..rlrr..', '..rlrd..', '..rrrd..', '.rrrrrr.', '.dddddd.'], { r: '#d8382e', l: '#f07a6a', d: '#9a241e' }),
  );

  const trash = mk(9, 12, (g) => {
    R(g, '#2f5a3a', 1, 2, 7, 10);
    R(g, '#3f7a4e', 0, 1, 9, 2);
    for (let x = 2; x < 8; x += 2) R(g, '#234a2e', x, 4, 1, 7);
    R(g, '#234a2e', 1, 7, 7, 1);
  });

  const mailbox = mk(10, 14, (g) => {
    R(g, '#2a4f9a', 1, 2, 8, 9);
    R(g, '#2a4f9a', 2, 0, 6, 2);
    R(g, '#4a72c4', 2, 1, 5, 1);
    R(g, '#1a336a', 2, 4, 6, 1);
    R(g, '#f2f2f2', 3, 6, 4, 2);
    R(g, '#1a336a', 1, 11, 2, 3);
    R(g, '#1a336a', 7, 11, 2, 3);
  });

  const news = ['#d8382e', '#e8c14a', '#2b7fd0'].map((cc) =>
    mk(8, 11, (g) => {
      R(g, cc, 0, 0, 8, 9);
      R(g, shade(cc, 1.3), 0, 0, 8, 1);
      R(g, '#1c2636', 1, 2, 6, 3);
      R(g, '#f2f2f2', 2, 3, 3, 1);
      R(g, shade(cc, 0.6), 1, 9, 2, 2);
      R(g, shade(cc, 0.6), 5, 9, 2, 2);
    }),
  );

  const bench = mk(24, 13, (g) => {
    R(g, '#8a5c34', 1, 1, 22, 2);
    R(g, '#8a5c34', 1, 4, 22, 2);
    R(g, '#a87442', 1, 7, 22, 3);
    R(g, '#c08a55', 1, 7, 22, 1);
    R(g, '#26262c', 2, 1, 1, 12);
    R(g, '#26262c', 21, 1, 1, 12);
    R(g, '#26262c', 11, 6, 1, 4);
  });

  const carts = [
    cart('#d8382e', '#f5d020', 'DOGS', '#c0392b'),
    cart('#2b7fd0', '#f5d020', 'HALAL', '#2f8a4a'),
    cart('#f2f2f2', '#d8382e', 'NUTS', '#8a4a2a'),
    cart('#3fa0d0', '#f2f2f2', 'ICE', '#2b7fd0'),
  ];

  const subway = mk(32, 26, (g) => {
    R(g, '#2f6b45', 0, 8, 32, 2);
    R(g, '#2f6b45', 0, 8, 3, 17);
    R(g, '#2f6b45', 29, 8, 3, 17);
    R(g, '#3f8a5a', 0, 8, 32, 1);
    for (let i = 0; i < 5; i++) {
      R(g, shade('#55565e', 1 - i * 0.16), 3, 10 + i * 3, 26, 3);
      R(g, shade('#77787f', 1 - i * 0.16), 3, 10 + i * 3, 26, 1);
    }
    R(g, '#15151a', 5, 0, 22, 7);
    ell(g, '#e23a2e', 9, 3, 2, 2);
    ell(g, '#2f9a4a', 15, 3, 2, 2);
    ell(g, '#f5c518', 21, 3, 2, 2);
    R(g, '#ffffff', 9, 3, 1, 1);
    R(g, '#ffffff', 15, 3, 1, 1);
    R(g, '#222222', 21, 3, 1, 1);
    R(g, '#2f6b45', 1, 3, 1, 5);
    R(g, '#2f6b45', 30, 3, 1, 5);
    ell(g, '#39d37a', 1, 2, 1, 1);
    ell(g, '#39d37a', 30, 2, 1, 1);
  }, { lamps: [2, 3, 22, 31, 3, 22], glows: [5, 1, 24, 8] });

  const steam = mk(8, 18, (g) => {
    for (let i = 0; i < 6; i++) R(g, i % 2 ? '#f4f4f4' : '#f28a1e', 2, i * 3, 4, 3);
    R(g, '#f28a1e', 1, 15, 6, 3);
  });

  const cone = mk(6, 8, (g) => pix(g, 0, 0, ['..oo..', '..oo..', '.wwww.', '.oooo.', '.wwww.', 'oooooo', 'oooooo', 'dddddd'], { o: '#f07a1e', w: '#f4f4f4', d: '#a8501a' }));

  const flagUS = flag([], true);
  const flags = [
    flag(['#d8382e', '#f2f2f2', '#2b5fb0']), flag(['#2f9a4a', '#f2f2f2', '#d8382e']), flag(['#f5d020', '#2b5fb0']), flag(['#111111', '#d8382e', '#f5d020']),
    flag(['#f2f2f2', '#d8382e']), flag(['#2b5fb0', '#f5d020', '#d8382e']), flag(['#2f9a4a', '#f5d020']), flag(['#f08a24', '#f2f2f2', '#2f9a4a']),
    flag(['#d8382e', '#f5d020', '#2f9a4a']), flag(['#5ab0e8', '#f2f2f2', '#5ab0e8']), flag(['#d8382e', '#f2f2f2']), flag(['#3a6ae0', '#f2f2f2', '#d8382e']),
  ];

  const planter = mk(16, 12, (g) => {
    R(g, '#8f887b', 0, 6, 16, 6);
    R(g, '#a9a294', 0, 6, 16, 1);
    ell(g, '#3a8340', 8, 4, 7, 3);
    R(g, '#58a84c', 3, 2, 4, 2);
    R(g, '#ff6b8a', 4, 3, 1, 1);
    R(g, '#ffd84a', 9, 2, 1, 1);
    R(g, '#ffffff', 12, 4, 1, 1);
    R(g, '#ff6b8a', 11, 2, 1, 1);
  });

  const tables = ['#d8382e', '#2f8a4a', '#2b7fd0', '#f5d020'].map((cc) =>
    mk(22, 26, (g) => {
      R(g, '#8a8d96', 10, 6, 1, 14);
      umbrella(g, 10, 0, 10, cc, shade(cc, 1.35));
      R(g, '#e8e2d4', 5, 16, 12, 3);
      R(g, '#b9b2a4', 5, 19, 12, 1);
      R(g, '#6a6258', 10, 20, 2, 5);
      R(g, '#3a3a44', 1, 15, 3, 2);
      R(g, '#3a3a44', 1, 17, 1, 7);
      R(g, '#3a3a44', 3, 17, 1, 7);
      R(g, '#3a3a44', 18, 15, 3, 2);
      R(g, '#3a3a44', 18, 17, 1, 7);
      R(g, '#3a3a44', 20, 17, 1, 7);
    }),
  );

  const statue = (col: string) =>
    mk(16, 32, (g) => {
      R(g, '#a9a294', 3, 20, 10, 12);
      R(g, '#c2bbad', 2, 19, 12, 2);
      R(g, '#8f887b', 2, 30, 12, 2);
      R(g, '#7a7468', 5, 24, 6, 3);
      const l = shade(col, 1.3);
      const d = shade(col, 0.7);
      R(g, col, 6, 3, 4, 4);
      R(g, l, 6, 3, 2, 2);
      R(g, col, 5, 7, 6, 8);
      R(g, d, 9, 8, 2, 7);
      R(g, col, 5, 15, 2, 4);
      R(g, col, 9, 15, 2, 4);
      R(g, col, 11, 4, 2, 5);
      R(g, col, 3, 8, 2, 5);
      R(g, l, 12, 2, 1, 3);
    });
  const statueB = statue('#5a9a86');
  const statueG = statue('#e3b53a');

  const rock = mk(22, 14, (g) => {
    ell(g, '#7f8288', 11, 8, 10, 5);
    ell(g, '#9a9da4', 9, 6, 6, 3);
    R(g, '#b5b8be', 6, 4, 4, 1);
    R(g, '#63666c', 12, 10, 7, 2);
  });

  const link = mk(8, 22, (g) => {
    R(g, '#3a3d46', 1, 0, 6, 22);
    R(g, '#5a5d66', 1, 0, 1, 22);
    R(g, '#2fa0e8', 2, 2, 4, 9);
    R(g, '#8fd0f8', 2, 2, 4, 2);
    R(g, '#f2f2f2', 3, 6, 2, 1);
    R(g, '#22242a', 2, 13, 4, 4);
  }, { glows: [3, 3, 4, 9] });

  const bush = mk(14, 10, (g) => {
    ell(g, '#2f7a3a', 7, 6, 6, 3);
    ell(g, '#46a050', 5, 4, 4, 3);
    ell(g, '#46a050', 9, 4, 3, 2);
    R(g, '#72c486', 4, 3, 2, 1);
  });

  const trees = [
    tree(r, 15, GREEN, 12), tree(r, 14, GREEN2, 12), tree(r, 16, GREEN3, 13), tree(r, 13, GREEN, 11),
    tree(r, 15, GREEN2, 12), tree(r, 14, GREEN3, 11),
  ];
  const autumn = [tree(r, 15, ORANGE, 12), tree(r, 14, RED, 12), tree(r, 15, YELLOW, 12), tree(r, 13, ORANGE, 11)];
  const cherry = [tree(r, 13, PINK, 11), tree(r, 12, PINK, 10)];
  const street = [tree(r, 9, GREEN, 13), tree(r, 9, GREEN3, 13), tree(r, 8, GREEN2, 12), tree(r, 9, YELLOW, 13), tree(r, 8, PINK, 12)];
  const pineT = pine();

  // dogs: 4 colours x [A,B] x [left,right], cell 14x10
  const dogs = mkCanvas(14 * 4, 10 * 4);
  const DA = ['.e..........', 'ebb......t..', 'bbbbbbbbbb..', 'nbbbbbbbbb..', '.bbbbbbbbb..', '..b.b..b.b..', '..b.b..b.b..'];
  const DB = ['.e..........', 'ebb.......t.', 'bbbbbbbbbb..', 'nbbbbbbbbb..', '.bbbbbbbbb..', '.b..b..b..b.', 'b...b..b...b'];
  ['#b5651d', '#f0ece0', '#2a2a2e', '#d9a441'].forEach((col, i) => {
    const pal = { b: col, e: shade(col, 0.7), n: '#1a1a1a', t: col };
    const t = mkCanvas(28, 10);
    pix(t.g, 1, 2, DA, pal);
    pix(t.g, 15, 2, DB, pal);
    dogs.g.drawImage(t.c, 0, i * 10);
    dogs.g.save();
    dogs.g.translate(42, i * 10);
    dogs.g.scale(-1, 1);
    dogs.g.drawImage(t.c, 0, 0, 14, 10, 0, 0, 14, 10);
    dogs.g.restore();
    dogs.g.save();
    dogs.g.translate(56, i * 10);
    dogs.g.scale(-1, 1);
    dogs.g.drawImage(t.c, 14, 0, 14, 10, 0, 0, 14, 10);
    dogs.g.restore();
  });
  outline(dogs.c);

  // pigeons: 4 frames, cell 8x7
  const pig = mkCanvas(32, 7);
  const pp = { g: '#8d93a3', h: '#5e6578', o: '#e8843a', w: '#c9cedb' };
  pix(pig.g, 1, 1, ['.h....', 'hhggg.', '.ggggg', '.gggg.', '..o.o.'], pp);
  pix(pig.g, 9, 1, ['......', '..ggg.', 'hhgggg', 'hgggg.', '..o.o.'], pp);
  pix(pig.g, 17, 1, ['w....w', '.wggw.', '..gg..'], pp);
  pix(pig.g, 25, 1, ['......', '..gg..', 'wwggww'], pp);

  // light glow
  const glow = mkCanvas(64, 64);
  const gr = glow.g.createRadialGradient(32, 32, 1, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,214,140,0.6)');
  gr.addColorStop(0.4, 'rgba(255,190,110,0.22)');
  gr.addColorStop(1, 'rgba(255,190,100,0)');
  glow.g.fillStyle = gr;
  glow.g.fillRect(0, 0, 64, 64);

  return {
    lamp, tlight, hydrant, trash, mailbox, news, bench, carts, subway, steam, cone, flagUS, flags, planter, tables,
    statueB, statueG, rock, link, bush, trees, autumn, cherry, street, pine: pineT, dogs: dogs.c, pigeons: pig.c, glow: glow.c,
  };
}

export type Props = ReturnType<typeof buildProps>;

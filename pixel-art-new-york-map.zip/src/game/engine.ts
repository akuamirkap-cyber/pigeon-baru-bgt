import { G, MH, MW, T, drawText, mixc, mkCanvas, textW } from './util';
import { ATLAS_COLS, COBBLE, CROSS_V, GRASS, ICE, PATH, PLAZA, REDPAVE, SIDEWALK, WOOD, buildAtlas, isRoad, isWater } from './tiles';
import { CarType, PeopleAtlas, Props, SP_COOKIE, SP_COP, SP_ELMO, SP_JOG, SP_LIBERTY, SP_MUSIC, SP_PLAYER, SP_RANDOM, SP_VENDOR, SP_WORKER, buildCars, buildPeople, buildProps } from './sprites';
import { BUCKET, BoatDef, Landmark, Obj, Station, World, generateWorld } from './world';
import { drawBoard } from './buildings';
import { INpc, Interior, Looks, TRAIN_DOORS, TRAIN_X, makeInterior, makeSubway, updateInterior } from './interior';

interface Npc {
  k: 1;
  sy: number;
  x: number;
  y: number;
  cx: number;
  cy: number;
  gx: number;
  gy: number;
  ox: number;
  oy: number;
  dir: number;
  sp: number;
  look: number;
  st: number; // 0 walk, 1 wait at curb, 2 stand
  t: number;
  an: number;
  kind: number; // 0 walker 1 vendor 2 performer 3 cop 4 mascot 5 stander 6 jogger 7 dog 8 skater
  own: Npc | null;
  say: string;
  sayT: number;
  dog: number;
}
interface Car {
  k: 2;
  sy: number;
  x: number;
  y: number;
  dir: number; // 0 N 1 E 2 S 3 W
  sp: number;
  max: number;
  type: CarType;
  stuck: number;
  cool: number;
  honk: number;
}
interface Pl {
  k: 3;
  sy: number;
  x: number;
  y: number;
  dir: number;
  an: number;
  moving: boolean;
}
interface Pigeon {
  x: number;
  y: number;
  hx: number;
  hy: number;
  st: number;
  t: number;
  vx: number;
  z: number;
  ph: number;
}
type Dr = Obj | Npc | Car | Pl;

export interface Hud {
  district(n: string): void;
  landmark(l: Landmark, found: number, total: number, fresh: boolean): void;
  clock(label: string, time: string): void;
  prompt(p: string | null): void;
  subway(): void;
}

const DX = [0, -1, 1, 0];
const DY = [1, 0, 0, -1];
const CDX = [0, 1, 0, -1];
const CDY = [-1, 0, 1, 0];
const WALK = [1, 0, 2, 0];
const LCOL = ['#ffd978', '#fff3c4', '#a8dcff', '#ffe6a8'];
const DAYLEN = 420;

const SAY = [
  "HEY, I'M WALKIN' HERE!", 'NICE DAY, HUH?', 'LATE FOR WORK!', 'TAXI!!', "WHERE'S THE SUBWAY?", 'NEED... COFFEE...', 'FUHGEDDABOUDIT', 'BEST PIZZA IN TOWN!',
  "HOW YOU DOIN'?", 'I { NY', 'EXCUSE ME!', 'RENT IS TOO HIGH', 'GO YANKEES!', "LET'S GO METS!", 'IS THAT A CELEBRITY?', 'ONLY IN NEW YORK...', 'BAGEL TIME',
  'YO!', 'THE L TRAIN IS DELAYED. AGAIN.', 'WATCH IT, BUDDY', 'WHAT A VIEW!', 'HOLD THE DOOR!', 'ONE SLICE, PLEASE', 'BIG APPLE, BABY!', "I'M ON THE PHONE!",
  'WAH KEREN BANGET!', 'FOTO DULU YUK!', 'GEDUNGNYA TINGGI BANGET', 'CAPEK TAPI SERU!', 'MAHAL BANGET DI SINI', 'KANGEN NASI GORENG...', 'MANTAP JIWA!', 'INI KAYAK DI FILM!',
];
const TALK = [
  'WELCOME TO NEW YORK!', 'CENTRAL PARK IS UP NORTH', 'TIMES SQUARE NEVER SLEEPS', 'TAKE THE SUBWAY, IT IS FASTER', 'FERRY TO LADY LIBERTY? BATTERY PARK!',
  'WALK THE BROOKLYN BRIDGE AT SUNSET', 'TRY A DOLLAR SLICE!', 'EMPIRE STATE? LOOK UP!', 'PRESS N TO SEE THE CITY AT NIGHT', 'DUMBO HAS THE BEST VIEW',
  'SELAMAT DATANG DI NEW YORK!', 'JALAN-JALAN SANTAI AJA, BRO', 'JANGAN LUPA MAMPIR CHINATOWN', 'HATI-HATI NYEBRANG YA!', 'KATANYA SHAKE SHACK ANTRE PANJANG',
];
const SAYK: Record<number, string[]> = {
  1: ['HOT DOGS! HOT DOGS!', 'PRETZELS! 3 BUCKS!', 'CHICKEN OVER RICE!', 'COLD WATER! ONE DOLLAR!', 'GET IT WHILE IT IS HOT!'],
  2: ['} } }', '} LA LA LA }', '} NEW YORK, NEW YORK }'],
  3: ['MOVE ALONG, FOLKS', 'STAY SAFE OUT THERE', 'CROSS AT THE LIGHT!'],
  4: ['PHOTO? FIVE BUCKS!', 'HUG TIME!', 'TIPS APPRECIATED!'],
  6: ['ON YOUR LEFT!', 'HUFF... HUFF...', '5 MORE MILES!'],
  8: ['WHEEE!', 'WHOA WHOA WHOA!', 'LOOK, NO HANDS!'],
};

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Game {
  cv: HTMLCanvasElement;
  g: G;
  lc: HTMLCanvasElement;
  lg: G;
  hud: Hud;
  world: World;
  atlas: HTMLCanvasElement[];
  people: PeopleAtlas;
  carTypes: CarType[];
  props: Props;

  vw = 320;
  vh = 200;
  scale = 3;
  camX = 0;
  camY = 0;
  time = 0;
  clock = 0.4;
  nf = 0;
  tint = '#ffffff';
  frame = 0;
  active = false;

  player: Pl;
  npcs: Npc[] = [];
  cars: Car[] = [];
  pigeons: Pigeon[] = [];
  boats: BoatDef[] = [];
  ped: Uint8Array;
  list: Dr[] = [];
  vis: Npc[] = [];
  glowList: number[] = [];
  cache: Obj[] = [];

  keys = new Set<string>();
  joy = { x: 0, y: 0 };
  run = false;
  found = new Set<number>();
  fade = 0;
  fadeDir = 0;
  scene: Interior | null = null;
  ret = { x: 0, y: 0 };
  looks: Looks;
  private pendingFn: (() => void) | null = null;
  private curDoor = -1;
  private curBoard = false;
  private boardCool = 0;

  private raf = 0;
  private last = 0;
  private hudT = 0;
  private chatT = 2;
  private lastDistrict = '';
  private lastPrompt: string | null = null;
  private lastClock = '';
  private curTrigger = -1;
  private curStation = -1;

  constructor(cv: HTMLCanvasElement, hud: Hud) {
    this.cv = cv;
    this.hud = hud;
    this.g = cv.getContext('2d')!;
    const l = mkCanvas(8, 8);
    this.lc = l.c;
    this.lg = l.g;
    this.atlas = buildAtlas();
    this.people = buildPeople(777);
    this.carTypes = buildCars();
    this.props = buildProps();
    this.world = generateWorld(this.props, this.carTypes);
    this.ped = new Uint8Array(MW * MH);
    this.looks = { rand: () => this.randLook(), staff: SP_VENDOR, cop: SP_COP, music: SP_MUSIC };
    this.player = { k: 3, sy: 0, x: this.world.start.x, y: this.world.start.y, dir: 0, an: 0, moving: false };
    this.boats = this.world.boats.map((b) => ({ ...b }));
    this.initNpcs();
    this.initCars();
    try {
      const s = typeof localStorage !== 'undefined' ? localStorage.getItem('nyc-pixel-found') : null;
      if (s) for (const i of JSON.parse(s) as number[]) if (i < this.world.landmarks.length) this.found.add(i);
    } catch {
      /* ignore */
    }
    this.updateSky();
  }

  // ================================================================ setup
  private mkNpc(x: number, y: number, look: number, kind: number, st: number, dir = 0): Npc {
    const cx = clamp(Math.floor(x / T), 0, MW - 1);
    const cy = clamp(Math.floor(y / T), 0, MH - 1);
    return { k: 1, sy: y, x, y, cx, cy, gx: x, gy: y, ox: x - cx * T - 8, oy: y - cy * T - 8, dir, sp: 22 + Math.random() * 16, look, st, t: st === 2 ? -1 : 0, an: Math.random() * 40, kind, own: null, say: '', sayT: 0, dog: 0 };
  }

  private randLook() {
    return SP_RANDOM + Math.floor(Math.random() * (this.people.n - SP_RANDOM));
  }

  private initNpcs() {
    const w = this.world;
    const R = Math.random;
    let made = 0;
    let tries = 0;
    while (made < 1500 && tries < 400000) {
      tries++;
      const tx = (R() * MW) | 0;
      const ty = (R() * MH) | 0;
      const i = ty * MW + tx;
      if (!w.npcOk[i]) continue;
      const t = w.tiles[i];
      if (isRoad(t) || t === ICE) continue;
      let wt = t === SIDEWALK ? 1 : t === PLAZA ? 1.6 : t === REDPAVE ? 4 : t === PATH ? 1.2 : t === WOOD ? 1 : t === COBBLE ? 0.7 : t === GRASS ? 0.05 : 0.3;
      if (ty >= 72 && ty < 126 && tx >= 18 && tx < 126) wt *= 1.5;
      if (R() * 4 > wt) continue;
      const n = this.mkNpc(tx * T + 8 + (R() * 10 - 5), ty * T + 8 + (R() * 10 - 5), this.randLook(), 0, 0, (R() * 4) | 0);
      if (t === PATH && tx >= 46 && tx < 98 && ty >= 30 && ty < 70 && R() < 0.3) {
        n.look = SP_JOG + ((R() * 4) | 0);
        n.sp = 56 + R() * 14;
        n.kind = 6;
      } else if (R() < 0.015) n.look = SP_WORKER;
      this.npcs.push(n);
      made++;
      if (n.kind === 0 && R() < 0.07) {
        const d = this.mkNpc(n.x + 8, n.y, 0, 7, 0, 1);
        d.own = n;
        d.dog = (R() * 4) | 0;
        d.ox = R() < 0.5 ? -9 : 9;
        d.oy = R() * 4 - 1;
        this.npcs.push(d);
      }
    }
    const ok = (x: number, y: number) => x >= 0 && y >= 0 && x < MW * T && y < MH * T && w.npcOk[Math.floor(y / T) * MW + Math.floor(x / T)] === 1;
    for (const s of w.spots) {
      switch (s.kind) {
        case 'vendor':
          this.npcs.push(this.mkNpc(s.x, s.y, SP_VENDOR, 1, 2, 0));
          break;
        case 'cop':
          this.npcs.push(this.mkNpc(s.x, s.y, SP_COP, 3, 2, (R() * 4) | 0));
          break;
        case 'mascot':
          this.npcs.push(this.mkNpc(s.x, s.y, [SP_ELMO, SP_LIBERTY, SP_COOKIE][s.v ?? 0], 4, 2, 0));
          break;
        case 'perf': {
          this.npcs.push(this.mkNpc(s.x, s.y, SP_MUSIC, 2, 2, 0));
          for (let i = 0; i < 6; i++) {
            const px = s.x + (i - 2.5) * 11;
            const py = s.y + 22 - Math.abs(i - 2.5) * 3 + R() * 3;
            if (ok(px, py)) this.npcs.push(this.mkNpc(px, py, this.randLook(), 5, 2, 3));
          }
          break;
        }
        case 'crowd': {
          const rad = s.w ?? 40;
          for (let i = 0; i < (s.n ?? 6); i++)
            for (let k = 0; k < 20; k++) {
              const a = R() * 6.283;
              const d = Math.sqrt(R()) * rad;
              const px = s.x + Math.cos(a) * d;
              const py = s.y + Math.sin(a) * d * 0.7;
              if (!ok(px, py)) continue;
              this.npcs.push(this.mkNpc(px, py, this.randLook(), 5, 2, (R() * 4) | 0));
              break;
            }
          break;
        }
        case 'queue':
          for (let i = 0; i < (s.n ?? 5); i++) this.npcs.push(this.mkNpc(s.x - i * 10, s.y + (i % 2), this.randLook(), 5, 2, i === 0 ? 3 : 2));
          break;
        case 'pigeons':
          for (let i = 0; i < (s.n ?? 5); i++) {
            const px = s.x + R() * 44 - 22;
            const py = s.y + R() * 28 - 14;
            this.pigeons.push({ x: px, y: py, hx: px, hy: py, st: 0, t: 0, vx: 0, z: 0, ph: R() * 10 });
          }
          break;
        case 'skate':
          for (let i = 0; i < (s.n ?? 5); i++) {
            const n = this.mkNpc((s.x + R() * (s.w ?? 2)) * T, (s.y + R() * (s.h ?? 2)) * T, this.randLook(), 8, 0, (R() * 4) | 0);
            n.ox = 0;
            n.oy = 0;
            n.x = n.gx = n.cx * T + 8;
            n.y = n.gy = n.cy * T + 8;
            n.sp = 40 + R() * 20;
            this.npcs.push(n);
          }
          break;
      }
    }
  }

  private initCars() {
    const L = this.world.lanes;
    const n = L.length / 3;
    const idx: number[] = [];
    for (let i = 0; i < n; i++) idx.push(i);
    for (let i = n - 1; i > 0; i--) {
      const j = (Math.random() * (i + 1)) | 0;
      const t = idx[i];
      idx[i] = idx[j];
      idx[j] = t;
    }
    const count = Math.min(210, n);
    for (let i = 0; i < count; i++) {
      const k = idx[i] * 3;
      const type = this.carTypes[(Math.random() * this.carTypes.length) | 0];
      this.cars.push({ k: 2, sy: 0, x: L[k], y: L[k + 1], dir: L[k + 2], sp: 0, max: (type.kind === 3 ? 44 : 56) + Math.random() * 22, type, stuck: 0, cool: 0, honk: 0 });
    }
  }

  // ================================================================ lifecycle
  start() {
    const kd = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(k);
      if (!this.active) return;
      if (k === 'e' || k === ' ') this.action();
      if (k === 'n') this.skipTime();
    };
    const ku = (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase());
    const blur = () => this.keys.clear();
    const rs = () => this.resize();
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('blur', blur);
    window.addEventListener('resize', rs);
    this.resize();
    this.last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - this.last) / 1000);
      this.last = t;
      this.step(dt);
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(this.raf);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('blur', blur);
      window.removeEventListener('resize', rs);
    };
  }

  resize() {
    const W = window.innerWidth;
    const H = window.innerHeight;
    const s = Math.max(2, Math.floor(Math.min(W / 380, H / 230)));
    this.setView(Math.ceil(W / s), Math.ceil(H / s), s);
  }

  setView(vw: number, vh: number, scale: number) {
    this.scale = scale;
    this.vw = vw;
    this.vh = vh;
    this.cv.width = vw;
    this.cv.height = vh;
    if (this.cv.style) {
      this.cv.style.width = vw * scale + 'px';
      this.cv.style.height = vh * scale + 'px';
    }
    this.lc.width = vw;
    this.lc.height = vh;
    this.g.imageSmoothingEnabled = false;
    this.lg.imageSmoothingEnabled = false;
  }

  // ================================================================ actions
  action() {
    if (this.fadeDir !== 0) return;
    const p = this.player;
    if (this.scene) {
      this.sceneAction();
      return;
    }
    if (this.curTrigger >= 0) {
      const t = this.world.triggers[this.curTrigger];
      this.teleport(t.tx, t.ty);
      return;
    }
    if (this.curDoor >= 0) {
      this.enterDoor(this.curDoor);
      return;
    }
    if (this.curStation >= 0) {
      this.enterSubway(this.curStation, false);
      return;
    }
    let best: Npc | null = null;
    let bd = 30 * 30;
    for (const n of this.npcs) {
      if (n.kind === 7) continue;
      const d = (n.x - p.x) * (n.x - p.x) + (n.y - p.y) * (n.y - p.y);
      if (d < bd) {
        bd = d;
        best = n;
      }
    }
    if (best) {
      const dx = p.x - best.x;
      const dy = p.y - best.y;
      best.dir = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 1 : 2) : dy < 0 ? 3 : 0;
      const list = SAYK[best.kind] && Math.random() < 0.6 ? SAYK[best.kind] : TALK;
      best.say = list[(Math.random() * list.length) | 0];
      best.sayT = 3.2;
      if (best.st !== 2 || best.t >= 0) {
        best.st = 2;
        best.t = 3;
      }
    }
  }

  private transition(fn: () => void) {
    if (this.fadeDir !== 0) return;
    this.pendingFn = fn;
    this.fadeDir = 1;
  }

  teleport(x: number, y: number) {
    this.transition(() => {
      this.player.x = x;
      this.player.y = y;
      this.player.dir = 0;
    });
  }

  private setScene(sc: Interior) {
    const p = this.player;
    this.scene = sc;
    p.x = sc.spawn.x;
    p.y = sc.spawn.y;
    p.dir = sc.spawn.dir;
    this.curDoor = -1;
    this.curStation = -1;
    this.curTrigger = -1;
    this.curBoard = false;
    this.lastPrompt = null;
    this.hud.prompt(null);
    this.lastDistrict = '#';
    this.hud.district(sc.kind === 'subway' ? 'Subway · ' + sc.title : sc.title);
  }

  enterDoor(i: number) {
    const d = this.world.doors[i];
    if (!d) return;
    this.transition(() => {
      this.ret = { x: d.x, y: d.y + 7 };
      this.setScene(makeInterior(d.kind, d.name, d.seed, this.looks));
    });
  }

  enterSubway(i: number, arrive: boolean) {
    const s: Station | undefined = this.world.stations[i];
    if (!s) return;
    this.transition(() => {
      this.ret = { x: s.x, y: s.y };
      this.setScene(makeSubway(s.name, i, this.looks, arrive));
      if (arrive) {
        this.player.x = TRAIN_X + TRAIN_DOORS[2] + 10;
        this.player.y = 5 * T + 12;
        this.player.dir = 0;
      }
    });
  }

  /** ride the train to another station (must be inside a subway scene) */
  ride(i: number) {
    if (!this.scene || this.scene.station === i) return;
    this.boardCool = 2;
    this.enterSubway(i, true);
  }

  exitScene() {
    this.transition(() => {
      this.scene = null;
      this.player.x = this.ret.x;
      this.player.y = this.ret.y;
      this.player.dir = 0;
      this.lastDistrict = '';
      this.lastPrompt = null;
      this.hud.prompt(null);
      this.hudT = 0;
    });
  }

  mapPos() {
    return this.scene ? this.ret : this.player;
  }

  private sceneAction() {
    const sc = this.scene!;
    const p = this.player;
    if (this.curBoard) {
      this.hud.subway();
      return;
    }
    let best: INpc | null = null;
    let bd = 32 * 32;
    for (const n of sc.npcs) {
      const d = (n.x - p.x) * (n.x - p.x) + (n.y - p.y) * (n.y - p.y);
      if (d < bd) {
        bd = d;
        best = n;
      }
    }
    if (best) {
      const dx = p.x - best.x;
      const dy = p.y - best.y;
      if (best.mode !== 1) best.dir = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 1 : 2) : dy < 0 ? 3 : 0;
      const list = best.role === 1 ? sc.staff : best.role === 2 ? ['} } }', '} LA LA LA }'] : sc.lines;
      best.say = list[(Math.random() * list.length) | 0];
      best.sayT = 3.2;
      if (best.mode === 2) best.t = 3;
    }
  }

  private stepScene(dt: number) {
    const sc = this.scene!;
    const p = this.player;
    updateInterior(sc, dt, this.looks);
    if (this.boardCool > 0) this.boardCool -= dt;
    if (this.fadeDir === 0 && (sc.exitRow >= 0 ? p.y >= sc.exitRow * T + 3 : p.y < 4 * T + 2)) this.exitScene();
    let prompt: string | null = null;
    this.curBoard = false;
    const tr = sc.train;
    if (tr && tr.open >= 1 && p.y < 6 * T + 4)
      for (const d of TRAIN_DOORS)
        if (Math.abs(TRAIN_X + d + 10 - p.x) < 12) {
          this.curBoard = true;
          prompt = 'Naik kereta · pilih tujuan';
        }
    if (prompt !== this.lastPrompt) {
      this.lastPrompt = prompt;
      this.hud.prompt(prompt);
    }
    this.chatT -= dt;
    if (this.chatT <= 0 && sc.npcs.length) {
      this.chatT = 1.2 + Math.random() * 1.6;
      const n = sc.npcs[(Math.random() * sc.npcs.length) | 0];
      if (n.sayT <= 0) {
        const list = n.role === 1 ? sc.staff : n.role === 2 ? ['} } }', '} LA LA LA }'] : sc.lines;
        n.say = list[(Math.random() * list.length) | 0];
        n.sayT = 2.6;
      }
    }
  }

  private renderScene() {
    const sc = this.scene!;
    const g = this.g;
    const vw = this.vw;
    const vh = this.vh;
    const p = this.player;
    const time = this.time;
    const W = sc.w * T;
    const H = sc.bg.height;
    const cx = W <= vw ? -Math.floor((vw - W) / 2) : clamp(Math.round(p.x - vw / 2), 0, W - vw);
    const cy = H <= vh ? -Math.floor((vh - H) / 2) : clamp(Math.round(p.y - 14 - vh / 2), 0, H - vh);
    this.camX = cx;
    this.camY = cy;
    g.fillStyle = '#07080f';
    g.fillRect(0, 0, vw, vh);
    g.drawImage(sc.bg, -cx, -cy);
    const tr = sc.train;
    if (tr && sc.trainSpr) {
      if (tr.t > 23 && tr.t < 31) {
        const rx = Math.round(9 * T + ((tr.t - 23) / 8) * (W - 9 * T)) - cx;
        g.fillStyle = '#7a7a84';
        g.fillRect(rx, 2 * T + 25 - cy, 5, 3);
        g.fillRect(rx - 3, 2 * T + 26 - cy, 3, 1);
        g.fillStyle = '#15151c';
        g.fillRect(rx + 4, 2 * T + 25 - cy, 1, 1);
      }
      if (tr.x < 600) {
        g.save();
        g.beginPath();
        g.rect(9 * T + 8 - cx, -cy, W - 9 * T - 8, 5 * T + 1);
        g.clip();
        const tx = Math.round(TRAIN_X + tr.x) - cx - 1;
        const ty = 2 * T - cy - 1;
        g.drawImage(sc.trainSpr, tx, ty);
        if (tr.open > 0)
          for (const d of TRAIN_DOORS) {
            const ow = Math.round(9 * tr.open);
            const mx = tx + 1 + d + 10;
            g.fillStyle = '#f2e6b8';
            g.fillRect(mx - ow, ty + 11, ow * 2, 34);
            g.fillStyle = '#8a7a5a';
            g.fillRect(mx - ow, ty + 41, ow * 2, 4);
            if (ow > 4) {
              g.fillStyle = '#c9ccd2';
              g.fillRect(mx, ty + 11, 1, 30);
              g.fillStyle = '#d8382e';
              g.fillRect(mx - ow + 1, ty + 30, 3, 6);
              g.fillStyle = '#2b5fb0';
              g.fillRect(mx + ow - 4, ty + 30, 3, 6);
            }
          }
        g.restore();
      }
      const txt = tr.t < 4 ? 'TRAIN ARRIVING' : tr.t < 17 ? 'NOW BOARDING' : tr.t < 22 ? 'DEPARTING' : 'NEXT TRAIN 1 MIN';
      const lx = 20 * T - cx;
      g.fillStyle = '#15151c';
      g.fillRect(lx, 1 - cy, 72, 9);
      drawText(g, txt, lx + 3, 3 - cy, tr.t < 17 ? '#7aff8a' : '#ffb03a');
    }
    const items: { sy: number; o?: Interior['objs'][number]; n?: INpc }[] = [];
    for (const o of sc.objs) items.push({ sy: o.sy, o });
    for (const n of sc.npcs) items.push({ sy: n.mode === 1 ? n.y + 3 : n.y, n });
    items.push({ sy: p.y });
    items.sort((a, b) => a.sy - b.sy);
    const pa = this.people;
    const person = (look: number, dir: number, fr: number, x: number, y: number, sit: boolean) => {
      const sx = (look % pa.per) * 48 + fr * 16;
      const sy = Math.floor(look / pa.per) * 96 + dir * 24;
      if (sit) g.drawImage(pa.c, sx, sy, 16, 16, x, y + 4, 16, 16);
      else {
        g.fillStyle = 'rgba(0,0,0,.22)';
        g.fillRect(x + 3, y + 21, 10, 2);
        g.drawImage(pa.c, sx, sy, 16, 24, x, y, 16, 24);
      }
    };
    for (const it of items) {
      if (it.o) g.drawImage(it.o.c, it.o.x - cx, it.o.y - cy);
      else if (it.n) {
        const n = it.n;
        const x = Math.round(n.x) - 8 - cx;
        let y = Math.round(n.y) - 22 - cy;
        if (n.role === 2) y -= Math.sin(time * 7 + n.x) > 0.3 ? 1 : 0;
        person(n.look, n.dir, n.moving ? WALK[((n.an / 7) | 0) & 3] : 0, x, y, n.mode === 1);
        if (n.role === 2) {
          const t = (time * 0.7 + n.x * 0.01) % 1;
          drawText(g, '}', x + 14 + Math.round(Math.sin(time * 4) * 2), y - Math.round(t * 14), t < 0.5 ? '#ffffff' : '#ffe14a');
        }
      } else person(SP_PLAYER, p.dir, p.moving ? WALK[((p.an / 8) | 0) & 3] : 0, Math.round(p.x) - 8 - cx, Math.round(p.y) - 22 - cy, false);
    }
    for (let i = 0; i < sc.fx.length; i += 2)
      for (let k = 0; k < 3; k++) {
        const t = (time * 0.5 + k / 3) % 1;
        const sz = 1 + Math.floor(t * 4);
        g.fillStyle = `rgba(245,245,250,${(0.6 * (1 - t)).toFixed(2)})`;
        g.fillRect(Math.round(sc.fx[i] - cx + Math.sin((t + k) * 6) * 2), Math.round(sc.fx[i + 1] - cy - t * 16), sz, sz);
      }
    if (sc.tint) {
      g.globalCompositeOperation = 'multiply';
      g.fillStyle = sc.tint;
      g.fillRect(-cx, -cy, W, H);
      g.globalCompositeOperation = 'source-over';
    }
    if (sc.lamps.length) {
      g.globalCompositeOperation = 'lighter';
      g.globalAlpha = sc.tint ? 0.5 : 0.22;
      const gl = this.props.glow;
      for (let i = 0; i < sc.lamps.length; i += 3) {
        const r = sc.lamps[i + 2];
        g.drawImage(gl, sc.lamps[i] - r - cx, sc.lamps[i + 1] - r - cy, r * 2, r * 2);
      }
      g.globalCompositeOperation = 'source-over';
      g.globalAlpha = 1;
    }
    for (const n of sc.npcs) if (n.sayT > 0) this.bubble(n.say, n.x - cx, n.y - cy - (n.mode === 1 ? 20 : 25));
    if (tr && tr.t > 15.5 && tr.t < 18.5) this.bubble('STAND CLEAR OF THE CLOSING DOORS, PLEASE', 20 * T - cx, 3 * T - cy, true);
    if (this.curBoard) {
      const b = Math.floor(time * 3) % 2;
      for (const d of TRAIN_DOORS) {
        const ax = TRAIN_X + d + 10 - cx;
        g.fillStyle = '#ffe14a';
        g.fillRect(ax, 5 * T - 6 - b - cy, 1, 1);
        g.fillRect(ax - 1, 5 * T - 5 - b - cy, 3, 1);
        g.fillRect(ax - 2, 5 * T - 4 - b - cy, 5, 1);
      }
    }
    if (this.fade > 0) {
      g.fillStyle = `rgba(8,10,20,${Math.min(1, this.fade).toFixed(2)})`;
      g.fillRect(0, 0, vw, vh);
    }
  }

  skipTime() {
    const h = this.clock * 24;
    const ts = [8, 13, 18.3, 22];
    const nx = ts.find((t) => t > h + 0.2) ?? ts[0];
    this.clock = nx / 24;
    this.updateSky();
    this.lastClock = '';
  }

  private updateSky() {
    const h = this.clock * 24;
    this.nf = h < 5 ? 1 : h < 7 ? 1 - (h - 5) / 2 : h < 17.5 ? 0 : h < 19.5 ? (h - 17.5) / 2 : 1;
    const K: [number, string][] = [[0, '#4c5aa6'], [5, '#4c5aa6'], [6.2, '#e89a8a'], [7.5, '#ffffff'], [16.5, '#ffffff'], [18.2, '#ffc08e'], [19.6, '#7470b8'], [21, '#4c5aa6'], [24, '#4c5aa6']];
    for (let i = 0; i < K.length - 1; i++)
      if (h >= K[i][0] && h <= K[i + 1][0]) {
        this.tint = mixc(K[i][1], K[i + 1][1], (h - K[i][0]) / (K[i + 1][0] - K[i][0] || 1));
        break;
      }
  }

  // ================================================================ traffic helpers
  private phase(z: number) {
    return (this.time + (z % 2) * 12) % 24;
  }
  private pedGreen(t: number, i: number) {
    const ph = this.phase(this.world.zone[i]);
    return t === CROSS_V ? ph >= 12.5 && ph < 18.5 : ph >= 0.5 && ph < 6.5;
  }
  private carGreen(ns: boolean, z: number) {
    const ph = this.phase(z);
    return ns ? ph < 9 : ph >= 12 && ph < 21;
  }

  // ================================================================ update
  step(dt: number) {
    this.time += dt;
    this.clock = (this.clock + dt / DAYLEN) % 1;
    this.updateSky();
    if (this.fadeDir !== 0) {
      this.fade += this.fadeDir * dt * 2.8;
      if (this.fade >= 1) {
        this.fade = 1;
        if (this.pendingFn) this.pendingFn();
        this.pendingFn = null;
        this.fadeDir = -1;
      } else if (this.fade <= 0) {
        this.fade = 0;
        this.fadeDir = 0;
      }
    }
    this.updatePlayer(dt);
    if (this.scene) {
      this.stepScene(dt);
      return;
    }
    this.updateNpcs(dt);
    this.updateCars(dt);
    this.updatePigeons(dt);
    for (const b of this.boats) {
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      if (b.vx > 0 && b.x > b.b) b.x = b.a;
      if (b.vx < 0 && b.x < b.a) b.x = b.b;
      if (b.vy > 0 && b.y > b.b) b.y = b.a;
      if (b.vy < 0 && b.y < b.a) b.y = b.b;
    }
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.2;
      this.updateHud();
    }
    this.chatT -= dt;
    if (this.chatT <= 0) {
      this.chatT = 0.7 + Math.random() * 0.9;
      const v = this.vis;
      if (v.length) {
        const n = v[(Math.random() * v.length) | 0];
        if (n.sayT <= 0 && n.kind !== 7) {
          const list = SAYK[n.kind] ?? (n.kind === 5 && Math.random() < 0.5 ? SAY.slice(-8) : SAY);
          n.say = list[(Math.random() * list.length) | 0];
          n.sayT = 2.6;
        }
      }
    }
  }

  private blocked(x: number, y: number) {
    const sc = this.scene;
    if (sc) {
      for (let c = 0; c < 4; c++) {
        const tx = Math.floor((x + (c & 1 ? 4 : -4)) / T);
        const ty = Math.floor((y + (c & 2 ? 0 : -5)) / T);
        if (tx < 0 || ty < 0 || tx >= sc.w || ty > sc.h || sc.solid[ty * sc.w + tx]) return true;
      }
      return false;
    }
    const w = this.world;
    for (let c = 0; c < 4; c++) {
      const tx = Math.floor((x + (c & 1 ? 4 : -4)) / T);
      const ty = Math.floor((y + (c & 2 ? 0 : -5)) / T);
      if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) return true;
      const i = ty * MW + tx;
      if (w.solid[i] || isWater(w.tiles[i]) || w.tiles[i] === ICE) return true;
    }
    const p = this.player;
    for (const c of this.cars) {
      if (Math.abs(c.x - x) > 40 || Math.abs(c.y - y) > 40) continue;
      const hw = c.dir % 2 ? c.type.len / 2 : 8;
      const hh = c.dir % 2 ? 8 : c.type.len / 2;
      const inNew = x + 4 > c.x - hw && x - 4 < c.x + hw && y > c.y - hh && y - 5 < c.y + hh;
      if (!inNew) continue;
      const inOld = p.x + 4 > c.x - hw && p.x - 4 < c.x + hw && p.y > c.y - hh && p.y - 5 < c.y + hh;
      if (!inOld) return true;
    }
    return false;
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    p.moving = false;
    if (!this.active || this.fadeDir !== 0) return;
    const k = this.keys;
    let ix = this.joy.x;
    let iy = this.joy.y;
    if (k.has('arrowleft') || k.has('a')) ix -= 1;
    if (k.has('arrowright') || k.has('d')) ix += 1;
    if (k.has('arrowup') || k.has('w')) iy -= 1;
    if (k.has('arrowdown') || k.has('s')) iy += 1;
    const len = Math.hypot(ix, iy);
    if (len < 0.15) return;
    const l = Math.max(1, len);
    ix /= l;
    iy /= l;
    const sp = this.run || k.has('shift') ? 128 : 72;
    const nx = p.x + ix * sp * dt;
    const ny = p.y + iy * sp * dt;
    if (!this.blocked(nx, p.y)) p.x = nx;
    if (!this.blocked(p.x, ny)) p.y = ny;
    p.dir = Math.abs(ix) > Math.abs(iy) ? (ix < 0 ? 1 : 2) : iy < 0 ? 3 : 0;
    p.an += sp * dt;
    p.moving = true;
    if (iy < -0.5 && this.fadeDir === 0) {
      if (this.scene) {
        if (this.curBoard && this.boardCool <= 0) {
          this.boardCool = 1.5;
          this.hud.subway();
        }
      } else if (this.curDoor >= 0) {
        const d = this.world.doors[this.curDoor];
        if (p.y - d.y < 8 && Math.abs(p.x - d.x) < 8) this.enterDoor(this.curDoor);
      }
    }
  }

  private choose(n: Npc) {
    const w = this.world;
    const cur = w.tiles[n.cy * MW + n.cx];
    const onRoad = isRoad(cur);
    let tot = 0;
    let wait = false;
    const ws = [0, 0, 0, 0];
    for (let d = 0; d < 4; d++) {
      const nx = n.cx + DX[d];
      const ny = n.cy + DY[d];
      if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      const i = ny * MW + nx;
      if (!w.npcOk[i]) continue;
      const t = w.tiles[i];
      let wt = d === n.dir ? 14 : d === 3 - n.dir ? 0.12 : 1;
      if (isRoad(t)) {
        if (!onRoad) {
          if (!this.pedGreen(t, i) && Math.random() > 0.02) {
            if (d === n.dir) wait = true;
            continue;
          }
          wt *= 1.5;
        } else wt = d === n.dir ? 60 : d === 3 - n.dir ? 0.01 : 0.4;
      } else if (onRoad) wt = d === n.dir ? 60 : 2;
      else if (n.kind === 6) {
        if (t !== PATH) wt *= 0.02;
      } else if (t === GRASS && cur !== GRASS) wt *= 0.12;
      else if (cur === GRASS && t !== GRASS) wt *= 3;
      ws[d] = wt;
      tot += wt;
    }
    if (wait && Math.random() < 0.85) {
      n.st = 1;
      n.t = 0.4 + Math.random() * 0.8;
      return;
    }
    if (tot <= 0) {
      n.st = 2;
      n.t = 1 + Math.random() * 2;
      n.dir = 3 - n.dir;
      return;
    }
    if (n.kind === 0 && !onRoad && Math.random() < 0.006) {
      n.st = 2;
      n.t = 1.5 + Math.random() * 4;
      return;
    }
    let q = Math.random() * tot;
    let d = 0;
    for (; d < 4; d++) {
      if (ws[d] <= 0) continue;
      q -= ws[d];
      if (q <= 0) break;
    }
    if (d > 3) d = ws[0] > 0 ? 0 : ws[1] > 0 ? 1 : ws[2] > 0 ? 2 : 3;
    n.dir = d;
    n.cx += DX[d];
    n.cy += DY[d];
    n.gx = n.cx * T + 8 + n.ox;
    n.gy = n.cy * T + 8 + n.oy;
    n.st = 0;
  }

  private updateNpcs(dt: number) {
    const w = this.world;
    const ped = this.ped;
    ped.fill(0);
    const p = this.player;
    const pi = clamp(Math.floor(p.y / T), 0, MH - 1) * MW + clamp(Math.floor(p.x / T), 0, MW - 1);
    if (isRoad(w.tiles[pi])) ped[pi] = 2;
    const pi2 = clamp(Math.floor((p.y - 5) / T), 0, MH - 1) * MW + clamp(Math.floor(p.x / T), 0, MW - 1);
    if (isRoad(w.tiles[pi2])) ped[pi2] = 2;
    for (const n of this.npcs) {
      if (n.sayT > 0) n.sayT -= dt;
      if (n.kind === 7) {
        const o = n.own!;
        const tx = o.x + n.ox - DX[o.dir] * 6;
        const ty = o.y + n.oy - DY[o.dir] * 6;
        const dx = tx - n.x;
        const dy = ty - n.y;
        const d = Math.hypot(dx, dy);
        if (d > 2) {
          const s = Math.min(d, (o.sp + 14) * dt);
          n.x += (dx / d) * s;
          n.y += (dy / d) * s;
          n.an += s;
          if (Math.abs(dx) > 0.5) n.dir = dx < 0 ? 1 : 2;
          n.st = 0;
        } else n.st = 2;
        continue;
      }
      if (n.st === 0) {
        const dx = n.gx - n.x;
        const dy = n.gy - n.y;
        const step = n.sp * dt;
        if (Math.abs(dx) + Math.abs(dy) <= step) {
          n.x = n.gx;
          n.y = n.gy;
          this.choose(n);
        } else if (Math.abs(dx) > 0.01) n.x += clamp(dx, -step, step);
        else n.y += clamp(dy, -step, step);
        n.an += step;
        const ti = n.cy * MW + n.cx;
        if (isRoad(w.tiles[ti])) ped[ti] = 1;
      } else if (n.st === 1) {
        n.t -= dt;
        if (n.t <= 0) this.choose(n);
      } else if (n.t >= 0) {
        n.t -= dt;
        if (n.t <= 0) this.choose(n);
      } else if (n.kind === 5 && Math.random() < dt * 0.12) n.dir = (Math.random() * 4) | 0;
    }
  }

  private node(c: Car, px: number, py: number): boolean {
    const w = this.world;
    const tx = Math.floor((px - 1) / T);
    const ty = Math.floor((py - 1) / T);
    if (tx < 0 || ty < 0 || tx >= MW - 1 || ty >= MH - 1) return false;
    const id = w.core[ty * MW + tx];
    if (!id || id !== w.core[(ty + 1) * MW + tx + 1]) return false;
    const it = w.inters[id - 1];
    const ox = px - it.x * T;
    const oy = py - it.y * T;
    if ((ox !== 16 && ox !== 48) || (oy !== 16 && oy !== 48)) return false;
    const vert = c.dir % 2 === 0;
    const pd = vert ? (oy === 16 ? 3 : 1) : ox === 16 ? 2 : 0;
    const ex = [it.n, it.e, it.s, it.w];
    const right = pd === (c.dir + 1) % 4;
    const canTurn = ex[pd];
    const canCont = right ? ex[c.dir] || ex[(c.dir + 3) % 4] : ex[c.dir];
    if (canTurn && (!canCont || (c.cool <= 0 && Math.random() < (right ? 0.25 : 0.2)))) {
      c.x = px;
      c.y = py;
      c.dir = pd;
      c.cool = 2;
      return true;
    }
    if (!canCont && !canTurn) {
      this.uturn(c);
      return true;
    }
    return false;
  }

  private uturn(c: Car) {
    const l = (c.dir + 3) % 4;
    c.x += CDX[l] * 32;
    c.y += CDY[l] * 32;
    c.dir = (c.dir + 2) % 4;
    c.sp = 0;
    c.cool = 2;
  }

  private updateCars(dt: number) {
    const w = this.world;
    const ped = this.ped;
    const cars = this.cars;
    const ti = (x: number, y: number) => clamp(Math.floor(y / T), 0, MH - 1) * MW + clamp(Math.floor(x / T), 0, MW - 1);
    for (const c of cars) {
      const dx = CDX[c.dir];
      const dy = CDY[c.dir];
      const half = c.type.len / 2;
      const nx = c.x + dx * half;
      const ny = c.y + dy * half;
      if (c.cool > 0) c.cool -= dt;
      if (c.honk > -10) c.honk -= dt;
      if (!isRoad(w.tiles[ti(c.x + dx * 10, c.y + dy * 10)])) {
        this.uturn(c);
        continue;
      }
      let go = true;
      let byPlayer = false;
      const zA = w.zone[ti(nx + dx * 5, ny + dy * 5)];
      if (zA && !w.zone[ti(nx, ny)] && !this.carGreen(c.dir % 2 === 0, zA)) go = false;
      if (go)
        for (let a = 6; a <= 16 && go; a += 10)
          for (let l = -20; l <= 20; l += l === -6 ? 12 : 14) {
            const v = ped[ti(nx + dx * a - dy * l, ny + dy * a + dx * l)];
            if (v) {
              go = false;
              if (v === 2) byPlayer = true;
              break;
            }
          }
      let byCar = false;
      if (go) {
        const ax0 = nx + (dx < 0 ? -14 : 0) - (dy !== 0 ? 7 : 0);
        const ax1 = nx + (dx > 0 ? 14 : 0) + (dy !== 0 ? 7 : 0);
        const ay0 = ny + (dy < 0 ? -14 : 0) - (dx !== 0 ? 7 : 0);
        const ay1 = ny + (dy > 0 ? 14 : 0) + (dx !== 0 ? 7 : 0);
        for (const o of cars) {
          if (o === c) continue;
          const hw = o.dir % 2 ? o.type.len / 2 : 8;
          const hh = o.dir % 2 ? 8 : o.type.len / 2;
          if (o.x - hw < ax1 && o.x + hw > ax0 && o.y - hh < ay1 && o.y + hh > ay0) {
            byCar = true;
            break;
          }
        }
        if (byCar && c.stuck < 9) go = false;
      }
      c.stuck = go && !byCar ? 0 : c.stuck + dt;
      if (byPlayer && c.stuck > 1.2 && c.honk <= -3) c.honk = 1.2;
      c.sp += ((go ? c.max : 0) - c.sp) * Math.min(1, dt * (go ? 2.2 : 12));
      if (!go && c.sp < 3) c.sp = 0;
      const dist = c.sp * dt;
      if (dist <= 0) continue;
      if (dy !== 0) {
        const after = c.y + dy * dist;
        const m = dy < 0 ? Math.floor(c.y / T - 1e-6) * T : Math.ceil(c.y / T + 1e-6) * T;
        if ((dy < 0 && after <= m) || (dy > 0 && after >= m)) if (this.node(c, c.x, m)) continue;
        c.y = after;
      } else {
        const after = c.x + dx * dist;
        const m = dx < 0 ? Math.floor(c.x / T - 1e-6) * T : Math.ceil(c.x / T + 1e-6) * T;
        if ((dx < 0 && after <= m) || (dx > 0 && after >= m)) if (this.node(c, m, c.y)) continue;
        c.x = after;
      }
    }
  }

  private updatePigeons(dt: number) {
    const p = this.player;
    for (const b of this.pigeons) {
      if (b.st === 0) {
        const dx = b.x - p.x;
        const dy = b.y - p.y;
        if (dx * dx + dy * dy < 28 * 28 && this.active) {
          b.st = 1;
          b.t = 0;
          b.vx = (dx >= 0 ? 1 : -1) * (40 + Math.random() * 40);
          b.z = 0;
        }
      } else if (b.st === 1) {
        b.t += dt;
        b.x += b.vx * dt;
        b.y -= 14 * dt;
        b.z += 62 * dt;
        if (b.t > 2.4) {
          b.st = 2;
          b.t = 8 + Math.random() * 12;
        }
      } else {
        b.t -= dt;
        if (b.t <= 0 && Math.abs(b.hx - p.x) + Math.abs(b.hy - p.y) > 90) {
          b.st = 0;
          b.x = b.hx;
          b.y = b.hy;
          b.z = 0;
        }
      }
    }
  }

  private updateHud() {
    if (this.scene) return;
    const w = this.world;
    const p = this.player;
    const tx = clamp(Math.floor(p.x / T), 0, MW - 1);
    const ty = clamp(Math.floor(p.y / T), 0, MH - 1);
    const d = w.district(tx, ty);
    if (d !== this.lastDistrict) {
      this.lastDistrict = d;
      this.hud.district(d);
    }
    if (this.active)
      for (let i = 0; i < w.landmarks.length; i++) {
        if (this.found.has(i)) continue;
        const l = w.landmarks[i];
        if (Math.abs(l.x - tx) <= l.r && Math.abs(l.y - ty) <= l.r) {
          this.found.add(i);
          try {
            localStorage.setItem('nyc-pixel-found', JSON.stringify([...this.found]));
          } catch {
            /* ignore */
          }
          this.hud.landmark(l, this.found.size, w.landmarks.length, true);
        }
      }
    this.curTrigger = -1;
    this.curStation = -1;
    let prompt: string | null = null;
    for (let i = 0; i < w.triggers.length; i++) {
      const t = w.triggers[i];
      if (tx >= t.x && tx < t.x + t.w && ty >= t.y && ty < t.y + t.h) {
        this.curTrigger = i;
        prompt = t.label;
      }
    }
    this.curDoor = -1;
    if (!prompt)
      for (let i = 0; i < w.doors.length; i++) {
        const d = w.doors[i];
        if (Math.abs(d.x - p.x) < 9 && p.y >= d.y && p.y - d.y < 13) {
          this.curDoor = i;
          prompt = 'Masuk · ' + d.name;
          break;
        }
      }
    if (!prompt)
      for (let i = 0; i < w.stations.length; i++) {
        const s = w.stations[i];
        if (Math.abs(s.x - p.x) < 30 && Math.abs(s.y - p.y) < 22) {
          this.curStation = i;
          prompt = 'Turun ke subway · ' + s.name;
        }
      }
    if (prompt !== this.lastPrompt) {
      this.lastPrompt = prompt;
      this.hud.prompt(prompt);
    }
    const h = this.clock * 24;
    const label = h >= 5 && h < 10.5 ? 'PAGI' : h < 15 && h >= 10.5 ? 'SIANG' : h >= 15 && h < 18.8 ? 'SORE' : 'MALAM';
    const mm = Math.floor(((h % 1) * 60) / 10) * 10;
    const s = `${String(Math.floor(h)).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
    if (s !== this.lastClock) {
      this.lastClock = s;
      this.hud.clock(label, s);
    }
  }

  // ================================================================ render
  private bubble(text: string, x: number, y: number, dark = false) {
    const g = this.g;
    const w = textW(text) + 6;
    const bx = clamp(Math.round(x - w / 2), 1, Math.max(1, this.vw - w - 1));
    const by = Math.round(y) - 9;
    const rx = clamp(Math.round(x), bx + 2, bx + w - 3);
    g.fillStyle = '#1b1b26';
    g.fillRect(bx - 1, by, w + 2, 9);
    g.fillRect(bx, by - 1, w, 11);
    g.fillRect(rx - 1, by + 10, 3, 1);
    g.fillRect(rx, by + 11, 1, 1);
    g.fillStyle = dark ? '#ffe14a' : '#ffffff';
    g.fillRect(bx, by, w, 9);
    g.fillRect(rx, by + 9, 1, 2);
    drawText(g, text, bx + 3, by + 2, '#1b1b26');
  }

  render() {
    if (this.scene) {
      this.renderScene();
      return;
    }
    const g = this.g;
    const w = this.world;
    const vw = this.vw;
    const vh = this.vh;
    const p = this.player;
    const WW = MW * T;
    const WH = MH * T;
    const cx = vw >= WW ? Math.round((WW - vw) / 2) : clamp(Math.round(p.x - vw / 2), 0, WW - vw);
    const cy = vh >= WH ? Math.round((WH - vh) / 2) : clamp(Math.round(p.y - 14 - vh / 2), 0, WH - vh);
    this.camX = cx;
    this.camY = cy;
    this.frame++;
    const time = this.time;

    // ---- tiles
    const atlas = this.atlas[Math.floor(time * 2.2) % 3];
    g.fillStyle = '#2a66ad';
    g.fillRect(0, 0, vw, vh);
    const tx0 = Math.max(0, cx >> 4);
    const ty0 = Math.max(0, cy >> 4);
    const tx1 = Math.min(MW - 1, (cx + vw) >> 4);
    const ty1 = Math.min(MH - 1, (cy + vh) >> 4);
    for (let ty = ty0; ty <= ty1; ty++)
      for (let tx = tx0; tx <= tx1; tx++) {
        const id = w.gfx[ty * MW + tx];
        g.drawImage(atlas, (id % ATLAS_COLS) * T, ((id / ATLAS_COLS) | 0) * T, T, T, tx * T - cx, ty * T - cy, T, T);
      }

    // ---- boats
    for (const b of this.boats) {
      if (b.x > cx + vw || b.x + b.c.width < cx || b.y > cy + vh || b.y + b.c.height < cy) continue;
      const bob = Math.sin(time * 2 + b.x * 0.01) > 0 ? 1 : 0;
      g.fillStyle = 'rgba(220,240,255,.55)';
      g.fillRect(Math.round(b.x - cx) - 2, Math.round(b.y - cy) + b.c.height - 3, b.c.width + 4, 2);
      g.drawImage(b.c, Math.round(b.x - cx), Math.round(b.y - cy) + bob);
    }

    // ---- collect drawables
    const list = this.list;
    list.length = 0;
    const vis = this.vis;
    vis.length = 0;
    const bx0 = Math.max(0, Math.floor(cx / BUCKET));
    const bx1 = Math.min(w.bw - 1, Math.floor((cx + vw) / BUCKET));
    const by0 = Math.max(0, Math.floor(cy / BUCKET));
    const by1 = Math.min(w.bh - 1, Math.floor((cy + vh) / BUCKET));
    for (let by = by0; by <= by1; by++)
      for (let bx = bx0; bx <= bx1; bx++)
        for (const o of w.buckets[by * w.bw + bx]) {
          if (o.stamp === this.frame) continue;
          o.stamp = this.frame;
          if (o.x > cx + vw || o.x + o.w < cx || o.y > cy + vh || o.y + o.h < cy) continue;
          list.push(o);
        }
    for (const n of this.npcs) {
      if (n.x < cx - 12 || n.x > cx + vw + 12 || n.y < cy - 4 || n.y > cy + vh + 26) continue;
      n.sy = n.y;
      list.push(n);
      vis.push(n);
    }
    for (const c of this.cars) {
      if (c.x < cx - 40 || c.x > cx + vw + 40 || c.y < cy - 40 || c.y > cy + vh + 40) continue;
      c.sy = c.y + (c.dir % 2 ? 6 : c.type.len / 2);
      list.push(c);
    }
    p.sy = p.y;
    list.push(p);
    list.sort((a, b) => a.sy - b.sy);

    // ---- pigeons on ground
    const pg = this.props.pigeons;
    for (const b of this.pigeons) {
      if (b.st !== 0 || b.x < cx - 8 || b.x > cx + vw + 8 || b.y < cy - 8 || b.y > cy + vh + 8) continue;
      const f = (time * 2 + b.ph) % 3 < 0.5 ? 1 : 0;
      g.drawImage(pg, f * 8, 0, 8, 7, Math.round(b.x - cx) - 4, Math.round(b.y - cy) - 6, 8, 7);
    }

    // ---- sorted sprites
    const night = this.nf > 0.02;
    const lg = this.lg;
    const glows = this.glowList;
    glows.length = 0;
    if (night) lg.clearRect(0, 0, vw, vh);
    const pa = this.people;
    const drawPerson = (look: number, dir: number, fr: number, x: number, y: number) => {
      const sx = (look % pa.per) * 48 + fr * 16;
      const sy = Math.floor(look / pa.per) * 96 + dir * 24;
      g.fillStyle = 'rgba(0,0,0,.22)';
      g.fillRect(x + 3, y + 21, 10, 2);
      g.drawImage(pa.c, sx, sy, 16, 24, x, y, 16, 24);
      if (night) {
        lg.globalCompositeOperation = 'destination-out';
        lg.drawImage(pa.c, sx, sy, 16, 24, x, y, 16, 24);
        lg.globalCompositeOperation = 'source-over';
      }
    };
    for (const d of list) {
      if (d.k === 0) {
        let s = d.spr;
        if (!s) {
          s = d.spr = d.make!();
          this.cache.push(d);
        }
        const sx = d.x - cx;
        const sy = d.y - cy;
        const behind = d.fade && p.y < d.sy && p.x + 7 > d.x && p.x - 7 < d.x + d.w && p.y > d.y && p.y - 22 < d.y + d.h;
        if (behind) g.globalAlpha = 0.4;
        g.drawImage(s.c, sx, sy);
        if (behind) g.globalAlpha = 1;
        if (s.boards) for (const b of s.boards) drawBoard(g, b, sx, sy, time);
        if (d.dyn === 1) {
          const a = d.a ?? 0;
          const ph = this.phase(a >> 1);
          const st = a & 1 ? (ph >= 12 && ph < 20 ? 2 : ph >= 20 && ph < 21 ? 1 : 0) : ph < 8 ? 2 : ph < 9 ? 1 : 0;
          g.fillStyle = st === 2 ? '#4aff7a' : st === 1 ? '#ffd23a' : '#ff4a3a';
          g.fillRect(sx + 5, sy + (st === 2 ? 9 : st === 1 ? 6 : 3), 2, 2);
        } else if (d.dyn === 2) {
          for (let i = 0; i < 4; i++) {
            const t = (time * 0.55 + i / 4) % 1;
            const sz = 2 + Math.floor(t * 5);
            g.fillStyle = `rgba(240,240,246,${(0.7 * (1 - t)).toFixed(2)})`;
            g.fillRect(Math.round(sx + 4 + Math.sin((t + i) * 6) * 3 - sz / 2), Math.round(sy - t * 26 - sz / 2), sz, sz);
          }
        }
        if (night) {
          lg.globalCompositeOperation = 'destination-out';
          lg.drawImage(s.c, sx, sy);
          lg.globalCompositeOperation = 'source-over';
          const L = s.lights;
          if (L)
            for (let i = 0; i < L.length; i += 5) {
              lg.fillStyle = LCOL[L[i + 4]];
              lg.globalAlpha = L[i + 4] === 3 ? 0.8 : 1;
              lg.fillRect(sx + L[i], sy + L[i + 1], L[i + 2], L[i + 3]);
            }
          lg.globalAlpha = 1;
          const GL = s.glows;
          if (GL) for (let i = 0; i < GL.length; i += 4) if (GL[i + 2] > 0 && GL[i + 3] > 0) lg.drawImage(s.c, GL[i], GL[i + 1], GL[i + 2], GL[i + 3], sx + GL[i], sy + GL[i + 1], GL[i + 2], GL[i + 3]);
          if (s.boards) for (const b of s.boards) drawBoard(lg, b, sx, sy, time);
          if (d.dyn === 1) {
            const a = d.a ?? 0;
            const ph = this.phase(a >> 1);
            const st = a & 1 ? (ph >= 12 && ph < 20 ? 2 : ph >= 20 && ph < 21 ? 1 : 0) : ph < 8 ? 2 : ph < 9 ? 1 : 0;
            lg.fillStyle = st === 2 ? '#4aff7a' : st === 1 ? '#ffd23a' : '#ff4a3a';
            lg.fillRect(sx + 5, sy + (st === 2 ? 9 : st === 1 ? 6 : 3), 2, 2);
          }
          const LP = s.lamps;
          if (LP) for (let i = 0; i < LP.length; i += 3) glows.push(sx + LP[i], sy + LP[i + 1], LP[i + 2]);
        }
      } else if (d.k === 1) {
        const x = Math.round(d.x) - 8 - cx;
        let y = Math.round(d.y) - 22 - cy;
        if (d.kind === 7) {
          const fr = d.st === 0 ? (d.an / 5) & 1 : 0;
          g.fillStyle = 'rgba(0,0,0,.2)';
          g.fillRect(x + 2, y + 21, 11, 2);
          g.drawImage(this.props.dogs, (d.dir === 2 ? 28 : 0) + fr * 14, d.dog * 10, 14, 10, x + 1, y + 13, 14, 10);
          continue;
        }
        if (d.kind === 2 || d.kind === 4) y -= Math.sin(time * 7 + d.x) > 0.3 ? 1 : 0;
        drawPerson(d.look, d.dir, d.st === 0 ? WALK[((d.an / 7) | 0) & 3] : 0, x, y);
        if (d.kind === 2) {
          const t = (time * 0.7) % 1;
          drawText(g, '}', x + 14 + Math.round(Math.sin(time * 4) * 2), y - Math.round(t * 14), t < 0.5 ? '#ffffff' : '#ffe14a');
          drawText(g, '}', x - 3 - Math.round(Math.sin(time * 3) * 2), y + 4 - Math.round(((t + 0.5) % 1) * 14), '#7ad8ff');
        }
      } else if (d.k === 2) {
        const spr = d.type.c[d.dir];
        const x = Math.round(d.x - spr.width / 2) - cx;
        const y = (d.dir % 2 ? Math.round(d.y) - 15 : Math.round(d.y - d.type.len / 2) - 3) - cy;
        g.fillStyle = 'rgba(0,0,0,.25)';
        if (d.dir % 2) g.fillRect(x + 2, y + spr.height - 4, spr.width - 4, 3);
        else g.fillRect(x + 3, y + spr.height - 3, 16, 3);
        g.drawImage(spr, x, y);
        if (d.type.kind === 2 && Math.floor(time * 6) % 2 === 0) {
          g.fillStyle = '#ffffff';
          if (d.dir % 2) g.fillRect(x + (spr.width >> 1) - 1, y + 2, 2, 2);
          else g.fillRect(x + 10, y + (spr.height >> 1) - 1, 2, 2);
        }
        if (night) {
          lg.globalCompositeOperation = 'destination-out';
          lg.drawImage(spr, x, y);
          lg.globalCompositeOperation = 'source-over';
          glows.push(Math.round(d.x - cx + CDX[d.dir] * (d.type.len / 2 + 6)), Math.round(d.y - cy + CDY[d.dir] * (d.type.len / 2 + 6)) - (d.dir % 2 ? 2 : 0), 20);
        }
      } else {
        const x = Math.round(p.x) - 8 - cx;
        const y = Math.round(p.y) - 22 - cy;
        drawPerson(SP_PLAYER, p.dir, p.moving ? WALK[((p.an / 8) | 0) & 3] : 0, x, y);
      }
    }

    // ---- flying pigeons
    for (const b of this.pigeons) {
      if (b.st !== 1 || b.x < cx - 8 || b.x > cx + vw + 8) continue;
      const f = 2 + (Math.floor(time * 12 + b.ph) & 1);
      g.drawImage(pg, f * 8, 0, 8, 7, Math.round(b.x - cx) - 4, Math.round(b.y - b.z - cy) - 6, 8, 7);
    }

    // ---- sky tint + lights
    if (this.tint !== '#ffffff') {
      g.globalCompositeOperation = 'multiply';
      g.fillStyle = this.tint;
      g.fillRect(0, 0, vw, vh);
      g.globalCompositeOperation = 'source-over';
    }
    if (night) {
      g.globalAlpha = this.nf;
      g.drawImage(this.lc, 0, 0);
      g.globalCompositeOperation = 'lighter';
      g.globalAlpha = this.nf * 0.85;
      const gl = this.props.glow;
      for (let i = 0; i < glows.length; i += 3) {
        const r = glows[i + 2];
        g.drawImage(gl, glows[i] - r, glows[i + 1] - r, r * 2, r * 2);
      }
      g.globalCompositeOperation = 'source-over';
      g.globalAlpha = 1;
    }

    // ---- UI layer in world: bubbles, honks, player marker
    for (const n of vis) if (n.sayT > 0) this.bubble(n.say, n.x - cx, n.y - cy - 25);
    for (const c of this.cars) if (c.honk > 0) this.bubble('HONK!', c.x - cx, c.y - cy - 20, true);
    if (this.active) {
      const bob = Math.floor(time * 3) % 2;
      for (let i = 0; i < w.doors.length; i++) {
        const d = w.doors[i];
        if (Math.abs(d.x - p.x) > 56 || d.y - p.y > 30 || p.y - d.y > 48) continue;
        const ax = d.x - cx;
        const ay = d.y - cy - 24 - bob;
        const cur = i === this.curDoor;
        g.fillStyle = '#1b1b26';
        g.fillRect(ax - 1, ay - 1, 3, 1);
        g.fillRect(ax - 2, ay, 5, 1);
        g.fillRect(ax - 3, ay + 1, 7, 2);
        g.fillStyle = cur ? '#7aff8a' : '#ffe14a';
        g.fillRect(ax, ay, 1, 1);
        g.fillRect(ax - 1, ay + 1, 3, 1);
        g.fillRect(ax - 2, ay + 2, 5, 1);
      }
      const mx = Math.round(p.x) - cx;
      const my = Math.round(p.y) - cy - 29 - (Math.floor(time * 3) % 2);
      g.fillStyle = '#1b1b26';
      g.fillRect(mx - 3, my - 1, 7, 3);
      g.fillRect(mx - 2, my + 2, 5, 1);
      g.fillRect(mx - 1, my + 3, 3, 1);
      g.fillStyle = '#ffe14a';
      g.fillRect(mx - 2, my, 5, 1);
      g.fillRect(mx - 1, my + 1, 3, 1);
      g.fillRect(mx, my + 2, 1, 1);
    }
    if (this.fade > 0) {
      g.fillStyle = `rgba(8,10,20,${Math.min(1, this.fade).toFixed(2)})`;
      g.fillRect(0, 0, vw, vh);
    }

    // ---- sprite cache eviction
    if (this.frame % 180 === 0 && this.cache.length > 170) {
      const keep: Obj[] = [];
      for (const o of this.cache) {
        if ((o.stamp ?? 0) >= this.frame - 2) keep.push(o);
        else o.spr = undefined;
      }
      this.cache = keep;
    }
  }

  /** draw minimap centred on player into ctx (size px, zoom = px per tile) */
  drawMini(ctx: CanvasRenderingContext2D, size: number, zoom: number) {
    const w = this.world;
    const tiles = size / zoom;
    const mp = this.mapPos();
    const px = mp.x / T;
    const py = mp.y / T;
    const sx = clamp(px - tiles / 2, 0, MW - tiles);
    const sy = clamp(py - tiles / 2, 0, MH - tiles);
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#2f6fb5';
    ctx.fillRect(0, 0, size, size);
    ctx.drawImage(w.mini, sx, sy, tiles, tiles, 0, 0, size, size);
    w.landmarks.forEach((l, i) => {
      const x = (l.x - sx) * zoom;
      const y = (l.y - sy) * zoom;
      if (x < 0 || y < 0 || x > size || y > size) return;
      ctx.fillStyle = '#1b1b26';
      ctx.fillRect(x - 2, y - 2, 5, 5);
      ctx.fillStyle = this.found.has(i) ? '#ffd23a' : '#ffffff';
      ctx.fillRect(x - 1, y - 1, 3, 3);
    });
    const x = Math.round((px - sx) * zoom);
    const y = Math.round((py - sy) * zoom);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x - 3, y - 3, 7, 7);
    ctx.fillStyle = Math.floor(this.time * 3) % 2 ? '#ff3b5c' : '#c0183a';
    ctx.fillRect(x - 2, y - 2, 5, 5);
  }
}

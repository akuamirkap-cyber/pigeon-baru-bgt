import type { Hex } from "./Vox";

/** Shared voxel colors. Light colors are rendered unlit (glow). */
export const P = {
  TIRE: 0x1d1d21,
  RIM: 0xd3d8de,
  ARCH: 0x26262b,
  BLACK: 0x1a1a1e,
  DARK: 0x34353b,
  CARBON: 0x2a2b30,
  CHROME: 0xe3e7ec,
  SILVER: 0xbfc5cc,
  WHITE: 0xf3f4f6,
  GLASS: 0x31465b,
  GLASS_HI: 0x8fbad6,
  PLATE: 0xf2efe2,
  RED: 0xd8282e,
  YELLOW: 0xffc81f,
  ORANGE: 0xff6d14,
  PINK: 0xff8fc8,
  NAVY: 0x1b2448,
  BLUE: 0x2a64d8,
  MAROON: 0x6e1a24,
  GOLD: 0xd9ad3c,
  // glowing
  HEAD: 0xfff3cc,
  XENON: 0xd4ebff,
  TAIL: 0xff2d3a,
  TAIL_DK: 0xb5141f,
  AMBER: 0xffa020,
  LIGHT_W: 0xfbfbff,
  // animated sirens
  SIREN_R: 0xff1e3c,
  SIREN_B: 0x2a6aff,
} as const;

export const GLOW = new Set<Hex>([P.HEAD, P.XENON, P.TAIL, P.TAIL_DK, P.AMBER, P.LIGHT_W]);

/** 0 = standard lit, 1 = glow, 2 = red siren, 3 = blue siren */
export function kindOf(c: Hex): 0 | 1 | 2 | 3 {
  if (c === P.SIREN_R) return 2;
  if (c === P.SIREN_B) return 3;
  return GLOW.has(c) ? 1 : 0;
}

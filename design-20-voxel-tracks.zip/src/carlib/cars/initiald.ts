import { CarCtx, type CarBuild } from "../voxel/CarCtx";
import { P } from "../voxel/palette";

const JP_FONT = '"Noto Sans JP", "Hiragino Sans", "Yu Gothic", "Meiryo", "MS Gothic", sans-serif';

// ───────── Toyota Sprinter Trueno AE86 — narrow boxy wedge hatch, pop-ups ─────────
export function ae86(): CarBuild {
  const c = new CarCtx({ body: 0xf6f6f3, pillar: P.BLACK, rim: 0xbcc0c6 }, { hw: 4, cw: 3 });
  c.profile([
    "...RRRRRRRR..........",
    "..GGGGGGGGGG.........",
    ".GGGGGGGGGGGG........",
    "GGGGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBB.",
    "BBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBb",
    "kBBBBBBBBBBBBBBBBBBBk",
  ]);
  c.sideFill(8, 8, 5, 7, P.BLACK); // B-pillar
  c.wheels([3, 14]);
  // the legendary "panda" two-tone: white top, black bottom
  c.side(["KKKKKKKKKKKKKKKKKKKKK", "KKKKKKKKKKKKKKKKKKKKK"], 2);
  c.front([".....h...", "......h..", ".........", ".........", "KOKKKKKOK", "KKKKKKKKK"], 6);
  c.rear([".........", "TTOKKKOTT", "KKKLLLKKK", "KKKKKKKKK"], 4);
  c.popups(1, 3, 4, 18, 19); // retractable headlights!
  c.box(-3, 3, 5, 5, -1, -1, P.BLACK); // GT-APEX hatch spoiler
  c.box(-2, -2, 1, 1, -1, -1, P.CHROME);
  c.mirrors(13, 5, P.BLACK);
  c.decal({ text: "藤原とうふ店", sub: "（自家用）", z: 10.4, y: 3.98, len: 7, h: 0.95, color: "#141414", font: JP_FONT });
  return c.done();
}

// ───────── Mazda RX-7 FD3S — super low, curvy humps, double-bubble roof, pop-ups ─────────
export function fd3s(): CarBuild {
  const c = new CarCtx({ body: 0xf7c600, wing: 0x1f2024, rim: 0x3e4046 }, { cw: 3 });
  c.profile([
    "WWW...rrrr...........",
    ".w..GGGGGGGGG........",
    "bBBBBBBBBBBBBBBBBBBB.",
    "bBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBc",
  ]);
  c.clear(-2, 2, 4, 4, 14, 19); // low hood between the fender humps
  c.clearSym(3, 4, 4, 4, 19, 19);
  c.clear(0, 0, 6, 6, 6, 9); // double-bubble roof
  c.wheels([3, 14]);
  c.front([".......h...", "...........", "BO.......OB", "B.KKKKKKK.B", "kkkkkkkkkkk"], 5);
  c.rear(["TTTKKKKKTTT", "...........", "....LLL....", "KKKKKKKKKKK"], 4);
  c.popups(3, 4, 4, 17, 18);
  c.endplates(0, 2, 5, 5);
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(11, 5);
  c.decal({ text: "PROJECT.D", z: 9, y: 2.6, len: 5.5, h: 1.0, color: "#141414" });
  return c.done();
}

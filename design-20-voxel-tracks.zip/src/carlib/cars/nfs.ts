import { CarCtx, noWing, type CarBuild, type Livery } from "../voxel/CarCtx";
import { P } from "../voxel/palette";

/*
 * Coordinate system: x = left/right (body |x|<=hw, cabin |x|<=cw, wheels at hw..hw+1),
 * y = up (wheels y0..3, body from y1), z = rear(0) -> front.
 * Profile rows go from the roof (top) down to y = 1.
 * Each car gets its own silhouette: roof height, beltline, cabin width & position, nose/tail shape.
 */

// ───────── BMW M3 GTR (E46) — wide-body notchback race car, giant GT wing ─────────
export function m3gtr(): CarBuild {
  const c = new CarCtx({ body: 0xc4cad1, A: 0x23367c, wing: 0x202126, rim: 0xd6dadf });
  c.profile([
    "VVVV...RRRRRRR..........",
    ".w....GGGGGGGGG.........",
    ".w...GGGGGGGGGGG........",
    ".w...GGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBBBb.",
    "BBBBBBBBBBBBBBBBBBBBBBB.",
    "BBBBBBBBBBBBBBBBBBBBBBB.",
    "bBBBBBBBBBBBBBBBBBBBBBBK",
  ]);
  c.wheels([3, 17], { flare: true });
  c.sym(6, 6, 1, 1, 8, 15, c.l.body); // side skirts -> full wide-body
  c.endplates(0, 3, 7, 7, undefined, 6);
  c.side(
    [
      "AAA.....AA....AA........",
      "AAAA.....AA....AAA......",
      "AAAAAAA...AAA...AAAAAAA.",
      "AAAAAAAAA...AAAAAAAAAA..",
    ],
    4
  );
  c.top([
    ".................AAAAAA.",
    ".................AAAAAA.",
    "........................",
    "..................KK....",
    "........................",
    "........................",
    "........................",
    "..................KK....",
    "........................",
    ".................AAAAAA.",
    ".................AAAAAA.",
  ]);
  c.front(["......h....", ".......h...", "....K.K....", "BHHXK.KXHHB", "AKKBKKKBKKA", "KKKKKKKKKKK"], 6);
  c.rear(["TT.......TT", "TTT.....TTT", "AA..LLL..AA", "KKKKKKKKKKK"], 4);
  c.sym(2, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(15, 5);
  return c.done();
}

// ───────── Ford Mustang GT (S197) — high-waisted muscle car, chopped roof, shark nose ─────────
function mustang(l: Livery, o: { flare: number; scoop: number; paint: (c: CarCtx) => void }): CarBuild {
  const c = new CarCtx(l);
  c.profile([
    "........RRRR............",
    "WWW...GGGGGGG...........",
    ".w.GGGGGGGGGGGG.........",
    "BBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBB.",
    "BBBBBBBBBBBBBBBBBBBBBBB.",
    "bBBBBBBBBBBBBBBBBBBBBBb.",
  ]);
  c.sideFill(4, 6, 6, 6, l.body); // big fastback C-pillar
  c.wheels([3, 17], { flare: true, flareColor: o.flare });
  c.front(
    ["......h....", ".......h...", "...........", "BHHSSSSSHHB", "BBKXKSKXKBB", "BKKKKKKKKKB", "KKKKKKKKKKK"],
    7
  );
  c.rear(["...........", "BTTTKKKTTTB", "BTTTKSKTTTB", "....LLL....", "KKKKKKKKKKK"], 5);
  o.paint(c);
  c.box(-1, 1, 6, 6, 17, 19, o.scoop); // shaker hood scoop
  c.endplates(0, 2, 6, 6);
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(13, 6);
  return c.done();
}

export const mustangJewels = () =>
  mustang(
    { body: 0xdbdee2, A: P.MAROON, wing: 0x9aa1a9, rim: 0xd6dadf },
    {
      flare: P.MAROON,
      scoop: P.CHROME,
      paint: (c) => {
        c.side(
          [
            "..AAAAAA........AAAAAA..",
            "........KKKKKK..........",
            "........K.K.K.K.........",
            "........................",
            "AAAAAAAAAAAAAAAAAAAAAAAA",
          ],
          5
        );
        c.front(["AAAAAAAAAAA"], 1);
      },
    }
  );

export const mustangRazor = () =>
  mustang(
    { body: 0x141417, wing: 0x1b1c20, rim: 0xd9dde2 },
    {
      flare: 0x141417,
      scoop: P.BLACK,
      paint: (c) => {
        c.side(
          [
            "........R..RRFFFYYYYY...",
            "....RR.RRFFFFYYY....YY..",
            ".......RRFFFFYYY....FF..",
            "........RR..............",
          ],
          5
        );
        c.top([
          "........................",
          "...................RRFYY",
          ".................RRFFYYY",
          "................R..FFYYY",
          "..................RRFYYY",
          "...................RFFYY",
          "..................RRFYYY",
          "................R..FFYYY",
          ".................RRFFYYY",
          "...................RRFYY",
          "........................",
        ]);
      },
    }
  );

// ───────── Mercedes-Benz SLR McLaren — endless hood, arrow nose, cabin far back ─────────
export function slr(): CarBuild {
  const c = new CarCtx({ body: 0x111216, rim: 0xd9dde2 }, { cw: 3 });
  c.profile([
    "....rrrr.................",
    "...GGGGGG................",
    "..GGGGGGGGG..............",
    "bBBBBBBBBBBBBBBBBBBBBbb..",
    "bBBBBBBBBBBBBBBBBBBBBBBb.",
    "bBBBBBBBBBBBBBBBBBBBBBBBc",
    "bBBBBBBBBBBBBBBBBBBBBBBBc",
  ]);
  c.wheels([3, 18]);
  c.top([
    ".....................HH..",
    ".....................HH..",
    ".........................",
    "................W.W......",
    ".................W.......",
    "................W.W......",
    ".........................",
    ".....................HH..",
    ".....................HH..",
  ]);
  c.front(["......h....", ".......h...", ".HH.....HH.", "BKK..S..KKB", "BKKK...KKKB", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.side(["SKS", "SKS"], 3, 14); // side gills
  c.sym(6, 6, 1, 1, 14, 16, P.CHROME); // side exhausts
  c.mirrors(9, 5);
  return c.done();
}

// ───────── Aston Martin DB9 — smooth rounded GT, tumblehome cabin, Aston grille ─────────
export function db9(): CarBuild {
  const c = new CarCtx({ body: 0xe6c01e, C: 0x22361a, wing: 0x1f2a1a, rim: 0xd6d9de });
  c.profile([
    "......rrrr.............",
    "WWW..ggggggggg.........",
    ".w.GGGGGGGGGGGG........",
    "bbBBBBBBBBBBBBBBBBBBb..",
    "bBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.wheels([3, 16]);
  c.side(
    [
      "..CC..C...CC...C...C.C.",
      ".CC..CC..CC..CC....CC..",
      "CC..CC..CC..CC.....C...",
      "C..CC..CC..CC..........",
    ],
    4
  );
  c.top([
    ".................C..C..",
    "................C..C..C",
    "...............C..C..C.",
    ".................C.....",
    ".......................",
    ".......................",
    ".......................",
    ".................C.....",
    "...............C..C..C.",
    "................C..C..C",
    ".................C..C..",
  ]);
  c.side(["SS"], 3, 13); // chrome side strakes
  c.front(["......h....", ".......h...", ".HH.....HH.", "B..SSSSS..B", "B.SKKKKKS.B", "KK.SSSSS.KK"], 6);
  c.rear([".T.......T.", "TTT.....TTT", "....LLL....", "KK.S...S.KK"], 4);
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 2, 5, 5);
  c.mirrors(13, 5);
  return c.done();
}

// ───────── Dodge Viper SRT-10 — huge fenders, low hood, double-bubble roof, side pipes ─────────
export function viper(): CarBuild {
  const c = new CarCtx({ body: 0x26ae3a, wing: 0xa9b0b8, rim: 0xd9dde2 }, { cw: 3 });
  c.profile([
    "WWW...RRRR..............",
    ".w...GGGGGGG............",
    "bbbbGGGGGGGGG...........",
    "BBBBBBBBBBBBBBB.........",
    "BBBBBBBBBBBBBBBBBBBBBBb.",
    "BBBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sym(3, 5, 4, 4, 15, 21, c.l.body); // front fenders rise above the hood
  c.sym(4, 5, 5, 5, 16, 20, c.l.body);
  c.sym(5, 5, 5, 5, 3, 7, c.l.body); // rear haunches
  c.clear(0, 0, 7, 7, 6, 9); // double bubble
  c.wheels([3, 17]);
  c.side(["....KKKK.....KKKKKKKK...", "..KK....KKKKK..........."], 4);
  c.side(["KK", "KK"], 3, 14);
  c.top(["KKKKKKKKKKKKKKKKKKKKKKKK", "........................", "........................", "........................", "KKKKKKKKKKKKKKKKKKKKKKKK"]);
  c.front(["......h....", ".......h...", "HHH.....HHH", "B.KKKKKKK.B", "B.KKKKKKK.B", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTT.....TTT", "...........", "....LLL....", "KKKKKKKKKKK"], 5);
  c.box(-1, 1, 4, 4, 16, 18, P.SILVER); // hood scoop
  c.sym(6, 6, 1, 1, 8, 12, P.CHROME); // side pipes!
  c.endplates(0, 2, 6, 6);
  c.mirrors(11, 5);
  return c.done();
}

// ───────── Chevrolet Corvette C6 — long low pointed nose, flat roof, Kamm tail ─────────
function corvette(l: Livery, variant: "webster" | "cross"): CarBuild {
  const c = new CarCtx(l);
  const rows = [
    "WWW...RRRRRR............",
    ".w..GGGGGGGGG...........",
    ".w.GGGGGGGGGGGG.........",
    "BBBBBBBBBBBBBBBBBB......",
    "BBBBBBBBBBBBBBBBBBBBBb..",
    "BBBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBBc",
  ];
  c.profile(variant === "cross" ? noWing(rows) : rows);
  c.sym(3, 5, 4, 4, 16, 20, l.body); // fender humps carrying the exposed headlights
  c.wheels([3, 17]);
  c.top([
    "...................HH...",
    "...................HH...",
    "........................",
    "........................",
    "........................",
    "........................",
    "........................",
    "...................HH...",
    "...................HH...",
  ]);
  c.front(["......h....", ".......h...", ".HH.....HH.", "...........", "B.KKKKKKK.B", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "BTBT...TBTB", "....LLL....", "KKKKKKKKKKK"], 4);
  if (variant === "webster") {
    c.side(
      [
        "........................",
        "............W.W.W.......",
        "AAAA........W.W.....AAAA",
        "AAAAAAAAAAAAAAAAAAAAAAAA",
      ],
      4
    );
    c.top([
      "................W.W.....",
      "...............W.W.W....",
      "...............WWW.W....",
      "................WW.WW...",
      ".................W.W....",
      "................WW.WW...",
      "...............WWW.W....",
      "...............W.W.W....",
      "................W.W.....",
    ]);
    c.front(["AAKKKKKKKAA", "AAAAAAAAAAA"], 2);
    c.endplates(0, 2, 6, 6);
  } else {
    c.side([".......WWWWWWW..........", ".......WWWWWWW..........", ".......WWWWWWW.........."], 4);
    c.lightbar(8, 9, 8, 3);
    c.decal({ text: "POLICE", z: 10.5, y: 3.5, len: 6.4, h: 1.5, color: "#111214" });
  }
  c.sym(1, 2, 1, 1, -1, -1, P.CHROME); // quad center exhaust
  c.mirrors(13, 5);
  return c.done();
}
export const corvetteWebster = () => corvette({ body: 0x151518, A: 0x8a4a1e, wing: 0x1b1c20, rim: 0xd6dadf }, "webster");
export const corvetteCross = () => corvette({ body: 0x141417, rim: 0xd6dadf }, "cross");

// ───────── Lamborghini Gallardo — extreme wedge, cab-forward, tall engine-cover tail ─────────
export function gallardo(): CarBuild {
  const c = new CarCtx({ body: 0x17181b, A: 0xbfc5cc, rim: 0xd2d6db });
  c.profile([
    ".....RRRRR............",
    "bbbbbGGGGGGG..........",
    "BBBBBBBBBBBBGGG.......",
    "BBBBBBBBBBBBBBBBBBb...",
    "BBBBBBBBBBBBBBBBBBBBb.",
    "bBBBBBBBBBBBBBBBBBBBcc",
  ]);
  c.sym(4, 5, 4, 4, 14, 18, c.l.body); // front fender tops
  c.wheels([3, 15]);
  c.side(["AAAAA.................", "AAAAAAAAAAAA..........", "AAAAAAAAAAAAAA........"], 5);
  c.top(Array.from({ length: 9 }, () => "AAAAAAAAAA............"));
  c.top(Array.from({ length: 7 }, () => ".K.K.................."));
  const lamp = ".................HH...";
  const none = "......................";
  c.top([lamp, lamp, none, none, none, none, none, none, none, lamp, lamp]);
  c.side(["KK", "KK"], 4, 7); // big side intakes
  c.front([".......h...", "HH.......HH", "...........", "KKK.....KKK", "KKKKKKKKKKK"], 5);
  c.rear([".KKKKKKKKK.", "TTTKKKKKTTT", "...........", "....LLL....", "KKKKKKKKKKK"], 5);
  c.sym(2, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(12, 4);
  return c.done();
}

// ───────── Mercedes-Benz CLK 500 — elegant arched notchback, pillarless ─────────
export function clk(): CarBuild {
  const c = new CarCtx({ body: 0xc9ced4, C: 0x4a2a1e, wing: 0x3a3d42, rim: 0xd6dade });
  c.profile([
    "........rrrrr..........",
    "WWW...gggggggg.........",
    ".w...GGGGGGGGGG........",
    ".w...GGGGGGGGGGG.......",
    "bBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.wheels([3, 16]);
  c.side([".....P.PP.", "..P.CCPCP.", ".PCCC..P..", "CC..P....."], 4, 5); // sakura branch
  c.top([
    "..................K....",
    "..................K....",
    ".......................",
    ".......................",
    ".......................",
    "..................K....",
    "..................K....",
  ]);
  c.front(["......h....", ".......h...", "...........", "...........", "BHXHKSKHXHB", "BKK.KKK.KKB", "KKKKKKKKKKK"], 7);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.box(-1, 1, 9, 9, 9, 10, c.l.body); // roof scoop
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 2, 6, 6);
  c.mirrors(14, 5);
  return c.done();
}

// ───────── Mitsubishi Lancer Evolution VIII — tall boxy rally sedan, sky-high wing ─────────
export function evo(): CarBuild {
  const c = new CarCtx({ body: 0xf1f2f4, A: 0x1d2f7c, wing: 0x1d2f7c, rim: 0xc9ced4 });
  c.profile([
    "WWW...RRRRRRRRR.........",
    ".w...GGGGGGGGGGG........",
    ".w...GGGGGGGGGGG........",
    ".w..GGGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(10, 10, 5, 7, P.BLACK); // B-pillar: 4 doors
  c.wheels([3, 17], { flare: true });
  c.side(
    [
      ".A..AA..A......A.AAAAAAA",
      "AA.AA..AA.....AA..AAAAAA",
      "A.AA..AA.....AA...AAAAAA",
      "AAA..AA.....AA....AAAAAA",
    ],
    4
  );
  c.top([
    ".................AA.AAAA",
    "..................AA.AAA",
    "...................A.AAA",
    ".....................AAA",
    "...................K.AAA",
    "...................K.AAA",
    "...................K.AAA",
    ".....................AAA",
    "...................A.AAA",
    "..................AA.AAA",
    ".................AA.AAAA",
  ]);
  c.front(["......h....", ".......h...", "...........", "AHHHKSKHHHA", "AKKKKKKKKKA", "AAKKKKKKKAA"], 6);
  c.rear(["...........", "TTT.....TTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.box(-1, 1, 9, 9, 12, 13, c.l.body); // roof vortex scoop
  c.box(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 2, 7, 7);
  c.mirrors(15, 5);
  return c.done();
}

// ───────── Porsche Cayman S — "frog" shape: round fender humps, bug-eye lights, narrow cabin ─────────
export function cayman(): CarBuild {
  const c = new CarCtx({ body: 0x121215, wing: 0x1e1f23, rim: 0xd3d7dc }, { cw: 3 });
  c.profile([
    "WWW...rrrr............",
    ".w...GGGGGGG..........",
    "bbbbGGGGGGGGGG........",
    "BBBBBBBBBBBBBBBBBBBBb.",
    "BBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sym(3, 5, 4, 4, 14, 19, c.l.body); // front fender humps
  c.sym(4, 5, 4, 4, 2, 8, c.l.body); // rear hips
  c.wheels([3, 15]);
  c.side([".........RFFYY........", "........RFFYYYY.......", "........YYYYYYY......."], 3); // flames
  c.side(["KK"], 3, 7); // side intake
  c.top([
    "..................HH..",
    "..................HH..",
    "......................",
    "......................",
    "......................",
    "......................",
    "......................",
    "..................HH..",
    "..................HH..",
  ]);
  c.front([".......h...", ".HH.....HH.", "...........", "KK.KKKKK.KK", "KKKKKKKKKKK"], 5);
  c.rear(["TTT.....TTT", "...........", "....LLL....", "KKKKKKKKKKK"], 4);
  c.sym(1, 1, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 2, 5, 5);
  c.mirrors(12, 4);
  return c.done();
}

// ───────── Mitsubishi Eclipse GT — bubble dome roof, rising beltline, high tail ─────────
export function eclipse(): CarBuild {
  const c = new CarCtx({ body: 0x2d3036, wing: 0x1e1f23, rim: 0x4a4d52 });
  c.profile([
    "......rrrr............",
    "WWW..gggggggg.........",
    ".w.GGGGGGGGGGG........",
    "BBGGGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBb...",
    "BBBBBBBBBBBBBBBBBBBBb.",
    "BBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.wheels([3, 15]);
  c.side([".FFWF..", "FKFFFWW", "FFWFFWW", ".FFF.W."], 4, 6); // tiger
  c.top([
    "................WW....",
    "...............W..W...",
    "...............W.W.W..",
    "................W..WW.",
    ".................W..W.",
    "................W..WW.",
    "...............W.W.W..",
    "...............W..W...",
    "................WW....",
  ]);
  c.front(["......h....", ".......h...", "...........", ".HHH...HHH.", "...........", "BKKKKKKKKKB", "KKKKKKKKKKK"], 7);
  c.rear(["TTTTTTTTTTT", "...........", "...........", "....LLL....", "KKKKKKKKKKK"], 5); // full-width light bar on the high tail
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 2, 6, 6);
  c.mirrors(12, 5);
  return c.done();
}

// ───────── Mazda RX-8 — long flat 4-seat cabin, short hood with fender peaks, stubby tail ─────────
export function rx8(): CarBuild {
  const c = new CarCtx({ body: 0xc4c9cf, wing: 0x1e1f23, rim: 0xd3d7dc });
  c.profile([
    "....RRRRRRRR..........",
    "WW.GGGGGGGGGG.........",
    "w.GGGGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBb.",
    "BBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.clear(-2, 2, 4, 4, 16, 20); // hood dips between the fender peaks
  c.sideFill(8, 8, 5, 6, P.BLACK);
  c.wheels([3, 15]);
  c.side(
    [
      "..K..KK.K.............",
      ".KKKKKKKKKK.K.........",
      "RRRRKKRRKKKRR.K.......",
      "RRRRRRRRRRRRRRR.......",
    ],
    4
  );
  c.top([
    "...................HH.",
    "...................HH.",
    "......................",
    "......................",
    "......................",
    "......................",
    "......................",
    "...................HH.",
    "...................HH.",
  ]);
  c.front(["......h....", ".......h...", ".HH.....HH.", "...KKKKK...", "BKK.KKK.KKB", "KKKKKKKKKKK"], 6);
  c.rear(["TT.......TT", "TT.......TT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 1, 5, 5);
  c.mirrors(13, 5);
  return c.done();
}

// ───────── Toyota Supra (A80) — rounded long nose, bubble cabin, hoop wing ─────────
export function supra(): CarBuild {
  const c = new CarCtx({ body: 0x1b2242, wing: 0x1b2242, rim: 0xb08a4a }, { cw: 3 });
  c.profile([
    ".......rrrr............",
    "WWW..GGGGGGGG..........",
    "....GGGGGGGGGGG........",
    "bBBBBBBBBBBBBBBBBBBBbb.",
    "bBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBb",
    "bBBBBBBBBBBBBBBBBBBBBBc",
  ]);
  c.wheels([3, 16]);
  c.top(["...............ssssssss", ".......................", ".......................", ".......................", "...............ssssssss"]);
  c.side([".......................", "........RFFYY..........", ".........RFY...........", "sssssssssssssssssssssss"], 4);
  c.front(["..WWWWWWW..", "......h....", "...........", "BHXH...HXHB", "B..KKKKK..B", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTBT...TBTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.endplates(0, 2, 5, 5); // the famous hoop wing
  c.box(-3, -2, 1, 1, -1, -1, P.CHROME);
  c.mirrors(13, 5);
  return c.done();
}

// ───────── Lexus IS 300 — compact low sedan, small spoiler ─────────
export function is300(): CarBuild {
  const c = new CarCtx({ body: 0x9a7a2c, wing: 0x1e1f23, rim: 0xc8202a });
  c.profile([
    "....RRRRRRR..........",
    "WW..GGGGGGGGG........",
    "w..GGGGGGGGGGG.......",
    "BBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(8, 8, 5, 6, P.BLACK);
  c.wheels([3, 14]);
  c.side(["..WWW.......", ".WKWKW..RR.R", "..WWW..R.RR.", "..W.W......."], 4, 6); // skull + claws
  c.top([
    "................RRR..",
    "...............RWWWR.",
    "...............RWKWR.",
    "...............RWWWR.",
    "................RRR..",
  ]);
  c.front(["......h....", ".......h...", "...........", "BHXHKKKHXHB", "B.KKKKKKK.B", "KKKKKKKKKKK"], 6);
  c.rear(["...........", "TTX.....XTT", "....LLL....", "KKKKKKKKKKK"], 4);
  c.box(-1, 1, 8, 8, 7, 8, c.l.body); // roof scoop
  c.sym(3, 3, 1, 1, -1, -1, P.CHROME);
  c.endplates(0, 1, 5, 5);
  c.mirrors(12, 5);
  return c.done();
}

// ───────── Volkswagen Golf GTI (Mk5) — narrow tall hatchback ─────────
export function golf(): CarBuild {
  const c = new CarCtx({ body: 0xf2f3f5, A: 0x1f4c8e, rim: 0xd3d7dc }, { hw: 4, cw: 3 });
  c.profile([
    "RRRRRRRRRR.........",
    "GGGGGGGGGGG........",
    "GGGGGGGGGGGG.......",
    "GGGGGGGGGGGGG......",
    "BBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(1, 4, 5, 7, c.l.body); // chunky hatch C-pillar
  c.wheels([3, 12]);
  c.side(["..........AAAAAAAAA", "...........AAAAAAAA", "AA.........AAAAAAAA", "AAAAAAAAAAAAAAAAAAA"], 4);
  c.top(Array.from({ length: 9 }, () => "...............AAAA"));
  c.front([".....h...", "......h..", ".........", "HHRKSKRHH", "AKKKKKKKA", "AAKKKKKAA"], 6);
  c.rear(["TT.....TT", "TT..S..TT", "A..LLL..A", "AKKKKKKKA"], 4);
  c.box(-3, 3, 8, 8, -1, -1, c.l.body); // roof spoiler
  c.box(2, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(11, 5);
  c.decal({ text: "極速", sub: "23", z: 8, y: 3.35, len: 5.5, h: 1.6, color: "#d8282e" });
  return c.done();
}

// ───────── Rockport PD Cruiser — long boxy sedan ─────────
export function police(): CarBuild {
  const c = new CarCtx({ body: 0xf1f2f4, rim: 0x2a2b2f });
  c.profile([
    "......RRRRRRRR...........",
    ".....GGGGGGGGGG..........",
    "....GGGGGGGGGGGG.........",
    "....GGGGGGGGGGGGG........",
    "BBBBBBBBBBBBBBBBBBBBBBBBb",
    "BBBBBBBBBBBBBBBBBBBBBBBBB",
    "BBBBBBBBBBBBBBBBBBBBBBBBB",
    "bBBBBBBBBBBBBBBBBBBBBBBBb",
  ]);
  c.sideFill(10, 10, 5, 7, P.BLACK);
  c.wheels([4, 18]);
  c.side(Array.from({ length: 4 }, () => "KKKKK............KKKKKKKK"), 4);
  c.top(Array.from({ length: 11 }, () => "KKKK.............KKKKKKKK"));
  c.front(["......h....", ".......h...", "KKKKKKKKKKK", "KHHHSSSHHHK", "KOKKKKKKKOK", "KKKKKKKKKKK"], 6);
  c.rear(["KKKKKKKKKKK", "TTTKKKKKTTT", "KKKKLLLKKKK", "KKKKKKKKKKK"], 4);
  c.lightbar(9, 10, 9, 4);
  c.box(3, 3, 1, 1, -1, -1, P.CHROME);
  c.mirrors(15, 5, P.BLACK);
  c.decal({ text: "POLICE", z: 10.5, y: 3.35, len: 8, h: 1.7, color: "#111214" });
  return c.done();
}

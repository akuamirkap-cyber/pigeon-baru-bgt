// ============================================================================
//  SLING DRIFT 3D — SISTEM 20 LEVEL KAMPANYE
//  Setiap level punya: tema visual sendiri, seed deterministik (lintasan sama
//  setiap main → bisa dipelajari), skrip seksi lintasan yang disusun tangan,
//  jarak finish, dan tingkat kesulitan.
// ============================================================================
import type { Step } from './game';

export type ThemeName =
  | 'violet' | 'candy' | 'sunset' | 'night' | 'desert'
  | 'forest' | 'snow' | 'volcano' | 'ocean' | 'hotwheels';

export type Theme = {
  label: string;
  fog: number;
  sky: [string, string, string];
  road: number; roadSide: number; roadBottom: number; line: number;
  dust: [number, number, number];
  bld: [number, number, number, number];
  bldCap: number; bldBeacon: number;
  cloud: number; cloudEm: number; street: number;
};

export const THEMES: Record<ThemeName, Theme> = {
  violet: {
    label: 'Senja Violet',
    fog: 0xc9b8ff, sky: ['#8f7bff', '#c9b8ff', '#efe6ff'],
    road: 0x40404e, roadSide: 0x9aa0c2, roadBottom: 0x666a85, line: 0xf5f5f5,
    dust: [0x9aa0b8, 0xffffff, 0xe0606e],
    bld: [0x8f93c9, 0x7d84c2, 0xa5a8d8, 0x6f76b8], bldCap: 0xe8e6f5, bldBeacon: 0xff4455,
    cloud: 0xffffff, cloudEm: 0x333344, street: 0x35314a,
  },
  candy: {
    label: 'Permen Pastel',
    fog: 0xcfe8ff, sky: ['#5fc8ff', '#bfe6ff', '#ffd3ec'],
    road: 0xfdf8ff, roadSide: 0xc4b3f2, roadBottom: 0x9d8ae0, line: 0xffd6e6,
    dust: [0xd9ccff, 0xffffff, 0xff8fb0],
    bld: [0xffc2e0, 0xb3e5ff, 0xd6c2ff, 0xffe6a8], bldCap: 0xffffff, bldBeacon: 0xff8fb0,
    cloud: 0xffffff, cloudEm: 0x3a3a55, street: 0x4a3f5e,
  },
  sunset: {
    label: 'Sunset Tropis',
    fog: 0xffb27d, sky: ['#ff5f6d', '#ff9a76', '#ffd6a5'],
    road: 0x4a3a44, roadSide: 0xd8875a, roadBottom: 0x8a5a44, line: 0xffe8c9,
    dust: [0xffc27a, 0xffffff, 0xff5f6d],
    bld: [0x6b4a5e, 0x7d5468, 0x5a3f52, 0x8a5a6e], bldCap: 0xffd9a0, bldBeacon: 0xffe066,
    cloud: 0xffe0c8, cloudEm: 0x442200, street: 0x3f2f35,
  },
  night: {
    label: 'Kota Neon',
    fog: 0x241a52, sky: ['#0b0620', '#241a52', '#3d2b6e'],
    road: 0x232333, roadSide: 0x3d3d5c, roadBottom: 0x2a2a40, line: 0x01cdfe,
    dust: [0xff71ce, 0x01cdfe, 0xfffb96],
    bld: [0x2f2b52, 0x3a3560, 0x252244, 0x443f6e], bldCap: 0x01cdfe, bldBeacon: 0xff71ce,
    cloud: 0x332e58, cloudEm: 0x120a2e, street: 0x0f0c24,
  },
  desert: {
    label: 'Gurun Pasir',
    fog: 0xf7d9a8, sky: ['#f79d65', '#f7c878', '#fdeec9'],
    road: 0x8a6f4d, roadSide: 0xd9b878, roadBottom: 0xa8855a, line: 0xfff6d8,
    dust: [0xe8cf9a, 0xffffff, 0xd88a3a],
    bld: [0xc9955c, 0xb8847a, 0xa89468, 0xd9b878], bldCap: 0xfff0c8, bldBeacon: 0xff6a3a,
    cloud: 0xffffff, cloudEm: 0x443a22, street: 0x8a6a3f,
  },
  forest: {
    label: 'Hutan Pinus',
    fog: 0xa8d8b0, sky: ['#2e7d5b', '#7cc59a', '#d8f3d0'],
    road: 0x3d4a42, roadSide: 0x5e7a6a, roadBottom: 0x2f3a33, line: 0xe8ffe8,
    dust: [0xa8e8c0, 0xffffff, 0x3a8a5c],
    bld: [0x2f5a44, 0x3a6b50, 0x274a38, 0x4a7a5c], bldCap: 0xa8e8c0, bldBeacon: 0xffc93c,
    cloud: 0xf0fff0, cloudEm: 0x1e3a2a, street: 0x24382c,
  },
  snow: {
    label: 'Pegunungan Salju',
    fog: 0xe8f2ff, sky: ['#7ea8d8', '#c2dcff', '#ffffff'],
    road: 0x5a6274, roadSide: 0xe8eefc, roadBottom: 0x8a94ac, line: 0xffffff,
    dust: [0xe8eefc, 0xffffff, 0x7ea8d8],
    bld: [0x8a9ab8, 0xa8b8d4, 0x7484a4, 0xc2cede], bldCap: 0xffffff, bldBeacon: 0xff5c5c,
    cloud: 0xffffff, cloudEm: 0x334455, street: 0x6a7086,
  },
  volcano: {
    label: 'Gunung Merapi',
    fog: 0x58241f, sky: ['#2b0f0f', '#712a1e', '#c2452a'],
    road: 0x2e2226, roadSide: 0x5c3a32, roadBottom: 0x40302c, line: 0xffb03a,
    dust: [0xff7a1a, 0xffc93c, 0xff4455],
    bld: [0x3a2a28, 0x4a322c, 0x2e2220, 0x553c34], bldCap: 0xff6a2a, bldBeacon: 0xffc93c,
    cloud: 0x5a332a, cloudEm: 0x1a0a06, street: 0x241412,
  },
  ocean: {
    label: 'Pesisir Tropis',
    fog: 0x9fe8e0, sky: ['#0e9bb5', '#4fd0d8', '#d8fffa'],
    road: 0x2f4a54, roadSide: 0x5e9aa4, roadBottom: 0x2a3a42, line: 0xd8fffa,
    dust: [0x9fe8e0, 0xffffff, 0x0e9bb5],
    bld: [0xe8f6f6, 0x9fd0d8, 0x6ab0c0, 0xffe8b0], bldCap: 0xffffff, bldBeacon: 0xff6a5c,
    cloud: 0xffffff, cloudEm: 0x0e3a44, street: 0x1e4a54,
  },
  // Lintasan oranye khas HOT WHEELS: aspal oranye menyala, langit biru cerah,
  // rel putih — cocok untuk spiral keong & lompatan gila.
  hotwheels: {
    label: 'Hot Wheels',
    fog: 0x8ec9f0, sky: ['#1565c0', '#42a5f5', '#d9f2ff'],
    road: 0xff6a1a, roadSide: 0xffffff, roadBottom: 0xb3470f, line: 0xfff3e0,
    dust: [0xffb03a, 0xffffff, 0xff6a1a],
    bld: [0xff8a2a, 0xffd23f, 0x2e9bd6, 0xffffff], bldCap: 0xffffff, bldBeacon: 0xff4455,
    cloud: 0xffffff, cloudEm: 0x2b5a80, street: 0x0d47a1,
  },
};

// ---------------------------------------------------------------------------
//  Helper penyusun seksi (Step) — dipakai untuk merancang lintasan tangan
// ---------------------------------------------------------------------------
const PI = Math.PI;
const S = (len: number): Step => ({ k: 's', len });
const A = (sweep: number, R: number, dir?: 'flip' | 'same'): Step => ({
  k: 'a', sweep, R, flip: dir === 'flip', same: dir === 'same',
});
const J = (): Step => ({ k: 'j' });
const P = (): Step => ({ k: 'p' });

type Part = Step | Step[];
const seq = (...parts: Part[]): Step[] => parts.flat() as Step[];

/** Landai 60° — pembuka ramah pemula */
const easy = (r = 8): Step[] => [S(10), A(PI / 3, r)];
/** Klasik 90° */
const classic = (r = 7): Step[] => [S(6), A(PI / 2, r)];
/** Tikungan cepat radius besar */
const fast = (r = 12.5): Step[] => [S(9), A(PI / 2, r)];
/** Sapuan lebar 120° */
const sweeper = (r = 9.5): Step[] => [S(7), A((2 * PI) / 3, r)];
/** Kurva-S: dua tikungan 90° berlawanan */
const sCurve = (r = 6.8): Step[] => [S(5), A(PI / 2, r), A(PI / 2, r, 'flip')];
/** Apex ganda: dua tikungan searah radius berbeda */
const double = (r = 7.0): Step[] => [S(5), A(PI / 3, r), A(PI / 3, r + 2.5, 'same')];
/** Esses: zig-zag 3 tikungan beruntun */
const esses = (r = 6.5): Step[] => [S(5), A(PI / 2, r), A(PI / 2, r, 'flip'), A(PI / 2, r, 'flip')];
/** Slalom landai */
const slalom = (r = 9.2): Step[] => [S(4), A(PI / 3, r), A(PI / 3, r, 'flip'), A(PI / 3, r, 'flip')];
/** Hook ketat: 90° lalu counter 90° yang langsung menyambung lurus */
const hook = (r = 6.2): Step[] => [S(5), A(PI / 2, r), S(3), A(PI / 2, r, 'flip')];
/** Hairpin: hook tiga-lapis sangat rapat */
const hairpin = (r = 6.1): Step[] => [S(6), A(PI / 2, r), S(4), A(PI / 2, r, 'flip'), S(3), A(PI / 2, r, 'flip')];
/** Lurusan + lompatan */
const jumpRun = (): Step[] => [S(12), J(), S(10)];
/** Lurusan panjang → spiral "keong" multi-lantai */
const spiral = (): Step[] => [S(24), P()];

export type LevelDef = {
  id: number;
  name: string;
  theme: ThemeName;
  tag: string;
  desc: string;
  diff: number; // 1..5 bintang kesulitan
  dist: number; // jarak finish (meter)
  seed: number; // seed RNG deterministik
  rare?: boolean; // edisi langka (HOT WHEELS)
  build: () => Step[];
};

const L = (
  id: number, name: string, theme: ThemeName, tag: string, desc: string,
  diff: number, dist: number, seed: number, build: () => Step[], rare?: boolean,
): LevelDef => ({ id, name, theme, tag, desc, diff, dist, seed, build, rare });

export const LEVELS: LevelDef[] = [
  L(1, 'Pemanasan Senja', 'violet', 'BELAJAR DRIFT',
    'Tikungan lebar dan lurusan panjang. Tempat terbaik jatuh cinta pada drift.',
    1, 650, 1101,
    () => seq(S(36), easy(8.0), easy(7.6), classic(7.4), easy(7.2), sCurve(7.4), classic(7.0), easy(7.2))),

  L(2, 'Lurusan Sunset', 'sunset', 'NOS ALLEY',
    'Pol-polan lurus panjang di bawah langit jingga. Full NOS, full gas!',
    1, 800, 1202,
    () => seq(S(36), S(28), fast(13.5), S(22), fast(12.5), S(26), A(PI / 3, 12.0), S(18))),

  L(3, 'Tikungan Manis', 'candy', 'PASTEL RUN',
    'Dunia permen pastel dengan kurva-S yang lembut dan mengalir.',
    2, 850, 1303,
    () => seq(S(36), sCurve(7.6), easy(7.2), sCurve(7.2), slalom(9.6), sCurve(7.0), easy(6.9))),

  L(4, 'S-Curve Tropis', 'ocean', 'S-CURVE',
    'Bolak-balik kurva-S ala pesisir. Jaga momentum, jangan panik.',
    2, 950, 1404,
    () => seq(S(36), sCurve(7.1), sCurve(6.9), classic(7.0), sCurve(6.8), fast(11.5), sCurve(6.7))),

  L(5, 'Slalom Sungai', 'forest', 'SLALOM',
    'Selip-selip landai di antara pinus. Latih feeling counter-steer kamu.',
    2, 1000, 1505,
    () => seq(S(36), slalom(9.6), slalom(9.2), easy(7.0), slalom(8.8), classic(6.8))),

  L(6, 'Kota Neon', 'night', 'NEON NIGHT',
    'Drivel malam hari di kota neon. Garis aspal menyala, refleksmu diuji.',
    2, 1050, 1606,
    () => seq(S(36), classic(6.8), fast(11.8), hook(6.4), classic(6.6), S(14), hook(6.3))),

  L(7, 'Esses Hijau', 'forest', 'ESSES',
    'Zig-zag tiga tikungan beruntun. Matikan kecemasan, nyalakan ritme.',
    2, 1100, 1707,
    () => seq(S(36), esses(6.8), easy(6.8), esses(6.5), slalom(8.6), esses(6.3))),

  L(8, 'Pantai Drift', 'ocean', 'SWEEPER',
    'Sapuan lebar 120° di tepi pantai. Gas penuh di tikungan terpanjang.',
    3, 1150, 1808,
    () => seq(S(36), sCurve(6.7), sweeper(9.8), fast(11.2), sCurve(6.5), sweeper(9.4))),

  L(9, 'Hairpin Gurun', 'desert', 'HAIRPIN',
    'Tikungan jepit di tengah gurun. Rem, kait, drift, ulangi.',
    3, 1200, 1909,
    () => seq(S(36), hairpin(6.3), easy(6.8), hairpin(6.1), hook(6.2), hairpin(6.0))),

  L(10, 'Double Apex', 'snow', 'DOUBLE APEX',
    'Dua apex radius berbeda dalam satu tarikan. Baca geometri tikungan.',
    3, 1250, 2010,
    () => seq(S(36), double(6.8), esses(6.4), double(6.5), classic(6.3), double(6.2))),

  L(11, 'Lava Jump', 'volcano', 'JUMP',
    'Lompatan ramp beruntun di atas aliran lava. Lepas tepat di bibir ramp!',
    3, 1300, 2111,
    () => seq(S(36), jumpRun(), S(8), jumpRun(), classic(6.4), jumpRun())),

  L(12, 'Kelok Maut', 'night', 'TECHNICAL',
    'Rangkaian hook dan tikungan 90° rapat. Fokus penuh, tanpa ampun.',
    4, 1400, 2212,
    () => seq(S(36), hook(6.0), classic(5.9), hairpin(5.9), classic(5.8), hook(5.8), classic(5.7))),

  L(13, 'Suroboyo Tempel', 'sunset', 'STREET RACE',
    'Rasa balapan jalanan Surabaya: hairpin, esses, lurusan, semuanya ada.',
    4, 1450, 2313,
    () => seq(S(36), hairpin(6.1), esses(6.3), fast(10.8), esses(6.1), hairpin(5.9))),

  L(14, 'Keong Salju', 'snow', 'SPIRAL',
    'Naik lantai-lantai spiral "keong" di pegunungan. Jangan melihat ke bawah!',
    4, 1500, 2414,
    () => seq(S(36), spiral(), S(18), double(6.4), spiral())),

  L(15, 'Tornado Twist', 'ocean', 'INSANE ESSES',
    'Esses tanpa akhir di atas laut. Kait tiang, ayun, drift, berulang.',
    4, 1550, 2515,
    () => seq(S(36), sCurve(6.2), esses(6.0), sCurve(6.1), slalom(7.8), esses(5.9))),

  L(16, 'Drift Neraka', 'volcano', 'HELL DRIFT',
    'Radius terkecil di atas lahar. Hanya drift-god yang pulang hidup.',
    5, 1650, 2616,
    () => seq(S(36), hook(5.7), hairpin(5.6), classic(5.7), esses(5.8), hairpin(5.6), hook(5.6))),

  L(17, 'Tanjakan Gurun', 'desert', 'GT CHALLENGE',
    'Kombinasi kecepatan tinggi + hairpin. GT di atas pasir.',
    5, 1750, 2717,
    () => seq(S(36), fast(10.2), hairpin(5.8), double(5.9), slalom(7.2), hairpin(5.6))),

  L(18, 'Turbo Midnight', 'night', 'MIDNIGHT GP',
    'Balapan tengah malam: padat, gelap, dan tanpa garis finis yang mudah.',
    5, 1850, 2818,
    () => seq(S(36), esses(6.0), fast(9.8), hook(5.6), double(5.7), esses(5.8), hairpin(5.7))),

  L(19, 'Keong Langit', 'violet', 'SKY SPIRAL',
    'Spiral keong menuju langit senja — drift di antara lantai-lantai awan.',
    5, 2000, 2919,
    () => seq(S(36), double(6.0), spiral(), esses(5.9), jumpRun(), spiral())),

  L(20, 'Sling Drift GP', 'volcano', 'GRAND FINALE',
    'Grand Prix pamungkas: semua pola, semua tantangan, 2200 meter neraka.',
    5, 2200, 3020,
    () => seq(S(36), hairpin(5.7), esses(5.8), jumpRun(), hairpin(5.6), sweeper(8.6), classic(5.6), spiral(), esses(5.7))),

  // =============== EDISI LANGKA: HOT WHEELS ===============
  L(21, 'HW: Ember Express', 'hotwheels', 'LANGKA 🔥',
    'Lintasan oranye super cepat: lompatan beruntun & sapuan lebar menyala.',
    4, 1250, 3102,
    () => seq(S(36), S(20), jumpRun(), sweeper(9.2), jumpRun(), fast(11.0), S(16), sweeper(8.8)), true),

  L(22, 'HW: Loop Lava', 'hotwheels', 'LANGKA 🔥',
    'Dua corong keong oranye di atas lahar — rasakan corkscrew Hot Wheels!',
    4, 1400, 3203,
    () => seq(S(36), spiral(), jumpRun(), hairpin(6.0), spiral()), true),

  L(23, 'HW: Spiral Cyclone', 'hotwheels', 'LANGKA 🔥',
    'Pusaran maut: spiral, esses, spiral — semakin lama di aspal makin pusing.',
    5, 1600, 3305,
    () => seq(S(36), esses(6.2), spiral(), sCurve(6.0), spiral(), esses(6.0)), true),

  L(24, 'HW: Firestorm Alley', 'hotwheels', 'LANGKA 🔥',
    'Lorong api terpadat: hook, hairpin, dan lompatan tanpa henti.',
    5, 1800, 3406,
    () => seq(S(36), hook(5.7), jumpRun(), hairpin(5.6), double(5.6), jumpRun(), hairpin(5.5), hook(5.5)), true),

  L(25, 'HW: Grand Prix Inferno', 'hotwheels', 'LANGKA 🔥',
    'Grand Prix pamungkas HOT WHEELS: dua spiral langit & 2300 meter neraka oranye.',
    5, 2300, 3507,
    () => seq(S(36), spiral(), esses(5.9), jumpRun(), hairpin(5.6), sweeper(8.4), spiral(), classic(5.5), jumpRun(), hairpin(5.4)), true),
];

export const LEVEL_COUNT = LEVELS.length;
export const TOTAL_STARS = LEVEL_COUNT * 3;
export const levelById = (id: number): LevelDef | undefined => LEVELS.find((l) => l.id === id);

// ---------------------------------------------------------------------------
//  Progres pemain (localStorage): bintang, skor terbaik, level terbuka
// ---------------------------------------------------------------------------
export type LevelProgress = {
  /** bintang tertinggi per level (0..3) */
  stars: Record<number, number>;
  /** skor terbaik per level */
  best: Record<number, number>;
  /** level tertinggi yang terbuka (1..20) */
  unlocked: number;
};

/** Semua lintasan dibuka sejak awal (permintaan: player bisa langsung menjelajahi semua track) */
export const UNLOCK_ALL = true;

const KEY = 'slingdrift3d-levels-v1';
const fresh = (): LevelProgress => ({ stars: {}, best: {}, unlocked: LEVEL_COUNT });

export function loadProgress(): LevelProgress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return fresh();
    const p = JSON.parse(raw) as Partial<LevelProgress>;
    return {
      stars: p?.stars && typeof p.stars === 'object' ? p.stars : {},
      best: p?.best && typeof p.best === 'object' ? p.best : {},
      unlocked: UNLOCK_ALL ? LEVEL_COUNT : Math.min(LEVEL_COUNT, Math.max(1, Number(p?.unlocked) || 1)),
    };
  } catch {
    return fresh();
  }
}

export function resetProgress(): LevelProgress {
  const p = fresh();
  try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* abaikan */ }
  return p;
}

export function totalStars(p: LevelProgress): number {
  return Object.values(p.stars).reduce((m, s) => m + (s || 0), 0);
}

export function levelsCleared(p: LevelProgress): number {
  return Object.values(p.stars).filter((s) => (s || 0) > 0).length;
}

/** Simpan hasil finish level. Mengembalikan ringkasan untuk layar hasil. */
export function recordLevelResult(id: number, score: number, falls: number) {
  const p = loadProgress();
  // Kriteria bintang: ⭐ finish • ⭐⭐ maks 2× jatuh • ⭐⭐⭐ tanpa jatuh sama sekali
  const earned = falls === 0 ? 3 : falls <= 2 ? 2 : 1;
  const prevStars = p.stars[id] ?? 0;
  p.stars[id] = Math.max(prevStars, earned);
  const prevBest = p.best[id] ?? 0;
  const newBest = score > prevBest;
  if (newBest) p.best[id] = score;
  if (id >= p.unlocked && id < LEVEL_COUNT) p.unlocked = id + 1;
  try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* abaikan */ }
  return { earned, stars: p.stars[id], newBest, progress: p, totalStars: totalStars(p) };
}


// ============ MUSIK ADAPTIF (tangga nada pentatonik, full synth) ============
export type MusicStyle = 'off' | 'ceria' | 'ngebut';

const MAJ_PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];
const MIN_PENTA = [0, 3, 5, 7, 10, 12, 15, 17, 19, 22, 24];
// melodi 32-step, -1 = istirahat
const CERIA_LEAD = [2,-1,3,-1,4,3,2,-1, 2,-1,3,-1,4,-1,5,-1, 5,-1,4,-1,3,-1,2,-1, 3,2,1,2,0,-1,0,-1];
const NGEBUT_LEAD = [4,4,-1,3,2,-1,2,3, 4,4,-1,5,4,3,2,1, 0,-1,0,1,2,-1,2,3, 4,3,2,1,0,-1,-1,-1];
const CERIA_ROOTS = [0, 7, 9, 5];    // C - G - Am - F (bagian bass, riang)
const NGEBUT_ROOTS = [0, 0, -4, -2]; // A - A - F - G (ngebut!)

export class Music {
  ctx: AudioContext | null = null;
  level!: GainNode;
  leadBus!: GainNode;
  noiseBuf: AudioBuffer | null = null;
  style: MusicStyle = 'ceria';
  step = 0;
  nextT = 0;
  lastLevel = -1;

  begin(ctx: AudioContext, master: GainNode, noise: AudioBuffer) {
    if (this.ctx) return;
    this.ctx = ctx;
    this.noiseBuf = noise;
    this.level = ctx.createGain(); this.level.gain.value = 0;
    this.level.connect(master);
    this.leadBus = ctx.createGain();
    const dry = ctx.createGain(); dry.gain.value = 0.8;
    this.leadBus.connect(dry).connect(this.level);
    // echo biar melodi berasa pro
    const dly = ctx.createDelay(1); dly.delayTime.value = 0.27;
    const fb = ctx.createGain(); fb.gain.value = 0.32;
    const wet = ctx.createGain(); wet.gain.value = 0.35;
    this.leadBus.connect(dly); dly.connect(fb).connect(dly); dly.connect(wet).connect(this.level);
  }
  setStyle(s: MusicStyle) { this.style = s; this.step = 0; }

  private toneAt(t: number, freq: number, dur: number, type: OscillatorType, vol: number, dest?: AudioNode, slideTo?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(Math.max(20, freq), t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest || this.level);
    o.start(t); o.stop(t + dur + 0.05);
  }
  private noiseAt(t: number, dur: number, freq: number, vol: number, type: BiquadFilterType) {
    const ctx = this.ctx!;
    const s = ctx.createBufferSource(); s.buffer = this.noiseBuf!;
    s.playbackRate.value = 0.9 + Math.random() * 0.2;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    if (type === 'bandpass') f.Q.value = 1.2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.level);
    s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.02);
  }

  update(_dt: number, run: boolean, intensity: number, drift: boolean, combo: number) {
    if (!this.ctx) return;
    const target = run && this.style !== 'off' ? 0.36 * intensity : 0;
    if (target !== this.lastLevel) {
      this.level.gain.setTargetAtTime(target, this.ctx.currentTime, 0.25);
      this.lastLevel = target;
    }
    if (!run || this.style === 'off') return;
    const ngebut = this.style === 'ngebut';
    const stepDur = 60 / (ngebut ? 150 : 132) / 4;
    const ct = this.ctx.currentTime;
    if (this.nextT < ct - 0.25) this.nextT = ct + 0.06;
    let guard = 0;
    while (this.nextT < ct + 0.18 && guard++ < 12) {
      this.playStep(this.step, this.nextT, ngebut, drift, combo);
      this.nextT += stepDur;
      this.step = (this.step + 1) % 32;
    }
  }

  private playStep(s: number, t: number, ngebut: boolean, drift: boolean, combo: number) {
    const bar = Math.floor(s / 8) % 4;
    if (!ngebut) {
      if (s % 4 === 0) this.toneAt(t, 150, 0.12, 'sine', 0.5, undefined, 42);
      if (s % 2 === 0) this.noiseAt(t, 0.035, 7500, 0.05, 'highpass');
      if (s % 2 === 0) {
        const f = 130.81 * Math.pow(2, CERIA_ROOTS[bar] / 12);
        this.toneAt(t, f, 0.2, 'triangle', 0.17, undefined, f * 0.995);
      }
      const deg = CERIA_LEAD[s];
      if (deg >= 0) {
        const up = combo >= 3 ? 12 : 0;
        const f = 261.63 * Math.pow(2, (MAJ_PENTA[deg] + up) / 12);
        this.toneAt(t, f, 0.24, 'triangle', 0.11, this.leadBus);
        if (combo >= 4) {
          const f2 = 261.63 * Math.pow(2, (MAJ_PENTA[Math.min(deg + 2, MAJ_PENTA.length - 1)] + up) / 12);
          this.toneAt(t + 0.02, f2, 0.2, 'sine', 0.05, this.leadBus);
        }
      }
      if (drift && s % 2 === 1) {
        const f = 523.25 * Math.pow(2, MAJ_PENTA[(s * 3) % 8] / 12);
        this.toneAt(t, f, 0.12, 'sine', 0.045, this.leadBus);
      }
    } else {
      if (s % 4 === 0) this.toneAt(t, 160, 0.11, 'sine', 0.55, undefined, 40);
      if (s % 8 === 4) { this.noiseAt(t, 0.12, 1900, 0.16, 'bandpass'); this.toneAt(t, 195, 0.09, 'triangle', 0.1); }
      this.noiseAt(t, s % 2 ? 0.025 : 0.04, 8000, s % 2 ? 0.03 : 0.055, 'highpass');
      if (s % 2 === 0) {
        const off = NGEBUT_ROOTS[bar] + (s % 8 === 6 ? 12 : 0);
        const f = 110 * Math.pow(2, off / 12);
        this.toneAt(t, f, 0.16, 'sawtooth', 0.08, undefined, f);
      }
      const deg = NGEBUT_LEAD[s];
      if (deg >= 0) {
        const up = combo >= 3 ? 12 : 0;
        const f = 220 * Math.pow(2, (MIN_PENTA[deg] + up) / 12);
        this.toneAt(t, f, 0.14, 'square', 0.05, this.leadBus);
        this.toneAt(t, f / 2, 0.14, 'triangle', 0.06, this.leadBus);
      }
    }
  }
}

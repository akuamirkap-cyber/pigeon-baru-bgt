import { useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from 'react';
import {
  Game, CAM_NAMES, NOS, RESPAWN_T,
  type BotMode, type CamMode, type CarName, type EdgeName, type FxName, type Mode, type NosColor,
  type RaceEnd, type RaceInfo, type RoadBuild, type SkinName, type SpeedName, type Telemetry,
} from './game';
import type { MusicStyle } from './audio';
import { GARAGE, CATEGORIES, CATEGORY_LABEL, carInfo, validCar, renderThumb, disposeThumbRenderer, type Category } from './carmodel';
import { LEVELS, LEVEL_COUNT, TOTAL_STARS, THEMES, UNLOCK_ALL, loadProgress, recordLevelResult, resetProgress, totalStars, levelsCleared, levelById, type LevelDef, type LevelProgress, type ThemeName } from './levels';
import { trackPreview } from './trackpreview';
import { cn } from './utils/cn';

type Screen = 'menu' | 'play' | 'over';
type Tab = 'race' | 'garage' | 'look' | 'audio';
type EndLevel = { id: number; name: string; theme: ThemeName; earned: number; stars: number; newBest: boolean; finished: boolean };
type End = { kind: 'run'; score: number; falls: number } | { kind: 'race'; r: RaceEnd; level?: EndLevel };

const CAM_ICON = ['🎥', '🏎️', '🛸'];
const MODES: { id: Mode; icon: string; label: string; sub: string }[] = [
  { id: 'drift', icon: '🏎️', label: 'Drift', sub: 'Kait tiang' },
  { id: 'free', icon: '💨', label: 'Bebas', sub: 'Tanpa tali' },
  { id: 'spidey', icon: '🕷️', label: 'Spidey', sub: 'Ayun jaring' },
];
const BOTS: { id: BotMode; icon: string; label: string; sub: string; badge?: string }[] = [
  { id: 'off', icon: '🚫', label: 'Solo', sub: 'Tanpa lawan' },
  { id: 'ghost', icon: '👻', label: 'Ghost', sub: '1 bot tembus' },
  { id: 'solid', icon: '🧱', label: 'Solid', sub: '1 bot senggol' },
  { id: 'ghost5', icon: '👻', label: 'Ghost ×5', sub: '5 bot hantu', badge: 'BARU' },
];
const SKIN_OPTS: { id: SkinName; label: string; sub: string; dot: string }[] = [
  { id: 'asphalt', label: 'Aspal', sub: 'Gelap & ungu', dot: 'linear-gradient(135deg,#40404e,#8f7bff)' },
  { id: 'candy', label: 'Candy', sub: 'Pastel manis', dot: 'linear-gradient(135deg,#fdf8ff,#ff9ec8)' },
];
const EDGES: { id: EdgeName; icon: string; label: string }[] = [
  { id: 'hidden', icon: '🙈', label: 'Hidden' },
  { id: 'flat', icon: '▬', label: 'Flat' },
  { id: 'rail', icon: '🛡️', label: 'Rail' },
];
const FXS: { id: FxName; icon: string; label: string; sub: string }[] = [
  { id: 'V1', icon: '🧃', label: 'Juicer', sub: 'Berhamburan' },
  { id: 'V2', icon: '🧱', label: 'Rapi', sub: 'Jatuh teratur' },
];
const ROADBUILDS: { id: RoadBuild; icon: string; label: string; sub: string }[] = [
  { id: 'instant', icon: '✨', label: 'Langsung', sub: 'Muncul instan' },
  { id: 'wave', icon: '🌊', label: 'Bangun', sub: 'Naik bergelombang' },
];
const MUSICS: { id: MusicStyle; icon: string; label: string }[] = [
  { id: 'off', icon: '🔇', label: 'Off' },
  { id: 'ceria', icon: '🌈', label: 'Ceria' },
  { id: 'ngebut', icon: '🔥', label: 'Ngebut' },
];
const NOSS: { id: NosColor; label: string }[] = [
  { id: 'blue', label: 'Biru' },
  { id: 'purple', label: 'Ungu' },
  { id: 'green', label: 'Hijau' },
];
const GOALS: { id: string; icon: string; label: string; sub: string }[] = [
  { id: '600', icon: '⚡', label: '600 m', sub: 'Sprint' },
  { id: '1100', icon: '🏁', label: '1100 m', sub: 'Normal' },
  { id: '2000', icon: '🛣️', label: '2000 m', sub: 'Maraton' },
  { id: '0', icon: '♾️', label: 'Endless', sub: 'Tanpa finish' },
];
const SPEED_OPTS: { id: SpeedName; icon: string; label: string; sub: string }[] = [
  { id: 'santai', icon: '🐢', label: 'Santai', sub: 'Aman & pemula' },
  { id: 'normal', icon: '🏎️', label: 'Normal', sub: 'Seimbang' },
  { id: 'kencang', icon: '🚀', label: 'Kencang', sub: 'Menantang' },
];
const MODE_LABEL: Record<Mode, string> = { drift: 'Drift', free: 'Bebas', spidey: 'Spidey' };
const TAGLINE: Record<Mode, string> = {
  drift: 'Tahan untuk kait tiang & ngedrift, lepas pas di titik emas. SPACE = NOS!',
  free: 'Tahan = ngepot, lepas = lurus. Tanpa tali, murni skill!',
  spidey: 'Tahan = tembak jaring, lepas = melayang. Jadi Spidey!',
};
const hex = (n: number) => '#' + n.toString(16).padStart(6, '0');
const bestKey = (m: Mode) => (m === 'spidey' ? 'slingdrift3d-best-spidey' : m === 'free' ? 'slingdrift3d-best-free' : 'slingdrift3d-best');
const load = <T extends string>(key: string, def: T): T => (localStorage.getItem(key) as T) || def;

// ---------- komponen kecil ----------
function Section({ label, children, cols = 3 }: { label: string; children: ReactNode; cols?: 2 | 3 }) {
  return (
    <div>
      <div className="font-hud mb-2 flex items-center gap-2 text-[10px] font-bold tracking-[0.26em] text-white/50">
        <span>{label}</span><span className="h-px flex-1 bg-gradient-to-r from-white/25 to-transparent" />
      </div>
      <div className={cn('grid gap-2', cols === 2 ? 'grid-cols-2' : 'grid-cols-3')}>{children}</div>
    </div>
  );
}

function Choice({ active, onClick, icon, label, sub, badge, dot }: {
  active: boolean; onClick: () => void; icon?: ReactNode; label: string; sub?: string; badge?: string; dot?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'font-hud relative flex min-w-0 flex-col items-center justify-center gap-0.5 rounded-2xl border px-1.5 py-2.5 text-center transition-all duration-150 active:scale-95',
        active
          ? 'border-amber-300/80 bg-gradient-to-b from-amber-300/30 via-amber-300/10 to-pink-500/20 text-white shadow-[0_0_0_1px_rgba(252,211,77,.35),0_10px_26px_-8px_rgba(251,191,36,.6)]'
          : 'border-white/10 bg-white/[0.06] text-white/70 hover:bg-white/[0.12] hover:text-white',
      )}
    >
      {badge && <span className="absolute -right-1 -top-2 rounded-full bg-gradient-to-r from-pink-500 to-orange-400 px-1.5 py-px text-[9px] font-bold tracking-wider text-white shadow">{badge}</span>}
      {dot ? <span className="mb-0.5 h-5 w-5 rounded-md border border-white/40" style={{ background: dot }} /> : <span className="text-xl leading-none">{icon}</span>}
      <span className="max-w-full truncate text-[13px] font-bold leading-tight">{label}</span>
      {sub && <span className="max-w-full truncate text-[10px] font-medium leading-tight text-white/45">{sub}</span>}
    </button>
  );
}

function Gauge({ tele }: { tele: RefObject<Telemetry> }) {
  const arc = useRef<SVGPathElement>(null);
  const kmh = useRef<HTMLDivElement>(null);
  const gear = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0, sm = 0;
    const loop = () => {
      const t = tele.current;
      sm += (t.rpm - sm) * 0.4;
      arc.current?.setAttribute('stroke-dasharray', `${(Math.min(1, Math.max(0, sm)) * 100).toFixed(1)} 100`);
      arc.current?.setAttribute('stroke', sm > 0.92 ? '#fb3b5f' : 'url(#gg)');
      if (kmh.current) kmh.current.textContent = String(Math.round(t.kmh));
      if (gear.current) gear.current.textContent = t.gear > 0 ? String(t.gear) : 'N';
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [tele]);
  const A = 'M 53.33 146.67 A 66 66 0 1 1 146.67 146.67';
  return (
    <div className="glass-soft pointer-events-none absolute bottom-3 right-3 h-[138px] w-[138px] rounded-full sm:bottom-4 sm:right-4 sm:h-[172px] sm:w-[172px]">
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full">
        <defs>
          <linearGradient id="gg" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0" stopColor="#22d3ee" /><stop offset=".55" stopColor="#fbbf24" /><stop offset="1" stopColor="#f43f5e" />
          </linearGradient>
        </defs>
        <path d={A} pathLength={100} fill="none" stroke="rgba(255,255,255,.13)" strokeWidth="12" strokeLinecap="round" />
        <path d={A} pathLength={100} fill="none" stroke="rgba(255,255,255,.35)" strokeWidth="5" strokeDasharray="0.35 4.65" transform="translate(100 100) scale(.82) translate(-100 -100)" />
        <path ref={arc} d={A} pathLength={100} fill="none" stroke="url(#gg)" strokeWidth="12" strokeLinecap="round" strokeDasharray="0 100" />
      </svg>
      <div className="font-hud absolute inset-0 flex flex-col items-center justify-center pt-1">
        <div ref={kmh} className="font-display text-[40px] leading-none text-white sm:text-[50px]">0</div>
        <div className="text-[9px] font-bold tracking-[0.3em] text-white/50 sm:text-[10px]">KM/H</div>
      </div>
      <div className="font-hud absolute inset-x-0 bottom-[7%] flex justify-center">
        <div className="flex items-center gap-1 rounded-full bg-black/40 px-2.5 py-0.5 text-[10px] font-bold tracking-widest text-white/60 sm:text-[11px]">
          GEAR <div ref={gear} className="min-w-[1ch] text-center text-amber-300">N</div>
        </div>
      </div>
    </div>
  );
}

// ---------- thumbnail 3D garasi (dirender sekali, bertahap, di renderer terpisah) ----------
function useThumbs(first: string) {
  const [t, setT] = useState<Record<string, string>>({});
  useEffect(() => {
    let alive = true, raf = 0, i = 0;
    const ids = [first, ...GARAGE.map((c) => c.id).filter((id) => id !== first)];
    const timer = window.setTimeout(() => {
      const step = () => {
        if (!alive) return;
        const batch: Record<string, string> = {};
        for (let k = 0; k < 2 && i < ids.length; k++, i++) { const u = renderThumb(ids[i]); if (u) batch[ids[i]] = u; }
        setT((prev) => ({ ...prev, ...batch }));
        if (i < ids.length) raf = requestAnimationFrame(step); else disposeThumbRenderer();
      };
      raf = requestAnimationFrame(step);
    }, 600);
    return () => { alive = false; window.clearTimeout(timer); cancelAnimationFrame(raf); disposeThumbRenderer(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return t;
}

function Thumb({ src, className }: { src?: string; className?: string }) {
  return (
    <div className={cn('relative overflow-hidden bg-gradient-to-br from-indigo-400/25 via-violet-500/15 to-pink-400/25', className)}>
      {src ? <img src={src} alt="" draggable={false} className="absolute inset-0 h-full w-full object-contain" /> : <div className="absolute inset-0 animate-pulse bg-white/5" />}
    </div>
  );
}

function StatBar({ label, v, c }: { label: string; v: number; c: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="font-hud w-[52px] text-[9px] font-bold tracking-[0.14em] text-white/50">{label}</span>
      <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
        <span className="block h-full rounded-full" style={{ width: `${v * 10}%`, background: c }} />
      </span>
      <span className="font-hud w-4 text-right text-[10px] font-bold text-white/70">{v}</span>
    </div>
  );
}

function Garage({ car, onPick, thumbs }: { car: string; onPick: (id: string) => void; thumbs: Record<string, string> }) {
  const [cat, setCat] = useState<'all' | Category>(() => 'all');
  const info = carInfo(car);
  const list = GARAGE.filter((c) => cat === 'all' || c.category === cat);
  const chips: { id: 'all' | Category; label: string; n: number }[] = [
    { id: 'all', label: 'Semua', n: GARAGE.length },
    ...CATEGORIES.map((c) => ({ id: c, label: CATEGORY_LABEL[c], n: GARAGE.filter((g) => g.category === c).length })).filter((c) => c.n > 0),
  ];
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-amber-300/40 bg-gradient-to-br from-amber-300/15 via-transparent to-pink-500/10 p-2.5">
        <div className="flex gap-3">
          <Thumb src={thumbs[info.id]} className="h-[84px] w-[128px] shrink-0 rounded-xl border border-white/10" />
          <div className="font-hud min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-[0.18em] text-amber-200">
              {info.rank && <span className="rounded bg-amber-300 px-1.5 py-px text-slate-900">#{info.rank}</span>}
              <span className="truncate">{CATEGORY_LABEL[info.category].toUpperCase()}</span>
            </div>
            <div className="mt-0.5 text-[15px] font-bold leading-tight text-white">{info.name}</div>
            <div className="mt-0.5 truncate text-[11px] text-white/55">{info.driver}</div>
            <div className="mt-1 inline-flex items-center gap-1 rounded-full bg-black/30 px-2 py-0.5 text-[10px] font-bold text-sky-200">🔊 {info.engine}</div>
          </div>
        </div>
        <div className="mt-2.5 space-y-1">
          <StatBar label="SPEED" v={info.stats[0]} c="linear-gradient(90deg,#22d3ee,#60a5fa)" />
          <StatBar label="AKSEL" v={info.stats[1]} c="linear-gradient(90deg,#fbbf24,#fb923c)" />
          <StatBar label="HANDLING" v={info.stats[2]} c="linear-gradient(90deg,#34d399,#a3e635)" />
        </div>
        <p className="font-hud mt-2 text-[11px] leading-relaxed text-white/60">{info.desc}</p>
      </div>

      <div className="thin-scroll font-hud -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {chips.map((c) => (
          <button
            key={c.id}
            onClick={() => setCat(c.id)}
            className={cn('shrink-0 rounded-full border px-3 py-1 text-[11px] font-bold transition-all active:scale-95', cat === c.id ? 'border-amber-300 bg-amber-300 text-slate-900' : 'border-white/15 bg-white/[0.07] text-white/70 hover:bg-white/15')}
          >
            {c.label} <span className="opacity-60">{c.n}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {list.map((c) => (
          <button
            key={c.id}
            onClick={() => onPick(c.id)}
            className={cn(
              'font-hud group relative overflow-hidden rounded-xl border text-left transition-all duration-150 active:scale-95',
              car === c.id ? 'border-amber-300 shadow-[0_0_0_1px_rgba(252,211,77,.5),0_10px_24px_-8px_rgba(251,191,36,.6)]' : 'border-white/10 hover:border-white/30',
            )}
          >
            <Thumb src={thumbs[c.id]} className="aspect-[3/2] w-full" />
            <div className={cn('px-1.5 py-1 text-[11px] font-bold leading-tight', car === c.id ? 'bg-amber-300 text-slate-900' : 'bg-black/30 text-white/85')}>
              <span className="block truncate">{c.short}</span>
            </div>
            {c.rank && <span className="absolute left-1 top-1 rounded bg-black/55 px-1 text-[9px] font-bold text-amber-200">#{c.rank}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

function Board({ race }: { race: RaceInfo }) {
  return (
    <div className="glass-soft font-hud pointer-events-none absolute left-4 top-4 hidden w-56 rounded-2xl p-2.5 md:block">
      <div className="mb-1.5 flex items-center justify-between px-1 text-[10px] font-bold tracking-[0.25em] text-white/55">
        <span>PAPAN SKOR</span><span>🏁 {race.rem}m</span>
      </div>
      <div className="space-y-1">
        {race.rows.map((r, i) => (
          <div key={r.id} className={cn('flex items-center gap-2 rounded-lg px-2 py-1', r.me ? 'bg-amber-300 text-slate-900' : 'bg-white/[0.07] text-white')}>
            <span className="w-3 text-center text-xs font-bold">{i + 1}</span>
            <span className="h-2.5 w-2.5 shrink-0 rounded-full border border-white/80" style={{ background: r.color }} />
            <span className="flex-1 truncate text-xs font-bold">{r.name}</span>
            <span className="h-1.5 w-12 overflow-hidden rounded-full bg-black/25">
              <span className="block h-full rounded-full" style={{ width: `${Math.round(r.p * 100)}%`, background: r.me ? '#1b1640' : r.color }} />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- minimap bentuk lintasan (SVG, presisi dengan generator asli) ----------
function TrackMap({ def, accent }: { def: LevelDef; accent: string }) {
  const d = useMemo(() => {
    const p = trackPreview(def);
    if (!p.pts.length) return null;
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (const q of p.pts) { if (q.x < minX) minX = q.x; if (q.x > maxX) maxX = q.x; if (q.z < minZ) minZ = q.z; if (q.z > maxZ) maxZ = q.z; }
    const spanX = Math.max(1, maxX - minX), spanZ = Math.max(1, maxZ - minZ);
    const padX = spanX * 0.14, padZ = spanZ * 0.09;
    minX -= padX; maxX += padX; minZ -= padZ; maxZ += padZ;
    const path = p.pts.map((q, i) => `${i ? 'L' : 'M'}${q.x.toFixed(1)} ${q.z.toFixed(1)}`).join(' ');
    const sx = (p.pts[0].x - minX) / (maxX - minX), sy = (p.pts[0].z - minZ) / (maxZ - minZ);
    const last = p.pts[p.pts.length - 1];
    const ex = (last.x - minX) / (maxX - minX), ey = (last.z - minZ) / (maxZ - minZ);
    return { vb: `${minX.toFixed(1)} ${minZ.toFixed(1)} ${(maxX - minX).toFixed(1)} ${(maxZ - minZ).toFixed(1)}`, path, sx, sy, ex, ey };
  }, [def]);
  if (!d) return <div className="absolute inset-0 animate-pulse bg-white/5" />;
  return (
    <>
      <svg viewBox={d.vb} preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
        <path d={d.path} fill="none" stroke="rgba(5,3,18,.9)" strokeWidth={6.5} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <path d={d.path} fill="none" stroke={accent} strokeWidth={2.3} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" style={{ filter: `drop-shadow(0 0 4px ${accent})` }} />
      </svg>
      <span className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black/70 bg-emerald-400 shadow-[0_0_7px_#5cff9d]" style={{ left: `${d.sx * 100}%`, top: `${d.sy * 100}%` }} title="START" />
      <span className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black/70 bg-amber-300 shadow-[0_0_7px_#ffd23f]" style={{ left: `${d.ex * 100}%`, top: `${d.ey * 100}%` }} title="FINISH" />
    </>
  );
}

// ---------- kartu level ----------
function LevelCard({ def, earned, best, onPick }: {
  def: LevelDef;
  earned: number;
  best: number;
  onPick: (id: number) => void;
}) {
  const locked = !UNLOCK_ALL && def.id > 0 && false; // semua lintasan terbuka
  const th = THEMES[def.theme];
  const accent = def.rare ? '#ffb03a' : '#ffd23f';
  return (
    <button
      disabled={locked}
      onClick={() => onPick(def.id)}
      title={def.desc}
      className={cn(
        'group relative overflow-hidden rounded-2xl border text-left transition-all duration-150 active:scale-[0.97]',
        def.rare
          ? 'hw-card border-orange-400/70 hover:border-amber-300 hover:shadow-[0_16px_44px_-10px_rgba(255,122,26,.7)]'
          : 'border-white/15 hover:-translate-y-0.5 hover:border-amber-300/80 hover:shadow-[0_16px_40px_-12px_rgba(251,191,36,.5)]',
      )}
    >
      {/* banner: bentuk lintasan */}
      <div
        className="relative h-[104px] overflow-hidden sm:h-[116px]"
        style={{ background: `radial-gradient(ellipse at 50% 130%, ${th.sky[1]}2e 0%, transparent 62%), linear-gradient(180deg, #1b1738 0%, #12102c 100%)` }}
      >
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,.09) 1.1px, transparent 0)', backgroundSize: '13px 13px' }} />
        <TrackMap def={def} accent={accent} />
        <span className="font-display pointer-events-none absolute left-1.5 top-0 select-none text-5xl leading-none text-white/10 sm:text-6xl">{String(def.id).padStart(2, '0')}</span>
        {def.rare && (
          <span className="font-hud absolute right-1.5 top-1.5 rounded-md bg-gradient-to-r from-orange-500 via-red-500 to-amber-400 px-1.5 py-0.5 text-[8px] font-black tracking-[0.18em] text-white shadow-[0_2px_10px_rgba(255,90,20,.6)]">🔥 LANGKA</span>
        )}
        {earned > 0 && (
          <span className="absolute bottom-1.5 right-1.5 rounded-md bg-black/55 px-1.5 py-0.5 text-[11px] leading-none text-yellow-300">{'★'.repeat(earned)}</span>
        )}
        <span className="font-hud absolute bottom-1.5 left-1.5 max-w-[70%] truncate rounded-md bg-black/55 px-1.5 py-0.5 text-[7px] font-bold tracking-[0.16em] text-amber-200/90">{def.tag}</span>
      </div>
      {/* info */}
      <div className="bg-[#171333] px-2.5 py-1.5">
        <div className="font-hud truncate text-[12px] font-bold text-white sm:text-[13px]">{def.name}</div>
        <div className="mt-1 flex items-center justify-between gap-1">
          <span className="flex items-center gap-0.5" title={`Kesulitan ${def.diff}/5`}>
            {[1, 2, 3, 4, 5].map((i) => (
              <span key={i} className={cn('h-1.5 w-2.5 rounded-full sm:w-3', i <= def.diff ? (def.rare ? 'bg-orange-400 shadow-[0_0_6px_rgba(255,138,42,.8)]' : 'bg-rose-400 shadow-[0_0_6px_rgba(251,113,133,.7)]') : 'bg-white/15')} />
            ))}
          </span>
          <span className="font-hud text-[9px] font-bold text-white/60">🏁 {def.dist}m</span>
        </div>
        <div className="font-hud mt-1 flex items-center justify-between gap-1 text-[8px] font-semibold text-white/45 sm:text-[9px]">
          <span className="truncate">{best > 0 ? `Terbaik ${best}` : 'Belum dimainkan'}</span>
          <span className={cn('shrink-0 font-bold', earned >= 3 ? 'text-yellow-300' : 'text-white/45')}>{earned}/3★</span>
        </div>
      </div>
    </button>
  );
}

// ---------- layar PILIH LEVEL (kampanye + edisi Hot Wheels) ----------
function LevelSelect({ progress, onBack, onPick, onReset }: {
  progress: LevelProgress;
  onBack: () => void;
  onPick: (id: number) => void;
  onReset: () => void;
}) {
  const cleared = levelsCleared(progress);
  const stars = totalStars(progress);
  const campaign = LEVELS.filter((l) => !l.rare);
  const hotwheels = LEVELS.filter((l) => l.rare);
  const sectionHead = (icon: string, title: string, sub: string, hot: boolean) => (
    <div key={title} className="col-span-full flex items-center gap-2.5">
      <span className={cn('flex h-8 w-8 items-center justify-center rounded-xl text-lg', hot ? 'bg-gradient-to-br from-orange-500 to-red-600 shadow-[0_0_14px_rgba(255,100,20,.5)]' : 'bg-white/10')}>{icon}</span>
      <div className={cn('font-hud text-[11px] font-black tracking-[0.3em] sm:text-xs', hot ? 'bg-gradient-to-r from-amber-300 via-orange-400 to-red-400 bg-clip-text text-transparent' : 'text-white/85')}>{title}</div>
      <div className={cn('h-px flex-1', hot ? 'bg-gradient-to-r from-orange-400/70 via-amber-400/30 to-transparent' : 'bg-gradient-to-r from-white/30 to-transparent')} />
      <span className="font-hud text-[8px] font-bold tracking-[0.22em] text-amber-200/80 sm:text-[9px]">{sub}</span>
    </div>
  );
  return (
    <div data-ui className="levels-scrim absolute inset-0 z-30 flex flex-col overflow-hidden">
      {/* header */}
      <div className="flex items-center gap-2 px-3 pt-4 sm:gap-3 sm:px-6 sm:pt-5">
        <button onClick={onBack} aria-label="Kembali ke menu" className="btn-ghost font-hud flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-2xl font-bold active:scale-90">←</button>
        <div className="min-w-0 flex-1">
          <div className="font-display text-[26px] leading-none text-white sm:text-4xl" style={{ WebkitTextStroke: '1.5px #1b1640', paintOrder: 'stroke fill', textShadow: '0 3px 0 #1b1640' }}>PILIH LEVEL</div>
          <div className="font-hud mt-1 text-[8px] font-bold tracking-[0.32em] text-amber-200/90 sm:text-[10px]">{LEVEL_COUNT} LINTASAN • KAMPANYE &amp; HOT WHEELS</div>
        </div>
        <div className="glass-soft font-hud shrink-0 rounded-2xl px-3 py-1.5 text-center sm:px-4">
          <div className="text-lg font-bold leading-none text-yellow-300">⭐ {stars}<span className="text-white/45">/{TOTAL_STARS}</span></div>
          <div className="mt-0.5 text-[8px] font-bold tracking-[0.22em] text-white/55 sm:text-[9px]">{cleared}/{LEVEL_COUNT} TAMAT</div>
        </div>
        <button onClick={onReset} title="Reset bintang & skor (level tetap terbuka)" className="btn-ghost font-hud flex h-11 shrink-0 items-center gap-1 rounded-2xl px-2.5 text-[10px] font-bold tracking-widest text-white/60 active:scale-90">↺<span className="hidden md:inline">RESET</span></button>
      </div>

      {/* grid level */}
      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto px-3 pb-4 pt-3 sm:px-6">
        <div className="mx-auto grid w-full max-w-6xl grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4 xl:grid-cols-5">
          {sectionHead('🏁', 'KAMPANYE', '20 LINTASAN', false)}
          {campaign.map((def) => (
            <LevelCard key={def.id} def={def} earned={progress.stars[def.id] ?? 0} best={progress.best[def.id] ?? 0} onPick={onPick} />
          ))}
          {sectionHead('🔥', 'HOT WHEELS', 'EDISI LANGKA • 5 LINTASAN', true)}
          {hotwheels.map((def) => (
            <LevelCard key={def.id} def={def} earned={progress.stars[def.id] ?? 0} best={progress.best[def.id] ?? 0} onPick={onPick} />
          ))}
        </div>
        <div className="font-hud mx-auto mt-3 max-w-6xl px-2 text-center text-[9px] font-medium leading-relaxed text-white/55 sm:text-[10px]">
          <span className="text-emerald-400">●</span> START &nbsp;<span className="text-amber-300">●</span> FINISH &nbsp;│&nbsp; ⭐ Finish &nbsp;•&nbsp; ⭐⭐ Maks. 2× jatuh &nbsp;•&nbsp; ⭐⭐⭐ Tanpa jatuh &nbsp;—&nbsp; bentuk lintasan selalu sama tiap main: hafal, pelajari, taklukkan!
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const game = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  const [tab, setTab] = useState<Tab>('race');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [mode, setMode] = useState<Mode>(() => load<Mode>('slingdrift3d-mode', 'free'));
  const modeRef = useRef<Mode>(load<Mode>('slingdrift3d-mode', 'free'));
  const [best, setBest] = useState(() => Number(localStorage.getItem(bestKey(modeRef.current)) || 0));
  const [popup, setPopup] = useState<{ text: string; color: string; id: number } | null>(null);
  const [bump, setBump] = useState(0);
  const [hint, setHint] = useState('');
  const [boosting, setBoosting] = useState(false);
  const [race, setRace] = useState<RaceInfo | null>(null);
  const [end, setEnd] = useState<End | null>(null);
  const [resp, setResp] = useState<{ n: number; id: number } | null>(null);
  const respId = useRef(0);
  const [grid, setGrid] = useState<number | null>(null);
  const [showLevels, setShowLevels] = useState(false);
  const [progress, setProgress] = useState<LevelProgress>(() => loadProgress());
  const [activeLevel, setActiveLevel] = useState<number | null>(null);
  const [goal, setGoal] = useState<string>(() => load<string>('slingdrift3d-goal', '1100'));
  const tele = useRef<Telemetry>({ kmh: 0, rpm: 0, gear: 0, boost: false, drift: false });
  const [skin, setSkin] = useState<SkinName>(() => load<SkinName>('slingdrift3d-skin', 'asphalt'));
  const [cam, setCam] = useState<CamMode>(() => Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
  const [edge, setEdge] = useState<EdgeName>(() => load<EdgeName>('slingdrift3d-edge', 'hidden'));
  const [car, setCar] = useState<CarName>(() => validCar(localStorage.getItem('slingdrift3d-car')));
  const [fx, setFx] = useState<FxName>(() => load<FxName>('slingdrift3d-fx', 'V2'));
  const [roadBuild, setRoadBuild] = useState<RoadBuild>(() => load<RoadBuild>('slingdrift3d-roadbuild', 'instant'));
  const [musik, setMusik] = useState<MusicStyle>(() => load<MusicStyle>('slingdrift3d-music', 'ceria'));
  const [nos, setNos] = useState<NosColor>(() => load<NosColor>('slingdrift3d-nos', 'blue'));
  const [nosFire, setNosFire] = useState<'hold' | 'toggle'>(() => load<'hold' | 'toggle'>('slingdrift3d-nosfire', 'hold'));
  const [speed, setSpeed] = useState<SpeedName>(() => load<SpeedName>('slingdrift3d-speed', 'normal'));
  const [bot, setBot] = useState<BotMode>(() => load<BotMode>('slingdrift3d-bot', 'ghost5'));
  const canRestart = useRef(true);
  const nosBtn = useRef(false);
  const nosBtnUp = () => { if (nosBtn.current) { nosBtn.current = false; game.current?.nosUp(); } };

  const go = (s: Screen) => { screenRef.current = s; setScreen(s); };
  const startFromMenu = () => {
    if (screenRef.current === 'play' || !canRestart.current) return;
    const g = game.current; if (!g) return;
    setEnd(null); setRace(null); setResp(null); setGrid(null); setScore(0); setCombo(0);
    g.unlockAudio(); g.start(); go('play');
  };
  const toMenu = () => {
    game.current?.setLevel(null);
    setActiveLevel(null);
    setShowLevels(false);
    // pulihkan mode tersimpan (default: Bebas) apa adanya
    const m = load<Mode>('slingdrift3d-mode', 'free');
    if (m !== modeRef.current) { modeRef.current = m; setMode(m); game.current?.setMode(m); }
    setBest(Number(localStorage.getItem(bestKey(m)) || 0));
    game.current?.reset();
    setEnd(null); setRace(null); go('menu');
  };
  const startLevel = (id: number) => {
    if (screenRef.current === 'play' || !canRestart.current) return;
    // level kampanye dimainkan dengan fisika Drift — TANPA menimpa mode tersimpan
    setMode('drift'); modeRef.current = 'drift';
    setBest(Number(localStorage.getItem(bestKey('drift')) || 0));
    const g = game.current; if (!g) return;
    g.setMode('drift');
    g.setLevel(id);
    setActiveLevel(id);
    setShowLevels(false);
    setEnd(null); setRace(null); setResp(null); setGrid(null); setScore(0); setCombo(0);
    g.unlockAudio(); g.start(); go('play');
  };
  const saveBest = (s: number) => {
    const k = bestKey(modeRef.current);
    setBest((b) => { const nb = Math.max(b, s); localStorage.setItem(k, String(nb)); return nb; });
    canRestart.current = false;
    setTimeout(() => (canRestart.current = true), 600);
  };

  useEffect(() => {
    const g = new Game(mount.current!, {
      onScore: (s, c) => { setScore(s); setCombo(c); setBump((b) => b + 1); },
      onPopup: (text, color) => setPopup({ text, color, id: Math.random() }),
      onHint: (h) => setHint(h),
      onBoost: (on) => setBoosting(on),
      onRace: (info) => setRace(info),
      onRespawn: (n) => { if (n === RESPAWN_T) respId.current++; setResp(n > 0 ? { n, id: respId.current } : null); },
      onGrid: (n) => setGrid(n > 0 ? n : null),
      onTelemetry: (t) => { tele.current = t; },
      onRaceEnd: (r) => {
        const lvl = game.current?.levelId ?? null;
        if (lvl != null) {
          const def = levelById(lvl);
          const base = { id: lvl, name: def?.name ?? `Level ${lvl}`, theme: (def?.theme ?? 'violet') as ThemeName };
          if (r.finished) {
            const res = recordLevelResult(lvl, r.score, r.falls);
            setProgress(res.progress);
            setEnd({ kind: 'race', r, level: { ...base, earned: res.earned, stars: res.stars, newBest: res.newBest, finished: true } });
          } else {
            const p = loadProgress();
            setEnd({ kind: 'race', r, level: { ...base, earned: 0, stars: p.stars[lvl] ?? 0, newBest: false, finished: false } });
          }
          go('over');
          return;
        }
        saveBest(r.score); setEnd({ kind: 'race', r }); go('over');
      },
      onGameOver: (s, falls) => { saveBest(s); setEnd({ kind: 'run', score: s, falls }); go('over'); },
    });
    g.setSkin(load<SkinName>('slingdrift3d-skin', 'asphalt'));
    g.setCam(Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
    g.setEdge(load<EdgeName>('slingdrift3d-edge', 'hidden'));
    g.setCar(validCar(localStorage.getItem('slingdrift3d-car')));
    g.setFx(load<FxName>('slingdrift3d-fx', 'V2'));
    g.setRoadBuild(load<RoadBuild>('slingdrift3d-roadbuild', 'instant'));
    g.setMusicStyle(load<MusicStyle>('slingdrift3d-music', 'ceria'));
    g.setNos(load<NosColor>('slingdrift3d-nos', 'blue'));
    g.setNosMode(load<string>('slingdrift3d-nosfire', 'hold') === 'toggle');
    g.setGoal(Number(load<string>('slingdrift3d-goal', '1100')));
    g.setSpeed(load<SpeedName>('slingdrift3d-speed', 'normal'));
    g.setMode(load<Mode>('slingdrift3d-mode', 'free'));
    g.setBot(g.mode === 'spidey' ? 'off' : load<BotMode>('slingdrift3d-bot', 'ghost5'));
    game.current = g;

    // pre-kompilasi minimap lintasan (deterministik) saat browser idle — sekali saja
    const prewarm = () => { try { LEVELS.forEach((def) => trackPreview(def)); } catch { /* abaikan */ } };
    const wIdle = window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number };
    if (wIdle.requestIdleCallback) wIdle.requestIdleCallback(prewarm, { timeout: 3500 });
    else window.setTimeout(prewarm, 1600);

    let driftPtr: number | null = null;
    const down = (e: PointerEvent) => {
      if ((e.target as HTMLElement)?.closest?.('[data-ui]')) return;
      if (e.button === 2) { g.nosDown(); return; }
      if (driftPtr !== null) { g.nosDown(); return; }
      driftPtr = e.pointerId;
      if (screenRef.current !== 'play') { startFromMenu(); return; }
      g.press();
    };
    const up = (e: PointerEvent) => {
      if (e.button === 2) { g.nosUp(); return; }
      if (e.pointerId === driftPtr) { driftPtr = null; g.release(); }
      else g.nosUp();
    };
    const kd = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        (document.activeElement as HTMLElement)?.blur?.();
        if (screenRef.current !== 'play') { startFromMenu(); return; }
        g.comboDown();
      }
      if (e.code === 'KeyC' && !e.repeat) {
        const m = g.cycleCam();
        localStorage.setItem('slingdrift3d-cam', String(m));
        setCam(m);
      }
      if (e.code === 'Escape' && screenRef.current === 'play') g.endRun();
      if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') && !e.repeat) g.nosKeyDown();
    };
    const ku = (e: KeyboardEvent) => {
      if (e.code === 'Space') { g.comboUp(); }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') g.nosKeyUp();
    };
    const ctx = (e: Event) => e.preventDefault();
    window.addEventListener('pointerdown', down);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('contextmenu', ctx);
    return () => {
      window.removeEventListener('pointerdown', down);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('contextmenu', ctx);
      g.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pickMode = (m: Mode) => {
    setMode(m); modeRef.current = m;
    localStorage.setItem('slingdrift3d-mode', m);
    setBest(Number(localStorage.getItem(bestKey(m)) || 0));
    if (m === 'spidey' && bot !== 'off') {
      setBot('off'); localStorage.setItem('slingdrift3d-bot', 'off');
      game.current?.setBot('off');
    }
    game.current?.setMode(m);
  };
  const pickSpeed = (v: SpeedName) => { setSpeed(v); localStorage.setItem('slingdrift3d-speed', v); game.current?.setSpeed(v); };
  const pickGoal = (v: string) => { setGoal(v); localStorage.setItem('slingdrift3d-goal', v); game.current?.setGoal(Number(v)); };
  const pickBot = (b: BotMode) => { setBot(b); localStorage.setItem('slingdrift3d-bot', b); game.current?.setBot(b); };
  const pickNosFire = (f: 'hold' | 'toggle') => { setNosFire(f); localStorage.setItem('slingdrift3d-nosfire', f); game.current?.setNosMode(f === 'toggle'); };
  const pickSkin = (v: SkinName) => { setSkin(v); localStorage.setItem('slingdrift3d-skin', v); game.current?.setSkin(v); };
  const pickEdge = (v: EdgeName) => { setEdge(v); localStorage.setItem('slingdrift3d-edge', v); game.current?.setEdge(v); };
  const pickFx = (v: FxName) => { setFx(v); localStorage.setItem('slingdrift3d-fx', v); game.current?.setFx(v); };
  const pickRoad = (v: RoadBuild) => { setRoadBuild(v); localStorage.setItem('slingdrift3d-roadbuild', v); game.current?.setRoadBuild(v); };
  const pickMusic = (v: MusicStyle) => { setMusik(v); localStorage.setItem('slingdrift3d-music', v); game.current?.setMusicStyle(v); };
  const pickNos = (v: NosColor) => { setNos(v); localStorage.setItem('slingdrift3d-nos', v); game.current?.setNos(v); };
  const pickCam = (v: CamMode) => { setCam(v); localStorage.setItem('slingdrift3d-cam', String(v)); game.current?.setCam(v); };
  const pickCar = (v: CarName) => { setCar(v); localStorage.setItem('slingdrift3d-car', v); game.current?.setCar(v); };
  const thumbs = useThumbs(car);
  const info = carInfo(car);

  const racing = bot !== 'off' && mode !== 'spidey';
  const TABS: { id: Tab; icon: string; label: string }[] = [
    { id: 'race', icon: '🏁', label: 'Balap' },
    { id: 'garage', icon: '🚗', label: 'Garasi' },
    { id: 'look', icon: '🎨', label: 'Tampilan' },
    { id: 'audio', icon: '🔊', label: 'Audio' },
  ];

  const levelEnd = end?.kind === 'race' ? end.level : undefined;
  const levelFalls = end?.kind === 'race' ? end.r.falls : 99;

  // teks hasil
  let title = 'RUN SELESAI', place = '', stats: [string, string][] = [], newBest = false, sc = 0;
  if (end?.kind === 'race') {
    const { r } = end; sc = r.score;
    if (r.total === 1) title = r.finished ? '🏁 FINISH!' : '🏁 SELESAI';
    else if (r.finished) title = r.win ? '🏆 JUARA 1!' : r.place <= 3 ? `🏅 POSISI ${r.place}` : `🏁 POSISI ${r.place}`;
    else title = r.place >= r.total ? '😅 KALAH' : '🏁 SELESAI';
    place = r.total > 1 ? `#${r.place} / ${r.total}` : '';
    stats = [['JATUH', String(r.falls)]];
    newBest = r.score >= best && r.score > 0;
  } else if (end?.kind === 'run') {
    sc = end.score; stats = [['JATUH', String(end.falls)]];
    newBest = end.score >= best && end.score > 0;
  }

  return (
    <div className="fixed inset-0 select-none overflow-hidden touch-none font-display">
      <div ref={mount} className="absolute inset-0" />

      {/* efek NOS: vignette + garis kecepatan */}
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-200"
        style={{ opacity: boosting && screen === 'play' ? 1 : 0, background: `radial-gradient(ellipse at center, transparent 50%, rgba(${NOS[nos].css},0.45) 100%)` }}
      />
      <div className="speedlines pointer-events-none absolute inset-0 transition-opacity duration-200" style={{ opacity: boosting && screen === 'play' ? 0.55 : 0 }} />

      {/* ================= HUD ================= */}
      {screen === 'play' && (
        <>
          <div className="pointer-events-none absolute inset-x-0 top-3 flex flex-col items-center gap-1.5 sm:top-4">
            <div className="font-hud text-[10px] font-bold tracking-[0.42em] text-white/85" style={{ textShadow: '0 2px 0 #1b1640' }}>SCORE</div>
            <div key={bump} className="score-pop font-display text-6xl leading-none text-white sm:text-7xl" style={{ WebkitTextStroke: '3px #1b1640', paintOrder: 'stroke fill', textShadow: '0 5px 0 #1b1640, 0 12px 26px rgba(0,0,0,.35)' }}>{score}</div>
            {combo > 1 && (
              <div key={'c' + combo} className="score-pop font-hud rounded-full bg-gradient-to-b from-yellow-200 to-amber-400 px-4 py-0.5 text-base font-bold text-pink-700 shadow-[0_4px_0_#b86a00] sm:text-lg">🔥 COMBO ×{combo}</div>
            )}
            {race && mode !== 'spidey' && (
              <div className="glass-soft font-hud mt-1 w-[min(86vw,360px)] rounded-2xl px-3 py-2">
                <div className="mb-2 flex items-center justify-between text-xs font-bold">
                  {race.total > 1 ? <span className="rounded-md bg-amber-300 px-1.5 py-0.5 text-slate-900">P{race.place}<span className="opacity-60">/{race.total}</span></span> : <span className="text-[10px] tracking-[0.25em] text-white/60">MENUJU FINISH</span>}
                  <span className="text-white/80">🏁 {race.rem} m</span>
                </div>
                <div className="relative mx-1 h-2.5 rounded-full bg-white/15">
                  {race.rows.slice().reverse().map((r) => (
                    <span
                      key={r.id}
                      className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/90 transition-[left] duration-300"
                      style={{ left: `${Math.round(r.p * 100)}%`, width: r.me ? 17 : 11, height: r.me ? 17 : 11, background: r.color, zIndex: r.me ? 5 : 1, boxShadow: r.me ? '0 0 14px #fde047' : undefined }}
                    />
                  ))}
                  <span className="absolute -right-2 -top-3 text-base">🏁</span>
                </div>
              </div>
            )}
          </div>

          {race && race.total > 1 && <Board race={race} />}

          <div data-ui className="absolute right-3 top-3 flex flex-col items-end gap-2 sm:right-4 sm:top-4">
            <button
              onClick={() => { const m = game.current?.cycleCam(); if (m !== undefined) { setCam(m); localStorage.setItem('slingdrift3d-cam', String(m)); } }}
              className="glass-soft font-hud flex items-center gap-1.5 rounded-2xl px-3 py-2 text-sm font-bold text-white active:scale-90"
            >
              <span className="text-lg leading-none">{CAM_ICON[cam]}</span><span className="hidden sm:inline">{CAM_NAMES[cam]}</span>
            </button>
            <button
              onClick={() => game.current?.endRun()}
              className="glass-soft font-hud flex items-center gap-1.5 rounded-2xl px-3 py-2 text-sm font-bold text-rose-200 active:scale-90"
              title="Akhiri run (Esc)"
            >
              <span className="text-lg leading-none">⏹</span><span className="hidden sm:inline">SELESAI</span>
            </button>
          </div>

          <div data-ui className="absolute bottom-4 left-3 flex flex-col items-center gap-1.5 sm:bottom-5 sm:left-4">
            <button
              onPointerDown={(e) => { e.stopPropagation(); if (!nosBtn.current) { nosBtn.current = true; game.current?.nosDown(); } }}
              onPointerUp={nosBtnUp}
              onPointerCancel={nosBtnUp}
              onPointerLeave={nosBtnUp}
              onContextMenu={(e) => e.preventDefault()}
              className={cn('flex h-[84px] w-[84px] items-center justify-center rounded-full border-[3px] border-white/85 text-4xl transition-transform active:translate-y-1 active:scale-95', boosting && 'pulse')}
              style={{
                background: `radial-gradient(circle at 32% 26%, ${hex(NOS[nos].mid)}, ${hex(NOS[nos].outer)} 62%, #10163a 130%)`,
                boxShadow: `0 6px 0 rgba(0,0,0,0.4), 0 0 ${boosting ? 40 : 20}px ${hex(NOS[nos].outer)}`,
              }}
            >
              🔥
            </button>
            <div className="glass-soft font-hud rounded-full px-3 py-0.5 text-xs font-bold tracking-widest text-white">NOS</div>
          </div>

          {mode !== 'spidey' && <Gauge tele={tele} />}

          {activeLevel && (
            <div className="pointer-events-none absolute left-3 top-3 sm:left-4 sm:top-4">
              <div className="glass-soft font-hud rounded-2xl px-3 py-1.5">
                <div className="flex items-center gap-1.5 text-[9px] font-bold tracking-[0.32em] text-amber-200/90"><span className="text-xs">🏁</span>LEVEL {activeLevel}/{LEVEL_COUNT}</div>
                <div className="max-w-[150px] truncate text-xs font-bold leading-tight text-white">{levelById(activeLevel)?.name}</div>
              </div>
            </div>
          )}

          {hint && !resp && !grid && (
            <div className="pointer-events-none absolute inset-x-0 bottom-[168px] flex justify-center sm:bottom-10">
              <div key={hint + bump} className="hint-pop font-display text-4xl text-yellow-300 sm:text-5xl" style={{ WebkitTextStroke: '2px #1b1640', paintOrder: 'stroke fill', textShadow: '0 5px 0 #1b1640' }}>
                {hint}
              </div>
            </div>
          )}

          {grid && (
            <div className="pointer-events-none absolute inset-x-0 top-[36%] flex flex-col items-center gap-2">
              <div className="glass-soft flex gap-3 rounded-full px-5 py-3">
                {[3, 2, 1].map((k) => (
                  <span key={k} className="h-9 w-9 rounded-full border-2 border-white/40 transition-all duration-150" style={{ background: grid <= k ? '#ff2d4d' : '#2b1a3f', boxShadow: grid <= k ? '0 0 24px #ff2d4d' : 'none' }} />
                ))}
              </div>
              <div className="glass-soft font-hud rounded-full px-4 py-1 text-xs font-bold tracking-[0.3em] text-white/85">SIAP DI GARIS START</div>
            </div>
          )}

          {resp && (
            <div className="resp-vignette pointer-events-none absolute inset-0">
              <div className="absolute inset-x-0 bottom-[172px] flex justify-center px-3 sm:bottom-6">
                <div className="popin glass flex items-center gap-4 rounded-full py-2.5 pl-2.5 pr-6">
                  <div className="relative flex h-[76px] w-[76px] shrink-0 items-center justify-center">
                    <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full -rotate-90">
                      <defs>
                        <linearGradient id="rg" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0" stopColor="#fde047" /><stop offset="1" stopColor="#fb3b7a" />
                        </linearGradient>
                      </defs>
                      <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.14)" strokeWidth="9" />
                      <circle key={resp.id} className="ring-run" cx="60" cy="60" r="52" fill="none" stroke="url(#rg)" strokeWidth="9" strokeLinecap="round" strokeDasharray="327" strokeDashoffset="0" style={{ animationDuration: `${RESPAWN_T}s` }} />
                    </svg>
                    <div key={resp.n} className="count-pop font-display text-5xl leading-none text-white" style={{ textShadow: '0 4px 0 #1b1640' }}>{resp.n}</div>
                  </div>
                  <div className="text-left">
                    <div className="font-display text-2xl leading-tight text-white sm:text-3xl" style={{ WebkitTextStroke: '2px #1b1640', paintOrder: 'stroke fill', textShadow: '0 4px 0 #1b1640' }}>JATUH! RESPAWN…</div>
                    <div className="font-hud text-xs font-semibold text-white/75 sm:text-sm">Ikuti cincin biru • combo direset</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {popup && screen === 'play' && !resp && (
        <div key={popup.id} className="popup pointer-events-none absolute inset-x-0 top-[34%] text-center font-display text-5xl sm:text-6xl" style={{ color: popup.color, WebkitTextStroke: '3px #1b1640', paintOrder: 'stroke fill', textShadow: '0 6px 0 #1b1640' }}>
          {popup.text}
        </div>
      )}

      {/* ================= MENU ================= */}
      {screen === 'menu' && (
        <div className="menu-scrim thin-scroll absolute inset-0 touch-pan-y overflow-y-auto">
          <div className="mx-auto flex min-h-full w-full max-w-6xl flex-col items-center justify-center gap-6 px-4 py-6 lg:flex-row lg:justify-between lg:gap-12 lg:px-10">
            {/* hero */}
            <div className="flex w-full max-w-md flex-col items-center text-center lg:items-start lg:text-left">
              <span className="glass-soft font-hud mb-4 inline-flex items-center gap-2 rounded-full px-3.5 py-1 text-[11px] font-bold tracking-[0.26em] text-amber-200">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> HYPERCASUAL • 3D • DRIFT
              </span>
              <h1 className="logo font-display pointer-events-none">SLING<br /><span className="logo-accent">DRIFT</span></h1>
              <p className="font-hud pointer-events-none mt-5 max-w-sm text-sm font-medium leading-relaxed text-white/85">{TAGLINE[mode]}</p>

              <div data-ui className="mt-6 flex w-full max-w-sm flex-col items-center gap-3 lg:items-stretch">
                <button onClick={startFromMenu} className="cta pulse font-display w-full rounded-2xl py-4 text-3xl tracking-wide">▶ MAIN</button>
                <button
                  onClick={() => setShowLevels(true)}
                  className="levels-btn font-display relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl border-2 border-amber-300/70 bg-gradient-to-r from-violet-600/80 via-indigo-600/80 to-violet-600/80 py-3 text-2xl tracking-wide text-amber-200 transition-all duration-150 hover:border-amber-300 hover:text-amber-100 active:scale-[0.98]"
                >
                  <span className="text-2xl leading-none">🏁</span> PILIH LEVEL
                  <span className="font-hud rounded-full bg-black/35 px-2.5 py-0.5 text-[11px] font-bold tracking-widest text-yellow-300">{levelsCleared(progress)}/{LEVEL_COUNT} ✓ • ⭐{totalStars(progress)}</span>
                </button>
                <div className="flex flex-wrap items-center justify-center gap-2 lg:justify-start">
                  {best > 0 && <span className="glass-soft font-hud rounded-full px-3.5 py-1 text-sm font-bold text-yellow-300">🏆 Terbaik {MODE_LABEL[mode]}: {best}</span>}
                  {mode !== 'spidey' && <span className="glass-soft font-hud rounded-full px-3 py-1 text-sm font-bold text-white/85">🚗 {info.short}</span>}
                  {racing && <span className="glass-soft font-hud rounded-full px-3 py-1 text-sm font-bold text-white/85">{BOTS.find((b) => b.id === bot)?.icon} {BOTS.find((b) => b.id === bot)?.sub}</span>}
                </div>
              </div>

              <div className="font-hud pointer-events-none mt-6 hidden flex-wrap gap-x-4 gap-y-2 text-xs font-medium text-white/70 sm:flex">
                {[['KLIK', 'Tahan drift'], ['SPACE', 'NOS'], ['C', 'Kamera'], ['ESC', 'Selesai']].map(([k, v]) => (
                  <span key={k} className="flex items-center gap-1.5"><kbd className="rounded-md border border-white/25 bg-white/15 px-1.5 py-0.5 text-[11px] font-bold text-white shadow-[0_2px_0_rgba(255,255,255,.2)]">{k}</kbd>{v}</span>
                ))}
              </div>
            </div>

            {/* panel pengaturan */}
            <div data-ui className="glass w-full max-w-md rounded-[1.75rem] p-3 sm:p-4">
              <div className="font-hud mb-3 grid grid-cols-4 gap-1 rounded-2xl bg-black/30 p-1">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={cn('flex flex-col items-center gap-0.5 rounded-xl px-1 py-1.5 text-[11px] font-bold leading-tight transition-all active:scale-95 sm:text-[12px]', tab === t.id ? 'bg-gradient-to-b from-amber-300 to-orange-400 text-slate-900 shadow-md' : 'text-white/65 hover:text-white')}
                  >
                    <span className="text-base leading-none">{t.icon}</span>{t.label}
                  </button>
                ))}
              </div>

              <div className="thin-scroll space-y-4 pr-1 lg:max-h-[min(62vh,560px)] lg:overflow-y-auto">
                {tab === 'race' && (
                  <>
                    <Section label="🎮 MODE">
                      {MODES.map((m) => <Choice key={m.id} active={mode === m.id} onClick={() => pickMode(m.id)} icon={m.icon} label={m.label} sub={m.sub} />)}
                    </Section>
                    {mode !== 'spidey' && (
                      <Section label="🤖 LAWAN BOT" cols={2}>
                        {BOTS.map((b) => <Choice key={b.id} active={bot === b.id} onClick={() => pickBot(b.id)} icon={b.icon} label={b.label} sub={b.sub} badge={b.badge} />)}
                      </Section>
                    )}
                    <Section label="⚡ KECEPATAN">
                      {SPEED_OPTS.map((o) => <Choice key={o.id} active={speed === o.id} onClick={() => pickSpeed(o.id)} icon={o.icon} label={o.label} sub={o.sub} />)}
                    </Section>
                    {mode !== 'spidey' && (
                      <Section label="🏁 LINTASAN FINISH" cols={2}>
                        {GOALS.map((g) => <Choice key={g.id} active={goal === g.id} onClick={() => pickGoal(g.id)} icon={g.icon} label={g.label} sub={g.sub} />)}
                      </Section>
                    )}
                    {mode !== 'spidey' && (
                      <div>
                        <div className="font-hud mb-2 flex items-center gap-2 text-[10px] font-bold tracking-[0.26em] text-white/50"><span>🚗 MOBIL</span><span className="h-px flex-1 bg-gradient-to-r from-white/25 to-transparent" /></div>
                        <button onClick={() => setTab('garage')} className="font-hud flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] p-2 text-left transition-all hover:bg-white/[0.12] active:scale-[0.98]">
                          <Thumb src={thumbs[info.id]} className="h-[54px] w-[82px] shrink-0 rounded-lg border border-white/10" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-bold text-white">{info.name}</span>
                            <span className="block truncate text-[11px] text-white/50">🔊 {info.engine}</span>
                          </span>
                          <span className="shrink-0 rounded-full bg-amber-300 px-2.5 py-1 text-[11px] font-bold text-slate-900">Ganti ›</span>
                        </button>
                      </div>
                    )}
                  </>
                )}
                {tab === 'garage' && (mode === 'spidey'
                  ? <div className="font-hud rounded-2xl border border-white/10 bg-white/[0.05] p-4 text-center text-sm text-white/70">🕷️ Mode Spidey tidak memakai mobil. Pilih mode Drift atau Bebas untuk membuka garasi.</div>
                  : <Garage car={car} onPick={pickCar} thumbs={thumbs} />)}
                {tab === 'look' && (
                  <>
                    {mode !== 'spidey' && (
                      <Section label="🛣️ TRACK" cols={2}>
                        {SKIN_OPTS.map((s) => <Choice key={s.id} active={skin === s.id} onClick={() => pickSkin(s.id)} dot={s.dot} label={s.label} sub={s.sub} />)}
                      </Section>
                    )}
                    {mode !== 'spidey' && (
                      <Section label="🧱 PINGGIRAN">
                        {EDGES.map((e) => <Choice key={e.id} active={edge === e.id} onClick={() => pickEdge(e.id)} icon={e.icon} label={e.label} />)}
                      </Section>
                    )}
                    <Section label="✨ EFEK JALAN" cols={2}>
                      {FXS.map((f) => <Choice key={f.id} active={fx === f.id} onClick={() => pickFx(f.id)} icon={f.icon} label={f.label} sub={f.sub} />)}
                    </Section>
                    <Section label="🛤️ JALAN DEPAN" cols={2}>
                      {ROADBUILDS.map((r) => <Choice key={r.id} active={roadBuild === r.id} onClick={() => pickRoad(r.id)} icon={r.icon} label={r.label} sub={r.sub} />)}
                    </Section>
                    <Section label="🎥 KAMERA">
                      {([0, 1, 2] as CamMode[]).map((m) => <Choice key={m} active={cam === m} onClick={() => pickCam(m)} icon={CAM_ICON[m]} label={CAM_NAMES[m]} />)}
                    </Section>
                  </>
                )}
                {tab === 'audio' && (
                  <>
                    <Section label="🎵 MUSIK">
                      {MUSICS.map((m) => <Choice key={m.id} active={musik === m.id} onClick={() => pickMusic(m.id)} icon={m.icon} label={m.label} />)}
                    </Section>
                    <Section label={mode === 'spidey' ? '🕸️ WEB BOOST' : '💨 NOS FLAME'}>
                      {NOSS.map((n) => (
                        <Choice key={n.id} active={nos === n.id} onClick={() => pickNos(n.id)} label={n.label} dot={`radial-gradient(circle at 30% 30%, ${hex(NOS[n.id].mid)}, ${hex(NOS[n.id].outer)})`} />
                      ))}
                    </Section>
                    <Section label="🔥 CARA NOS" cols={2}>
                      <Choice active={nosFire === 'hold'} onClick={() => pickNosFire('hold')} icon="💨" label="Tahan" sub="Lepas = mati" />
                      <Choice active={nosFire === 'toggle'} onClick={() => pickNosFire('toggle')} icon="🔒" label="Toggle" sub="Tekan on/off" />
                    </Section>
                    <div className="font-hud rounded-2xl border border-white/10 bg-white/[0.05] p-3 text-xs leading-relaxed text-white/65">
                      🔊 <b className="text-white/90">Suara mesin realistis</b> — tiap mobil punya karakter sendiri (V10, I4 high-rev, diesel turbo, turbin, boxer). RPM, perpindahan gigi, rev limiter, backfire &amp; ban berdecit mengikuti aksimu.
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= PILIH LEVEL ================= */}
      {screen === 'menu' && showLevels && (
        <LevelSelect
          progress={progress}
          onBack={() => setShowLevels(false)}
          onPick={startLevel}
          onReset={() => { if (window.confirm('Reset semua bintang & progres level?')) setProgress(resetProgress()); }}
        />
      )}

      {/* ================= HASIL ================= */}
      {screen === 'over' && levelEnd && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-5 bg-indigo-950/60 p-4 backdrop-blur-[3px]">
          <div className="popin glass relative w-full max-w-sm rounded-[2rem] px-6 pb-5 pt-12 text-center">
            <div className={cn('absolute -top-5 left-1/2 -translate-x-1/2 -rotate-2 whitespace-nowrap rounded-2xl px-6 py-1.5 text-xl shadow-[0_5px_0_#1b1640] sm:text-2xl', levelEnd.finished ? 'bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-900' : 'bg-gradient-to-r from-rose-500 to-orange-400 text-white')}>
              {levelEnd.finished ? (levelEnd.earned >= 3 ? '⭐ SEMPURNA!' : '🏁 LEVEL SELESAI!') : '⛔ BELUM FINISH'}
            </div>
            <div className="font-hud text-[10px] font-bold tracking-[0.42em] text-amber-200/80">LEVEL {levelEnd.id} / {LEVEL_COUNT}</div>
            <div className="font-display mt-0.5 text-3xl leading-tight text-white" style={{ textShadow: '0 3px 0 #1b1640' }}>{levelEnd.name}</div>
            <div className="mt-2 flex items-center justify-center gap-3">
              {[0, 1, 2].map((i) => (
                <span key={i} className={cn('star-pop font-display text-6xl leading-none', i < levelEnd.earned ? 'star-on' : 'text-white/15')} style={{ animationDelay: `${0.25 + i * 0.22}s` }}>★</span>
              ))}
            </div>
            <div className="font-hud mt-3 text-[10px] font-bold tracking-[0.42em] text-white/55">SCORE</div>
            <div className="font-display text-7xl leading-none text-white" style={{ textShadow: '0 6px 0 #1b1640' }}>{end?.kind === 'race' ? end.r.score : 0}</div>
            <div className="font-hud mt-3 flex items-center justify-center gap-2 text-[9px] font-bold tracking-wider text-white/55">
              <span className={levelEnd.finished ? 'text-yellow-300' : ''}>⭐ finish</span><span className="text-white/30">•</span><span className={levelEnd.finished && levelFalls <= 2 ? 'text-yellow-300' : ''}>⭐⭐ ≤2× jatuh</span><span className="text-white/30">•</span><span className={levelEnd.earned >= 3 ? 'text-yellow-300' : ''}>⭐⭐⭐ tanpa jatuh</span>
            </div>
            {levelEnd.newBest && <div className="font-hud mt-2 rounded-full bg-yellow-300/20 px-4 py-1 text-xs font-bold text-yellow-200">⭐ REKOR BARU LEVEL INI! ⭐</div>}
            {!levelEnd.finished && <div className="font-hud mt-2 text-[11px] font-semibold text-rose-200/90">Capai garis FINISH untuk mencatat bintang</div>}
            {levelEnd.finished && levelEnd.id >= LEVEL_COUNT && <div className="font-hud mt-2 rounded-full bg-amber-300/20 px-4 py-1 text-xs font-bold text-amber-200">🏆 KAMU MENYELESAIKAN SEMUA 20 LEVEL!</div>}
          </div>
          <div data-ui className="pointer-events-auto flex w-full max-w-sm items-stretch gap-2.5">
            <button onClick={toMenu} className="btn-ghost font-display flex-1 rounded-2xl py-3.5 text-lg">☰ MENU</button>
            {levelEnd.finished ? (
              <>
                <button onClick={() => startLevel(levelEnd.id)} className="btn-ghost font-display flex-1 rounded-2xl py-3.5 text-lg text-amber-200">↻ ULANGI</button>
                {levelEnd.id < LEVEL_COUNT
                  ? <button onClick={() => startLevel(levelEnd.id + 1)} className="cta pulse font-display flex-[1.35] rounded-2xl py-3.5 text-xl">LV {levelEnd.id + 1} ▶</button>
                  : <button onClick={toMenu} className="cta pulse font-display flex-[1.35] rounded-2xl py-3.5 text-xl">🏆 TAMAT!</button>}
              </>
            ) : (
              <button onClick={() => startLevel(levelEnd.id)} className="cta pulse font-display flex-[1.6] rounded-2xl py-3.5 text-2xl">↻ COBA LAGI</button>
            )}
          </div>
        </div>
      )}

      {screen === 'over' && !levelEnd && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-6 bg-indigo-950/55 p-4 backdrop-blur-[3px]">
          <div className="popin glass relative w-full max-w-sm rounded-[2rem] px-6 pb-6 pt-10 text-center">
            <div className="absolute -top-5 left-1/2 -translate-x-1/2 -rotate-2 whitespace-nowrap rounded-2xl bg-gradient-to-r from-rose-500 to-orange-400 px-6 py-1.5 text-2xl text-white shadow-[0_5px_0_#1b1640]">{title}</div>
            {place && <div className="font-display text-5xl text-amber-300" style={{ textShadow: '0 4px 0 #1b1640' }}>{place}</div>}
            <div className="font-hud mt-1 text-[11px] font-bold tracking-[0.35em] text-white/55">SCORE</div>
            <div className="font-display text-8xl leading-none text-white" style={{ textShadow: '0 6px 0 #1b1640' }}>{sc}</div>
            <div className="font-hud mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-white/10 px-3 py-2"><div className="text-[10px] font-bold tracking-[0.25em] text-white/50">TERBAIK</div><div className="text-2xl font-bold text-yellow-300">🏆 {best}</div></div>
              {stats.map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-white/10 px-3 py-2"><div className="text-[10px] font-bold tracking-[0.25em] text-white/50">{k}</div><div className="text-2xl font-bold text-rose-300">{v}×</div></div>
              ))}
            </div>
            {newBest && <div className="font-hud mt-3 rounded-full bg-yellow-300/20 px-4 py-1 text-sm font-bold text-yellow-200">⭐ NEW BEST! ⭐</div>}
          </div>
          <div data-ui className="pointer-events-auto flex w-full max-w-sm items-stretch gap-3">
            <button onClick={toMenu} className="btn-ghost font-display flex-1 rounded-2xl py-3.5 text-xl">☰ MENU</button>
            <button onClick={startFromMenu} className="cta pulse font-display flex-[1.6] rounded-2xl py-3.5 text-2xl">↻ MAIN LAGI</button>
          </div>
          <div className="font-hud text-xs font-medium text-white/55">atau ketuk di mana saja</div>
        </div>
      )}
    </div>
  );
}

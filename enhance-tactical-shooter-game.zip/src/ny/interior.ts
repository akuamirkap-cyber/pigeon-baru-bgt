import { G, R, Rng, T, drawText, ell, line, mkCanvas, mulberry32, outline, pick, pix, ri, shade, textW, tri } from './util';

export interface IObj { x: number; y: number; c: HTMLCanvasElement; sy: number }
export interface INpc {
  x: number; y: number; look: number; dir: number;
  mode: number; // 0 stand 1 sit 2 wander 3 path->vanish 4 path->stand
  t: number; an: number; say: string; sayT: number; sp: number; path: number[];
  role: number; // 0 guest 1 staff 2 musician 3 waiting rider
  gx: number; gy: number; dead: boolean; moving: boolean;
}
export interface Train { t: number; x: number; open: number; ev: number }
export interface Interior {
  kind: string; title: string; w: number; h: number; bg: HTMLCanvasElement; solid: Uint8Array;
  objs: IObj[]; npcs: INpc[]; spawn: { x: number; y: number; dir: number }; exitRow: number;
  lines: string[]; staff: string[]; tint: string; lamps: number[]; fx: number[];
  train?: Train; trainSpr?: HTMLCanvasElement; station: number;
}
export interface Looks { rand: () => number; staff: number; cop: number; music: number }

export const LINE_COL = ['#ee352e', '#00933c', '#fccc0a', '#0039a6', '#ff6319', '#b933ad', '#a7a9ac', '#6cbe45'];
const LINE_CH = ['1', '4', 'N', 'A', 'F', '7', 'L', 'G'];
export const TRAIN_X = 9 * T + 2;
export const TRAIN_DOORS = [18, 80, 142, 204, 266, 328];

// ================================================================ sprite cache
const cache = new Map<string, HTMLCanvasElement>();
function S(key: string, w: number, h: number, f: (g: G) => void, ol = true): HTMLCanvasElement {
  const hit = cache.get(key);
  if (hit) return hit;
  const m = mkCanvas(w + 2, h + 2);
  m.g.translate(1, 1);
  f(m.g);
  m.g.setTransform(1, 0, 0, 1, 0, 0);
  if (ol) outline(m.c, '#241c1c');
  cache.set(key, m.c);
  return m.c;
}
function big(g: G, s: string, x: number, y: number, col: string, sc: number) {
  const m = mkCanvas(textW(s) + 1, 5);
  drawText(m.g, s, 0, 0, col);
  g.imageSmoothingEnabled = false;
  g.drawImage(m.c, Math.round(x), Math.round(y), m.c.width * sc, 5 * sc);
}

// ================================================================ furniture
const chair = (col: string) => S('chair' + col, 10, 15, (g) => {
  R(g, col, 1, 0, 8, 7);
  R(g, shade(col, 0.75), 3, 1, 1, 5);
  R(g, shade(col, 0.75), 6, 1, 1, 5);
  R(g, shade(col, 1.2), 0, 7, 10, 3);
  R(g, shade(col, 0.6), 0, 10, 2, 5);
  R(g, shade(col, 0.6), 8, 10, 2, 5);
});
const tableR = (top: string) => S('tr' + top, 16, 15, (g) => {
  R(g, shade(top, 0.75), 1, 3, 14, 4);
  R(g, top, 1, 1, 14, 4);
  R(g, top, 2, 0, 12, 1);
  R(g, shade(top, 1.15), 3, 1, 6, 1);
  R(g, '#3a3a40', 7, 7, 2, 6);
  R(g, '#3a3a40', 4, 13, 8, 2);
  R(g, '#ffffff', 4, 1, 3, 2);
  R(g, '#6b3e12', 5, 1, 1, 1);
  R(g, '#e8c14a', 10, 2, 2, 1);
});
const tableS = (top: string) => S('ts' + top, 30, 18, (g) => {
  R(g, top, 0, 0, 30, 9);
  R(g, shade(top, 1.15), 1, 1, 28, 1);
  R(g, shade(top, 0.72), 0, 9, 30, 3);
  R(g, shade(top, 0.5), 1, 12, 2, 6);
  R(g, shade(top, 0.5), 27, 12, 2, 6);
  ell(g, '#f4f4f0', 7, 4, 3, 2);
  ell(g, '#f4f4f0', 22, 4, 3, 2);
  R(g, '#d8452e', 6, 3, 2, 1);
  R(g, '#4ab06a', 21, 3, 2, 1);
  R(g, '#8fd0f8', 14, 2, 2, 4);
});
const booth = (col: string) => S('booth' + col, 46, 26, (g) => {
  for (const [bx, sx] of [[0, 5], [41, 32]]) {
    R(g, shade(col, 0.78), bx, 0, 5, 23);
    R(g, shade(col, 1.2), bx, 0, 5, 2);
    R(g, col, sx, 10, 9, 10);
    R(g, shade(col, 1.25), sx, 10, 9, 2);
    R(g, shade(col, 0.6), sx, 20, 9, 3);
  }
  R(g, '#e8e2d4', 15, 7, 16, 11);
  R(g, '#fbf7ee', 15, 7, 16, 1);
  R(g, '#b9b2a4', 15, 18, 16, 2);
  R(g, '#55565e', 22, 20, 2, 6);
  R(g, '#d8382e', 20, 8, 2, 4);
  R(g, '#f5d020', 24, 8, 2, 4);
  ell(g, '#f4f4f0', 19, 14, 3, 2);
  ell(g, '#f4f4f0', 27, 14, 3, 2);
  R(g, '#b5651d', 18, 13, 3, 1);
});
function counterItem(g: G, ch: string, x: number, y: number) {
  switch (ch) {
    case 'r':
      R(g, '#3a3d46', x + 3, y - 6, 10, 7);
      R(g, '#7ad8a0', x + 5, y - 10, 6, 5);
      R(g, '#22242a', x + 4, y - 3, 8, 1);
      break;
    case 'e':
      R(g, '#c9ccd2', x + 1, y - 13, 14, 13);
      R(g, '#eef0f4', x + 1, y - 13, 14, 2);
      R(g, '#8a8d96', x + 1, y - 5, 14, 2);
      R(g, '#22242a', x + 3, y - 3, 3, 3);
      R(g, '#22242a', x + 10, y - 3, 3, 3);
      R(g, '#d8382e', x + 4, y - 10, 2, 2);
      R(g, '#ffffff', x + 3, y - 16, 3, 3);
      R(g, '#ffffff', x + 8, y - 16, 3, 3);
      break;
    case 'p': {
      R(g, '#8a8d96', x, y - 13, 16, 14);
      R(g, '#d6eef8', x + 1, y - 12, 14, 12);
      R(g, '#8a8d96', x + 1, y - 6, 14, 1);
      const cs = ['#d9a441', '#ff8fb4', '#8a5a2b', '#f5e9c8', '#c0392b', '#7ad8a0'];
      for (let i = 0; i < 4; i++) {
        R(g, cs[(i + x) % 6], x + 2 + i * 3, y - 9, 2, 2);
        R(g, cs[(i + x + 3) % 6], x + 2 + i * 3, y - 3, 2, 2);
      }
      R(g, '#ffffff', x + 2, y - 12, 4, 1);
      break;
    }
    case 't':
      R(g, '#8a8d96', x + 2, y - 3, 12, 2);
      for (let i = 0; i < 3; i++) {
        R(g, '#c9ccd2', x + 3 + i * 4, y - 8, 2, 6);
        R(g, ['#d8382e', '#f5d020', '#2f8a4a'][i], x + 3 + i * 4, y - 12, 2, 4);
      }
      break;
    case 'z':
      R(g, '#8a8d96', x + 7, y - 4, 2, 4);
      ell(g, '#e8b04a', x + 8, y - 6, 7, 3);
      ell(g, '#d8452e', x + 8, y - 6, 5, 2);
      R(g, '#8a1c20', x + 5, y - 7, 1, 1);
      R(g, '#8a1c20', x + 9, y - 6, 1, 1);
      R(g, '#f5e9c8', x + 7, y - 5, 1, 1);
      break;
    case 'j':
      R(g, '#d6eef8', x + 5, y - 9, 6, 9);
      R(g, '#b5651d', x + 6, y - 6, 4, 5);
      R(g, '#c0392b', x + 5, y - 10, 6, 2);
      break;
    case 'f':
      R(g, '#4a8fd0', x + 6, y - 6, 4, 6);
      R(g, '#2f8a4a', x + 7, y - 11, 2, 5);
      R(g, '#ff6b8a', x + 5, y - 13, 3, 3);
      R(g, '#ffd84a', x + 9, y - 12, 2, 2);
      break;
    case 'm':
      R(g, '#22242a', x + 3, y - 11, 10, 8);
      R(g, '#4a8fd0', x + 4, y - 10, 8, 6);
      R(g, '#22242a', x + 7, y - 3, 2, 3);
      break;
    case 's':
      R(g, '#22242a', x + 1, y - 1, 14, 7);
      ell(g, '#55565e', x + 5, y + 2, 2, 1);
      ell(g, '#55565e', x + 11, y + 2, 2, 1);
      R(g, '#c9ccd2', x + 9, y - 6, 5, 5);
      R(g, '#8a8d96', x + 13, y - 4, 2, 1);
      break;
    case 'k':
      R(g, '#8a8d96', x + 2, y, 12, 6);
      R(g, '#55565e', x + 3, y + 1, 10, 4);
      R(g, '#c9ccd2', x + 7, y - 5, 2, 6);
      R(g, '#c9ccd2', x + 7, y - 5, 5, 2);
      break;
    case 'b':
      R(g, '#22242a', x + 4, y - 9, 2, 9);
      R(g, '#2f8a4a', x + 7, y - 8, 2, 8);
      R(g, '#b5651d', x + 10, y - 10, 2, 10);
      R(g, '#f5d020', x + 4, y - 6, 2, 2);
      R(g, '#f2f2f2', x + 7, y - 5, 2, 2);
      break;
  }
}
const counter = (items: string, top: string, front: string) => S(`ct${items}${top}${front}`, items.length * T, 40, (g) => {
  const w = items.length * T;
  R(g, top, 0, 16, w, 9);
  R(g, shade(top, 1.18), 0, 16, w, 2);
  R(g, front, 0, 25, w, 15);
  for (let x = 0; x < w; x += T) {
    R(g, shade(front, 0.84), x + 1, 27, 14, 10);
    R(g, shade(front, 1.12), x + 2, 28, 12, 1);
  }
  R(g, shade(front, 0.55), 0, 38, w, 2);
  for (let i = 0; i < items.length; i++) counterItem(g, items[i], i * T, 18);
});
const stool = (col: string) => S('stool' + col, 8, 13, (g) => {
  R(g, col, 0, 0, 8, 3);
  R(g, shade(col, 1.3), 1, 0, 6, 1);
  R(g, '#8a8d96', 3, 3, 2, 8);
  R(g, '#8a8d96', 1, 11, 6, 2);
});
const plant = (tall: boolean) => S('plant' + tall, 16, tall ? 36 : 24, (g) => {
  const h = tall ? 36 : 24;
  R(g, '#b5651d', 4, h - 9, 8, 9);
  R(g, '#d98a4a', 3, h - 10, 10, 2);
  R(g, '#8a4a18', 4, h - 2, 8, 2);
  if (tall) R(g, '#6b4a2e', 7, h - 22, 2, 13);
  const cy = tall ? 9 : h - 15;
  ell(g, '#2f7a3a', 8, cy, 7, tall ? 8 : 6);
  ell(g, '#46a050', 6, cy - 2, 4, 4);
  ell(g, '#46a050', 11, cy + 1, 3, 3);
  R(g, '#72c486', 5, cy - 4, 2, 2);
  R(g, '#72c486', 10, cy - 1, 2, 1);
});
const shelf = (kind: string, seed: number) => S(`sh${kind}${seed}`, 32, 38, (g) => {
  const r = mulberry32(seed * 31 + kind.length);
  R(g, '#6a4a2e', 0, 0, 32, 38);
  R(g, '#8a6240', 0, 0, 32, 2);
  R(g, '#33241a', 2, 2, 28, 34);
  const cols = kind === 'book' ? ['#8a2a2a', '#2a4a7a', '#2f6b45', '#b8862a', '#5a2a6a', '#d8d0b8', '#3a3a44', '#c0703c']
    : kind === 'bottle' ? ['#2f8a4a', '#b8862a', '#8a2a2a', '#d6eef8', '#3a6ae0', '#e8c14a', '#5a2a1a']
    : kind === 'shoe' ? ['#f2f2f2', '#d8382e', '#22242a', '#2b5fb0', '#f5d020', '#8a5a2b']
    : ['#d8382e', '#f5d020', '#2b7fd0', '#4ab06a', '#f08a3c', '#e87ab0', '#f2f2f2', '#8a5ad9'];
  for (let s = 0; s < 4; s++) {
    const by = 10 + s * 9;
    R(g, '#8a6240', 2, by, 28, 1);
    let x = 3;
    while (x < 28) {
      if (kind === 'book') {
        const h = ri(r, 5, 7);
        R(g, pick(r, cols), x, by - h, 2, h);
        x += r() < 0.12 ? 4 : 2;
      } else if (kind === 'bottle') {
        const c = pick(r, cols);
        R(g, c, x, by - 5, 3, 5);
        R(g, c, x + 1, by - 7, 1, 2);
        R(g, '#f2f2f2', x, by - 3, 3, 1);
        x += 4;
      } else if (kind === 'shoe') {
        const c = pick(r, cols);
        R(g, c, x, by - 3, 6, 3);
        R(g, c, x, by - 5, 3, 2);
        R(g, '#f2f2f2', x, by - 1, 6, 1);
        x += 8;
      } else if (kind === 'record') {
        if (r() < 0.3) {
          R(g, pick(r, cols), x, by - 7, 7, 7);
          ell(g, '#111111', x + 3, by - 4, 2, 2);
          x += 8;
        } else {
          R(g, pick(r, cols), x, by - 7, 1, 7);
          x += 2;
        }
      } else {
        const w = ri(r, 2, 4);
        const h = ri(r, 3, 7);
        const c = pick(r, cols);
        R(g, c, x, by - h, w, h);
        R(g, shade(c, 1.4), x, by - h + 1, w, 1);
        x += w + 1;
      }
    }
  }
});
const fridge = () => S('fridge', 32, 40, (g) => {
  R(g, '#d9dde2', 0, 0, 32, 40);
  R(g, '#d8382e', 0, 0, 32, 4);
  drawText(g, 'COLD', 8, -1 + 0, '#ffffff');
  for (const dx of [2, 17]) {
    R(g, '#cfeefa', dx, 5, 13, 32);
    const cs = ['#d8382e', '#2f8a4a', '#2b7fd0', '#f08a3c', '#d6eef8', '#f5d020'];
    for (let s = 0; s < 4; s++) {
      R(g, '#9ab8c6', dx, 12 + s * 8, 13, 1);
      for (let i = 0; i < 4; i++) R(g, cs[(s * 2 + i + dx) % 6], dx + 1 + i * 3, 7 + s * 8, 2, 5);
    }
    R(g, '#8a8d96', dx + 11, 16, 1, 10);
  }
  R(g, '#9a9da6', 0, 37, 32, 3);
});
const rack = (seed: number) => S('rack' + seed, 32, 30, (g) => {
  const r = mulberry32(seed + 9);
  R(g, '#8a8d96', 1, 2, 30, 1);
  R(g, '#8a8d96', 1, 2, 1, 27);
  R(g, '#8a8d96', 30, 2, 1, 27);
  R(g, '#55565e', 0, 28, 4, 2);
  R(g, '#55565e', 28, 28, 4, 2);
  for (let x = 3; x < 28; x += 4) {
    const c = pick(r, ['#d94a4a', '#4a7fd9', '#f2f2f2', '#2b2b35', '#e8c14a', '#e87ab0', '#4ab06a', '#8a5ad9', '#f08a3c', '#33405c']);
    const h = ri(r, 10, 17);
    R(g, '#55565e', x + 1, 1, 1, 2);
    R(g, c, x, 3, 3, h);
    R(g, shade(c, 0.75), x + 2, 4, 1, h - 1);
  }
});
const mannequin = (col: string) => S('man' + col, 10, 28, (g) => {
  R(g, '#e8dcc8', 3, 0, 4, 4);
  R(g, col, 1, 5, 8, 9);
  R(g, shade(col, 0.8), 2, 14, 6, 7);
  R(g, shade(col, 1.25), 2, 6, 2, 3);
  R(g, '#8a8d96', 4, 21, 2, 5);
  R(g, '#55565e', 2, 26, 6, 2);
});
const buckets = (seed: number) => S('bk' + seed, 32, 24, (g) => {
  const r = mulberry32(seed + 3);
  for (let b = 0; b < 3; b++) {
    const x = 1 + b * 10;
    R(g, '#9aa0a8', x + 1, 14, 8, 10);
    R(g, '#c9ced6', x, 13, 10, 2);
    R(g, '#7a8088', x + 7, 15, 2, 9);
    const c = pick(r, ['#e23a5a', '#ffd23a', '#ff8fb4', '#c95aff', '#ffffff', '#ff7a1e']);
    for (let i = 0; i < 5; i++) {
      const fx = x + 1 + ri(r, 0, 7);
      const fy = ri(r, 1, 8);
      R(g, '#2f8a4a', fx, fy + 2, 1, 12 - fy);
      R(g, c, fx - 1, fy, 3, 3);
      R(g, shade(c, 1.3), fx, fy, 1, 1);
    }
  }
});
const recordBin = (seed: number) => S('rb' + seed, 32, 22, (g) => {
  const r = mulberry32(seed + 5);
  R(g, '#8a6240', 0, 8, 32, 14);
  R(g, '#6a4a2e', 0, 20, 32, 2);
  R(g, '#a87850', 0, 8, 32, 1);
  for (let x = 1; x < 30; x += 3) {
    const c = pick(r, ['#d8382e', '#f5d020', '#2b7fd0', '#4ab06a', '#f08a3c', '#e87ab0', '#f2f2f2', '#22242a', '#8a5ad9']);
    const h = ri(r, 6, 9);
    R(g, c, x, 9 - h + 3, 2, h);
  }
  R(g, '#f2ead8', 9, 13, 14, 5);
  drawText(g, 'LP', 13, 13, '#22242a');
});
const sofa = (col: string) => S('sofa' + col, 46, 22, (g) => {
  R(g, shade(col, 0.82), 2, 0, 42, 11);
  R(g, shade(col, 1.1), 2, 0, 42, 2);
  R(g, shade(col, 0.9), 0, 4, 5, 15);
  R(g, shade(col, 0.9), 41, 4, 5, 15);
  R(g, col, 5, 9, 18, 8);
  R(g, col, 23, 9, 18, 8);
  R(g, shade(col, 1.2), 5, 9, 36, 1);
  R(g, shade(col, 0.7), 22, 9, 1, 8);
  R(g, shade(col, 0.6), 2, 17, 42, 3);
  R(g, '#3a2a1e', 3, 20, 2, 2);
  R(g, '#3a2a1e', 41, 20, 2, 2);
});
const coffeeT = () => S('cft', 28, 12, (g) => {
  R(g, '#8a5c34', 0, 0, 28, 6);
  R(g, '#a87442', 1, 1, 26, 1);
  R(g, '#5a3a20', 0, 6, 28, 2);
  R(g, '#5a3a20', 1, 8, 2, 4);
  R(g, '#5a3a20', 25, 8, 2, 4);
  R(g, '#d8382e', 5, 2, 6, 3);
  R(g, '#ffffff', 18, 1, 3, 3);
});
const tv = () => S('tv', 32, 26, (g) => {
  R(g, '#3a2a1e', 2, 16, 28, 10);
  R(g, '#5a4028', 2, 16, 28, 1);
  R(g, '#22242a', 12, 20, 8, 3);
  R(g, '#15151c', 3, 0, 26, 16);
  R(g, '#3a8fd0', 5, 2, 22, 12);
  R(g, '#4ab06a', 5, 9, 22, 5);
  R(g, '#ffe14a', 20, 4, 3, 3);
  R(g, '#ffffff', 8, 4, 6, 2);
});
const bed = (col: string) => S('bed' + col, 30, 40, (g) => {
  R(g, '#6a4a2e', 0, 0, 30, 9);
  R(g, '#8a6240', 0, 0, 30, 2);
  R(g, '#f2efe6', 1, 8, 28, 30);
  R(g, '#ffffff', 3, 9, 11, 7);
  R(g, '#ffffff', 16, 9, 11, 7);
  R(g, '#d9d4c8', 3, 15, 11, 1);
  R(g, '#d9d4c8', 16, 15, 11, 1);
  R(g, col, 1, 18, 28, 20);
  R(g, shade(col, 1.2), 1, 18, 28, 3);
  R(g, shade(col, 0.8), 1, 36, 28, 2);
  R(g, '#6a4a2e', 0, 38, 30, 2);
});
const homeFridge = () => S('hfr', 16, 36, (g) => {
  R(g, '#c9ced6', 0, 0, 16, 36);
  R(g, '#e4e8ee', 1, 1, 3, 34);
  R(g, '#8a8d96', 0, 12, 16, 1);
  R(g, '#8a8d96', 12, 4, 1, 6);
  R(g, '#8a8d96', 12, 15, 1, 10);
  R(g, '#d8382e', 5, 5, 2, 2);
  R(g, '#f5d020', 8, 7, 2, 2);
  R(g, '#7a8088', 0, 34, 16, 2);
});
const lampF = () => S('lampf', 10, 30, (g) => {
  R(g, '#f5e9c8', 0, 0, 10, 8);
  R(g, '#fff6dc', 1, 1, 8, 2);
  R(g, '#3a3a40', 4, 8, 2, 20);
  R(g, '#3a3a40', 2, 28, 6, 2);
});
const pedestal = (k: number) => S('ped' + k, 16, 32, (g) => {
  R(g, '#d9d4c8', 3, 16, 10, 16);
  R(g, '#f2efe6', 2, 15, 12, 2);
  R(g, '#b9b2a4', 2, 30, 12, 2);
  R(g, '#b9b2a4', 11, 17, 2, 13);
  if (k === 0) {
    ell(g, '#3a6ae0', 8, 9, 4, 5);
    R(g, '#3a6ae0', 6, 2, 4, 3);
    R(g, '#f2f2f2', 5, 8, 6, 2);
    R(g, '#f2f2f2', 7, 5, 2, 1);
  } else if (k === 1) {
    R(g, '#f2efe6', 5, 2, 6, 7);
    R(g, '#f2efe6', 4, 9, 8, 6);
    R(g, '#b9b2a4', 6, 5, 1, 1);
    R(g, '#b9b2a4', 9, 5, 1, 1);
    R(g, '#d9d4c8', 9, 3, 2, 11);
  } else if (k === 2) {
    line(g, '#d8382e', 5, 14, 11, 8);
    line(g, '#d8382e', 11, 8, 5, 3);
    line(g, '#d8382e', 6, 14, 12, 8);
    line(g, '#a8241e', 5, 3, 10, 1);
    R(g, '#d8382e', 4, 13, 4, 2);
  } else {
    ell(g, '#e3b53a', 8, 8, 4, 6);
    R(g, '#8a6a1e', 6, 6, 1, 2);
    R(g, '#8a6a1e', 9, 6, 1, 2);
    R(g, '#8a6a1e', 7, 11, 2, 1);
    R(g, '#2b5fb0', 4, 2, 8, 2);
  }
});
const glassCase = (k: number) => S('case' + k, 30, 26, (g) => {
  R(g, '#5a3a22', 0, 14, 30, 12);
  R(g, '#7a5232', 0, 14, 30, 2);
  R(g, '#d6eef8', 1, 0, 28, 14);
  R(g, '#ffffff', 2, 1, 8, 1);
  R(g, '#8a8d96', 1, 0, 28, 1);
  R(g, '#8a8d96', 1, 0, 1, 14);
  R(g, '#8a8d96', 28, 0, 1, 14);
  const c = ['#e3b53a', '#3ad0a0', '#c98b3f', '#c95aff'][k % 4];
  if (k % 2) {
    ell(g, c, 15, 8, 5, 3);
    R(g, shade(c, 1.3), 12, 6, 3, 1);
  } else {
    R(g, c, 8, 9, 14, 3);
    R(g, c, 12, 4, 6, 5);
    R(g, shade(c, 1.3), 13, 5, 2, 1);
  }
  R(g, '#f2ead8', 11, 18, 8, 4);
});
const dino = () => S('dino', 100, 60, (g) => {
  const B = '#e8dcc0';
  const D = '#b9ad90';
  R(g, '#3a2a1e', 2, 52, 96, 8);
  R(g, '#5a4028', 2, 52, 96, 2);
  R(g, '#e3b53a', 40, 55, 20, 3);
  const spine: [number, number][] = [[4, 44], [14, 38], [26, 31], [38, 26], [50, 24], [60, 25], [70, 20], [78, 13], [84, 8]];
  for (let i = 0; i < spine.length - 1; i++) {
    line(g, B, spine[i][0], spine[i][1], spine[i + 1][0], spine[i + 1][1]);
    line(g, B, spine[i][0], spine[i][1] + 1, spine[i + 1][0], spine[i + 1][1] + 1);
    line(g, D, spine[i][0], spine[i][1] + 2, spine[i + 1][0], spine[i + 1][1] + 2);
  }
  for (let x = 6; x < 70; x += 3) {
    const t = x < 26 ? 31 + ((26 - x) * 13) / 22 : x < 60 ? 25 : 25 - ((x - 60) * 5) / 10;
    R(g, B, x, t - 3, 1, 3);
  }
  for (let i = 0; i < 9; i++) {
    const x = 34 + i * 3;
    line(g, B, x, 27, x + (i < 5 ? -1 : 1), 27 + 13 - Math.abs(i - 4) * 2);
  }
  for (const lx of [36, 46]) {
    line(g, B, lx, 28, lx + 5, 38);
    line(g, B, lx + 1, 28, lx + 6, 38);
    line(g, B, lx + 5, 38, lx - 1, 46);
    line(g, B, lx + 6, 38, lx, 46);
    line(g, B, lx - 1, 46, lx + 2, 52);
    R(g, B, lx, 50, 6, 2);
  }
  line(g, B, 62, 27, 66, 33);
  line(g, B, 66, 33, 70, 31);
  R(g, B, 82, 3, 14, 7);
  R(g, B, 86, 10, 11, 3);
  R(g, '#241c1c', 86, 5, 2, 2);
  R(g, D, 82, 9, 14, 1);
  for (let x = 88; x < 97; x += 2) R(g, '#ffffff', x, 9, 1, 2);
  R(g, B, 80, 5, 3, 4);
});
const benchM = () => S('benchm', 32, 10, (g) => {
  R(g, '#2a2a33', 0, 0, 32, 6);
  R(g, '#44444e', 1, 1, 30, 1);
  R(g, '#8a8d96', 2, 6, 2, 4);
  R(g, '#8a8d96', 28, 6, 2, 4);
});
const pew = () => S('pew', 46, 16, (g) => {
  R(g, '#5a3a22', 0, 0, 46, 10);
  R(g, '#7a5232', 0, 0, 46, 2);
  R(g, '#6a4628', 0, 10, 46, 4);
  R(g, '#3a2414', 0, 14, 46, 2);
  R(g, '#3a2414', 0, 0, 3, 16);
  R(g, '#3a2414', 43, 0, 3, 16);
  for (let x = 8; x < 40; x += 8) R(g, '#4a3018', x, 3, 1, 6);
});
const altar = () => S('altar', 46, 32, (g) => {
  R(g, '#f2efe6', 2, 14, 42, 16);
  R(g, '#ffffff', 2, 14, 42, 2);
  R(g, '#e3b53a', 2, 27, 42, 1);
  R(g, '#e3b53a', 21, 18, 4, 8);
  R(g, '#e3b53a', 19, 20, 8, 2);
  R(g, '#d9d4c8', 2, 30, 42, 2);
  for (const cx of [7, 37]) {
    R(g, '#e3b53a', cx - 1, 10, 4, 4);
    R(g, '#f2efe6', cx, 3, 2, 8);
    R(g, '#ffb03a', cx, 1, 2, 2);
  }
  R(g, '#e3b53a', 22, 0, 2, 13);
  R(g, '#e3b53a', 18, 3, 10, 2);
});
const candles = () => S('candles', 10, 24, (g) => {
  R(g, '#b8862a', 4, 8, 2, 14);
  R(g, '#b8862a', 1, 22, 8, 2);
  R(g, '#b8862a', 0, 8, 10, 1);
  for (const x of [0, 4, 8]) {
    R(g, '#f2efe6', x, 3, 2, 5);
    R(g, '#ffb03a', x, 1, 2, 2);
  }
});
const poolTable = () => S('pool', 46, 30, (g) => {
  R(g, '#6a3c1e', 0, 0, 46, 22);
  R(g, '#8a5430', 0, 0, 46, 2);
  R(g, '#1f7a4a', 3, 3, 40, 16);
  R(g, '#2a9a5e', 4, 4, 38, 1);
  for (const [x, y] of [[3, 3], [22, 3], [41, 3], [3, 17], [22, 17], [41, 17]]) R(g, '#15151c', x, y, 2, 2);
  R(g, '#ffffff', 12, 10, 2, 2);
  R(g, '#d8382e', 28, 8, 2, 2);
  R(g, '#f5d020', 31, 10, 2, 2);
  R(g, '#2b5fb0', 30, 13, 2, 2);
  R(g, '#15151c', 33, 11, 2, 2);
  line(g, '#d9b88a', 6, 14, 18, 8);
  R(g, '#4a2812', 0, 22, 46, 3);
  R(g, '#4a2812', 2, 25, 4, 5);
  R(g, '#4a2812', 40, 25, 4, 5);
});
const jukebox = () => S('juke', 16, 30, (g) => {
  R(g, '#7a2a2a', 0, 6, 16, 24);
  ell(g, '#7a2a2a', 8, 7, 7, 6);
  ell(g, '#ffd23a', 8, 8, 5, 4);
  ell(g, '#ff7ab0', 8, 9, 3, 2);
  R(g, '#3ad0ff', 2, 14, 12, 2);
  R(g, '#ffd23a', 2, 17, 12, 1);
  R(g, '#22242a', 3, 20, 10, 7);
  for (let x = 4; x < 12; x += 2) R(g, '#55565e', x, 21, 1, 5);
  R(g, '#4a1818', 0, 28, 16, 2);
});
const piano = () => S('piano', 36, 28, (g) => {
  R(g, '#15151c', 0, 0, 36, 24);
  R(g, '#33333d', 0, 0, 36, 2);
  R(g, '#22222a', 1, 3, 34, 8);
  R(g, '#f2f2f2', 2, 13, 32, 4);
  for (let x = 3; x < 34; x += 3) R(g, '#15151c', x, 13, 1, 2);
  R(g, '#15151c', 2, 17, 32, 1);
  R(g, '#e3b53a', 17, 6, 3, 1);
  R(g, '#0b0b10', 2, 24, 3, 4);
  R(g, '#0b0b10', 31, 24, 3, 4);
});
const mic = () => S('mic', 6, 22, (g) => {
  R(g, '#8a8d96', 2, 0, 3, 4);
  R(g, '#3a3a40', 3, 4, 1, 16);
  R(g, '#3a3a40', 1, 20, 5, 2);
});
const seats = (col: string) => S('seats' + col, 46, 14, (g) => {
  for (let i = 0; i < 4; i++) {
    const x = 1 + i * 11;
    R(g, col, x, 1, 10, 9);
    R(g, col, x + 1, 0, 8, 1);
    R(g, shade(col, 1.25), x + 1, 1, 8, 1);
    R(g, shade(col, 0.7), x, 10, 10, 4);
    R(g, '#3a2a1e', x - 1, 6, 1, 8);
  }
  R(g, '#3a2a1e', 45, 6, 1, 8);
});
const longTable = () => S('ltable', 62, 26, (g) => {
  R(g, '#7a4a28', 0, 8, 62, 10);
  R(g, '#9a6238', 0, 8, 62, 2);
  R(g, '#4a2a14', 0, 18, 62, 3);
  R(g, '#4a2a14', 2, 21, 3, 5);
  R(g, '#4a2a14', 57, 21, 3, 5);
  for (const lx of [14, 44]) {
    R(g, '#b8862a', lx + 2, 4, 1, 6);
    R(g, '#1f7a4a', lx, 0, 6, 4);
    R(g, '#3ad08a', lx + 1, 1, 4, 1);
  }
  R(g, '#f2ead8', 5, 11, 6, 4);
  R(g, '#8a2a2a', 26, 11, 6, 4);
  R(g, '#f2ead8', 50, 12, 6, 4);
});
const infoClock = () => S('iclock', 32, 44, (g) => {
  R(g, '#b8862a', 2, 22, 28, 22);
  R(g, '#e3b53a', 2, 22, 28, 2);
  R(g, '#7a5a1a', 2, 42, 28, 2);
  R(g, '#f2ead8', 5, 26, 22, 9);
  drawText(g, 'INFO', 8, 28, '#3a2a1e');
  R(g, '#3a2a1e', 5, 36, 22, 5);
  R(g, '#b8862a', 14, 14, 4, 8);
  ell(g, '#e3b53a', 16, 8, 8, 8);
  ell(g, '#fff6dc', 16, 8, 6, 6);
  R(g, '#22242a', 16, 4, 1, 5);
  R(g, '#22242a', 16, 8, 4, 1);
  R(g, '#e3b53a', 15, -1 + 1, 3, 1);
});
const turnstile = () => S('turn', 14, 22, (g) => {
  R(g, '#b9bcc4', 0, 5, 14, 17);
  R(g, '#e4e6ea', 0, 5, 14, 2);
  R(g, '#8a8d96', 0, 20, 14, 2);
  R(g, '#22242a', 3, 8, 8, 3);
  R(g, '#4aff7a', 4, 9, 2, 1);
  R(g, '#f5d020', 2, 13, 10, 2);
  R(g, '#8a8d96', 6, 0, 2, 6);
  R(g, '#8a8d96', 2, 2, 10, 1);
});
const tokenBooth = () => S('tbooth', 46, 46, (g) => {
  R(g, '#6a7078', 0, 0, 46, 6);
  R(g, '#8a9098', 0, 0, 46, 2);
  R(g, '#7a8088', 0, 6, 46, 40);
  R(g, '#1f2f5a', 0, 6, 46, 7);
  drawText(g, 'STATION', 9, 7, '#ffffff');
  R(g, '#cfeefa', 4, 15, 38, 15);
  R(g, '#ffffff', 5, 16, 10, 1);
  R(g, '#c98e62', 20, 18, 6, 6);
  R(g, '#18244a', 19, 16, 8, 3);
  R(g, '#1f2f5a', 17, 24, 12, 6);
  R(g, '#55565e', 23, 15, 1, 15);
  R(g, '#22242a', 16, 31, 14, 2);
  R(g, '#5a6068', 0, 33, 46, 13);
  R(g, '#8a9098', 0, 33, 46, 1);
  R(g, '#f5d020', 4, 37, 12, 5);
  R(g, '#3a3f46', 0, 44, 46, 2);
});
const mvm = () => S('mvm', 16, 32, (g) => {
  R(g, '#c9ccd2', 0, 0, 16, 32);
  R(g, '#e4e6ea', 0, 0, 16, 2);
  R(g, '#2b7fd0', 2, 3, 12, 8);
  R(g, '#8fd0f8', 3, 4, 10, 2);
  R(g, '#f5d020', 2, 13, 5, 6);
  R(g, '#2f9a4a', 9, 13, 5, 6);
  R(g, '#d8382e', 2, 21, 5, 4);
  R(g, '#22242a', 9, 21, 5, 4);
  R(g, '#8a8d96', 0, 29, 16, 3);
});
const column = (txt: string) => S('col' + txt, 10, 50, (g) => {
  R(g, '#2f5a48', 1, 0, 8, 50);
  R(g, '#3f7a62', 1, 0, 2, 50);
  R(g, '#1f3f32', 7, 0, 2, 50);
  for (let y = 4; y < 48; y += 8) {
    R(g, '#1f3f32', 4, y, 1, 1);
    R(g, '#1f3f32', 6, y + 4, 1, 1);
  }
  R(g, '#15151c', 0, 12, 10, 13);
  for (let i = 0; i < Math.min(2, txt.length); i++) drawText(g, txt[i], 3, 13 + i * 6, '#ffffff');
  R(g, '#f5d020', 0, 46, 10, 4);
  R(g, '#15151c', 2, 46, 2, 4);
  R(g, '#15151c', 6, 46, 2, 4);
});
const benchS = () => S('benchs', 46, 18, (g) => {
  R(g, '#8a5c34', 0, 0, 46, 7);
  R(g, '#a87442', 0, 0, 46, 1);
  R(g, '#a87442', 0, 7, 46, 6);
  R(g, '#c08a55', 0, 7, 46, 1);
  R(g, '#6a4424', 0, 13, 46, 2);
  for (const x of [0, 11, 22, 33, 44]) R(g, '#4a2e16', x, 0, 2, 15);
  R(g, '#4a2e16', 1, 15, 2, 3);
  R(g, '#4a2e16', 43, 15, 2, 3);
});
const bin = () => S('bin', 10, 14, (g) => {
  R(g, '#22242a', 1, 3, 8, 11);
  R(g, '#2f9a4a', 0, 0, 10, 4);
  R(g, '#15151c', 3, 1, 4, 2);
  R(g, '#3a3d46', 2, 6, 1, 7);
});
const cat = () => S('cat', 10, 6, (g) => pix(g, 0, 0, ['.e.e......', '.ooo...t..', '.oooooot..', 'oooooooo..', '.oooooo...'], { o: '#f08a3c', e: '#c0601c', t: '#f08a3c' }));

function trainSprite(col: string, ch: string): HTMLCanvasElement {
  return S('train' + col, 366, 48, (g) => {
    for (let car = 0; car < 2; car++) {
      const ox = car * 186;
      R(g, '#aeb4bc', ox, 0, 180, 8);
      R(g, '#d0d5dc', ox + 2, 1, 176, 2);
      R(g, '#8e949c', ox + 28, 2, 32, 4);
      R(g, '#8e949c', ox + 120, 2, 32, 4);
      R(g, '#c8cdd4', ox, 8, 180, 36);
      R(g, '#b4bac2', ox, 8, 180, 3);
      for (const y of [30, 33, 36, 39]) R(g, '#aab0b8', ox, y, 180, 1);
      for (const [sx, sw] of [[2, 12], [42, 34], [104, 34], [166, 12]]) {
        R(g, '#22303f', ox + sx, 12, sw, 13);
        R(g, '#f2e6b8', ox + sx + 1, 13, sw - 2, 11);
        if (sw > 20) {
          R(g, '#22303f', ox + sx + (sw >> 1), 12, 1, 13);
          for (let k = 0; k < 4; k++) {
            R(g, ['#3a2a1e', '#5a3b22', '#1d1a1a', '#8a5a2b'][k], ox + sx + 4 + k * 7, 17, 4, 4);
            R(g, ['#4a7fd9', '#d94a4a', '#4ab06a', '#2b2b35'][k], ox + sx + 3 + k * 7, 21, 6, 3);
          }
        }
      }
      for (const dx of [18, 80, 142]) {
        R(g, '#b9bfc7', ox + dx, 10, 20, 34);
        R(g, '#7a8088', ox + dx + 10, 10, 1, 34);
        R(g, '#7a8088', ox + dx, 10, 1, 34);
        R(g, '#7a8088', ox + dx + 19, 10, 1, 34);
        R(g, '#22303f', ox + dx + 2, 13, 7, 12);
        R(g, '#22303f', ox + dx + 11, 13, 7, 12);
        R(g, '#f2e6b8', ox + dx + 3, 14, 5, 10);
        R(g, '#f2e6b8', ox + dx + 12, 14, 5, 10);
      }
      R(g, '#3a3f48', ox, 44, 180, 4);
      ell(g, col, ox + 70, 34, 4, 4);
      drawText(g, ch, ox + 69, 32, col === '#fccc0a' || col === '#a7a9ac' ? '#15151c' : '#ffffff');
      for (let i = 0; i < 4; i++) R(g, i % 2 ? '#f2f2f2' : '#c0392b', ox + 126, 31 + i, 7, 1);
      R(g, '#2b3f8a', ox + 126, 31, 3, 2);
    }
    R(g, '#2a2d34', 180, 30, 6, 8);
    R(g, '#22303f', 2, 12, 9, 13);
    R(g, '#e03a3a', 1, 38, 2, 3);
  });
}

// ================================================================ surfaces
type FloorFn = (g: G, x: number, y: number, w: number, h: number) => void;
const fWood = (col: string): FloorFn => (g, x, y, w, h) => {
  g.save();
  g.beginPath();
  g.rect(x, y, w, h);
  g.clip();
  R(g, col, x, y, w, h);
  for (let yy = y, k = 0; yy < y + h; yy += 6, k++) {
    R(g, shade(col, 0.82), x, yy + 5, w, 1);
    for (let xx = x + ((k * 13) % 28); xx < x + w; xx += 28) R(g, shade(col, 0.82), xx, yy, 1, 5);
    for (let xx = x + ((k * 7) % 19) + 3; xx < x + w - 6; xx += 19) R(g, shade(col, 1.08), xx, yy + 2, 5, 1);
  }
  g.restore();
};
const fCheck = (a: string, b: string, s = 8): FloorFn => (g, x, y, w, h) => {
  for (let j = 0; j < h; j += s) for (let i = 0; i < w; i += s) R(g, (i / s + j / s) & 1 ? a : b, x + i, y + j, Math.min(s, w - i), Math.min(s, h - j));
};
const fMarble = (col: string, r: Rng): FloorFn => (g, x, y, w, h) => {
  for (let j = 0; j < h; j += T) for (let i = 0; i < w; i += T) R(g, shade(col, 0.94 + (((i + j) / T) & 1) * 0.08), x + i, y + j, T, Math.min(T, h - j));
  for (let j = T - 1; j < h; j += T) R(g, shade(col, 0.82), x, y + j, w, 1);
  for (let i = T - 1; i < w; i += T) R(g, shade(col, 0.82), x + i, y, 1, h);
  for (let n = 0; n < (w * h) / 700; n++) {
    const px = x + ri(r, 4, w - 12);
    const py = y + ri(r, 2, h - 10);
    line(g, shade(col, 0.86), px, py, px + ri(r, -7, 7), py + ri(r, 3, 8));
  }
};
const fConc = (col: string, r: Rng): FloorFn => (g, x, y, w, h) => {
  R(g, col, x, y, w, h);
  for (let n = 0; n < (w * h) / 22; n++) R(g, shade(col, r() < 0.5 ? 0.9 : 1.08), x + ri(r, 0, w - 1), y + ri(r, 0, h - 1), 1, 1);
  for (let i = 32; i < w; i += 48) R(g, shade(col, 0.86), x + i, y, 1, h);
};
const fCarpet = (col: string): FloorFn => (g, x, y, w, h) => {
  R(g, col, x, y, w, h);
  for (let j = 0; j < h; j += 2) for (let i = (j % 4 ? 2 : 0); i < w; i += 4) R(g, shade(col, 0.88), x + i, y + j, 1, 1);
};
function rug(g: G, x: number, y: number, w: number, h: number, a: string, b: string) {
  R(g, a, x, y, w, h);
  R(g, b, x + 2, y + 2, w - 4, h - 4);
  R(g, a, x + 5, y + 5, w - 10, h - 10);
  R(g, shade(a, 1.25), x + 8, y + 8, w - 16, h - 16);
  for (let i = x + 12; i < x + w - 12; i += 8) {
    R(g, b, i, y + (h >> 1) - 2, 4, 4);
    R(g, shade(b, 1.3), i + 1, y + (h >> 1) - 1, 2, 2);
  }
  for (let i = x; i < x + w; i += 2) {
    R(g, shade(a, 1.4), i, y - 1, 1, 1);
    R(g, shade(a, 1.4), i, y + h, 1, 1);
  }
}
function wPaint(g: G, W: number, col: string, base = '#3a2a1e') {
  R(g, col, 0, 0, W, 48);
  R(g, shade(col, 0.78), 0, 0, W, 2);
  R(g, shade(col, 1.12), 0, 2, W, 1);
  R(g, base, 0, 42, W, 6);
  R(g, shade(base, 1.35), 0, 42, W, 1);
}
function wBrick(g: G, W: number, col: string, r: Rng) {
  R(g, col, 0, 0, W, 48);
  for (let y = 0; y < 48; y += 4) {
    R(g, shade(col, 0.76), 0, y + 3, W, 1);
    for (let x = ((y / 4) % 2) * 4; x < W; x += 8) R(g, shade(col, 0.76), x, y, 1, 3);
  }
  for (let n = 0; n < W / 3; n++) R(g, shade(col, r() < 0.5 ? 0.88 : 1.14), ri(r, 0, W / 8 - 1) * 8 + 1 + (n % 2) * 4, ri(r, 0, 11) * 4, 7, 3);
  R(g, '#3a2a1e', 0, 43, W, 5);
  R(g, '#5a4028', 0, 43, W, 1);
}
function wTile(g: G, x0: number, y0: number, W: number, H: number, col: string, band: string) {
  R(g, col, x0, y0, W, H);
  for (let y = 0; y < H; y += 4) {
    R(g, shade(col, 0.86), x0, y0 + y + 3, W, 1);
    for (let x = ((y / 4) % 2) * 4; x < W; x += 8) R(g, shade(col, 0.86), x0 + x, y0 + y, 1, 3);
  }
  R(g, band, x0, y0 + 5, W, 4);
  R(g, shade(band, 0.65), x0, y0 + 9, W, 1);
  R(g, shade(band, 0.65), x0, y0 + 4, W, 1);
  R(g, '#2a2b33', x0, y0 + H - 4, W, 4);
}
function wPanel(g: G, W: number, col: string, wood: string) {
  R(g, col, 0, 0, W, 26);
  R(g, shade(col, 0.78), 0, 0, W, 2);
  R(g, wood, 0, 26, W, 22);
  R(g, shade(wood, 1.3), 0, 26, W, 2);
  for (let x = 0; x < W; x += T) {
    R(g, shade(wood, 0.8), x + 2, 31, 12, 11);
    R(g, shade(wood, 1.12), x + 3, 32, 10, 1);
  }
  R(g, shade(wood, 0.55), 0, 45, W, 3);
}
function wStripe(g: G, W: number, a: string, b: string) {
  for (let x = 0; x < W; x += 4) R(g, (x / 4) & 1 ? a : b, x, 0, 4, 48);
  R(g, shade(a, 0.7), 0, 0, W, 2);
  R(g, '#f2ead8', 0, 42, W, 6);
  R(g, '#d6ccb8', 0, 47, W, 1);
}
function frame(g: G, r: Rng, x: number, y: number, w: number, h: number) {
  R(g, '#b8862a', x, y, w, h);
  R(g, '#e8c14a', x, y, w, 1);
  R(g, '#7a5a1a', x, y + h - 1, w, 1);
  const ix = x + 2;
  const iy = y + 2;
  const iw = w - 4;
  const ih = h - 4;
  const k = ri(r, 0, 3);
  if (k === 0) {
    R(g, '#9fd0ee', ix, iy, iw, ih);
    R(g, '#4f9a4a', ix, iy + Math.round(ih * 0.6), iw, ih - Math.round(ih * 0.6));
    tri(g, '#6a7a8a', ix + iw * 0.35, iy + ih * 0.25, iw * 0.22, ih * 0.38);
    R(g, '#ffe14a', ix + iw - 5, iy + 2, 3, 3);
  } else if (k === 1) {
    R(g, '#f2ead8', ix, iy, iw, ih);
    for (let i = 0; i < 6; i++) R(g, pick(r, ['#d8382e', '#2b5fb0', '#f5d020', '#15151c']), ix + ri(r, 0, Math.max(0, iw - 5)), iy + ri(r, 0, Math.max(0, ih - 5)), ri(r, 2, 5), ri(r, 2, 5));
  } else if (k === 2) {
    R(g, '#2a2a3a', ix, iy, iw, ih);
    const cx = ix + (iw >> 1);
    R(g, pick(r, ['#8a2a2a', '#2f6b45', '#2a4a7a']), cx - iw * 0.3, iy + ih * 0.62, iw * 0.6, ih * 0.38);
    ell(g, pick(r, ['#f6d3b3', '#c98e62', '#e8b88f']), cx, iy + ih * 0.4, Math.max(2, iw * 0.16), Math.max(2, ih * 0.22));
    R(g, '#3a2a1e', cx - iw * 0.18, iy + ih * 0.16, iw * 0.36, 2);
  } else {
    R(g, '#1f3a6a', ix, iy, iw, ih);
    for (let i = 0; i < 7; i++) R(g, '#ffe14a', ix + ri(r, 0, iw - 2), iy + ri(r, 0, ih >> 1), 2, 2);
    R(g, '#15203a', ix, iy + ih - 4, iw, 4);
    R(g, '#3a6ae0', ix + 2, iy + 3, iw - 6, 1);
  }
}
function menu(g: G, r: Rng, x: number, y: number, w: number, h: number, title: string) {
  R(g, '#6a4a2e', x, y, w, h);
  R(g, '#1f2a24', x + 1, y + 1, w - 2, h - 2);
  if (textW(title) <= w - 4) drawText(g, title, x + ((w - textW(title)) >> 1), y + 3, '#ffe14a');
  for (let yy = y + 11; yy < y + h - 3; yy += 4) {
    const lw = ri(r, 6, w - 16);
    R(g, pick(r, ['#f2f2f2', '#f2f2f2', '#ff8fb4', '#8fd0f8']), x + 3, yy, lw, 1);
    R(g, '#ffe14a', x + w - 8, yy, 5, 1);
  }
}
function neon(g: G, x: number, y: number, text: string, col: string) {
  const w = textW(text) * 2 + 6;
  R(g, '#15151c', x, y, w, 16);
  big(g, text, x + 3, y + 3, shade(col, 0.6), 2);
  big(g, text, x + 3, y + 2, col, 2);
}
function win(g: G, x: number, y: number, w: number, h: number, floorY: number) {
  R(g, '#f2ead8', x - 1, y - 1, w + 2, h + 3);
  R(g, '#9fd8f5', x, y, w, h);
  R(g, '#c9ecff', x, y, w, h >> 1);
  for (let i = 0; i < w; i += 7) R(g, '#7ab0d0', x + i, y + h - 6 - ((i * 7) % 9), 5, 6 + ((i * 7) % 9));
  R(g, '#f2ead8', x + (w >> 1), y, 1, h);
  R(g, '#f2ead8', x, y + (h >> 1), w, 1);
  R(g, '#d6ccb8', x - 2, y + h + 1, w + 4, 2);
  g.fillStyle = 'rgba(255,250,210,.13)';
  for (let i = 0; i < 26; i++) g.fillRect(x + i, floorY + i, w, 1);
}
function wshelf(g: G, r: Rng, x: number, y: number, w: number, kind: number) {
  R(g, '#6a4a2e', x, y + 8, w, 2);
  for (let i = x + 1; i < x + w - 3; i += 4) {
    if (kind === 0) {
      R(g, '#f2f2f2', i, y + 4, 3, 4);
      R(g, pick(r, ['#d8382e', '#2b7fd0', '#f5d020']), i, y + 5, 3, 1);
    } else {
      const c = pick(r, ['#2f8a4a', '#b8862a', '#8a2a2a', '#d6eef8', '#3a6ae0', '#e8c14a']);
      R(g, c, i, y + 3, 3, 5);
      R(g, c, i + 1, y, 1, 3);
      R(g, '#f2f2f2', i, y + 5, 3, 1);
    }
  }
}
function elevator(g: G, x: number, y: number) {
  R(g, '#b8862a', x - 2, y - 8, 28, 50);
  R(g, '#c9ccd2', x, y, 24, 40);
  R(g, '#e4e6ea', x + 1, y + 1, 4, 38);
  R(g, '#8a8d96', x + 12, y, 1, 40);
  R(g, '#15151c', x + 6, y - 6, 12, 5);
  R(g, '#ffb03a', x + 8, y - 5, 3, 3);
  R(g, '#e3b53a', x + 27, y + 18, 3, 5);
}
function stained(g: G, r: Rng, x: number, y: number, w: number, h: number, floorY: number) {
  const cs = ['#d94a6a', '#4aa3d9', '#e8c14a', '#4ab06a', '#c95aff', '#ff7a1e', '#3a6ae0'];
  R(g, '#3a3a44', x - 1, y - 1, w + 2, h + 1);
  for (let j = 0; j < h; j += 3) for (let i = 0; i < w; i += 3) {
    const cut = j < 6 && (i < 6 - j || i >= w - 6 + j);
    if (!cut) R(g, pick(r, cs), x + i, y + j, 2, 2);
  }
  R(g, '#3a3a44', x + (w >> 1), y, 1, h);
  for (let i = 0; i < 30; i++) {
    g.fillStyle = `rgba(${[217, 74, 232][i % 3]},${[74, 163, 193][i % 3]},${[106, 217, 74][i % 3]},.10)`;
    g.fillRect(x + i * 0.5, floorY + i * 2, w, 2);
  }
}
function curtain(g: G, x: number, y: number, w: number, h: number) {
  for (let i = 0; i < w; i += 4) R(g, (i / 4) & 1 ? '#8a1c20' : '#b3262a', x + i, y, 4, h);
  R(g, '#e3b53a', x, y + h - 2, w, 2);
}
function oven(g: G, x: number, y: number) {
  R(g, '#7a3a28', x, y, 40, 34);
  for (let j = 0; j < 34; j += 4) for (let i = (j / 4) % 2 ? 4 : 0; i < 40; i += 8) R(g, '#5a2a1c', x + i, y + j, 1, 3);
  ell(g, '#15151c', x + 20, y + 22, 13, 10);
  R(g, '#15151c', x + 7, y + 22, 27, 12);
  ell(g, '#ff7a1e', x + 20, y + 28, 9, 4);
  ell(g, '#ffd23a', x + 20, y + 30, 5, 2);
  R(g, '#ff7a1e', x + 14, y + 23, 2, 4);
  R(g, '#ffd23a', x + 22, y + 22, 2, 5);
  R(g, '#a85a3c', x + 5, y + 34 - 2, 31, 2);
}

// ================================================================ room builder
class RB {
  c: HTMLCanvasElement;
  g: G;
  solid: Uint8Array;
  objs: IObj[] = [];
  npcs: INpc[] = [];
  lamps: number[] = [];
  fx: number[] = [];
  constructor(public w: number, public h: number, public r: Rng, public L: Looks) {
    const m = mkCanvas(w * T, (h + 1) * T);
    this.c = m.c;
    this.g = m.g;
    R(m.g, '#07080f', 0, 0, w * T, (h + 1) * T);
    this.solid = new Uint8Array(w * (h + 1)).fill(1);
  }
  open(x: number, y: number, w: number, h: number) {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (xx >= 0 && yy >= 0 && xx < this.w && yy <= this.h) this.solid[yy * this.w + xx] = 0;
  }
  shut(x: number, y: number, w = 1, h = 1) {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (xx >= 0 && yy >= 0 && xx < this.w && yy <= this.h) this.solid[yy * this.w + xx] = 1;
  }
  add(c: HTMLCanvasElement, tx: number, ty: number, wt = 1, dt = 1, dx = 0, dy = 0, solid = true) {
    this.objs.push({ x: Math.round(tx * T + (wt * T - c.width) / 2 + dx), y: (ty + dt) * T - c.height + dy, c, sy: (ty + dt) * T + dy - 1 });
    if (solid) this.shut(tx, ty, wt, dt);
  }
  npc(px: number, py: number, mode: number, dir: number, role = 0, look = -1): INpc {
    const n: INpc = { x: px, y: py, look: look < 0 ? this.L.rand() : look, dir, mode, t: Math.random() * 3, an: 0, say: '', sayT: 0, sp: 20 + Math.random() * 10, path: [], role, gx: px, gy: py, dead: false, moving: false };
    this.npcs.push(n);
    return n;
  }
  sit(px: number, py: number, dir: number, p = 0.7) {
    if (this.r() < p) this.npc(px, py, 1, dir);
  }
  free(tx: number, ty: number) {
    return tx >= 0 && ty >= 0 && tx < this.w && ty < this.h && !this.solid[ty * this.w + tx];
  }
  roam(n: number, y0 = 4) {
    for (let i = 0; i < n; i++)
      for (let k = 0; k < 30; k++) {
        const tx = ri(this.r, 0, this.w - 1);
        const ty = ri(this.r, y0, this.h - 2);
        if (!this.free(tx, ty)) continue;
        this.npc(tx * T + 8, ty * T + 10, 2, ri(this.r, 0, 3));
        break;
      }
  }
  tableSet(tx: number, ty: number, top: string, cc: string) {
    this.add(tableR(top), tx, ty);
    this.add(chair(cc), tx - 1, ty, 1, 1, 4, -1);
    this.add(chair(cc), tx + 1, ty, 1, 1, -4, -1);
    this.sit((tx - 1) * T + 12, (ty + 1) * T - 2, 2);
    this.sit((tx + 1) * T + 4, (ty + 1) * T - 2, 1);
  }
  shell(wall: (g: G, W: number) => void, floor: FloorFn) {
    const g = this.g;
    const W = this.w * T;
    floor(g, 0, 3 * T, W, (this.h - 3) * T);
    wall(g, W);
    R(g, 'rgba(0,0,0,.24)', 0, 48, W, 3);
    R(g, 'rgba(0,0,0,.1)', 0, 51, W, 2);
    R(g, '#07080f', 0, 0, 2, this.h * T);
    R(g, '#07080f', W - 2, 0, 2, this.h * T);
    this.open(0, 3, this.w, this.h - 3);
    const dx = (this.w >> 1) - 1;
    R(g, '#6a2a2a', dx * T + 2, this.h * T - 11, 28, 10);
    R(g, '#8a3a3a', dx * T + 4, this.h * T - 9, 24, 6);
    R(g, '#d8d0b8', dx * T, this.h * T, 32, 5);
    R(g, '#8a8478', dx * T, this.h * T + 5, 32, 3);
    R(g, '#3a3832', dx * T, this.h * T + 8, 32, 3);
    this.open(dx, this.h, 2, 1);
  }
  done(kind: string, title: string, lines: string[], staff: string[], tint = ''): Interior {
    return {
      kind, title, w: this.w, h: this.h, bg: this.c, solid: this.solid, objs: this.objs, npcs: this.npcs,
      spawn: { x: (this.w >> 1) * T, y: this.h * T - 4, dir: 3 }, exitRow: this.h, lines, staff, tint, lamps: this.lamps, fx: this.fx, station: -1,
    };
  }
}

const has = (name: string, list: string[]) => list.some((s) => name.includes(s));

// ================================================================ templates
function cafe(name: string, rb: RB): Interior {
  const { g, r } = rb;
  rb.shell((gg, W) => {
    wBrick(gg, W, '#a8563c', r);
    menu(gg, r, 6, 5, 42, 30, 'COFFEE');
    menu(gg, r, 52, 5, 42, 30, 'PASTRY');
    wshelf(gg, r, 98, 10, 34, 0);
    wshelf(gg, r, 98, 24, 34, 0);
    win(gg, 150, 8, 34, 26, 48);
    if (textW(name) * 2 + 6 < 30) neon(gg, 190, 12, name, '#ffb03a');
    for (let x = 4; x < W; x += 9) {
      R(gg, '#3a2a1e', x, 1, 9, 1);
      R(gg, '#ffe9a8', x + 4, 2, 2, 2);
    }
  }, fWood('#c08a55'));
  rug(g, 8, 8 * T - 2, 44, 28, '#8a3a3a', '#e8c98a');
  rb.add(counter('e.pp.rj', '#e8dcc0', '#5a3a22'), 0, 4, 7, 1);
  rb.fx.push(8, 58);
  rb.npc(3 * T, 3 * T + 12, 0, 0, 1, rb.L.staff);
  rb.npc(5 * T + 8, 3 * T + 12, 0, 0, 1);
  for (let i = 0; i < 3; i++) if (r() < 0.8) rb.npc(5 * T + 8, (5 + i) * T + 8 + i * 2, 0, 3);
  rb.tableSet(9, 5, '#f2ead8', '#5a3a22');
  rb.tableSet(12, 5, '#f2ead8', '#5a3a22');
  rb.tableSet(9, 8, '#f2ead8', '#5a3a22');
  rb.tableSet(12, 8, '#f2ead8', '#5a3a22');
  rb.add(sofa('#4a7a6a'), 0, 8, 3, 1);
  rb.sit(1 * T + 2, 9 * T - 3, 0, 0.8);
  rb.add(cat(), 2, 8, 1, 1, 2, -10, false);
  rb.add(plant(true), 13, 3);
  rb.add(plant(false), 7, 3, 1, 1, 0, 0);
  rb.add(shelf('book', 2), 10, 3, 2, 1);
  rb.lamps.push(30, 30, 40, 100, 30, 40, 170, 60, 44);
  return rb.done('cafe', name, ['ONE OAT LATTE, PLEASE', 'THIS CROISSANT IS LIFE', 'WIFI PASSWORD?', "I'M WRITING A SCREENPLAY", 'ENAK BANGET KOPINYA!', 'COLD BREW SEASON', 'MMM... CAFFEINE'], ['WHAT CAN I GET YA?', 'LATTE FOR... UH... PLAYER ONE?', 'OAT, SOY OR ALMOND?', 'FRESH BAGELS TODAY!']);
}

function food(name: string, rb: RB): Interior {
  const { g, r } = rb;
  const pizza = has(name, ['PIZZA', 'PASTA', 'TRATTORIA', 'VINO', 'CANNOLI']);
  const asian = has(name, ['RAMEN', 'SUSHI', 'NOODLE', 'DIM SUM', 'THAI', 'BBQ', 'BIBIMBAP', 'TOFU', 'DUMPLING', 'TEA']);
  const diner = has(name, ['DINER', 'BURGER', 'TACOS']);
  rb.shell((gg, W) => {
    if (pizza) wPanel(gg, W, '#f2ead8', '#2f6b45');
    else if (asian) wPanel(gg, W, '#e8dcc0', '#5a2a1c');
    else wTile(gg, 0, 0, W, 48, '#f2f2ee', diner ? '#d8382e' : '#2f8a4a');
    menu(gg, r, 4, 4, 40, 28, 'MENU');
    menu(gg, r, 48, 4, 40, 28, 'SPECIAL');
    if (pizza) oven(gg, 92, 8);
    else if (asian) for (let x = 96; x < 130; x += 12) {
      R(gg, '#15151c', x + 3, 4, 1, 4);
      ell(gg, '#d8382e', x + 3, 13, 4, 5);
      R(gg, '#ffd23a', x + 2, 12, 3, 1);
      R(gg, '#ffd23a', x + 3, 18, 1, 3);
    } else {
      R(gg, '#8a8d96', 92, 14, 38, 16);
      R(gg, '#22303f', 94, 16, 34, 12);
      R(gg, '#ffb03a', 98, 17, 4, 2);
      R(gg, '#ffb03a', 110, 17, 4, 2);
      R(gg, '#c9ccd2', 94, 28, 34, 2);
    }
    if (textW(name) * 2 + 8 < W - 170) neon(gg, 168, 6, name, pizza ? '#ff5a5a' : asian ? '#ff7ab0' : '#3ad0ff');
    else neon(gg, 168, 6, 'OPEN', '#ff5a5a');
    frame(gg, r, 172, 24, 18, 14);
    frame(gg, r, 196, 24, 18, 14);
  }, pizza ? fCheck('#c0392b', '#f2ead8') : diner ? fCheck('#22242a', '#f2f2ee') : asian ? fWood('#a87442') : fCheck('#d9d4c8', '#b9b2a4'));
  void g;
  rb.add(counter(pizza ? 'zz.r.pz.' : asian ? 'p.j.r.pp' : 'pp.r.jtp', pizza ? '#d9d4c8' : '#c9ccd2', pizza ? '#8a2a2a' : asian ? '#3a2a1e' : '#8a8d96'), 0, 4, 8, 1);
  rb.npc(2 * T, 3 * T + 12, 0, 0, 1, rb.L.staff);
  rb.npc(6 * T, 3 * T + 12, 0, 0, 1, rb.L.staff);
  for (let x = 1; x < 8; x += 2) {
    rb.add(stool(diner ? '#d8382e' : '#3a3a44'), x, 5, 1, 1, 0, -2);
    rb.sit(x * T + 8, 6 * T - 3, 3, 0.65);
  }
  rb.add(fridge(), 8, 3, 2, 1);
  for (const ty of [4, 6, 8]) {
    rb.add(booth(diner ? '#d8382e' : pizza ? '#2f6b45' : '#8a5a2b'), 11, ty, 3, 1);
    rb.sit(11 * T + 9, (ty + 1) * T - 2, 2);
    rb.sit(13 * T + 5, (ty + 1) * T - 2, 1);
  }
  rb.add(tableS('#e8e2d4'), 3, 8, 2, 1);
  rb.add(chair('#5a3a22'), 2, 8, 1, 1, 5, -1);
  rb.add(chair('#5a3a22'), 5, 8, 1, 1, -5, -1);
  rb.sit(2 * T + 13, 9 * T - 2, 2);
  rb.sit(5 * T + 3, 9 * T - 2, 1);
  rb.add(plant(false), 0, 9, 1, 1);
  rb.roam(1, 6);
  rb.lamps.push(40, 40, 40, 112, 36, pizza ? 46 : 30, 200, 20, 36);
  return rb.done('food', name, ['TWO SLICES AND A COKE', 'EXTRA HOT SAUCE!', 'BEST IN THE CITY, NO CAP', 'CHECK, PLEASE!', 'PORSINYA GEDE BANGET', 'INI ENAK PARAH', 'I COME HERE EVERY DAY', 'PASS THE KETCHUP'], ['ORDER UP!', 'FOR HERE OR TO GO?', 'NEXT! WHO IS NEXT?', "WHAT'LL IT BE, HON?"]);
}

function bar(name: string, rb: RB): Interior {
  const { r } = rb;
  const stage = has(name, ['JAZZ', 'COMEDY', 'KARAOKE', 'PUNK']);
  rb.shell((gg, W) => {
    wPanel(gg, W, '#3a2a3a', '#4a2a1a');
    R(gg, '#22242a', 4, 4, 136, 30);
    R(gg, '#5a7a8a', 6, 6, 132, 26);
    R(gg, '#7a9aaa', 8, 7, 40, 1);
    wshelf(gg, r, 6, 5, 132, 1);
    wshelf(gg, r, 6, 15, 132, 1);
    R(gg, '#4a2a1a', 4, 33, 136, 3);
    neon(gg, 150, 4, textW(name) * 2 + 8 < 100 ? name : 'BAR', '#ff5ab0');
    if (stage) curtain(gg, 162, 22, 94, 26);
    else {
      frame(gg, r, 160, 24, 20, 16);
      frame(gg, r, 190, 24, 20, 16);
      neon(gg, 220, 24, 'ALE', '#ffd23a');
    }
  }, fWood('#5a3a26'));
  rb.add(counter('.t..j.t.r', '#3a2418', '#5a3220'), 0, 4, 9, 1);
  rb.npc(4 * T, 3 * T + 12, 0, 0, 1, rb.L.staff);
  for (let x = 0; x < 9; x += 2) {
    rb.add(stool('#8a2a2a'), x, 5, 1, 1, 0, -2);
    rb.sit(x * T + 8, 6 * T - 3, 3, 0.7);
  }
  rb.add(jukebox(), 9, 3);
  if (stage) {
    R(rb.g, '#7a5232', 10 * T, 3 * T, 6 * T, 2 * T);
    R(rb.g, '#9a6a42', 10 * T, 3 * T, 6 * T, 2);
    R(rb.g, '#3a2414', 10 * T, 5 * T - 4, 6 * T, 4);
    rb.shut(10, 3, 6, 2);
    rb.add(piano(), 10, 3, 3, 1, 0, 8, false);
    rb.add(mic(), 14, 4, 1, 1, 0, -6, false);
    rb.npc(14 * T - 6, 5 * T - 6, 0, 0, 2, rb.L.music);
    rb.tableSet(11, 6, '#3a2418', '#5a3220');
    rb.tableSet(14, 6, '#3a2418', '#5a3220');
    rb.tableSet(12, 8, '#3a2418', '#5a3220');
    rb.lamps.push(13 * T, 4 * T, 50);
  } else {
    rb.add(poolTable(), 11, 6, 3, 2);
    rb.npc(10 * T + 6, 7 * T + 4, 0, 2);
    rb.npc(14 * T + 10, 7 * T + 10, 0, 1);
    rb.tableSet(12, 4, '#3a2418', '#5a3220');
  }
  rb.tableSet(2, 8, '#3a2418', '#5a3220');
  rb.tableSet(6, 8, '#3a2418', '#5a3220');
  rb.roam(2, 6);
  rb.lamps.push(72, 20, 60, 180, 12, 40, 152, 60, 30);
  return rb.done('bar', name, ['ANOTHER ROUND!', 'CHEERS!', 'THIS SONG AGAIN?', "I'M NOT DRUNK, YOU ARE", 'GO KNICKS!', 'ONE MORE, THEN HOME', 'SANTAI DULU, BRO'], ["WHAT'LL IT BE?", 'ID, PLEASE', 'HAPPY HOUR TILL 7', 'LAST CALL... JUST KIDDING'], '#c8b0c0');
}

function shop(name: string, rb: RB): Interior {
  const { r } = rb;
  const v = has(name, ['BOOK', 'NEWS', 'MAPS']) ? 'book' : has(name, ['VINYL', 'RECORD', 'K-POP']) ? 'record'
    : has(name, ['BOUTIQUE', 'DENIM', 'SHOES', 'SNEAKER', 'VINTAGE', 'THRIFT', 'ATELIER', 'BEAUTY', 'NAILS', 'BARBER', 'TATTOO', 'LAUNDRY']) ? 'clothes'
    : has(name, ['FLOWER', 'HERB']) ? 'flower' : 'grocery';
  const wallC = { book: '#3a5a4a', record: '#2a2a3a', clothes: '#f2e6e0', flower: '#e8f0d8', grocery: '#f2ead0' }[v];
  rb.shell((gg, W) => {
    wPaint(gg, W, wallC, v === 'clothes' ? '#d6c4b8' : '#3a2a1e');
    if (textW(name) * 2 + 8 < 78) neon(gg, 146, 4, name, v === 'record' ? '#ff5ab0' : '#ffd23a');
    frame(gg, r, 150, 24, 18, 14);
    frame(gg, r, 174, 24, 18, 14);
    R(gg, '#f2ead8', 198, 22, 22, 16);
    drawText(gg, 'SALE', 201, 24, '#d8382e');
    drawText(gg, '50%', 203, 31, '#15151c');
  }, v === 'clothes' ? fWood('#d9b88a') : v === 'grocery' ? fCheck('#d9d4c8', '#c4bfb2', 16) : v === 'record' ? fCheck('#2a2a33', '#3a3a44', 16) : fWood('#b8824f'));
  const sk = v === 'book' ? 'book' : v === 'record' ? 'record' : v === 'clothes' ? 'shoe' : 'grocery';
  for (let i = 0; i < 4; i++) {
    if (v === 'grocery' && i === 3) rb.add(fridge(), 6, 3, 2, 1);
    else if (v === 'flower' && i % 2) rb.add(buckets(i), i * 2, 3, 2, 1);
    else rb.add(shelf(sk, i + 1), i * 2, 3, 2, 1);
  }
  rb.add(counter(v === 'flower' ? 'f.rf.' : v === 'book' ? 'b.r.b' : '.jr..', '#e8dcc0', v === 'record' ? '#3a2a4a' : '#6a4a2e'), 9, 4, 5, 1);
  rb.npc(11 * T + 8, 3 * T + 12, 0, 0, 1, v === 'grocery' ? rb.L.staff : -1);
  const unit = (tx: number, ty: number, k: number) => {
    if (v === 'clothes') rb.add(rack(k), tx, ty, 2, 1);
    else if (v === 'record') rb.add(recordBin(k), tx, ty, 2, 1);
    else if (v === 'flower') rb.add(buckets(k + 4), tx, ty, 2, 1);
    else rb.add(shelf(sk, k + 10), tx, ty, 2, 1);
  };
  unit(1, 6, 1);
  unit(4, 6, 2);
  unit(1, 8, 3);
  unit(4, 8, 4);
  unit(8, 7, 5);
  unit(11, 7, 6);
  if (v === 'clothes') {
    rb.add(mannequin('#d94a4a'), 7, 9, 1, 1);
    rb.add(mannequin('#4a7fd9'), 13, 9, 1, 1);
    R(rb.g, '#b8862a', 9 * T - 14, 6, 12, 30);
    R(rb.g, '#cfeefa', 9 * T - 12, 8, 8, 26);
  } else if (v === 'book') {
    rb.add(sofa('#8a3a3a'), 10, 9, 3, 1);
    rb.sit(11 * T, 10 * T - 3, 0, 0.9);
    rb.add(lampF(), 13, 9);
    rb.add(cat(), 9, 9, 1, 1, 0, -2, false);
  } else rb.add(plant(v === 'flower'), 13, 9, 1, 1);
  rb.add(plant(false), 0, 9, 1, 1);
  rb.roam(3, 5);
  rb.lamps.push(60, 30, 50, 180, 30, 50);
  const lines = v === 'book' ? ['SHHH... READING', 'THE BOOK WAS BETTER', 'ONE MORE CHAPTER', 'DO YOU HAVE MAPS?'] : v === 'record' ? ['VINYL JUST SOUNDS WARMER', 'RARE PRESSING!!', 'THIS BAND WAS BETTER LIVE']
    : v === 'clothes' ? ['DOES THIS FIT ME?', 'TOO EXPENSIVE...', 'TREAT YOURSELF!', 'COCOK NGGAK YA?'] : v === 'flower' ? ['ROSES FOR MY MOM', 'SMELLS SO GOOD HERE', 'A DOZEN TULIPS, PLEASE'] : ['WHERE IS THE MILK?', 'BACON EGG AND CHEESE!', 'GOT ANY SNACKS?', 'BELI OLEH-OLEH DULU'];
  return rb.done('shop', name, lines, ['CASH OR CARD?', 'NEED A BAG?', 'LET ME KNOW IF YOU NEED HELP', 'HAVE A GOOD ONE!']);
}

function lobby(name: string, rb: RB): Interior {
  const { g, r } = rb;
  rb.shell((gg, W) => {
    wPanel(gg, W, '#e8dcc0', '#6a4628');
    for (const x of [24, 62, 100]) elevator(gg, x, 8);
    R(gg, '#b8862a', 150, 4, W - 162, 16);
    R(gg, '#3a2418', 152, 6, W - 166, 12);
    const tw = textW(name);
    if (tw * 2 <= W - 172) big(gg, name, 152 + ((W - 166 - tw * 2) >> 1), 7, '#e8c14a', 2);
    else if (tw <= W - 170) drawText(gg, name, 152 + ((W - 166 - tw) >> 1), 10, '#e8c14a');
    frame(gg, r, 160, 24, 24, 16);
    frame(gg, r, 240, 24, 24, 16);
    R(gg, '#f2ead8', 200, 26, 24, 10);
    for (let i = 0; i < 4; i++) R(gg, i % 2 ? '#f2f2f2' : '#c0392b', 200, 26 + i * 2 + 1, 24, 1);
    R(gg, '#2b3f8a', 200, 26, 10, 5);
  }, fMarble('#e8e0cc', r));
  const W = rb.w * T;
  rug(g, (W >> 1) - 44, 6 * T, 88, 44, '#7a2a2a', '#e3b53a');
  rb.add(counter('m.b.m', '#3a2418', '#6a4628'), 12, 4, 5, 1);
  rb.npc(14 * T + 8, 3 * T + 12, 0, 0, 1);
  rb.add(sofa('#2f5a6a'), 1, 7, 3, 1);
  rb.add(sofa('#2f5a6a'), 1, 9, 3, 1);
  rb.sit(2 * T, 8 * T - 3, 0);
  rb.sit(3 * T + 4, 10 * T - 3, 0);
  rb.add(coffeeT(), 5, 8, 2, 1, 0, 0, true);
  rb.add(plant(true), 0, 3);
  rb.add(plant(true), 17, 3);
  rb.add(plant(true), 8, 3);
  rb.add(pedestal(0), 14, 8, 1, 1);
  rb.add(pedestal(3), 16, 8, 1, 1);
  rb.add(lampF(), 4, 7, 1, 1, 6, 0, false);
  rb.npc(10 * T + 8, 9 * T + 8, 0, 0, 0, rb.L.cop);
  rb.roam(4, 5);
  rb.lamps.push(40, 30, 40, 78, 30, 40, 116, 30, 40, 230, 50, 50);
  return rb.done('lobby', name, ['HOLD THE ELEVATOR!', 'MEETING ON THE 80TH FLOOR', 'NICE LOBBY', 'WHERE IS THE GIFT SHOP?', 'LIFTNYA LAMA BANGET', 'BIG DEAL TODAY'], ['WELCOME! HOW CAN I HELP?', 'ELEVATORS ARE ON YOUR LEFT', 'VISITOR PASS, PLEASE', 'ENJOY YOUR STAY!']);
}

function home(name: string, rb: RB): Interior {
  const { g, r } = rb;
  rb.shell((gg, W) => {
    wStripe(gg, W, pick(r, ['#d8c8a8', '#c8d8c8', '#d8c0c0', '#c0c8d8']), '#e8dcc0');
    win(gg, 70, 8, 28, 26, 48);
    R(gg, '#8a3a3a', 66, 6, 5, 32);
    R(gg, '#8a3a3a', 97, 6, 5, 32);
    frame(gg, r, 36, 6, 14, 12);
    R(gg, '#d9c8a8', 112, 4, 64, 16);
    for (let x = 114; x < 174; x += 16) {
      R(gg, '#b8a888', x, 6, 14, 12);
      R(gg, '#8a7a5a', x + 11, 11, 1, 3);
    }
    void W;
  }, fWood(pick(r, ['#b8824f', '#a87442', '#c8965f'])));
  rug(g, 18, 6 * T - 2, 76, 40, pick(r, ['#2f5a6a', '#7a2a2a', '#4a3a6a']), '#e8c98a');
  rb.add(tv(), 0, 3, 2, 1);
  rb.add(shelf('book', 7), 2, 3, 2, 1);
  rb.add(counter('sk.', '#d9d4c8', '#f2ead8'), 7, 3, 3, 1);
  rb.add(homeFridge(), 10, 3);
  rb.add(sofa(pick(r, ['#8a5a3a', '#4a6a8a', '#6a8a5a'])), 1, 6, 3, 1);
  rb.add(cat(), 3, 6, 1, 1, -2, -9, false);
  rb.add(coffeeT(), 5, 6, 2, 1, -4, 0, true);
  rb.add(tableS('#a87442'), 7, 6, 2, 1, 8, 0);
  rb.add(chair('#5a3a22'), 7, 6, 1, 1, 0, -1, false);
  rb.add(bed(pick(r, ['#4a7fd9', '#d94a6a', '#4ab06a'])), 10, 6, 2, 2, 0, 0);
  rb.add(lampF(), 9, 7, 1, 1, 4, 0, false);
  rb.add(plant(true), 11, 3);
  rb.add(plant(false), 0, 8, 1, 1);
  rb.npc(8 * T + 8, 4 * T + 12, 2, 0);
  rb.lamps.push(86, 30, 50, 150, 100, 36);
  return rb.done('home', name, ['UH... WHO ARE YOU?!', 'RENT IS $4000 FOR THIS', 'SHOES OFF, PLEASE!', 'MY CAT RUNS THIS PLACE', 'MAU TEH?'], ['UH... WHO ARE YOU?!', 'DID I LEAVE THE DOOR OPEN?', 'NICE PLACE, RIGHT? TINY THOUGH']);
}

function museum(name: string, rb: RB): Interior {
  const { g, r } = rb;
  const dinoHall = name.includes('NATURAL');
  const white = name.includes('GUGGENHEIM') || has(name, ['GALLERY', 'ART', 'STUDIO']);
  rb.shell((gg, W) => {
    wPaint(gg, W, white ? '#f4f2ec' : dinoHall ? '#6a4a3a' : '#7a2a3a', white ? '#d9d4c8' : '#3a2a1e');
    let x = 8;
    while (x < W - 30) {
      const fw = ri(r, 18, 34);
      const fh = ri(r, 16, 28);
      frame(gg, r, x, 6 + ((30 - fh) >> 1), fw, fh);
      R(gg, '#f2ead8', x + (fw >> 1) - 3, 38, 6, 2);
      x += fw + ri(r, 8, 16);
    }
  }, white ? fCheck('#e8e6e0', '#dedcd4', 16) : fWood('#9a6a42'));
  const W = rb.w * T;
  void g;
  const mid = rb.w >> 1;
  if (dinoHall) {
    rb.add(dino(), mid - 3, 6, 6, 2);
    rb.add(glassCase(1), 1, 6, 2, 1);
    rb.add(glassCase(2), rb.w - 3, 6, 2, 1);
    if (rb.h > 10) {
      rb.add(glassCase(3), 1, 9, 2, 1);
      rb.add(glassCase(0), rb.w - 3, 9, 2, 1);
    }
  } else {
    const ks = [1, 0, 2, 3, 1, 2];
    let k = 0;
    for (let tx = 2; tx < rb.w - 1; tx += 4) rb.add(pedestal(ks[k++ % 6]), tx, 6, 1, 1);
    if (rb.h > 10) {
      rb.add(glassCase(0), 2, 9, 2, 1);
      rb.add(glassCase(1), rb.w - 4, 9, 2, 1);
    }
  }
  rb.add(benchM(), mid - 1, rb.h - 3, 2, 1);
  rb.sit(mid * T - 6, (rb.h - 2) * T - 4, 3, 0.8);
  rb.npc(T + 8, 4 * T + 6, 0, 0, 1, rb.L.cop);
  for (let i = 0; i < Math.floor(rb.w / 4); i++) rb.npc(ri(r, 2, rb.w - 2) * T, 3 * T + 12 + ri(r, 0, 6), 0, 3);
  rb.roam(Math.floor(rb.w / 5), 5);
  for (let x = 30; x < W; x += 70) rb.lamps.push(x, 26, 44);
  return rb.done('museum', name, ['IS THIS ART?', 'MY KID COULD PAINT THAT', 'WOW...', 'NO PHOTOS? AWW', dinoHall ? 'THAT T-REX IS HUGE!' : 'SO MUCH HISTORY', 'KEREN BANGET!', 'WHERE IS THE EXIT?'], ['NO FLASH PHOTOGRAPHY', 'PLEASE DO NOT TOUCH', 'WE CLOSE AT 5:30']);
}

function church(name: string, rb: RB): Interior {
  const { g, r } = rb;
  rb.shell((gg, W) => {
    R(gg, '#8a8478', 0, 0, W, 48);
    for (let y = 0; y < 48; y += 8) {
      R(gg, '#6a655c', 0, y + 7, W, 1);
      for (let x = ((y / 8) % 2) * 8; x < W; x += 16) R(gg, '#6a655c', x, y, 1, 7);
    }
    for (const x of [16, 60, W - 80, W - 36]) stained(gg, r, x, 6, 20, 34, 48);
    stained(gg, r, (W >> 1) - 16, 2, 32, 40, 48);
    R(gg, '#4a463e', 0, 44, W, 4);
  }, fCheck('#a8a296', '#989286', 16));
  const W = rb.w * T;
  const mid = rb.w >> 1;
  R(g, '#7a2a2a', mid * T - 20, 3 * T, 40, (rb.h - 3) * T);
  R(g, '#e3b53a', mid * T - 20, 3 * T, 2, (rb.h - 3) * T);
  R(g, '#e3b53a', mid * T + 18, 3 * T, 2, (rb.h - 3) * T);
  rb.add(altar(), mid - 1, 4, 2, 1, 0, 0);
  rb.add(candles(), mid - 3, 4, 1, 1);
  rb.add(candles(), mid + 2, 4, 1, 1);
  for (let ty = 6; ty < rb.h - 1; ty += 2) {
    rb.add(pew(), mid - 5, ty, 3, 1);
    rb.add(pew(), mid + 2, ty, 3, 1);
    for (const px of [mid - 5, mid - 4, mid + 2, mid + 3]) rb.sit(px * T + 14, (ty + 1) * T - 3, 3, 0.3);
  }
  rb.npc(mid * T + 26, 5 * T + 8, 0, 0, 1);
  rb.lamps.push(mid * T, 4 * T, 60, (mid - 3) * T + 8, 4 * T, 26, (mid + 2) * T + 8, 4 * T, 26, 26, 30, 40, W - 26, 30, 40);
  return rb.done('church', name, ['...', 'SO PEACEFUL', 'AMEN', 'LOOK AT THOSE WINDOWS', 'ADEM BANGET DI SINI'], ['WELCOME, MY CHILD', 'ALL ARE WELCOME HERE', 'PEACE BE WITH YOU'], '#b0a8c0');
}

function library(name: string, rb: RB): Interior {
  const { r } = rb;
  rb.shell((gg, W) => wPanel(gg, W, '#5a3a2a', '#4a2a1a'), fWood('#8a5a34'));
  for (let tx = 0; tx < rb.w; tx += 2) {
    if (tx === 8) {
      win(rb.g, 8 * T + 2, 8, 28, 28, 48);
      continue;
    }
    rb.add(shelf('book', tx + 20), tx, 3, 2, 1);
  }
  for (const ty of [6, 8]) for (const tx of [1, 7, 13]) {
    rb.add(longTable(), tx, ty, 4, 1);
    for (let i = 0; i < 3; i++) rb.sit(tx * T + 12 + i * 20, (ty + 1) * T - 14, 0, 0.45);
  }
  rb.add(counter('b.m', '#3a2418', '#6a4628'), 14, 10, 3, 1, 0, -6);
  rb.npc(15 * T + 8, 9 * T + 6, 0, 0, 1);
  rb.add(pedestal(0), 0, 10, 1, 1);
  rb.roam(3, 5);
  for (let x = 40; x < rb.w * T; x += 96) rb.lamps.push(x, 7 * T, 40, x, 9 * T, 40);
  void r;
  return rb.done('library', name, ['SHHH!', '...', '(TURNS PAGE)', 'OVERDUE BY 3 YEARS...', 'BELAJAR DULU'], ['SHHH! QUIET, PLEASE', 'LIBRARY CARD?', 'RETURNS GO ON THE LEFT'], '#e0d0b8');
}

function theater(name: string, rb: RB): Interior {
  const { g } = rb;
  rb.shell((gg, W) => {
    R(gg, '#15151c', 0, 0, W, 48);
    curtain(gg, 0, 0, 40, 48);
    curtain(gg, W - 40, 0, 40, 48);
    curtain(gg, 40, 0, W - 80, 10);
    R(gg, '#2a1c3a', 40, 10, W - 80, 38);
    for (let i = 0; i < 14; i++) R(gg, '#ffe14a', 46 + ((i * 37) % (W - 96)), 14 + ((i * 11) % 22), 1, 1);
    const tw = textW(name) * 2;
    if (tw < W - 90) big(gg, name, (W - tw) >> 1, 16, '#ffd23a', 2);
  }, fCarpet('#7a2230'));
  const W = rb.w * T;
  R(g, '#8a5c34', 0, 3 * T, W, 2 * T);
  fWood('#9a6a42')(g, 0, 3 * T, W, 2 * T - 5);
  R(g, '#4a2e16', 0, 5 * T - 5, W, 5);
  for (let x = 6; x < W; x += 12) R(g, '#ffe9a8', x, 5 * T - 4, 3, 2);
  rb.shut(0, 3, rb.w, 2);
  rb.add(piano(), 2, 3, 3, 1, 0, 8, false);
  rb.add(mic(), 8, 4, 1, 1, 0, -6, false);
  rb.npc(8 * T - 6, 5 * T - 8, 0, 0, 2, rb.L.music);
  rb.npc(10 * T, 5 * T - 9, 0, 0, 2);
  rb.npc(11 * T + 6, 5 * T - 7, 0, 0, 2);
  for (let ty = 6; ty < rb.h - 1; ty += 2) for (const tx of [1, 4, 9, 12]) {
    rb.add(seats('#b3262a'), tx, ty, 3, 1);
    for (let i = 0; i < 4; i++) rb.sit(tx * T + 7 + i * 11, (ty + 1) * T - 3, 3, 0.6);
  }
  rb.lamps.push(8 * T, 4 * T, 70, 3 * T, 4 * T, 40, 12 * T, 4 * T, 40);
  return rb.done('theater', name, ['BRAVO!', 'ENCORE!', 'SHH, IT IS STARTING', 'BEST SHOW EVER', 'TIKETNYA MAHAL TAPI WORTH IT'], ['} BROADWAY BABY }', '} LA LA LAAA }', '} NEW YORK, NEW YORK }'], '#b8a0b0');
}

function terminal(name: string, rb: RB): Interior {
  const { g, r } = rb;
  rb.shell((gg, W) => {
    wPaint(gg, W, '#d9cdb0', '#8a7a5a');
    for (let i = 0; i < 3; i++) {
      const x = 30 + i * ((W - 60) / 3) + 20;
      R(gg, '#b9ad90', x - 3, 4, 56, 40);
      R(gg, '#cfeefa', x, 8, 50, 34);
      R(gg, '#eaf8ff', x, 8, 50, 12);
      R(gg, '#d9cdb0', x, 8, 6, 5);
      R(gg, '#d9cdb0', x + 44, 8, 6, 5);
      for (let k = 10; k < 50; k += 10) R(gg, '#8a9aa8', x + k, 8, 1, 34);
      R(gg, '#8a9aa8', x, 24, 50, 1);
      gg.fillStyle = 'rgba(255,248,200,.12)';
      for (let k = 0; k < 110; k++) gg.fillRect(x + k * 0.55, 48 + k, 50, 1);
    }
    R(gg, '#15151c', 6, 6, 36, 30);
    drawText(gg, 'DEPART', 9, 8, '#ffb03a');
    for (let y = 16; y < 34; y += 4) {
      R(gg, '#ffb03a', 9, y, ri(r, 10, 18), 1);
      R(gg, '#7ad8a0', 32, y, 7, 1);
    }
    for (let x = W - 44; x < W - 6; x += 13) {
      R(gg, '#b8862a', x, 14, 11, 28);
      R(gg, '#3a2a1e', x + 2, 18, 7, 12);
      R(gg, '#ffe9a8', x + 3, 19, 5, 4);
    }
  }, fMarble('#e8dcc0', r));
  const mid = rb.w >> 1;
  void g;
  rb.add(infoClock(), mid - 1, 6, 2, 2);
  rb.npc(mid * T, 8 * T + 10, 0, 0, 1);
  rb.add(benchS(), 2, 9, 3, 1);
  rb.add(benchS(), rb.w - 5, 9, 3, 1);
  rb.sit(3 * T, 10 * T - 4, 0);
  rb.sit(4 * T + 4, 10 * T - 4, 0);
  rb.sit((rb.w - 4) * T, 10 * T - 4, 0);
  rb.npc(3 * T, 5 * T, 0, 0, 0, rb.L.cop);
  rb.roam(12, 4);
  for (let i = 0; i < 5; i++) rb.npc(ri(r, 2, rb.w - 2) * T, ri(r, 5, rb.h - 2) * T, 0, ri(r, 0, 3));
  rb.lamps.push(mid * T, 6 * T + 6, 40);
  return rb.done('terminal', name, ['WHICH TRACK?!', "I'LL MISS MY TRAIN!", 'MEET ME AT THE CLOCK', 'LOOK AT THAT CEILING', 'KERETA KE MANA NIH?', 'ALL ABOARD!'], ['INFORMATION! HOW CAN I HELP?', 'TRACK 29, DOWN THE RAMP', 'THE CLOCK IS WORTH MILLIONS']);
}

export function classify(name: string): string {
  if (has(name, ['COFFEE', 'CAFE', 'BAKERY', 'DONUT', 'BAGEL', 'ESPRESSO', 'CAFFE', 'BOBA', 'GELATO', 'ICE CREAM'])) return 'cafe';
  if (has(name, ['BAR', 'WINE', 'JAZZ', 'COMEDY', 'KARAOKE', 'SOJU', 'PUNK']) && !name.includes('BARBER')) return 'bar';
  if (has(name, ['PIZZA', 'DINER', 'RAMEN', 'SUSHI', 'TACOS', 'THAI', 'BURGER', 'HALAL', 'DIM SUM', 'NOODLE', 'PASTA', 'BBQ', 'BIBIMBAP', 'TOFU', 'DUMPLING', 'TRATTORIA', 'PIEROGI', 'OYSTER', 'CHOWDER', 'FISH', 'KATZ', 'DELI', 'CANNOLI', 'VINO', 'TEA'])) return 'food';
  if (has(name, ['GALLERY', 'ART', 'STUDIO'])) return 'museum';
  if (has(name, ['HOTEL', 'BANK', 'GYM'])) return 'lobby';
  return 'shop';
}

export function makeInterior(kind: string, name: string, seed: number, L: Looks): Interior {
  const r = mulberry32(seed);
  switch (kind) {
    case 'cafe': return cafe(name, new RB(14, 10, r, L));
    case 'food': return food(name, new RB(14, 10, r, L));
    case 'bar': return bar(name, new RB(16, 10, r, L));
    case 'lobby': return lobby(name, new RB(18, 11, r, L));
    case 'home': return home(name, new RB(12, 9, r, L));
    case 'museum': return museum(name, has(name, ['GALLERY', 'ART', 'STUDIO']) && !name.includes('MET') ? new RB(14, 10, r, L) : new RB(22, 12, r, L));
    case 'church': return church(name, new RB(14, 14, r, L));
    case 'library': return library(name, new RB(18, 11, r, L));
    case 'theater': return theater(name, new RB(16, 12, r, L));
    case 'terminal': return terminal(name, new RB(24, 12, r, L));
    default: return shop(name, new RB(14, 10, r, L));
  }
}

// ================================================================ subway station
export function makeSubway(name: string, idx: number, L: Looks, arrive: boolean): Interior {
  const w = 32;
  const h = 12;
  const r = mulberry32(idx * 77 + 5);
  const rb = new RB(w, h, r, L);
  const g = rb.g;
  const W = w * T;
  const band = LINE_COL[idx % 8];
  const short = name.split('·')[0].trim().toUpperCase();
  fConc('#8f8f8a', r)(g, 0, 5 * T, W, 7 * T);
  for (let y = 5 * T; y < 12 * T; y += 2) R(g, 'rgba(0,0,0,.02)', 0, y, W, 1);
  R(g, 'rgba(0,0,0,.28)', 0, 12 * T - 6, W, 6);
  // far wall + name tablets
  wTile(g, 9 * T, 0, W - 9 * T, 2 * T, '#e8e6dc', band);
  for (let x = 10 * T; x + textW(short) + 12 < W; x += Math.max(120, textW(short) + 60)) {
    R(g, shade(band, 0.55), x, 12, textW(short) + 10, 13);
    R(g, '#f2ead8', x + 1, 13, textW(short) + 8, 11);
    R(g, shade(band, 0.55), x + 2, 14, textW(short) + 6, 9);
    drawText(g, short, x + 5, 16, '#ffffff');
  }
  for (let x = 14 * T; x < W - 30; x += 150) {
    R(g, '#22242a', x + 70, 11, 22, 16);
    R(g, pick(r, ['#d8382e', '#f5d020', '#3ad0ff', '#4ab06a']), x + 71, 12, 20, 14);
    drawText(g, pick(r, ['SALE', 'SHOW', 'COLA', 'NYC']), x + 73, 16, '#15151c');
  }
  // track pit
  R(g, '#1c1d24', 9 * T, 2 * T, W - 9 * T, 3 * T);
  for (let n = 0; n < 500; n++) R(g, r() < 0.5 ? '#2a2b33' : '#15161c', 9 * T + ri(r, 0, W - 9 * T - 1), 2 * T + ri(r, 0, 47), 1, 1);
  for (let x = 9 * T + 2; x < W; x += 8) R(g, '#3a2a1e', x, 2 * T + 12, 4, 26);
  R(g, '#9a9da6', 9 * T, 2 * T + 15, W - 9 * T, 2);
  R(g, '#9a9da6', 9 * T, 2 * T + 33, W - 9 * T, 2);
  R(g, '#5a5d66', 9 * T, 2 * T + 17, W - 9 * T, 1);
  R(g, '#5a5d66', 9 * T, 2 * T + 35, W - 9 * T, 1);
  R(g, '#c8b060', 9 * T, 2 * T + 5, W - 9 * T, 3);
  R(g, '#0c0d12', 9 * T, 5 * T - 5, W - 9 * T, 5);
  R(g, '#0a0a0f', 9 * T, 2 * T, 10, 3 * T);
  // platform edge
  R(g, '#e8c530', 9 * T, 5 * T, W - 9 * T, 7);
  for (let x = 9 * T + 1; x < W; x += 3) {
    R(g, '#b89a1c', x, 5 * T + 1, 1, 1);
    R(g, '#b89a1c', x + 1, 5 * T + 4, 1, 1);
  }
  R(g, '#f2f2ee', 9 * T, 5 * T + 7, W - 9 * T, 1);
  // entry zone wall (rows 2..4) with stairs
  R(g, '#0b0c14', 0, 0, 9 * T, 2 * T);
  wTile(g, 0, 2 * T, 9 * T, 3 * T, '#e8e6dc', band);
  R(g, '#3a3d46', 9 * T - 3, 2 * T, 3, 3 * T);
  R(g, '#15151c', 2 * T - 2, 2 * T + 4, 36, 44);
  for (let i = 0; i < 9; i++) {
    R(g, shade('#8a8d96', 1.1 - i * 0.08), 2 * T, 5 * T - (i + 1) * 5, 32, 4);
    R(g, shade('#55565e', 1.1 - i * 0.08), 2 * T, 5 * T - (i + 1) * 5 + 4, 32, 1);
  }
  R(g, '#cfeefa', 2 * T, 2 * T + 4, 32, 4);
  R(g, '#c9ccd2', 2 * T - 2, 2 * T + 4, 2, 44);
  R(g, '#c9ccd2', 2 * T + 32, 2 * T + 4, 2, 44);
  R(g, '#1f7a3a', 2 * T - 4, T + 6, 40, 11);
  drawText(g, 'EXIT', 2 * T + 2, T + 9, '#ffffff');
  tri(g, '#ffffff', 2 * T + 26, T + 9, 3, 4);
  // subway map + posters
  R(g, '#22242a', 5 * T - 4, 2 * T + 12, 34, 26);
  R(g, '#f2ead8', 5 * T - 3, 2 * T + 13, 32, 24);
  for (let i = 0; i < 6; i++) line(g, LINE_COL[i], 5 * T, 2 * T + 16 + i * 3, 5 * T + 26, 2 * T + 20 + ((i * 5) % 14));
  R(g, '#22242a', 7 * T + 4, 2 * T + 14, 16, 22);
  R(g, band, 7 * T + 5, 2 * T + 15, 14, 20);
  drawText(g, LINE_CH[idx % 8], 7 * T + 10, 2 * T + 22, '#ffffff');
  R(g, 'rgba(0,0,0,.24)', 0, 5 * T, 9 * T, 3);

  rb.open(0, 5, w, 7);
  rb.open(2, 3, 2, 2);
  rb.shut(8, 5);
  rb.shut(8, 11);
  for (const y of [5, 11]) {
    R(g, '#8a8d96', 8 * T + 6, y * T - 12, 2, 28);
    for (let k = 0; k < 4; k++) R(g, '#c9ccd2', 8 * T + 2, y * T - 8 + k * 6, 10, 1);
  }
  for (const y of [6, 8, 10]) rb.add(turnstile(), 8, y);
  rb.add(mvm(), 0, 5);
  rb.add(mvm(), 1, 5);
  rb.add(tokenBooth(), 4, 5, 3, 1);
  const abbr = short.replace(/[^A-Z0-9]/g, '').slice(0, 2);
  for (const x of [12, 17, 22, 27]) rb.add(column(abbr), x, 8);
  rb.add(benchS(), 13, 8, 3, 1);
  rb.add(benchS(), 23, 8, 3, 1);
  for (const [bx, n] of [[13, 3], [23, 3]]) for (let i = 0; i < n; i++) rb.sit(bx * T + 6 + i * 11, 9 * T - 5, 0, 0.6);
  rb.add(bin(), 18, 8);
  rb.add(bin(), 28, 8);
  rb.npc(20 * T, 10 * T + 8, 0, 0, 2, L.music);
  rb.npc(6 * T, 8 * T + 4, 0, 2, 0, L.cop);
  for (let i = 0; i < 8; i++) rb.npc(ri(r, 10, 30) * T + ri(r, 0, 10), 6 * T + 8 + ri(r, 0, 20), 0, 3, 3);
  for (let i = 0; i < 4; i++) rb.npc(ri(r, 10, 30) * T + 4, 9 * T + 10 + ri(r, 0, 26), 0, ri(r, 0, 3));
  for (let x = 11 * T; x < W; x += 80) rb.lamps.push(x, 7 * T, 46);
  rb.lamps.push(3 * T, 3 * T, 40, 5 * T + 8, 5 * T, 36);
  const it = rb.done('subway', name, ['IS THIS THE EXPRESS?', 'DELAYS... OF COURSE', 'SHOWTIME, FOLKS!', 'WAS THAT A RAT?', 'SWIPE AGAIN... SWIPE AGAIN', 'KERETANYA LAMA YA', 'STAND BEHIND THE YELLOW LINE', "IT'S SO HOT DOWN HERE"], ['} } }', '} TAKE THE A TRAIN }'], '#d8d8e0');
  it.spawn = { x: 2 * T + 16, y: 5 * T + 8, dir: 0 };
  it.exitRow = -1;
  it.station = idx;
  it.train = { t: arrive ? 5.2 : 22 + Math.random() * 6, x: arrive ? 0 : 9999, open: arrive ? 1 : 0, ev: arrive ? 1 : 0 };
  it.trainSpr = trainSprite(band, LINE_CH[idx % 8]);
  return it;
}

// ================================================================ simulation
export function updateInterior(sc: Interior, dt: number, L: Looks) {
  const W = sc.w;
  const solidAt = (x: number, y: number) => {
    const tx = Math.floor(x / T);
    const ty = Math.floor(y / T);
    return tx < 0 || ty < 0 || tx >= W || ty >= sc.h || sc.solid[ty * W + tx] === 1;
  };
  let dead = false;
  for (const n of sc.npcs) {
    if (n.sayT > 0) n.sayT -= dt;
    n.moving = false;
    if (n.mode === 0) {
      if (n.role === 0 && Math.random() < dt * 0.1) n.dir = (Math.random() * 4) | 0;
    } else if (n.mode === 2) {
      if (n.t > 0) {
        n.t -= dt;
        continue;
      }
      const dx = n.gx - n.x;
      const dy = n.gy - n.y;
      if (Math.abs(dx) < 1 && Math.abs(dy) < 1) {
        n.t = 1 + Math.random() * 4;
        for (let k = 0; k < 8; k++) {
          const tx = Math.floor(n.x / T) + ((Math.random() * 7) | 0) - 3;
          const ty = Math.floor(n.y / T) + ((Math.random() * 5) | 0) - 2;
          if (ty < sc.h && !solidAt(tx * T + 8, ty * T + 8)) {
            n.gx = tx * T + 8;
            n.gy = ty * T + 10;
            break;
          }
        }
        continue;
      }
      const st = n.sp * dt;
      let nx = n.x;
      let ny = n.y;
      if (Math.abs(dx) >= 1) {
        nx += Math.sign(dx) * Math.min(st, Math.abs(dx));
        n.dir = dx < 0 ? 1 : 2;
      } else {
        ny += Math.sign(dy) * Math.min(st, Math.abs(dy));
        n.dir = dy < 0 ? 3 : 0;
      }
      if (solidAt(nx, ny)) {
        n.gx = n.x;
        n.gy = n.y;
        n.t = 0.3;
      } else {
        n.x = nx;
        n.y = ny;
        n.an += st;
        n.moving = true;
      }
    } else if (n.mode >= 3) {
      if (!n.path.length) {
        if (n.mode === 3) {
          n.dead = true;
          dead = true;
        } else {
          n.mode = 0;
          n.dir = 3;
          n.role = 3;
        }
        continue;
      }
      const dx = n.path[0] - n.x;
      const dy = n.path[1] - n.y;
      const d = Math.hypot(dx, dy);
      const st = n.sp * dt;
      if (d <= st) {
        n.x = n.path[0];
        n.y = n.path[1];
        n.path.splice(0, 2);
      } else {
        n.x += (dx / d) * st;
        n.y += (dy / d) * st;
        n.dir = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 1 : 2) : dy < 0 ? 3 : 0;
      }
      n.an += st;
      n.moving = true;
    }
  }
  if (dead) sc.npcs = sc.npcs.filter((n) => !n.dead);

  const tr = sc.train;
  if (!tr) return;
  tr.t = (tr.t + dt) % 32;
  const t = tr.t;
  const mk = (x: number, y: number, mode: number, path: number[]) => {
    const n: INpc = { x, y, look: L.rand(), dir: 0, mode, t: 0, an: 0, say: '', sayT: 0, sp: 34 + Math.random() * 14, path, role: 0, gx: x, gy: y, dead: false, moving: true };
    sc.npcs.push(n);
  };
  if (t < 4) {
    const u = 1 - t / 4;
    tr.x = 430 * u * u;
    tr.open = 0;
  } else if (t < 5) {
    tr.x = 0;
    tr.open = t - 4;
  } else if (t < 17) {
    tr.x = 0;
    tr.open = 1;
    if (tr.ev === 0) {
      tr.ev = 1;
      for (let i = 0; i < 6; i++) {
        const dx = TRAIN_X + TRAIN_DOORS[(Math.random() * 6) | 0] + 10 + Math.random() * 6 - 3;
        const gy = (Math.random() < 0.5 ? 7 : 9) * T + 10;
        const ry = 6 * T + 6 + Math.random() * 8;
        mk(dx, 5 * T + 4, 3, [dx, ry, 9 * T + 10, ry, 9 * T + 6, gy, 7 * T, gy, 2 * T + 16, 5 * T + 10, 2 * T + 16, 3 * T + 6]);
      }
      let n = 0;
      for (const p of sc.npcs) {
        if (p.role !== 3 || p.mode !== 0 || n >= 4) continue;
        let best = TRAIN_DOORS[0];
        for (const d of TRAIN_DOORS) if (Math.abs(TRAIN_X + d + 10 - p.x) < Math.abs(TRAIN_X + best + 10 - p.x)) best = d;
        p.mode = 3;
        p.sp = 30 + Math.random() * 10;
        p.path = [p.x, 6 * T + 12, TRAIN_X + best + 10, 6 * T + 10, TRAIN_X + best + 10, 5 * T + 2];
        n++;
      }
    }
  } else if (t < 18) {
    tr.open = 18 - t;
  } else if (t < 22) {
    const u = (t - 18) / 4;
    tr.x = -440 * u * u;
    tr.open = 0;
    if (tr.ev === 1) {
      tr.ev = 2;
      for (let i = 0; i < 4; i++) {
        const gy = (Math.random() < 0.5 ? 7 : 9) * T + 10;
        const fx = (10 + Math.random() * 20) * T;
        const fy = 6 * T + 8 + Math.random() * 20;
        const n: INpc = { x: 2 * T + 16, y: 3 * T + 6 - i * 3, look: L.rand(), dir: 0, mode: 4, t: 0, an: 0, say: '', sayT: 0, sp: 30 + Math.random() * 12, path: [2 * T + 16, 5 * T + 10 + i * 3, 7 * T, gy, 9 * T + 8, gy, 9 * T + 12, fy, fx, fy], role: 0, gx: 0, gy: 0, dead: false, moving: true };
        sc.npcs.push(n);
      }
    }
  } else {
    tr.x = 9999;
    tr.ev = 0;
  }
}

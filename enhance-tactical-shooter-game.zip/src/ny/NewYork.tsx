import { useCallback, useEffect, useRef, useState } from 'react';
import type { PointerEvent as RPointerEvent } from 'react';
import { Game } from './engine';
import type { ZStat } from './engine';
import type { Landmark, Station } from './world';
import { MH, MW, T } from './util';

const LINE_COL = ['#ee352e', '#00933c', '#fccc0a', '#0039a6', '#ff6319', '#b933ad', '#a7a9ac', '#6cbe45'];

// ------------------------------------------------------------------ touch joystick
function Joystick({ game }: { game: Game | null }) {
  const base = useRef<HTMLDivElement>(null);
  const [k, setK] = useState({ x: 0, y: 0, on: false });
  const move = (e: RPointerEvent) => {
    const r = base.current!.getBoundingClientRect();
    let dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    let dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    const l = Math.hypot(dx, dy);
    if (l > 1) {
      dx /= l;
      dy /= l;
    }
    setK({ x: dx, y: dy, on: true });
    if (game) {
      game.joy.x = dx;
      game.joy.y = dy;
    }
  };
  const end = () => {
    setK({ x: 0, y: 0, on: false });
    if (game) {
      game.joy.x = 0;
      game.joy.y = 0;
    }
  };
  return (
    <div
      ref={base}
      aria-label="Joystick gerak"
      className="relative h-28 w-28 rounded-full border-2 border-[#f7f3e3] bg-[#14162a]/60"
      style={{ touchAction: 'none', boxShadow: '0 0 0 2px #14162a' }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        move(e);
      }}
      onPointerMove={(e) => k.on && move(e)}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full border-2 border-[#14162a] bg-[#ffd23a]"
        style={{ transform: `translate(calc(-50% + ${k.x * 30}px), calc(-50% + ${k.y * 30}px))`, boxShadow: '0 0 0 2px #f7f3e3' }}
      />
    </div>
  );
}

// ------------------------------------------------------------------ full map
function MapModal({ game, onClose }: { game: Game; onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const lms = game.world.landmarks;
  useEffect(() => {
    const S = 3;
    const cv = ref.current!;
    cv.width = MW * S;
    cv.height = MH * S;
    const ctx = cv.getContext('2d')!;
    const draw = (blink: boolean) => {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(game.world.mini, 0, 0, MW * S, MH * S);
      for (const s of game.world.stations) {
        const x = Math.round((s.x / T) * S);
        const y = Math.round((s.y / T) * S);
        ctx.fillStyle = '#14162a';
        ctx.fillRect(x - 4, y - 4, 9, 9);
        ctx.fillStyle = '#3ad0ff';
        ctx.fillRect(x - 3, y - 3, 7, 7);
        ctx.fillStyle = '#14162a';
        ctx.fillRect(x - 1, y - 1, 3, 3);
      }
      lms.forEach((l, i) => {
        const x = l.x * S;
        const y = l.y * S;
        const f = game.found.has(i);
        ctx.fillStyle = '#14162a';
        ctx.fillRect(x - 4, y - 2, 9, 5);
        ctx.fillRect(x - 2, y - 4, 5, 9);
        ctx.fillStyle = f ? '#ffd23a' : '#f7f3e3';
        ctx.fillRect(x - 3, y - 1, 7, 3);
        ctx.fillRect(x - 1, y - 3, 3, 7);
      });
      const mp = game.mapPos();
      const px = Math.round((mp.x / T) * S);
      const py = Math.round((mp.y / T) * S);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(px - 6, py - 6, 13, 13);
      ctx.fillStyle = blink ? '#ff3b5c' : '#b3122f';
      ctx.fillRect(px - 4, py - 4, 9, 9);
    };
    let b = false;
    draw(b);
    const id = setInterval(() => {
      b = !b;
      draw(b);
    }, 400);
    return () => clearInterval(id);
  }, [game, lms]);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#0a0c1c]/85 p-3" onClick={onClose} role="dialog" aria-modal="true" aria-label="Peta New York">
      <div className="panel flex max-h-full w-full max-w-4xl flex-col gap-3 p-3 sm:p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-[11px] text-[#ffd23a] sm:text-sm">PETA NEW YORK</h2>
            <p className="mt-2 text-[8px] leading-relaxed text-[#b8bce0]">
              ★ {game.found.size}/{lms.length} landmark ditemukan
            </p>
          </div>
          <button className="btn px-3 py-2 text-[9px]" onClick={onClose} autoFocus>
            TUTUP
          </button>
        </div>
        <div className="flex min-h-0 flex-1 flex-col gap-3 md:flex-row">
          <div className="flex shrink-0 justify-center">
            <canvas ref={ref} className="max-h-[42vh] w-auto border-2 border-[#f7f3e3] md:max-h-[72vh]" style={{ aspectRatio: `${MW}/${MH}` }} />
          </div>
          <div className="scroll-px min-h-0 flex-1 overflow-y-auto pr-2">
            <div className="mb-3 flex flex-wrap gap-x-4 gap-y-2 text-[8px] text-[#b8bce0]">
              <span><i className="mr-2 inline-block h-2 w-2 bg-[#ff3b5c]" />Kamu</span>
              <span><i className="mr-2 inline-block h-2 w-2 bg-[#ffd23a]" />Sudah dikunjungi</span>
              <span><i className="mr-2 inline-block h-2 w-2 bg-[#f7f3e3]" />Belum</span>
              <span><i className="mr-2 inline-block h-2 w-2 bg-[#3ad0ff]" />Subway</span>
            </div>
            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-1 lg:grid-cols-2">
              {lms.map((l, i) => {
                const f = game.found.has(i);
                return (
                  <li key={l.name} className={`text-[8px] leading-relaxed ${f ? 'text-[#f7f3e3]' : 'text-[#6b70a0]'}`}>
                    <span className={f ? 'text-[#ffd23a]' : ''}>{f ? '★' : '☆'}</span> {f ? l.name : '? ? ?'}
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ subway
function SubwayModal({ game, onClose }: { game: Game; onClose: () => void }) {
  const cur = game.scene?.station ?? -1;
  const go = (i: number) => {
    game.ride(i);
    onClose();
  };
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#0a0c1c]/85 p-3" onClick={onClose} role="dialog" aria-modal="true" aria-label="Pilih stasiun subway">
      <div className="panel flex max-h-full w-full max-w-2xl flex-col gap-3 p-3 sm:p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#fccc0a] text-[12px] text-[#14162a]">M</span>
            <div>
              <h2 className="text-[11px] text-[#ffd23a] sm:text-sm">NYC SUBWAY</h2>
              <p className="mt-2 text-[8px] text-[#b8bce0]">Pintu kereta terbuka — mau turun di mana?</p>
            </div>
          </div>
          <button className="btn px-3 py-2 text-[9px]" onClick={onClose}>
            BATAL
          </button>
        </div>
        <div className="scroll-px grid min-h-0 grid-cols-1 gap-2 overflow-y-auto p-1 pr-2 sm:grid-cols-2">
          {game.world.stations.map((s: Station, i) => (
            <button
              key={s.name}
              className={`ghost flex items-center gap-3 px-3 py-3 text-left text-[8px] leading-relaxed ${i === cur ? 'opacity-50' : ''}`}
              onClick={() => go(i)}
              disabled={i === cur}
              autoFocus={i === (cur === 0 ? 1 : 0)}
            >
              <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: LINE_COL[i % LINE_COL.length] }} />
              {s.name}
              {i === cur && <span className="ml-auto text-[#ffd23a]">DI SINI</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ app
/** New York before the outbreak: the peaceful city walk, embedded as a game mode */
export function NewYork({ onExit, zombie = false }: { onExit: () => void; zombie?: boolean }) {
  const [zs, setZs] = useState<ZStat | null>(null);
  const [riding, setRiding] = useState(true);
  const [runId, setRunId] = useState(0);
  const cvRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [started, setStarted] = useState(false);
  const [district, setDistrict] = useState('');
  const [clock, setClock] = useState({ label: 'PAGI', time: '09:30' });
  const [prompt, setPrompt] = useState<string | null>(null);
  const [toast, setToast] = useState<{ l: Landmark; id: number } | null>(null);
  const [found, setFound] = useState({ n: 0, total: 0 });
  const [mapOpen, setMapOpen] = useState(false);
  const [subOpen, setSubOpen] = useState(false);
  const [touch, setTouch] = useState(false);
  const [run, setRun] = useState(false);

  useEffect(() => {
    const g = new Game(cvRef.current!, {
      district: setDistrict,
      landmark: (l, n, total) => {
        setFound({ n, total });
        setToast({ l, id: Date.now() });
      },
      clock: (label, time) => setClock({ label, time }),
      prompt: setPrompt,
      subway: () => {
        if (!zombie) setSubOpen(true);
      },
      zombie: setZs,
    }, { zombie });
    gameRef.current = g;
    (window as unknown as { __ny?: Game }).__ny = g; // console handle for testing
    setGame(g);
    setFound({ n: g.found.size, total: g.world.landmarks.length });
    const stop = g.start();
    setTouch(window.matchMedia('(pointer: coarse)').matches);
    return () => {
      stop();
      gameRef.current = null;
    };
  }, [runId, zombie]);

  useEffect(() => {
    if (gameRef.current) gameRef.current.active = started && !mapOpen && !subOpen;
  }, [started, mapOpen, subOpen, game]);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 6500);
    return () => clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    const kd = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'escape') {
        setMapOpen(false);
        setSubOpen(false);
      }
      if (!started) {
        if (k === 'enter') setStarted(true);
        return;
      }
      if (k === 'm') setMapOpen((v) => !v);
    };
    window.addEventListener('keydown', kd);
    return () => window.removeEventListener('keydown', kd);
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const id = setInterval(() => {
      const g = gameRef.current;
      const cv = miniRef.current;
      if (!g || !cv) return;
      g.drawMini(cv.getContext('2d')!, 96, 2);
      setRiding(g.riding);
    }, 160);
    return () => clearInterval(id);
  }, [started]);

  const act = useCallback(() => gameRef.current?.action(), []);
  const toggleRun = () => {
    const v = !run;
    setRun(v);
    if (gameRef.current) gameRef.current.run = v;
  };
  const night = clock.label === 'MALAM';

  return (
    <div className="nyc fixed inset-0 z-50 overflow-hidden bg-[#14162a]">
      <canvas ref={cvRef} className="absolute left-0 top-0 block" aria-label="Peta dunia New York bergaya pixel" />

      {started && (
        <>
          {/* top-left: district + clock */}
          <div className="pointer-events-none absolute left-2 top-2 flex flex-col items-start gap-2 sm:left-4 sm:top-4" style={{ paddingLeft: 'env(safe-area-inset-left)', paddingTop: 'env(safe-area-inset-top)' }}>
            <div className="panel px-3 py-2">
              <p className="text-[7px] text-[#b8bce0]">LOKASI</p>
              <p className="mt-2 max-w-[46vw] text-[9px] leading-relaxed text-[#ffd23a] sm:text-[11px]">{district.toUpperCase() || '...'}</p>
            </div>
            <button className="ghost pointer-events-auto flex items-center gap-2 px-3 py-2 text-[8px]" onClick={() => gameRef.current?.skipTime()} title="Ganti waktu (N)">
              <span className={night ? 'text-[#9fc0ff]' : 'text-[#ffd23a]'}>{night ? '☾' : '☀'}</span>
              <span>{clock.label}</span>
              <span className="text-[#b8bce0]">{clock.time}</span>
            </button>
          </div>

          {/* top-right: minimap */}
          <div className="absolute right-2 top-2 flex flex-col items-end gap-2 sm:right-4 sm:top-4" style={{ paddingRight: 'env(safe-area-inset-right)', paddingTop: 'env(safe-area-inset-top)' }}>
            <button className="panel block cursor-pointer p-1" onClick={() => setMapOpen(true)} aria-label="Buka peta besar">
              <canvas ref={miniRef} width={96} height={96} className="block h-24 w-24 sm:h-36 sm:w-36" />
            </button>
            <div className="flex gap-2">
              <span className="panel px-2 py-2 text-[8px] text-[#ffd23a]">
                ★ {found.n}/{found.total}
              </span>
              <button className="ghost px-2 py-2 text-[8px]" onClick={onExit}>
                KELUAR
              </button>
              <button className={`px-2 py-2 text-[8px] ${riding ? 'btn' : 'ghost'}`} onClick={() => gameRef.current?.toggleRide()}>
                {riding ? 'TURUN MOTOR' : 'NAIK MOTOR'}
                {!touch && <span className="opacity-60"> [F]</span>}
              </button>
              <button className="ghost px-2 py-2 text-[8px]" onClick={() => setMapOpen(true)}>
                PETA{!touch && <span className="text-[#b8bce0]"> [M]</span>}
              </button>
            </div>
          </div>

          {/* outbreak status */}
          {zombie && zs && (
            <div className="pointer-events-none absolute left-1/2 top-2 flex w-[min(92vw,430px)] -translate-x-1/2 flex-col items-center gap-2 sm:top-4">
              <div className="panel w-full px-3 py-2">
                <div className="flex items-center justify-between gap-3 text-[8px]">
                  <span className={zs.hp < 30 ? 'blink text-[#ff4a5e]' : 'text-[#7aff8a]'}>HP {zs.hp}</span>
                  <span className="text-[#ffd23a]">BASMI {zs.kills}</span>
                  <span className="text-[#ff7a8a]">ZOMBIE {zs.z}</span>
                  <span className="text-[#b8bce0]">WARGA {zs.h}</span>
                </div>
                <div className="mt-2 h-2 w-full bg-[#14162a]">
                  <div className="h-full" style={{ width: `${zs.hp}%`, background: zs.hp < 30 ? '#ff4a5e' : '#7aff8a' }} />
                </div>
                <p className="mt-2 text-[8px] leading-relaxed text-[#ffd23a]">
                  {zs.stage === 0 ? `AMBIL SUPLAI ${zs.got}/${zs.need}: ${zs.goal}` : zs.stage === 1 ? `KE TITIK EVAKUASI: ${zs.goal}` : `BERTAHAN SAMPAI HELI TIBA: ${zs.hold} DETIK`}
                  <span className="text-[#b8bce0]"> - {zs.dist} blok</span>
                </p>
              </div>
              {zs.note && <div className="panel px-3 py-2 text-center text-[9px] leading-relaxed text-[#7aff8a]">{zs.note}</div>}
            </div>
          )}

          {/* area title */}
          {district && (
            <div key={district} className="area-title txt-shadow pointer-events-none absolute left-1/2 top-[22%] w-max max-w-[90vw] text-center text-sm text-[#f7f3e3] sm:text-2xl">
              {district.toUpperCase()}
            </div>
          )}

          {/* landmark toast */}
          {toast && (
            <div key={toast.id} className="toast panel pointer-events-none absolute left-1/2 top-[34%] w-[min(92vw,460px)] px-4 py-3" role="status">
              <p className="text-[8px] text-[#3ad0ff]">★ LANDMARK DITEMUKAN</p>
              <p className="mt-2 text-[10px] leading-relaxed text-[#ffd23a] sm:text-xs">{toast.l.name}</p>
              <p className="mt-2 text-[8px] leading-[1.8] text-[#f7f3e3]">{toast.l.info}</p>
            </div>
          )}

          {/* action prompt */}
          {prompt && (
            <button className="btn absolute bottom-36 left-1/2 w-max max-w-[92vw] -translate-x-1/2 px-3 py-3 text-[8px] leading-relaxed sm:bottom-16 sm:text-[9px]" onClick={act}>
              {!touch && <span className="mr-2">[E]</span>}
              {prompt}
            </button>
          )}

          {/* controls */}
          {touch ? (
            <>
              <div className="absolute bottom-5 left-5" style={{ paddingLeft: 'env(safe-area-inset-left)', paddingBottom: 'env(safe-area-inset-bottom)' }}>
                <Joystick game={game} />
              </div>
              <div className="absolute bottom-6 right-5 flex items-end gap-4" style={{ paddingRight: 'env(safe-area-inset-right)', paddingBottom: 'env(safe-area-inset-bottom)' }}>
                <button className={`h-14 w-14 rounded-full text-[8px] ${run ? 'btn' : 'ghost'}`} onClick={toggleRun} aria-pressed={run}>
                  LARI
                </button>
                <button className={`h-14 w-14 rounded-full text-[7px] ${riding ? 'btn' : 'ghost'}`} onClick={() => gameRef.current?.toggleRide()}>
                  MOTOR
                </button>
                {zombie && (
                  <button className="btn h-16 w-16 rounded-full text-[8px]" onClick={() => gameRef.current?.fireNearest()}>
                    TEMBAK
                  </button>
                )}
                <button className="btn mb-6 h-16 w-16 rounded-full text-[9px]" onClick={act}>
                  AKSI
                </button>
              </div>
            </>
          ) : (
            <div className="panel pointer-events-none absolute bottom-3 left-3 flex flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2 text-[7px] text-[#b8bce0] sm:left-4">
              <span><span className="key">WASD</span> jalan</span>
              <span><span className="key">SHIFT</span> lari</span>
              <span><span className="key">E</span> masuk / ngobrol</span>
              <span><span className="key">M</span> peta</span>
              <span><span className="key">N</span> ganti waktu</span>
              <span><span className="key">F</span> naik / turun motor</span>
              {zombie && <span><span className="key">KLIK</span> tembak</span>}
            </div>
          )}
        </>
      )}

      {/* title screen */}
      {!started && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-6 bg-gradient-to-b from-[#14162a]/80 via-[#14162a]/55 to-[#14162a]/90 p-5 text-center">
          <div className="logo">
            <p className="txt-shadow text-[9px] tracking-widest text-[#3ad0ff] sm:text-xs">★ THE BIG APPLE ★</p>
            <h1 className="mt-4 text-4xl leading-tight text-[#ffd23a] sm:text-6xl md:text-7xl" style={{ textShadow: '4px 4px 0 #c0183a, 8px 8px 0 #14162a' }}>
              NEW YORK
            </h1>
            <p className="txt-shadow mt-4 text-sm text-[#f7f3e3] sm:text-xl">{zombie ? 'HARI WABAH' : 'SEBELUM WABAH'}</p>
          </div>
          <p className="txt-shadow max-w-xl text-[8px] leading-[2] text-[#f7f3e3] sm:text-[10px]">
            {zombie
              ? 'Wabah pecah di tengah Manhattan. Warga berlarian, yang tergigit ikut berubah. Naik skuter hitammu, ambil 4 suplai di penjuru kota, lalu bertahan di Battery Park sampai helikopter datang.'
              : 'Beberapa minggu sebelum semuanya runtuh. Belum ada zombie, belum ada sirene — cuma kamu, skuter hitammu, dan ribuan warga New York yang masih sibuk lalu-lalang seperti biasa.'}
          </p>
          <button className="btn px-6 py-4 text-[11px] sm:text-sm" onClick={() => setStarted(true)} disabled={!game} autoFocus>
            <span className="blink mr-2">▶</span>
            {game ? (zombie ? 'BERTAHAN HIDUP' : 'MULAI JALAN-JALAN') : 'MEMUAT KOTA...'}
          </button>
          <button className="ghost px-4 py-3 text-[8px] sm:text-[9px]" onClick={onExit}>
            ← KEMBALI KE MENU UTAMA
          </button>
          <ul className="txt-shadow flex max-w-2xl flex-wrap justify-center gap-x-6 gap-y-3 text-[7px] text-[#b8bce0] sm:text-[8px]">
            <li>★ {found.total || 39} LANDMARK</li>
            <li>▲ MASUK KAFE, TOKO & GEDUNG</li>
            <li>◆ 18 STASIUN SUBWAY BAWAH TANAH</li>
            <li>☾ SIANG & MALAM</li>
            <li>♥ FERRY KE LIBERTY</li>
          </ul>
        </div>
      )}

      {zombie && zs && zs.over > 0 && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-5 bg-[#0a0c1c]/85 p-5 text-center">
          <h2 className="text-3xl sm:text-5xl" style={{ color: zs.over === 2 ? '#7aff8a' : '#ff4a5e', textShadow: '4px 4px 0 #14162a' }}>
            {zs.over === 2 ? 'KAMU LOLOS!' : 'KAMU TERINFEKSI'}
          </h2>
          <p className="txt-shadow max-w-lg text-[9px] leading-[2] text-[#f7f3e3]">
            {zs.over === 2 ? 'Helikopter membawamu keluar dari New York.' : 'New York menelanmu, seperti jutaan lainnya.'} Zombie dibasmi: {zs.kills} - Suplai: {zs.got}/{zs.need}
          </p>
          <div className="flex gap-3">
            <button className="btn px-5 py-3 text-[10px]" onClick={() => { setZs(null); setRunId((n) => n + 1); }}>
              MAIN LAGI
            </button>
            <button className="ghost px-5 py-3 text-[10px]" onClick={onExit}>
              MENU UTAMA
            </button>
          </div>
        </div>
      )}
      {mapOpen && game && <MapModal game={game} onClose={() => setMapOpen(false)} />}
      {subOpen && game && <SubwayModal game={game} onClose={() => setSubOpen(false)} />}
    </div>
  );
}

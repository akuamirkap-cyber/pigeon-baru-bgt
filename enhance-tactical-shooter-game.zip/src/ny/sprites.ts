import { G, R, Rng, Spr, drawText, ell, mkCanvas, mulberry32, outline, pick, pix, shade, textW } from './util';
import { fromMap } from '../game/sprites';
import { zombieSprites } from '../game/city';

// ============================================================ PEOPLE
export interface Look {
  skin: string;
  hair: string;
  hs: number; // 0 short 1 long 2 cap 3 beanie 4 afro 5 bald
  hat: string;
  shirt: string;
  pants: string;
  shoes: string;
  bottom: number; // 0 pants 1 shorts 2 skirt
  top: number; // 0 tee 1 suit 2 hoodie 3 vest
  acc: number; // 0 none 1 backpack 2 shoulder bag
  bag: string;
  sp: number; // special
}

const SKINS = ['#f6d3b3', '#e8b88f', '#c98e62', '#a36a44', '#6f4a32', '#f1c7a1', '#dba77c'];
const HAIRS = ['#1d1a1a', '#1d1a1a', '#3a2a1e', '#5a3b22', '#8a5a2b', '#c9a15a', '#d9d2c8', '#a8402a', '#e7c66a', '#ff6fb0', '#4a6fd9'];
const SHIRTS = ['#d94a4a', '#4a7fd9', '#4ab06a', '#e8c14a', '#f2f2f2', '#2b2b35', '#e87ab0', '#8a5ad9', '#f08a3c', '#3cc0c0', '#7a8a9a', '#b03a5a', '#2f6b4a', '#f5f0dc', '#5a3a2a'];
const SUITS = ['#2b3040', '#3a3a44', '#22242e', '#4a4038', '#2f3a5a', '#6a6a72'];
const PANTS = ['#2b3a5c', '#1f2430', '#4a4a52', '#6b5a44', '#3a5a8a', '#222229', '#7a6a55', '#33405c'];
const SHOES = ['#2a2220', '#f2f2f2', '#5a3a22', '#c0392b', '#1a1a1a'];
const HATS = ['#c0392b', '#2b5fb0', '#1f1f28', '#e8c14a', '#3f8a4a', '#f2f2f2', '#e8742b', '#8a3fb0'];
const BAGS = ['#c0392b', '#2b5fb0', '#3f8a4a', '#e8c14a', '#5a3a22', '#1f1f28', '#8a3fb0', '#e87ab0'];

export const SP_PLAYER = 0;
export const SP_COP = 1;
export const SP_VENDOR = 2;
export const SP_ELMO = 3;
export const SP_LIBERTY = 4;
export const SP_WORKER = 5;
export const SP_MUSIC = 6;
export const SP_JOG = 7; // 7..10
export const SP_COOKIE = 11;
export const SP_RANDOM = 12;

const base = (o: Partial<Look>): Look => ({
  skin: '#e8b88f', hair: '#3a2a1e', hs: 0, hat: '#c0392b', shirt: '#4a7fd9', pants: '#2b3a5c', shoes: '#2a2220',
  bottom: 0, top: 0, acc: 0, bag: '#c0392b', sp: 0, ...o,
});

const SPECIALS: Look[] = [
  base({ hs: 2, hat: '#e23b3b', shirt: '#2f6fd0', top: 2, pants: '#2b3350', shoes: '#f2f2f2', acc: 1, bag: '#f5c518', sp: 0 }),
  base({ hs: 2, hat: '#18244a', shirt: '#1f2f5a', top: 2, pants: '#141c33', shoes: '#111111', sp: 1, skin: '#c98e62' }),
  base({ hs: 2, hat: '#f2f2f2', shirt: '#f2f2f2', top: 2, pants: '#3a3a44', sp: 2, skin: '#a36a44', hair: '#1d1a1a' }),
  base({ hs: 5, skin: '#e23a2e', hair: '#e23a2e', shirt: '#e23a2e', top: 2, pants: '#e23a2e', shoes: '#e23a2e', sp: 3 }),
  base({ hs: 0, skin: '#9fe0c8', hair: '#5fb59a', shirt: '#5fb59a', top: 2, pants: '#5fb59a', bottom: 2, shoes: '#3e8f7a', sp: 4 }),
  base({ hs: 2, hat: '#f5d020', shirt: '#f08a24', top: 3, pants: '#3a4a6a', shoes: '#5a3a22', sp: 5, skin: '#dba77c' }),
  base({ hs: 3, hat: '#3a2a4a', shirt: '#2b2b35', top: 2, pants: '#33405c', sp: 6, skin: '#6f4a32', hair: '#1d1a1a' }),
  base({ hs: 0, shirt: '#ff5a8a', top: 0, bottom: 1, pants: '#1f1f28', shoes: '#f2f2f2', sp: 7, hair: '#e7c66a', skin: '#f6d3b3' }),
  base({ hs: 1, shirt: '#3cd0c0', top: 0, bottom: 1, pants: '#2b2b35', shoes: '#ff6a3a', sp: 7, hair: '#1d1a1a', skin: '#a36a44' }),
  base({ hs: 2, hat: '#f2f2f2', shirt: '#c8f03c', top: 0, bottom: 1, pants: '#33405c', shoes: '#f2f2f2', sp: 7, skin: '#6f4a32' }),
  base({ hs: 5, shirt: '#f2f2f2', top: 0, bottom: 1, pants: '#b03a3a', shoes: '#3a6ae0', sp: 7, skin: '#e8b88f' }),
  base({ hs: 5, skin: '#3a7ae0', hair: '#3a7ae0', shirt: '#3a7ae0', top: 2, pants: '#3a7ae0', shoes: '#3a7ae0', sp: 3 }),
];

function randLook(r: Rng): Look {
  const top = pick(r, [0, 0, 0, 1, 1, 2, 2]);
  return {
    skin: pick(r, SKINS),
    hair: pick(r, HAIRS),
    hs: pick(r, [0, 0, 0, 1, 1, 1, 2, 2, 3, 4, 5]),
    hat: pick(r, HATS),
    shirt: top === 1 ? pick(r, SUITS) : pick(r, SHIRTS),
    pants: top === 1 ? pick(r, ['#22242e', '#2c3040', '#3a3a44']) : pick(r, PANTS),
    shoes: pick(r, SHOES),
    bottom: top === 1 ? 0 : pick(r, [0, 0, 0, 0, 1, 2]),
    top,
    acc: pick(r, [0, 0, 0, 1, 1, 2]),
    bag: pick(r, BAGS),
    sp: -1,
  };
}

type PF = (c: string, x: number, y: number, w?: number, h?: number) => void;

// ---- the people who make a city: the old, the homeless, couriers, people in uniform - and the odd costume
export const N_BASE = 150;
export const LK_ELDER = N_BASE;
export const LK_HOMELESS = LK_ELDER + 6;
export const LK_COURIER = LK_HOMELESS + 4;
export const LK_PRO = LK_COURIER + 4;
export const LK_COSTUME = LK_PRO + 9;
export const LK_END = LK_COSTUME + 13;
const X_ELDER = 20, X_HOMELESS = 21, X_COURIER = 22, X_CHEF = 23, X_HOTDOG = 24, X_DINO = 25, X_ASTRO = 26, X_HERO = 27, X_CLOWN = 28, X_PUNK = 29;
const X_TOURIST = 30, X_DOC = 31, X_FIRE = 32, X_COWBOY = 33, X_NUN = 34, X_BIZ = 35, X_MIME = 36, X_ROBOT = 37, X_BANANA = 38;

const EXTRAS: Look[] = [
  // the elderly: grey hair, cardigans, flat caps, a walking stick
  base({ sp: X_ELDER, hs: 1, hair: '#dcdce2', shirt: '#b56a8a', top: 2, bottom: 2, pants: '#5a5a66', shoes: '#5a3a22', skin: '#f1c7a1' }),
  base({ sp: X_ELDER, hs: 2, hat: '#6a6a72', hair: '#c8c8d0', shirt: '#7a6a55', top: 1, pants: '#4a4a52', skin: '#e8b88f', bag: '#8a3a3a' }),
  base({ sp: X_ELDER, hs: 5, hair: '#dcdce2', shirt: '#5a7a9a', top: 2, pants: '#6b5a44', skin: '#dba77c' }),
  base({ sp: X_ELDER, hs: 0, hair: '#e8e8ee', shirt: '#8a5ad9', top: 2, bottom: 2, pants: '#3a3a44', shoes: '#1a1a1a', skin: '#c98e62', acc: 2, bag: '#5a3a22' }),
  base({ sp: X_ELDER, hs: 3, hat: '#8a3a3a', hair: '#c8c8d0', shirt: '#4a6a4a', top: 2, pants: '#33405c', shoes: '#5a3a22', skin: '#a36a44' }),
  base({ sp: X_ELDER, hs: 1, hair: '#f2f2f2', shirt: '#e8c14a', top: 2, pants: '#7a6a55', shoes: '#5a3a22', skin: '#f6d3b3' }),
  // the homeless: long patched coats, beards, a bundle with everything they own
  base({ sp: X_HOMELESS, hs: 3, hat: '#4a4a3a', hair: '#6a5a4a', shirt: '#5a5a44', top: 2, pants: '#3a3a36', shoes: '#3a2a20', skin: '#c98e62', bag: '#6b5a44' }),
  base({ sp: X_HOMELESS, hs: 0, hair: '#8a8a84', shirt: '#6a5246', top: 2, pants: '#4a463e', skin: '#e8b88f', bag: '#3f4a3a' }),
  base({ sp: X_HOMELESS, hs: 3, hat: '#5a3a3a', hair: '#3a2a1e', shirt: '#4a5260', top: 2, pants: '#3c3a44', shoes: '#3a2a20', skin: '#a36a44', bag: '#5a5a66' }),
  base({ sp: X_HOMELESS, hs: 4, hair: '#5a5a5a', shirt: '#6a6a4a', top: 2, pants: '#4a4038', skin: '#6f4a32', bag: '#7a6a55' }),
  // food couriers: bright jackets and a big insulated box
  base({ sp: X_COURIER, hs: 2, hat: '#1f1f28', shirt: '#2fd06a', top: 2, pants: '#22242e', shoes: '#f2f2f2', bag: '#2fd06a', skin: '#e8b88f' }),
  base({ sp: X_COURIER, hs: 2, hat: '#f2f2f2', shirt: '#ff7a1a', top: 2, pants: '#2b2b35', shoes: '#1a1a1a', bag: '#ff7a1a', skin: '#a36a44' }),
  base({ sp: X_COURIER, hs: 2, hat: '#e23b6a', shirt: '#e23b6a', top: 2, pants: '#33405c', shoes: '#f2f2f2', bag: '#e23b6a', skin: '#f6d3b3' }),
  base({ sp: X_COURIER, hs: 2, hat: '#18244a', shirt: '#3aa8ff', top: 2, pants: '#1f2430', shoes: '#c0392b', bag: '#3aa8ff', skin: '#6f4a32' }),
  // people at work: chef, doctor, nurse, firefighter, two office workers, two tourists, a nun
  base({ sp: X_CHEF, hs: 5, shirt: '#f5f5f5', top: 2, pants: '#3a3a44', shoes: '#1a1a1a', skin: '#e8b88f' }),
  base({ sp: X_DOC, hs: 1, hair: '#3a2a1e', shirt: '#f5f5f5', top: 2, pants: '#3cc0c0', shoes: '#f2f2f2', skin: '#c98e62' }),
  base({ sp: X_DOC, hs: 0, hair: '#1d1a1a', shirt: '#3cc0c0', top: 0, pants: '#3cc0c0', shoes: '#f2f2f2', skin: '#f6d3b3' }),
  base({ sp: X_FIRE, hs: 2, hat: '#c0392b', shirt: '#3a3028', top: 3, pants: '#3a3028', shoes: '#1a1a1a', skin: '#dba77c' }),
  base({ sp: X_BIZ, hs: 0, hair: '#3a2a1e', shirt: '#22242e', top: 1, pants: '#22242e', shoes: '#1a1a1a', bag: '#c0392b' }),
  base({ sp: X_BIZ, hs: 1, hair: '#c9a15a', shirt: '#4a4038', top: 1, pants: '#2c3040', bag: '#2b5fb0', skin: '#f6d3b3' }),
  base({ sp: X_TOURIST, hs: 2, hat: '#f5f0dc', shirt: '#ff6fb0', top: 0, bottom: 1, pants: '#7a6a55', shoes: '#f2f2f2', acc: 1, bag: '#3f8a4a', skin: '#f6d3b3' }),
  base({ sp: X_TOURIST, hs: 2, hat: '#e8c14a', shirt: '#3cc0c0', top: 0, bottom: 1, pants: '#5a3a2a', shoes: '#5a3a22' }),
  base({ sp: X_NUN, hs: 5, shirt: '#16161c', top: 2, bottom: 2, pants: '#16161c', shoes: '#1a1a1a', skin: '#f1c7a1' }),
  // costumes: hot dog, two dinosaurs, astronaut, two heroes, clown, two punks, cowboy, mime, robot, banana
  base({ sp: X_HOTDOG, hs: 0, shirt: '#d9a05a', pants: '#c0432b', shoes: '#c0432b' }),
  base({ sp: X_DINO, hs: 5, shirt: '#4ab06a', top: 2, pants: '#4ab06a', shoes: '#2f6b4a' }),
  base({ sp: X_DINO, hs: 5, shirt: '#8a5ad9', top: 2, pants: '#8a5ad9', shoes: '#5a3a9a', skin: '#c98e62' }),
  base({ sp: X_ASTRO, hs: 5, shirt: '#eef2f7', top: 2, pants: '#eef2f7', shoes: '#c9d1de' }),
  base({ sp: X_HERO, hs: 0, hair: '#1d1a1a', hat: '#2b5fb0', shirt: '#2b5fb0', top: 2, pants: '#c0392b', shoes: '#c0392b', bag: '#c0392b' }),
  base({ sp: X_HERO, hs: 1, hair: '#a8402a', hat: '#8a3fb0', shirt: '#22242e', top: 2, pants: '#22242e', shoes: '#8a3fb0', bag: '#8a3fb0', skin: '#f6d3b3' }),
  base({ sp: X_CLOWN, hs: 4, hair: '#ff3a6a', skin: '#f6f0e8', shirt: '#f5d020', top: 2, pants: '#3b6ea8', shoes: '#c0392b' }),
  base({ sp: X_PUNK, hs: 5, hat: '#3cf07a', shirt: '#16161c', top: 2, pants: '#2b2b35', shoes: '#1a1a1a' }),
  base({ sp: X_PUNK, hs: 5, hat: '#ff3ab0', shirt: '#2b2b35', top: 2, bottom: 2, pants: '#b03a3a', shoes: '#1a1a1a', skin: '#f6d3b3' }),
  base({ sp: X_COWBOY, hs: 2, hat: '#f5f0dc', shirt: '#e8b88f', top: 0, bottom: 1, pants: '#f2f2f2', shoes: '#f5f0dc' }),
  base({ sp: X_MIME, hs: 0, hair: '#16161c', skin: '#f6f0e8', shirt: '#f5f5f5', top: 2, pants: '#16161c', shoes: '#16161c' }),
  base({ sp: X_ROBOT, hs: 5, shirt: '#9aa2ae', top: 2, pants: '#6a7280', shoes: '#4a505c' }),
  base({ sp: X_BANANA, hs: 5, shirt: '#f5d020', top: 2, pants: '#f5d020', shoes: '#6b4a2e' }),
];

/* ───────────── figures in the build of the co-op zombie city ─────────────
 * Every New Yorker is assembled the way the survivors are: a head sprite and a torso sprite in the co-op format (14 x 10 and 14 x 6,
 * same face, same hair and hat shapes, same jackets), on two little legs that are animated in code. The sprite is then brought down
 * to street scale by dropping its outline and the rows / columns that carry no feature - so a taxi is still three people long.
 */
const H_TOP = '....KKKKKK....', H_END = '...KKKKKKKK...', H_CHIN = '..KfFFMMFFfK..';
const HEAD_T: string[][] = [
  // short hair
  [H_TOP, '..KKHHHHHHKK..', '.KHHhhHHHHHHK.', '.KHHHHHHHHHHK.', 'KHHFFFFFFFFHHK', 'KHFFFFFFFFFFHK', 'KFFWEFFFWEFFfK', 'KFFFFFFFFFFFfK', H_CHIN, H_END],
  // long hair, framing the face
  [H_TOP, '..KKHHHHHHKK..', '.KHHhhHHHHHHK.', '.KHHHHHHHHHHK.', 'KHHHFFFFFFHHHK', 'KHHFFFFFFFFHHK', 'KHHWEFFFWEFHHK', 'KHHFFFFFFFFHHK', H_CHIN, H_END],
  // baseball cap
  [H_TOP, '..KKCCCCCCKK..', '.KCCcCCCCCCCK.', '.KCCcCCCCCCCK.', 'KKbbbbbbbbbbKK', 'KHHFFFFFFFFHHK', 'KFFWEFFFWEFFfK', 'KFFFFFFFFFFFfK', H_CHIN, H_END],
  // beanie
  [H_TOP, '..KKCCCCCCKK..', '.KCCcCcCcCCCK.', '.KCCcCcCcCCCK.', 'KbbbbbbbbbbbbK', 'KHHFFFFFFFFHHK', 'KFFWEFFFWEFFfK', 'KFFFFFFFFFFFfK', H_CHIN, H_END],
  // afro
  ['..KKKKKKKKKK..', '.KHHHhHHHHHHK.', 'KHHHHHHHhHHHHK', 'KHHHHHHHHHHHHK', 'KHHHFFFFFFHHHK', 'KHHFFFFFFFFHHK', 'KHHWEFFFWEFHHK', 'KHHFFFFFFFFHHK', H_CHIN, H_END],
  // bald
  [H_TOP, '..KKFFFFFFKK..', '.KFFsFFFFFFFK.', '.KFFsFFFFFFFK.', 'KFFFFFFFFFFFfK', 'KFFFFFFFFFFFfK', 'KFFWEFFFWEFFfK', 'KFFFFFFFFFFFfK', H_CHIN, H_END],
];
const TORSO_T: Record<string, string[]> = {
  tee: ['..KJJJFFJJJK..', '.KJjJJJJJJjJK.', '.KFKJJJJJJKFK.', '.KFKJjjjjJKFK.'],
  suit: ['..KJJTAATJJK..', '.KJjJTAATJjJK.', '.KJKJJAAJJKJK.', '.KJKJJJJJJKJK.'],
  hood: ['..KJJJTTJJJK..', '.KJjJJWJWJjJK.', '.KJKJJJJJJKJK.', '.KJKJjjjjJKJK.'],
  jacket: ['..KJJTTTTJJK..', '.KJjJTTTTJjJK.', '.KJKJTTTTJKJK.', '.KJKJJTTJJKJK.'],
  flannel: ['..KJjJjJjJjK..', '.KjJjJjJjJjJK.', '.KJKJjJjJjKJK.', '.KjKjJjJjJKjK.'],
  vest: ['..KJYYYYYYJK..', '.KJjJJJJJJjJK.', '.KJKJJJJJJKJK.', '.KJKYYYYYYKJK.'],
};
const HIP_PANTS = ['..KKPPPPPPKK..', '...KDPKKPDK...'], HIP_SKIRT = ['.KJJJJJJJJJJK.', '..KjjjjjjjjK..'];
/** which columns / rows of a 14 x 16 co-op sprite survive the trip to street scale: the eyes, the mouth, the hat brim, the shoulders, the belt */
const KEEP_X = [2, 3, 4, 5, 7, 8, 9, 10, 11];
const KEEP_Y = [1, 3, 4, 5, 6, 7, 8, 10, 12, 13, 14];

/** a 14 x 16 co-op sprite (head over torso) at street scale: 9 x 11, without its outer outline - the atlas draws its own */
function mini(src: HTMLCanvasElement): HTMLCanvasElement {
  const a = src.getContext('2d')!.getImageData(0, 0, 14, 16).data;
  const op = (x: number, y: number) => x >= 0 && y >= 0 && x < 14 && y < 16 && a[(y * 14 + x) * 4 + 3] > 0;
  const { c, g } = mkCanvas(9, 11);
  const o = g.createImageData(9, 11);
  KEEP_Y.forEach((sy, dy) =>
    KEEP_X.forEach((sx, dx) => {
      const i = (sy * 14 + sx) * 4;
      if (a[i + 3] === 0) return;
      const dark = a[i] < 40 && a[i + 1] < 40 && a[i + 2] < 44;
      if (dark && !(op(sx - 1, sy) && op(sx + 1, sy) && op(sx, sy - 1) && op(sx, sy + 1))) return;
      const j = (dy * 9 + dx) * 4;
      o.data[j] = a[i];
      o.data[j + 1] = a[i + 1];
      o.data[j + 2] = a[i + 2];
      o.data[j + 3] = 255;
    }),
  );
  g.putImageData(o, 0, 0);
  return c;
}

/** what sets the special people apart, drawn over the basic figure (cell coordinates: head x 4-12 / y 8-14, torso y 15-18, feet y 21) */
function extras(P: PF, L: Look) {
  switch (L.sp) {
    case SP_VENDOR:
      P('#ffffff', 7, 16, 3, 3);
      break;
    case SP_COP:
      P('#f5d020', 7, 16);
      P('#f5d020', 8, 9);
      break;
    case SP_MUSIC:
      P('#b5651d', 6, 16, 4, 3);
      P('#e8c98a', 7, 17);
      P('#6b3e12', 10, 15, 3, 1);
      break;
    case SP_ELMO:
      P('#ffffff', 5, 10, 2, 3);
      P('#ffffff', 9, 10, 2, 3);
      P('#111111', 6, 12);
      P('#111111', 9, 12);
      P('#f59a23', 8, 13);
      break;
    case SP_LIBERTY:
      P(L.hair, 5, 7);
      P(L.hair, 8, 6, 1, 2);
      P(L.hair, 11, 7);
      P('#f5c542', 13, 12, 1, 3);
      P('#ffe9a0', 13, 11);
      break;
    case X_ELDER:
      P('#6b4a2e', 13, 16, 1, 6);
      P('#30303c', 5, 11, 3, 1);
      P('#30303c', 9, 11, 3, 1);
      break;
    case X_HOMELESS:
      P(L.shirt, 5, 18, 7, 2);
      P(shade(L.shirt, 0.7), 5, 19, 7, 1);
      P(L.hair, 5, 13, 7, 1);
      P(L.hair, 6, 14, 5, 1);
      P(shade(L.shirt, 1.45), 7, 16);
      P(shade(L.shirt, 1.45), 10, 18);
      break;
    case X_COURIER:
      P(shade(L.bag, 0.72), 6, 16, 5, 1);
      break;
    case X_CHEF:
      P('#ffffff', 5, 5, 7, 3);
      P('#dcdcdc', 4, 8, 9, 1);
      break;
    case X_HOTDOG:
      P('#d9a05a', 3, 11, 1, 8);
      P('#d9a05a', 13, 11, 1, 8);
      P('#d9a05a', 4, 15, 9, 5);
      P('#b9843f', 4, 19, 9, 1);
      P('#c0432b', 7, 15, 3, 5);
      P('#f5d020', 8, 16);
      P('#f5d020', 7, 17);
      P('#f5d020', 9, 18);
      break;
    case X_DINO: {
      const c = L.shirt, d = shade(c, 0.72);
      P(c, 5, 7, 7, 1);
      P(c, 4, 8, 9, 2);
      P(c, 4, 10, 1, 5);
      P(c, 12, 10, 1, 5);
      P(d, 6, 6);
      P(d, 8, 5);
      P(d, 10, 6);
      P('#ffffff', 6, 10);
      P('#ffffff', 8, 10);
      P('#ffffff', 10, 10);
      break;
    }
    case X_ASTRO:
      P('#eef2f7', 4, 7, 9, 8);
      P('#3a5a8a', 5, 10, 7, 4);
      P('#9cc6ea', 6, 10, 2, 1);
      P('#d8433b', 7, 16);
      P('#3b6ea8', 9, 16);
      break;
    case X_HERO:
      P(L.hat, 5, 11, 7, 2);
      P('#ffffff', 6, 12);
      P('#ffffff', 10, 12);
      P('#f5d020', 8, 16);
      break;
    case X_CLOWN:
      P('#ff2030', 8, 13);
      P('#ff2030', 7, 14, 3, 1);
      P('#3b6ea8', 7, 16);
      P('#ff3a6a', 9, 17);
      break;
    case X_PUNK:
      P(L.hat, 8, 5, 1, 4);
      P(L.hat, 7, 6, 3, 2);
      break;
    case X_TOURIST:
      P(L.hat, 3, 10, 11, 1);
      P('#22242e', 7, 16, 3, 2);
      P('#9cc6ea', 8, 16);
      break;
    case X_DOC:
      P('#50505c', 7, 15, 1, 2);
      P('#50505c', 9, 15, 1, 2);
      P('#c0c0c8', 8, 17);
      break;
    case X_FIRE:
      P(L.hat, 3, 10, 11, 1);
      P('#f5d020', 8, 9);
      break;
    case X_COWBOY:
      P(L.hat, 2, 10, 13, 1);
      P(shade(L.hat, 0.75), 7, 9, 3, 1);
      break;
    case X_NUN:
      P('#16161c', 5, 7, 7, 1);
      P('#16161c', 4, 8, 9, 2);
      P('#16161c', 4, 10, 1, 8);
      P('#16161c', 12, 10, 1, 8);
      P('#ffffff', 5, 10, 7, 1);
      P('#ffffff', 7, 15, 3, 1);
      P('#f5d020', 8, 16, 1, 2);
      break;
    case X_BIZ:
      P('#5a3a22', 12, 18, 3, 3);
      P('#8a6844', 13, 17);
      break;
    case X_MIME:
      P('#16161c', 6, 16, 5, 1);
      P('#16161c', 5, 7, 7, 1);
      P('#16161c', 4, 8, 9, 1);
      break;
    case X_ROBOT:
      P('#9aa2ae', 4, 7, 9, 8);
      P('#6a7280', 4, 14, 9, 1);
      P('#d8433b', 8, 5, 1, 2);
      P('#f5d020', 5, 10, 2, 2);
      P('#f5d020', 10, 10, 2, 2);
      P('#30303c', 6, 13, 5, 1);
      P('#9aa2ae', 5, 15, 7, 4);
      P('#5ff0e0', 7, 16, 3, 2);
      break;
    case X_BANANA:
      P('#f5d020', 5, 5, 7, 3);
      P('#6b4a2e', 8, 4);
      P('#f5d020', 4, 8, 1, 7);
      P('#f5d020', 12, 8, 1, 7);
      P('#f5d020', 4, 15, 9, 5);
      P('#d8b02a', 4, 19, 9, 1);
      break;
  }
}

/** head + torso (+ what they carry and wear) of one look, in a 16 x 24 cell, facing right; the legs are added per animation frame */
function upperOf(L: Look): HTMLCanvasElement {
  const { c, g } = mkCanvas(16, 24);
  const P: PF = (col, x, y, w = 1, h = 1) => {
    g.fillStyle = col;
    g.fillRect(x, y, w, h);
  };
  // on the back, like the survivors' backpacks: drawn first so the body covers its edge
  if (L.sp === X_COURIER) {
    P(L.bag, 1, 11, 3, 8);
    P(shade(L.bag, 0.72), 1, 18, 3, 1);
    P('#ffffff', 2, 13, 1, 2);
  } else if (L.sp === X_HOMELESS) {
    P(L.bag, 1, 13, 3, 5);
    P(shade(L.bag, 0.72), 1, 17, 3, 1);
  } else if (L.sp === X_HERO) {
    P(L.bag, 2, 15, 2, 4);
    P(L.bag, 1, 18, 2, 2);
  } else if (L.sp === X_ASTRO) P('#c9d1de', 2, 14, 2, 5);
  else if (L.sp === X_DINO) {
    P(L.shirt, 2, 18, 2, 1);
    P(L.shirt, 1, 17, 1, 1);
  } else if (L.acc === 1) {
    P(L.bag, 1, 14, 3, 5);
    P(shade(L.bag, 1.25), 1, 14, 3, 1);
    P(shade(L.bag, 0.72), 1, 18, 3, 1);
  }
  const key = (L.shirt.charCodeAt(1) + L.pants.charCodeAt(2) + L.skin.charCodeAt(3)) % 3;
  const torso = L.top === 1 ? TORSO_T.suit : L.top === 3 ? TORSO_T.vest : L.top === 2 ? (L.sp >= 0 || key === 0 ? TORSO_T.hood : key === 1 ? TORSO_T.jacket : TORSO_T.flannel) : TORSO_T.tee;
  const skirt = L.bottom === 2;
  const pal = {
    K: '#0d0a0c', F: L.skin, f: shade(L.skin, 0.84), s: shade(L.skin, 1.12), W: '#ffffff', E: '#20202c', M: shade(L.skin, 0.66),
    H: L.hair, h: shade(L.hair, 1.35), C: L.hat, c: shade(L.hat, 1.25), b: shade(L.hat, 0.76),
    J: L.shirt, j: shade(L.shirt, torso === TORSO_T.flannel ? 0.72 : 1.2), T: L.top === 1 ? '#eeeeee' : torso === TORSO_T.jacket ? '#e6e0d0' : shade(L.shirt, 1.3), A: L.bag, Y: '#ffe14a',
    P: skirt ? L.shirt : L.pants, D: skirt ? L.shirt : L.pants,
  };
  g.drawImage(mini(fromMap([...(HEAD_T[L.hs] ?? HEAD_T[0]), ...torso, ...(skirt ? HIP_SKIRT : HIP_PANTS)], pal)), 4, 8);
  if (skirt) P(shade(L.shirt, 0.78), 4, 19, 9, 1);
  if (L.hs === 1) {
    P(L.hair, 4, 15, 1, 2);
    P(L.hair, 12, 15, 1, 2);
  } else if (L.hs === 2) P(shade(L.hat, 0.76), 13, 10, 1, 1); // the peak of the cap points where they are going
  else if (L.hs === 3) P(shade(L.hat, 1.25), 8, 7, 1, 1);
  else if (L.hs === 4) {
    P(L.hair, 5, 7, 7, 1);
    P(L.hair, 3, 9, 1, 4);
    P(L.hair, 13, 9, 1, 4);
  }
  if (L.acc === 2) {
    for (let i = 0; i < 3; i++) P(L.bag, 6 + i, 15 + i);
    P(L.bag, 10, 17, 2, 2);
  }
  extras(P, L);
  return c;
}

/**
 * One animation frame, facing right, exactly as the survivors of the zombie city move: fr 0 stands; fr 1 the legs come together
 * and one foot lifts; fr 2 they swing apart and the other foot lifts - and the body dips with every step. fr 3 is the idle breath.
 * arms: the two-part arms of the dead, stretched out towards whoever is in front (zombies only).
 */
function figFrame(up: HTMLCanvasElement, leg: string, shoe: string, fr: number, bx = 0, arms: [string, string] | null = null): HTMLCanvasElement {
  const { c, g } = mkCanvas(16, 24);
  const P = (col: string, x: number, y: number, w = 1, h = 1) => {
    g.fillStyle = col;
    g.fillRect(x, y, w, h);
  };
  const bob = fr ? 1 : 0, lx = fr === 1 ? 1 : fr === 2 ? -1 : 0, u1 = fr === 1 ? 1 : 0, u2 = fr === 2 ? 1 : 0;
  const l1 = 6 + lx + bx, l2 = 9 - lx + bx;
  P(leg, l1, 19 - u1, 2, 2);
  P(shoe, l1, 21 - u1, 2, 1);
  P(leg, l2, 19 - u2, 2, 2);
  P(shoe, l2, 21 - u2, 2, 1);
  g.drawImage(up, bx, bob);
  if (arms) {
    // far arm first, then the near one: sleeve, then bare forearm and hand, wobbling with the shamble
    const hy = [[15, 17], [14, 17], [16, 18], [15, 17]][fr];
    for (let a = 1; a >= 0; a--)
      for (let k = 0; k < 4; k++) {
        const y0 = (a ? 17 : 16) + bob, y1 = hy[a] + bob;
        P(k < 2 ? arms[0] : arms[1], (a ? 10 : 11) + bx + k, Math.round(y0 + ((y1 - y0) * k) / 3));
      }
  }
  return c;
}

function mirror(src: HTMLCanvasElement): HTMLCanvasElement {
  const { c, g } = mkCanvas(16, 24);
  g.translate(17, 0);
  g.scale(-1, 1);
  g.drawImage(src, 0, 0);
  return c;
}

/** draw one figure into any sprite (the riders of bikes and scooters). dir 1 / 3 face left, 0 / 2 face right */
function person(g: G, ox: number, oy: number, dir: number, fr: number, L: Look) {
  const cell = figFrame(upperOf(L), L.bottom ? L.skin : L.pants, L.shoes, fr);
  g.drawImage(dir === 1 || dir === 3 ? mirror(cell) : cell, ox, oy);
}

/** lay figures out as the engine expects them: per look four frames (stand, step, step, idle breath) for down, left, right, up */
function atlas(n: number, cell: (i: number, fr: number) => HTMLCanvasElement): PeopleAtlas {
  const per = 12;
  const { c, g } = mkCanvas(per * 64, Math.ceil(n / per) * 96);
  for (let i = 0; i < n; i++) {
    const X = (i % per) * 64, Y = Math.floor(i / per) * 96;
    for (let f = 0; f < 4; f++) {
      const r = cell(i, f), l = mirror(r);
      g.drawImage(r, X + f * 16, Y);
      g.drawImage(l, X + f * 16, Y + 24);
      g.drawImage(r, X + f * 16, Y + 48);
      g.drawImage(l, X + f * 16, Y + 72);
    }
  }
  outline(c);
  return { c, n, per };
}

export interface PeopleAtlas {
  c: HTMLCanvasElement;
  n: number;
  per: number;
}

export function buildPeople(seed: number, n = N_BASE): PeopleAtlas {
  const r = mulberry32(seed);
  const looks: Look[] = [...SPECIALS];
  while (looks.length < n) looks.push(randLook(r));
  looks.push(...EXTRAS);
  const ups = looks.map(upperOf);
  return atlas(looks.length, (i, fr) => figFrame(ups[i], looks[i].bottom ? looks[i].skin : looks[i].pants, looks[i].shoes, fr));
}

/**
 * The infected of the New York outbreak are the zombies of the co-op city themselves: the same head and torso sprites
 * (shamblers and red-eyed runners), the same shuffling legs, the same arms stretched out in front.
 */
export function buildZPeople(n: number): PeopleAtlas {
  const Z = zombieSprites(), vs = [...Z.scav, ...Z.warrior];
  const frames = vs.map((v) => {
    const { c, g } = mkCanvas(16, 24);
    g.drawImage(mini(v.img), 4, 8);
    return [0, 1, 2, 3].map((fr) => figFrame(c, v.pants, '#1a1418', fr, -1, [v.sleeve, v.skin]));
  });
  return atlas(n, (i, fr) => frames[i % frames.length][fr]);
}

// ============================================================ CARS
export interface CarType {
  len: number;
  kind: number; // 0 sedan 1 taxi 2 police 3 bus 4 van 5 two-wheeler 6 food truck
  c: HTMLCanvasElement[]; // N E S W
}

function carH(len: number, body: string, kind: number): HTMLCanvasElement {
  const { c, g } = mkCanvas(len + 2, 24);
  const top = shade(body, 1.1);
  const side = shade(body, 0.85);
  const glass = '#253348';
  const gl2 = '#5a7fa8';
  const mid = len >> 1;
  if (kind >= 3) {
    R(g, top, 1, 2, len, 10);
    R(g, shade(body, 1.22), 2, 3, len - 2, 1);
    R(g, shade(top, 0.88), 6, 5, 8, 4);
    if (kind === 3) R(g, shade(top, 0.88), len - 22, 5, 10, 4);
    R(g, glass, len - 3, 3, 3, 8);
    R(g, side, 1, 12, len, 8);
    if (kind === 3) {
      R(g, glass, 3, 13, len - 8, 4);
      for (let x = 9; x < len - 6; x += 7) R(g, side, x, 13, 1, 4);
      R(g, '#2a5fb8', 1, 18, len, 1);
    } else {
      R(g, glass, len - 11, 13, 8, 4);
      R(g, shade(body, 0.7), 5, 14, 12, 4);
      R(g, shade(body, 1.2), 7, 15, 8, 1);
    }
    R(g, shade(body, 0.55), 1, 20, len, 1);
    R(g, '#17181d', 6, 18, 7, 4);
    R(g, '#17181d', len - 14, 18, 7, 4);
    R(g, '#8a8d96', 8, 19, 3, 2);
    R(g, '#8a8d96', len - 12, 19, 3, 2);
    R(g, '#fff3b0', len - 1, 16, 2, 2);
    R(g, '#e03a3a', 1, 16, 1, 2);
  } else {
    R(g, top, 1, 7, len, 6);
    R(g, shade(body, 1.25), 8, 3, len - 16, 7);
    R(g, glass, len - 9, 4, 3, 8);
    R(g, gl2, len - 9, 4, 1, 3);
    R(g, glass, 6, 4, 2, 8);
    R(g, glass, 9, 10, len - 18, 3);
    R(g, gl2, 10, 10, 3, 1);
    R(g, side, mid, 10, 1, 3);
    R(g, side, 1, 13, len, 5);
    R(g, shade(body, 0.6), 1, 17, len, 1);
    R(g, shade(body, 0.7), mid, 13, 1, 4);
    if (kind === 1) {
      R(g, '#ffffff', mid - 3, 1, 6, 3);
      R(g, '#222222', mid - 2, 2, 4, 1);
      for (let x = 4; x < len - 2; x += 2) R(g, '#222222', x, 14, 1, 1);
    }
    if (kind === 2) {
      R(g, '#2a4fb0', 1, 14, len, 2);
      R(g, '#e03a3a', mid - 3, 2, 3, 2);
      R(g, '#3a6ae0', mid, 2, 3, 2);
    }
    R(g, '#17181d', 5, 15, 6, 4);
    R(g, '#17181d', len - 10, 15, 6, 4);
    R(g, '#8a8d96', 7, 16, 2, 2);
    R(g, '#8a8d96', len - 8, 16, 2, 2);
    R(g, '#fff3b0', len - 1, 13, 2, 2);
    R(g, '#e03a3a', 1, 13, 1, 2);
  }
  outline(c);
  return c;
}

function carV(len: number, body: string, kind: number, north: boolean): HTMLCanvasElement {
  const { c, g } = mkCanvas(22, len + 6);
  const W = 16;
  const x0 = 3;
  const top = shade(body, 1.1);
  const side = shade(body, 0.8);
  const roof = shade(body, 1.25);
  const glass = '#253348';
  const gl2 = '#5a7fa8';
  R(g, top, x0, 2, W, len);
  R(g, side, x0, len - 2, W, 4);
  if (kind >= 3) {
    R(g, shade(body, 1.22), x0 + 1, 3, W - 2, 1);
    R(g, shade(top, 0.88), x0 + 4, 10, 8, 6);
    if (kind === 3) R(g, shade(top, 0.88), x0 + 4, len - 22, 8, 8);
    if (north) R(g, glass, x0 + 1, 3, W - 2, 3);
    else {
      R(g, glass, x0 + 1, len - 6, W - 2, 4);
      R(g, gl2, x0 + 2, len - 6, 4, 1);
    }
    if (kind === 3) R(g, '#2a5fb8', x0, len, W, 1);
  } else if (!north) {
    R(g, glass, x0 + 1, 5, W - 2, 3);
    R(g, roof, x0 + 1, 8, W - 2, len - 22);
    R(g, glass, x0 + 1, len - 14, W - 2, 5);
    R(g, gl2, x0 + 2, len - 14, 4, 1);
  } else {
    R(g, glass, x0 + 1, 6, W - 2, 4);
    R(g, gl2, x0 + 2, 6, 4, 1);
    R(g, roof, x0 + 1, 10, W - 2, len - 22);
    R(g, glass, x0 + 1, len - 12, W - 2, 4);
  }
  if (north) {
    R(g, '#e03a3a', x0, len - 1, 3, 2);
    R(g, '#e03a3a', x0 + W - 3, len - 1, 3, 2);
    R(g, '#eeeeee', x0 + 6, len, 4, 1);
  } else {
    R(g, '#fff3b0', x0, len - 1, 3, 2);
    R(g, '#fff3b0', x0 + W - 3, len - 1, 3, 2);
    R(g, '#17181d', x0 + 4, len - 1, W - 8, 2);
  }
  R(g, '#17181d', x0 - 1, 6, 1, 6);
  R(g, '#17181d', x0 + W, 6, 1, 6);
  R(g, '#17181d', x0 - 1, len - 10, 1, 6);
  R(g, '#17181d', x0 + W, len - 10, 1, 6);
  const mid = (len >> 1) + 1;
  if (kind === 1) {
    R(g, '#ffffff', x0 + 5, mid - 2, 6, 3);
    R(g, '#222222', x0 + 6, mid - 1, 4, 1);
  }
  if (kind === 2) {
    R(g, '#e03a3a', x0 + 2, mid - 1, 6, 2);
    R(g, '#3a6ae0', x0 + 8, mid - 1, 6, 2);
    R(g, '#2a4fb0', x0, len, W, 1);
  }
  outline(c);
  return c;
}

function flipH(src: HTMLCanvasElement): HTMLCanvasElement {
  const { c, g } = mkCanvas(src.width, src.height);
  g.translate(src.width, 0);
  g.scale(-1, 1);
  g.drawImage(src, 0, 0);
  return c;
}

export function buildCars(): CarType[] {
  const defs: [number, string, number][] = [
    [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32], [1, '#f2c230', 32],
    [0, '#c0392b', 32], [0, '#2b5fb0', 32], [0, '#e9e9ee', 32], [0, '#2a2a33', 32], [0, '#7a8a9a', 32], [0, '#3f8a5a', 32], [0, '#8a8f99', 32],
    [2, '#f0f0f4', 32],
    [3, '#e8eaf0', 54],
    [4, '#f0f0f0', 36], [4, '#6b4a2e', 36],
  ];
  const out: CarType[] = defs.map(([kind, body, len]) => {
    const e = carH(len, body, kind);
    return { len, kind, c: [carV(len, body, kind, true), e, carV(len, body, kind, false), flipH(e)] };
  });
  // two-wheelers, each with its own rider: motorbikes, scooters and food couriers
  const r = mulberry32(4242);
  const HEL = ['#f2f2f2', '#22242e', '#c0392b', '#2b5fb0', '#e8c14a', '#3f8a4a'];
  const two = (body: string, style: number, L: Look) => {
    const h = pick(r, HEL), w = twoWheelH(body, L, style, h);
    out.push({ len: 22, kind: 5, c: [twoWheelV(body, L, style, h, true), flipH(w), twoWheelV(body, L, style, h, false), w] });
  };
  for (const col of ['#c0392b', '#2b5fb0', '#2a2a33', '#e8c14a', '#3f8a5a']) two(col, 0, randLook(r));
  for (const col of ['#ff7ab0', '#3cc0c0', '#f08a3c', '#7a8a9a']) two(col, 1, randLook(r));
  ['#22242e', '#f2f2f2', '#c0392b', '#2b5fb0'].forEach((col, i) => two(col, 2, EXTRAS[10 + i]));
  out.push(foodTruck('#f5d020', '#c0392b'), foodTruck('#f2f2f2', '#2f8a4a'), foodTruck('#ff8ab0', '#2b5fb0'));
  return out;
}

/**
 * A two-wheeler and its rider. The rider is one of the regular figures - same head, same clothes - sitting on the saddle
 * with a helmet on, a leg on the footboard and a hand on the bar. style: 0 motorbike, 1 scooter, 2 scooter with a delivery box.
 * L = null draws the machine parked on its own. Drawn facing west; flip it for east.
 */
function twoWheelH(body: string, L: Look | null, style: number, helmet: string): HTMLCanvasElement {
  const { c, g } = mkCanvas(24, 24);
  const b2 = shade(body, 0.72), b3 = shade(body, 1.4);
  if (L) {
    person(g, 6, -4, 1, 0, L);
    g.clearRect(9, 15, 11, 4); // sitting, not standing
    R(g, helmet, 12, 3, 5, 1);
    R(g, helmet, 10, 4, 9, 3);
    R(g, helmet, 16, 7, 3, 3);
    R(g, shade(helmet, 1.45), 12, 4, 3, 1);
  }
  for (const x of [2, 16]) {
    R(g, '#17181d', x + 1, 17, 3, 6);
    R(g, '#17181d', x, 18, 5, 4);
    R(g, '#8a8d96', x + 2, 19, 1, 2);
  }
  if (style === 0) {
    R(g, '#5a5d66', 6, 11, 1, 8);
    R(g, '#3a3d46', 8, 16, 8, 3);
    R(g, '#6a6d76', 9, 17, 3, 1);
    R(g, body, 8, 13, 6, 3);
    R(g, b3, 9, 13, 4, 1);
    R(g, '#1a1a20', 13, 13, 7, 2);
    R(g, b2, 16, 15, 5, 2);
    R(g, '#9a9da6', 13, 19, 8, 1);
  } else {
    R(g, body, 6, 12, 2, 8);
    R(g, b3, 6, 12, 1, 6);
    R(g, b2, 7, 19, 9, 2);
    R(g, body, 12, 15, 9, 4);
    R(g, b3, 13, 15, 7, 1);
    R(g, '#2a2a33', 11, 14, 8, 1);
    R(g, b2, 3, 16, 4, 1);
    R(g, '#c9d1de', 9, 18, 3, 1);
  }
  R(g, '#3a3d46', 7, 10, 1, 2);
  R(g, '#1a1a20', 6, 9, 3, 1);
  R(g, '#9aa2ae', 6, 8, 1, 1);
  R(g, '#fff3c0', 5, 12, 1, 2);
  R(g, '#d8433b', 21, 15, 1, 2);
  if (L) {
    const sd = shade(L.shirt, 0.78), leg = L.bottom ? L.skin : L.pants;
    R(g, leg, 10, 14, 4, 2);
    R(g, leg, 9, 15, 2, 4);
    R(g, L.shoes, 8, 19, 3, 1);
    R(g, sd, 9, 12, 3, 1);
    R(g, sd, 8, 11, 2, 1);
    R(g, L.skin, 7, 10, 1, 1);
  }
  if (style === 2) {
    const bc = L ? L.bag : '#2fd06a';
    R(g, bc, 18, 6, 5, 8);
    R(g, shade(bc, 0.72), 18, 13, 5, 1);
    R(g, '#ffffff', 20, 8, 2, 3);
  }
  outline(c);
  return c;
}

/** the same machine seen from behind (north) or from the front (south) */
function twoWheelV(body: string, L: Look | null, style: number, helmet: string, north: boolean): HTMLCanvasElement {
  const { c, g } = mkCanvas(22, 28);
  const b2 = shade(body, 0.72), b3 = shade(body, 1.4);
  const sd = L ? shade(L.shirt, 0.78) : '', leg = L ? (L.bottom ? L.skin : L.pants) : '';
  const bc = L ? L.bag : '#2fd06a';
  if (north) {
    if (L) {
      person(g, 3, -2, 3, 0, L);
      g.clearRect(6, 17, 11, 4);
      R(g, helmet, 9, 5, 5, 1);
      R(g, helmet, 7, 6, 9, 7); // seen from behind: the helmet hides the head
      R(g, shade(helmet, 1.45), 9, 6, 3, 1);
      R(g, shade(helmet, 0.7), 8, 12, 7, 1);
    }
    R(g, '#17181d', 10, 20, 3, 7);
    R(g, '#1a1a20', 4, 13, 3, 1);
    R(g, '#1a1a20', 16, 13, 3, 1);
    R(g, '#9aa2ae', 4, 11, 1, 2);
    R(g, '#9aa2ae', 18, 11, 1, 2);
    R(g, body, 8, 16, 7, 6);
    R(g, b3, 9, 16, 5, 1);
    R(g, b2, 8, 21, 7, 1);
    R(g, '#d8433b', 9, 18, 5, 1);
    R(g, '#e6e0d0', 10, 20, 3, 1);
    if (style === 0) R(g, '#9a9da6', 15, 19, 1, 4);
    if (L) {
      R(g, leg, 6, 16, 2, 4);
      R(g, leg, 15, 16, 2, 4);
      R(g, L.shoes, 6, 20, 2, 1);
      R(g, L.shoes, 15, 20, 2, 1);
      R(g, sd, 6, 13, 2, 1);
      R(g, sd, 15, 13, 2, 1);
      R(g, L.skin, 5, 13, 1, 1);
      R(g, L.skin, 17, 13, 1, 1);
    }
    if (style === 2) {
      R(g, bc, 7, 11, 9, 8);
      R(g, shade(bc, 0.72), 7, 18, 9, 1);
      R(g, '#ffffff', 10, 13, 3, 3);
    }
  } else {
    if (style === 2) {
      R(g, bc, 5, 9, 2, 7);
      R(g, bc, 16, 9, 2, 7);
    }
    if (L) {
      person(g, 3, -2, 0, 0, L);
      g.clearRect(6, 17, 11, 4);
      R(g, helmet, 9, 5, 5, 1);
      R(g, helmet, 7, 6, 9, 3);
      R(g, helmet, 7, 9, 1, 3);
      R(g, helmet, 15, 9, 1, 3);
      R(g, shade(helmet, 1.45), 9, 6, 3, 1);
    }
    R(g, '#17181d', 10, 21, 3, 6);
    R(g, '#1a1a20', 4, 14, 15, 1);
    R(g, '#9aa2ae', 4, 12, 1, 2);
    R(g, '#9aa2ae', 18, 12, 1, 2);
    if (style === 0) {
      R(g, '#5a5d66', 10, 15, 3, 6);
      R(g, body, 9, 15, 5, 4);
      R(g, b3, 10, 15, 3, 1);
    } else {
      R(g, body, 8, 15, 7, 7);
      R(g, b3, 9, 15, 5, 1);
      R(g, b2, 8, 21, 7, 1);
    }
    R(g, '#fff3c0', 10, 16, 3, 2);
    if (L) {
      R(g, leg, 6, 17, 2, 4);
      R(g, leg, 15, 17, 2, 4);
      R(g, L.shoes, 6, 21, 2, 1);
      R(g, L.shoes, 15, 21, 2, 1);
      R(g, sd, 6, 14, 2, 1);
      R(g, sd, 15, 14, 2, 1);
      R(g, L.skin, 5, 14, 1, 1);
      R(g, L.skin, 17, 14, 1, 1);
    }
  }
  outline(c);
  return c;
}

/** your ride: a black scooter. `ride` has you on it, `park` is the scooter on its stand; both indexed N, E, S, W */
export function buildScooter() {
  const body = '#23232b', hel = '#2a2a33';
  const mk = (L: Look | null) => {
    const w = twoWheelH(body, L, 1, hel);
    return [twoWheelV(body, L, 1, hel, true), flipH(w), twoWheelV(body, L, 1, hel, false), w];
  };
  return { ride: mk(SPECIALS[0]), park: mk(null) };
}

/** a street-food truck: a van with a serving hatch, a striped awning and a sign on the roof */
function foodTruck(body: string, sign: string): CarType {
  const len = 40, e = carH(len, body, 4), n = carV(len, body, 4, true), s = carV(len, body, 4, false);
  const g = e.getContext('2d')!;
  R(g, '#16263a', 9, 13, 15, 4);
  R(g, '#fff3c0', 10, 14, 13, 2);
  for (let x = 8; x < 25; x += 2) R(g, (x >> 1) & 1 ? '#ffffff' : sign, x, 11, 2, 2);
  R(g, sign, 10, 4, 16, 5);
  for (const x of [12, 16, 20]) R(g, '#ffffff', x, 6, 2, 1);
  for (const cv of [n, s]) {
    const q = cv.getContext('2d')!;
    R(q, sign, 6, 14, 10, 12);
    R(q, '#ffffff', 8, 17, 6, 1);
    R(q, '#ffffff', 8, 21, 6, 1);
  }
  return { len, kind: 6, c: [n, e, s, flipH(e)] };
}



// ============================================================ TREES
function tree(r: Rng, rad: number, pal: string[], trunkH: number): Spr {
  const W = rad * 2 + 6;
  const H = rad * 2 + trunkH + 3;
  const { c, g } = mkCanvas(W, H);
  const cx = W / 2;
  const cy = rad + 1;
  const ty = Math.round(cy + rad * 0.5);
  R(g, '#6b4a2e', cx - 2, ty, 4, H - 1 - ty);
  R(g, '#4f351f', cx + 1, ty, 1, H - 1 - ty);
  R(g, '#6b4a2e', cx - 3, H - 2, 6, 1);
  const blobs = [
    [0, -rad * 0.32, rad * 0.72],
    [-rad * 0.48, rad * 0.08, rad * 0.58],
    [rad * 0.48, rad * 0.08, rad * 0.58],
    [0, rad * 0.3, rad * 0.62],
  ];
  for (let y = 0; y < rad * 2 + 2; y++)
    for (let x = 0; x < W; x++) {
      const dx = x + 0.5 - cx;
      const dy = y + 0.5 - cy;
      let inside = false;
      for (const b of blobs) {
        const ex = dx - b[0];
        const ey = dy - b[1];
        if (ex * ex + ey * ey <= b[2] * b[2]) {
          inside = true;
          break;
        }
      }
      if (!inside) continue;
      const tt = (dx * 0.55 + dy) / rad + (r() - 0.5) * 0.4;
      g.fillStyle = tt < -0.5 ? pal[3] : tt < 0.0 ? pal[2] : tt < 0.5 ? pal[1] : pal[0];
      g.fillRect(x, y, 1, 1);
    }
  outline(c, shade(pal[0], 0.55));
  return { c };
}

function pine(): Spr {
  const { c, g } = mkCanvas(24, 40);
  R(g, '#5a3d24', 10, 32, 4, 7);
  for (let t = 0; t < 4; t++) {
    const top = 1 + t * 7;
    for (let i = 0; i < 12; i++) {
      const hw = Math.round(2 + (i * (5 + t * 1.6)) / 11);
      R(g, i > 8 ? '#1f5a3a' : i < 3 ? '#3f9a5a' : '#2c7a48', 12 - hw, top + i, hw * 2, 1);
    }
  }
  outline(c, '#123322');
  return { c };
}

// ============================================================ PROPS
function mk(w: number, h: number, f: (g: G) => void, extra: Partial<Spr> = {}, ol = true): Spr {
  const { c, g } = mkCanvas(w + 2, h + 2);
  g.translate(1, 1);
  f(g);
  g.setTransform(1, 0, 0, 1, 0, 0);
  if (ol) outline(c);
  return { c, ...extra };
}

function umbrella(g: G, cx: number, y: number, rx: number, a: string, b: string) {
  for (let dy = 0; dy < rx * 0.62; dy++) {
    const hw = Math.round(rx * Math.sqrt(1 - Math.pow(1 - (dy + 1) / (rx * 0.62), 2)));
    for (let x = -hw; x <= hw; x++) {
      const seg = Math.floor(((x + rx) / (rx * 2 + 1)) * 6);
      R(g, seg % 2 ? a : b, cx + x, y + dy, 1, 1);
    }
  }
}

function cart(a: string, b: string, label: string, sign: string): Spr {
  return mk(28, 34, (g) => {
    R(g, '#8a8d96', 13, 8, 1, 12);
    umbrella(g, 13, 0, 13, a, b);
    R(g, '#c9ccd2', 3, 18, 22, 11);
    R(g, '#e8eaee', 3, 18, 22, 2);
    R(g, sign, 3, 21, 22, 6);
    drawText(g, label, 3 + ((22 - textW(label)) >> 1), 22, '#ffffff');
    R(g, '#9a9da6', 3, 28, 22, 1);
    ell(g, '#22232a', 7, 30, 2, 2);
    ell(g, '#22232a', 20, 30, 2, 2);
    R(g, '#d94a3a', 5, 16, 2, 2);
    R(g, '#e8c14a', 9, 16, 2, 2);
    R(g, '#f2f2f2', 20, 15, 2, 3);
  });
}

function flag(cols: string[], us = false): Spr {
  return mk(13, 34, (g) => {
    R(g, '#b9bcc4', 1, 1, 1, 33);
    R(g, '#e8c14a', 0, 0, 3, 2);
    if (us) {
      for (let i = 0; i < 7; i++) R(g, i % 2 ? '#f2f2f2' : '#c0392b', 2, 2 + i, 10, 1);
      R(g, '#2b3f8a', 2, 2, 4, 4);
      R(g, '#ffffff', 3, 3, 1, 1);
      R(g, '#ffffff', 5, 4, 1, 1);
    } else {
      const n = cols.length;
      cols.forEach((cc, i) => R(g, cc, 2, 2 + Math.round((i * 7) / n), 10, Math.ceil(7 / n)));
    }
  });
}

export function buildProps() {
  const r = mulberry32(4242);
  const GREEN = ['#2a6234', '#3a8340', '#58a84c', '#84c868'];
  const GREEN2 = ['#24583a', '#2f7a4a', '#46a060', '#72c486'];
  const GREEN3 = ['#3a6a2a', '#55903a', '#78b44a', '#a4d468'];
  const ORANGE = ['#8a3b1d', '#c25a1f', '#e58a2a', '#f5b84a'];
  const RED = ['#7a2420', '#a8342a', '#d0503a', '#e8845a'];
  const YELLOW = ['#9a7a1a', '#c9a224', '#e8c83a', '#f8e878'];
  const PINK = ['#a8507a', '#d977a0', '#f2a6c4', '#ffd8e6'];

  const lamp = mk(12, 36, (g) => {
    R(g, '#2d3838', 4, 6, 2, 27);
    R(g, '#2d3838', 3, 31, 4, 4);
    R(g, '#3d4a4a', 4, 12, 2, 1);
    R(g, '#2d3838', 4, 3, 2, 3);
    R(g, '#2d3838', 5, 1, 5, 2);
    R(g, '#2d3838', 8, 3, 3, 2);
    R(g, '#fff0b0', 8, 5, 3, 2);
  }, { lamps: [10, 7, 44] });

  const tlight = mk(10, 36, (g) => {
    R(g, '#3a3d42', 4, 12, 2, 23);
    R(g, '#3a3d42', 3, 33, 4, 2);
    R(g, '#e8c530', 2, 0, 6, 13);
    R(g, '#1c1d22', 3, 1, 4, 11);
    R(g, '#4a1c1c', 4, 2, 2, 2);
    R(g, '#4a401c', 4, 5, 2, 2);
    R(g, '#1c4026', 4, 8, 2, 2);
  });

  const hydrant = mk(8, 11, (g) =>
    pix(g, 0, 0, ['..rrrr..', '.rllrrr.', '..rrrr..', '..rlrr..', 'rrrlrrrr', 'rrrrrrdd', '..rlrr..', '..rlrd..', '..rrrd..', '.rrrrrr.', '.dddddd.'], { r: '#d8382e', l: '#f07a6a', d: '#9a241e' }),
  );

  const trash = mk(9, 12, (g) => {
    R(g, '#2f5a3a', 1, 2, 7, 10);
    R(g, '#3f7a4e', 0, 1, 9, 2);
    for (let x = 2; x < 8; x += 2) R(g, '#234a2e', x, 4, 1, 7);
    R(g, '#234a2e', 1, 7, 7, 1);
  });

  const mailbox = mk(10, 14, (g) => {
    R(g, '#2a4f9a', 1, 2, 8, 9);
    R(g, '#2a4f9a', 2, 0, 6, 2);
    R(g, '#4a72c4', 2, 1, 5, 1);
    R(g, '#1a336a', 2, 4, 6, 1);
    R(g, '#f2f2f2', 3, 6, 4, 2);
    R(g, '#1a336a', 1, 11, 2, 3);
    R(g, '#1a336a', 7, 11, 2, 3);
  });

  const news = ['#d8382e', '#e8c14a', '#2b7fd0'].map((cc) =>
    mk(8, 11, (g) => {
      R(g, cc, 0, 0, 8, 9);
      R(g, shade(cc, 1.3), 0, 0, 8, 1);
      R(g, '#1c2636', 1, 2, 6, 3);
      R(g, '#f2f2f2', 2, 3, 3, 1);
      R(g, shade(cc, 0.6), 1, 9, 2, 2);
      R(g, shade(cc, 0.6), 5, 9, 2, 2);
    }),
  );

  const bench = mk(24, 13, (g) => {
    R(g, '#8a5c34', 1, 1, 22, 2);
    R(g, '#8a5c34', 1, 4, 22, 2);
    R(g, '#a87442', 1, 7, 22, 3);
    R(g, '#c08a55', 1, 7, 22, 1);
    R(g, '#26262c', 2, 1, 1, 12);
    R(g, '#26262c', 21, 1, 1, 12);
    R(g, '#26262c', 11, 6, 1, 4);
  });

  const carts = [
    cart('#d8382e', '#f5d020', 'DOGS', '#c0392b'),
    cart('#2b7fd0', '#f5d020', 'HALAL', '#2f8a4a'),
    cart('#f2f2f2', '#d8382e', 'NUTS', '#8a4a2a'),
    cart('#3fa0d0', '#f2f2f2', 'ICE', '#2b7fd0'),
  ];

  const subway = mk(32, 26, (g) => {
    R(g, '#2f6b45', 0, 8, 32, 2);
    R(g, '#2f6b45', 0, 8, 3, 17);
    R(g, '#2f6b45', 29, 8, 3, 17);
    R(g, '#3f8a5a', 0, 8, 32, 1);
    for (let i = 0; i < 5; i++) {
      R(g, shade('#55565e', 1 - i * 0.16), 3, 10 + i * 3, 26, 3);
      R(g, shade('#77787f', 1 - i * 0.16), 3, 10 + i * 3, 26, 1);
    }
    R(g, '#15151a', 5, 0, 22, 7);
    ell(g, '#e23a2e', 9, 3, 2, 2);
    ell(g, '#2f9a4a', 15, 3, 2, 2);
    ell(g, '#f5c518', 21, 3, 2, 2);
    R(g, '#ffffff', 9, 3, 1, 1);
    R(g, '#ffffff', 15, 3, 1, 1);
    R(g, '#222222', 21, 3, 1, 1);
    R(g, '#2f6b45', 1, 3, 1, 5);
    R(g, '#2f6b45', 30, 3, 1, 5);
    ell(g, '#39d37a', 1, 2, 1, 1);
    ell(g, '#39d37a', 30, 2, 1, 1);
  }, { lamps: [2, 3, 22, 31, 3, 22], glows: [5, 1, 24, 8] });

  const steam = mk(8, 18, (g) => {
    for (let i = 0; i < 6; i++) R(g, i % 2 ? '#f4f4f4' : '#f28a1e', 2, i * 3, 4, 3);
    R(g, '#f28a1e', 1, 15, 6, 3);
  });

  const cone = mk(6, 8, (g) => pix(g, 0, 0, ['..oo..', '..oo..', '.wwww.', '.oooo.', '.wwww.', 'oooooo', 'oooooo', 'dddddd'], { o: '#f07a1e', w: '#f4f4f4', d: '#a8501a' }));

  const flagUS = flag([], true);
  const flags = [
    flag(['#d8382e', '#f2f2f2', '#2b5fb0']), flag(['#2f9a4a', '#f2f2f2', '#d8382e']), flag(['#f5d020', '#2b5fb0']), flag(['#111111', '#d8382e', '#f5d020']),
    flag(['#f2f2f2', '#d8382e']), flag(['#2b5fb0', '#f5d020', '#d8382e']), flag(['#2f9a4a', '#f5d020']), flag(['#f08a24', '#f2f2f2', '#2f9a4a']),
    flag(['#d8382e', '#f5d020', '#2f9a4a']), flag(['#5ab0e8', '#f2f2f2', '#5ab0e8']), flag(['#d8382e', '#f2f2f2']), flag(['#3a6ae0', '#f2f2f2', '#d8382e']),
  ];

  const planter = mk(16, 12, (g) => {
    R(g, '#8f887b', 0, 6, 16, 6);
    R(g, '#a9a294', 0, 6, 16, 1);
    ell(g, '#3a8340', 8, 4, 7, 3);
    R(g, '#58a84c', 3, 2, 4, 2);
    R(g, '#ff6b8a', 4, 3, 1, 1);
    R(g, '#ffd84a', 9, 2, 1, 1);
    R(g, '#ffffff', 12, 4, 1, 1);
    R(g, '#ff6b8a', 11, 2, 1, 1);
  });

  const tables = ['#d8382e', '#2f8a4a', '#2b7fd0', '#f5d020'].map((cc) =>
    mk(22, 26, (g) => {
      R(g, '#8a8d96', 10, 6, 1, 14);
      umbrella(g, 10, 0, 10, cc, shade(cc, 1.35));
      R(g, '#e8e2d4', 5, 16, 12, 3);
      R(g, '#b9b2a4', 5, 19, 12, 1);
      R(g, '#6a6258', 10, 20, 2, 5);
      R(g, '#3a3a44', 1, 15, 3, 2);
      R(g, '#3a3a44', 1, 17, 1, 7);
      R(g, '#3a3a44', 3, 17, 1, 7);
      R(g, '#3a3a44', 18, 15, 3, 2);
      R(g, '#3a3a44', 18, 17, 1, 7);
      R(g, '#3a3a44', 20, 17, 1, 7);
    }),
  );

  const statue = (col: string) =>
    mk(16, 32, (g) => {
      R(g, '#a9a294', 3, 20, 10, 12);
      R(g, '#c2bbad', 2, 19, 12, 2);
      R(g, '#8f887b', 2, 30, 12, 2);
      R(g, '#7a7468', 5, 24, 6, 3);
      const l = shade(col, 1.3);
      const d = shade(col, 0.7);
      R(g, col, 6, 3, 4, 4);
      R(g, l, 6, 3, 2, 2);
      R(g, col, 5, 7, 6, 8);
      R(g, d, 9, 8, 2, 7);
      R(g, col, 5, 15, 2, 4);
      R(g, col, 9, 15, 2, 4);
      R(g, col, 11, 4, 2, 5);
      R(g, col, 3, 8, 2, 5);
      R(g, l, 12, 2, 1, 3);
    });
  const statueB = statue('#5a9a86');
  const statueG = statue('#e3b53a');

  const rock = mk(22, 14, (g) => {
    ell(g, '#7f8288', 11, 8, 10, 5);
    ell(g, '#9a9da4', 9, 6, 6, 3);
    R(g, '#b5b8be', 6, 4, 4, 1);
    R(g, '#63666c', 12, 10, 7, 2);
  });

  const link = mk(8, 22, (g) => {
    R(g, '#3a3d46', 1, 0, 6, 22);
    R(g, '#5a5d66', 1, 0, 1, 22);
    R(g, '#2fa0e8', 2, 2, 4, 9);
    R(g, '#8fd0f8', 2, 2, 4, 2);
    R(g, '#f2f2f2', 3, 6, 2, 1);
    R(g, '#22242a', 2, 13, 4, 4);
  }, { glows: [3, 3, 4, 9] });

  const bush = mk(14, 10, (g) => {
    ell(g, '#2f7a3a', 7, 6, 6, 3);
    ell(g, '#46a050', 5, 4, 4, 3);
    ell(g, '#46a050', 9, 4, 3, 2);
    R(g, '#72c486', 4, 3, 2, 1);
  });

  const trees = [
    tree(r, 15, GREEN, 12), tree(r, 14, GREEN2, 12), tree(r, 16, GREEN3, 13), tree(r, 13, GREEN, 11),
    tree(r, 15, GREEN2, 12), tree(r, 14, GREEN3, 11),
  ];
  const autumn = [tree(r, 15, ORANGE, 12), tree(r, 14, RED, 12), tree(r, 15, YELLOW, 12), tree(r, 13, ORANGE, 11)];
  const cherry = [tree(r, 13, PINK, 11), tree(r, 12, PINK, 10)];
  const street = [tree(r, 9, GREEN, 13), tree(r, 9, GREEN3, 13), tree(r, 8, GREEN2, 12), tree(r, 9, YELLOW, 13), tree(r, 8, PINK, 12)];
  const pineT = pine();

  // dogs: 4 colours x [A,B] x [left,right], cell 14x10
  const dogs = mkCanvas(14 * 4, 10 * 4);
  const DA = ['.e..........', 'ebb......t..', 'bbbbbbbbbb..', 'nbbbbbbbbb..', '.bbbbbbbbb..', '..b.b..b.b..', '..b.b..b.b..'];
  const DB = ['.e..........', 'ebb.......t.', 'bbbbbbbbbb..', 'nbbbbbbbbb..', '.bbbbbbbbb..', '.b..b..b..b.', 'b...b..b...b'];
  ['#b5651d', '#f0ece0', '#2a2a2e', '#d9a441'].forEach((col, i) => {
    const pal = { b: col, e: shade(col, 0.7), n: '#1a1a1a', t: col };
    const t = mkCanvas(28, 10);
    pix(t.g, 1, 2, DA, pal);
    pix(t.g, 15, 2, DB, pal);
    dogs.g.drawImage(t.c, 0, i * 10);
    dogs.g.save();
    dogs.g.translate(42, i * 10);
    dogs.g.scale(-1, 1);
    dogs.g.drawImage(t.c, 0, 0, 14, 10, 0, 0, 14, 10);
    dogs.g.restore();
    dogs.g.save();
    dogs.g.translate(56, i * 10);
    dogs.g.scale(-1, 1);
    dogs.g.drawImage(t.c, 14, 0, 14, 10, 0, 0, 14, 10);
    dogs.g.restore();
  });
  outline(dogs.c);

  // pigeons: 4 frames, cell 8x7
  const pig = mkCanvas(32, 7);
  const pp = { g: '#8d93a3', h: '#5e6578', o: '#e8843a', w: '#c9cedb' };
  pix(pig.g, 1, 1, ['.h....', 'hhggg.', '.ggggg', '.gggg.', '..o.o.'], pp);
  pix(pig.g, 9, 1, ['......', '..ggg.', 'hhgggg', 'hgggg.', '..o.o.'], pp);
  pix(pig.g, 17, 1, ['w....w', '.wggw.', '..gg..'], pp);
  pix(pig.g, 25, 1, ['......', '..gg..', 'wwggww'], pp);

  // light glow
  const glow = mkCanvas(64, 64);
  const gr = glow.g.createRadialGradient(32, 32, 1, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,214,140,0.6)');
  gr.addColorStop(0.4, 'rgba(255,190,110,0.22)');
  gr.addColorStop(1, 'rgba(255,190,100,0)');
  glow.g.fillStyle = gr;
  glow.g.fillRect(0, 0, 64, 64);

  return {
    lamp, tlight, hydrant, trash, mailbox, news, bench, carts, subway, steam, cone, flagUS, flags, planter, tables,
    statueB, statueG, rock, link, bush, trees, autumn, cherry, street, pine: pineT, dogs: dogs.c, pigeons: pig.c, glow: glow.c,
  };
}

export type Props = ReturnType<typeof buildProps>;

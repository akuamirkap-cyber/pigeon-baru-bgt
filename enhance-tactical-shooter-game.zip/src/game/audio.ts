export type SfxName =
  | "pistol" | "shotgun" | "sniper" | "bazooka" | "slash" | "whoosh" | "thunk" | "hit" | "hurt" | "ko" | "boom"
  | "squish" | "roar" | "beep" | "pod" | "groan" | "bark" | "crack" | "thunder" | "alarm" | "ping" | "heart" | "screech" | "rumble" | "reload" | "dash" | "deflect" | "start" | "win" | "lose" | "click" | "wall" | "pick" | "tick" | "engine" | "bite" | "step" | "door" | "ak47" | "goldgun" | "magout" | "magin" | "rack" | "shellin" | "pump" | "shell";

/** Tiny chiptune-style sound kit, everything is synthesized with WebAudio. */
class SoundKit {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  /** reverb send: shots get a tail off the buildings, voices get distance */
  private verb: GainNode | null = null;
  /** the last stage before the speakers (music goes straight here, past the SFX volume) */
  private out: AudioNode | null = null;
  private last: Partial<Record<SfxName, number>> = {};
  muted = false;

  unlock() {
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.32;
        // a compressor glues the layers together and keeps loud moments punchy instead of clipping
        const comp = this.ctx.createDynamicsCompressor();
        comp.threshold.value = -16; comp.knee.value = 18; comp.ratio.value = 5; comp.attack.value = 0.002; comp.release.value = 0.18;
        this.master.connect(comp);
        comp.connect(this.ctx.destination);
        this.out = comp;
        const len = Math.floor(this.ctx.sampleRate * 1.3), ir = this.ctx.createBuffer(2, len, this.ctx.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
          const q = ir.getChannelData(ch);
          for (let i = 0; i < len; i++) q[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6);
        }
        const conv = this.ctx.createConvolver();
        conv.buffer = ir;
        this.verb = this.ctx.createGain();
        this.verb.gain.value = 0.5;
        this.verb.connect(conv);
        conv.connect(this.master);
        const buf = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        this.noiseBuf = buf;
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  private amb: { drone: GainNode; wind: GainNode; rain: GainNode } | null = null;
  private ambLevel = -1;

  /** continuous low drone + wind for the alien planet (level 0 turns it off) */
  ambience(level: number, wind = 0.5, rain = 0) {
    if (!this.ctx || !this.master) return;
    const key = Math.round(level * 20) + Math.round(wind * 20) * 100 + Math.round(rain * 10) * 10000;
    if (key === this.ambLevel) return;
    this.ambLevel = key;
    try {
      const c = this.ctx, t = c.currentTime;
      if (!this.amb) {
        if (level <= 0) return;
        const drone = c.createGain(), wnd = c.createGain(), lp = c.createBiquadFilter(), bp = c.createBiquadFilter();
        drone.gain.value = 0; wnd.gain.value = 0;
        lp.type = "lowpass"; lp.frequency.value = 210;
        bp.type = "bandpass"; bp.frequency.value = 520; bp.Q.value = 0.6;
        for (const [type, f] of [["sine", 46], ["sawtooth", 69.4], ["sine", 92.5]] as [OscillatorType, number][]) {
          const o = c.createOscillator();
          o.type = type; o.frequency.value = f;
          o.connect(lp);
          o.start();
        }
        const lfo = c.createOscillator(), lg = c.createGain();
        lfo.frequency.value = 0.13; lg.gain.value = 70;
        lfo.connect(lg).connect(lp.frequency);
        lfo.start();
        lp.connect(drone).connect(this.master);
        const n = c.createBufferSource();
        n.buffer = this.noiseBuf; n.loop = true;
        const l2 = c.createOscillator(), g2 = c.createGain();
        l2.frequency.value = 0.21; g2.gain.value = 260;
        l2.connect(g2).connect(bp.frequency);
        l2.start();
        n.connect(bp).connect(wnd).connect(this.master);
        n.start();
        // rain hiss
        const rn = c.createGain(), hp = c.createBiquadFilter(), n2 = c.createBufferSource();
        rn.gain.value = 0;
        hp.type = "highpass"; hp.frequency.value = 2600;
        n2.buffer = this.noiseBuf; n2.loop = true;
        n2.connect(hp).connect(rn).connect(this.master);
        n2.start(0, 0.37);
        this.amb = { drone, wind: wnd, rain: rn };
      }
      this.amb.drone.gain.setTargetAtTime(level * 0.55, t, 0.4);
      this.amb.wind.gain.setTargetAtTime(level * wind * 0.5, t, 0.5);
      this.amb.rain.gain.setTargetAtTime(level > 0 ? Math.min(2, rain) * 0.15 : 0, t, 0.6);
    } catch {
      /* optional */
    }
  }

  // ───────── background music: one clock, two moods, cross-faded by how dangerous it is right now ─────────
  musicOn = false;
  private mBus: GainNode | null = null;
  private mNext = 0;
  private mStep = 0;

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.mBus && this.ctx) this.mBus.gain.setTargetAtTime(on ? 0.55 : 0, this.ctx.currentTime, 0.25);
  }

  private mTone(type: OscillatorType, f: number, at: number, dur: number, vol: number, atk: number, lp = 0, f1 = f) {
    const c = this.ctx!, o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, at);
    if (f1 !== f) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), at + dur);
    g.gain.setValueAtTime(0.0001, at);
    g.gain.linearRampToValueAtTime(Math.max(0.0002, vol), at + Math.max(0.004, atk));
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    if (lp) {
      const q = c.createBiquadFilter();
      q.type = "lowpass";
      q.frequency.value = lp;
      o.connect(q).connect(g);
    } else o.connect(g);
    g.connect(this.mBus!);
    o.start(at);
    o.stop(at + dur + 0.05);
  }

  private mHat(at: number, vol: number, dur = 0.04) {
    const c = this.ctx!, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    f.type = "highpass";
    f.frequency.value = 6000;
    g.gain.setValueAtTime(Math.max(0.0002, vol), at);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    s.connect(f).connect(g).connect(this.mBus!);
    s.start(at, Math.random() * 0.5);
    s.stop(at + dur + 0.03);
  }

  /** one sixteenth note of the tune. T = tension 0..1 */
  private mNote(step: number, at: number, T: number) {
    const hz = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
    const bar = (step >> 4) & 3, s = step & 15, calm = 1 - T, beat = 60 / (72 + 56 * T);
    const ROOT = [57, 53, 48, 55]; // A minor - F - C - G
    const tri = [0, bar === 0 ? 3 : 4, 7];
    if (calm > 0.06) {
      // safe: slow warm chords, a bass note under them, a few notes picked out on top, now and then a bell
      if (s === 0) {
        for (const iv of tri) this.mTone("sine", hz(ROOT[bar] + iv), at, beat * 4.2, 0.1 * calm, beat * 0.9);
        this.mTone("triangle", hz(ROOT[bar] - 12), at, beat * 3.6, 0.12 * calm, 0.08);
      }
      if (s % 4 === 2 || s === 12) this.mTone("triangle", hz(ROOT[bar] + 12 + tri[(s >> 2) % 3]), at, beat * 1.6, 0.085 * calm, 0.02);
      if (s === 8 && bar & 1) this.mTone("sine", hz(ROOT[bar] + 31), at, beat * 2.4, 0.05 * calm, 0.05);
    }
    if (T > 0.08) {
      // danger: a pulsing bass, a kick on every beat, hats and a snare as it gets worse, two notes a semitone apart grinding underneath
      const rt = [45, 45, 41, 43][bar];
      if (s % 2 === 0) this.mTone("sawtooth", hz(rt + (s === 14 ? 3 : 0)), at, beat * 0.42, 0.2 * T, 0.005, 260 + 500 * T);
      if (s % 4 === 0) this.mTone("sine", 125, at, 0.17, 0.5 * T, 0.004, 0, 40);
      if (T > 0.35 && s % 4 === 2) this.mHat(at, 0.07 * T);
      if (T > 0.6 && s % 2 === 1) this.mHat(at, 0.035 * T, 0.02);
      if (T > 0.55 && (s === 4 || s === 12)) {
        this.mHat(at, 0.14 * T, 0.11);
        this.mTone("triangle", 190, at, 0.09, 0.16 * T, 0.003, 0, 110);
      }
      if (s === 0 && !(bar & 1)) {
        this.mTone("sawtooth", hz(rt + 12), at, beat * 8, 0.045 * T, beat * 2, 700);
        this.mTone("sawtooth", hz(rt + 13), at, beat * 8, 0.04 * T, beat * 2, 700);
      }
      if (T > 0.75 && s % 8 === 6) this.mTone("square", hz(rt + 24 + [0, 3, 6, 1][bar]), at, beat * 0.3, 0.05 * T, 0.004, 1800);
    }
  }

  /** call every frame. tension: 0 = safe and quiet, 1 = they are on you. Does nothing until the music has been switched on. */
  music(tension: number) {
    const c = this.ctx;
    if (!c || !this.out || !this.noiseBuf) return;
    if (!this.mBus) {
      this.mBus = c.createGain();
      this.mBus.gain.value = this.musicOn ? 0.55 : 0;
      this.mBus.connect(this.out); // not through the SFX volume: muting the effects leaves the music alone
    }
    if (!this.musicOn) { this.mNext = 0; return; }
    const t = c.currentTime, T = tension < 0 ? 0 : tension > 1 ? 1 : tension;
    if (this.mNext < t - 0.4) this.mNext = t + 0.05;
    try {
      for (let guard = 0; this.mNext < t + 0.2 && guard < 8; guard++) {
        this.mNote(this.mStep++, this.mNext, T);
        this.mNext += 60 / (72 + 56 * T) / 4;
      }
    } catch {
      /* optional */
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.32;
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0, wet = 0) {
    const c = this.ctx!, t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master!);
    if (wet > 0 && this.verb) { const w = c.createGain(); w.gain.value = wet; g.connect(w).connect(this.verb); }
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(ftype: BiquadFilterType, f0: number, f1: number, dur: number, vol: number, delay = 0, wet = 0) {
    const c = this.ctx!, t = c.currentTime + delay;
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    s.loop = true;
    f.type = ftype;
    f.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(this.master!);
    if (wet > 0 && this.verb) { const w = c.createGain(); w.gain.value = wet; g.connect(w).connect(this.verb); }
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }

  /** a throat: detuned saws through a formant filter, roughened by a fast flutter - groans, roars, barks */
  private voice(f0: number, f1: number, dur: number, vol: number, formant: number, rough = 30, delay = 0, wet = 0.3) {
    const c = this.ctx!, t = c.currentTime + delay;
    const g = c.createGain(), bp = c.createBiquadFilter(), lp = c.createBiquadFilter(), am = c.createGain(), mix = c.createGain();
    bp.type = "bandpass"; bp.Q.value = 2.2;
    bp.frequency.setValueAtTime(formant, t);
    bp.frequency.linearRampToValueAtTime(formant * 0.7, t + dur);
    lp.type = "lowpass"; lp.frequency.value = formant * 2.4;
    for (const det of [1, 1.012, 0.5]) {
      const o = c.createOscillator();
      o.type = "sawtooth";
      o.frequency.setValueAtTime(f0 * det, t);
      o.frequency.linearRampToValueAtTime(Math.max(20, f1 * det), t + dur);
      o.connect(am);
      o.start(t);
      o.stop(t + dur + 0.05);
    }
    const l = c.createOscillator(), lg = c.createGain();
    l.type = "square"; l.frequency.value = rough * (0.85 + Math.random() * 0.3);
    lg.gain.value = 0.45; am.gain.value = 0.6;
    l.connect(lg).connect(am.gain);
    l.start(t);
    l.stop(t + dur + 0.05);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t + Math.min(0.08, dur * 0.3));
    g.gain.setValueAtTime(Math.max(0.001, vol), t + dur * 0.6);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    mix.gain.value = 0.5;
    am.connect(bp).connect(g);
    am.connect(lp).connect(mix).connect(g);
    g.connect(this.master!);
    if (wet > 0 && this.verb) { const w = c.createGain(); w.gain.value = wet; g.connect(w).connect(this.verb); }
  }

  /** layered, slightly randomised sounds for guns, blows and the dead; returns false for everything it does not cover */
  private rich(name: SfxName, v: number): boolean {
    const r = 0.93 + Math.random() * 0.14;
    switch (name) {
      case "pistol":
        this.noise("highpass", 3200 * r, 1400, 0.045, 0.6 * v);          // crack
        this.noise("bandpass", 1100 * r, 320, 0.13, 0.55 * v, 0, 0.35);  // body, into the room
        this.tone("sine", 210 * r, 55, 0.1, 0.6 * v);                    // thump
        this.tone("square", 2600, 1500, 0.012, 0.12 * v, 0.05);          // slide
        return true;
      case "ak47":
        this.noise("highpass", 2600 * r, 1100, 0.05, 0.6 * v);
        this.noise("bandpass", 800 * r, 240, 0.16, 0.7 * v, 0, 0.4);
        this.tone("sine", 150 * r, 48, 0.12, 0.85 * v);
        this.tone("square", 1900, 900, 0.015, 0.14 * v, 0.03); // the bolt slamming back
        return true;
      case "goldgun":
        this.noise("highpass", 3600 * r, 1500, 0.05, 0.75 * v);
        this.noise("lowpass", 3000 * r, 180, 0.42, 0.95 * v, 0, 0.6);
        this.tone("sine", 190 * r, 34, 0.34, 1.0 * v);
        this.tone("triangle", 2400, 1700, 0.22, 0.1 * v, 0.02, 0.5); // it rings like a bell
        this.tone("triangle", 3200, 2600, 0.3, 0.06 * v, 0.03, 0.5);
        return true;
      case "magout":
        this.noise("bandpass", 1900, 1500, 0.03, 0.34 * v);
        this.tone("square", 1200, 800, 0.02, 0.12 * v, 0.01);
        this.noise("lowpass", 600, 300, 0.05, 0.2 * v, 0.03);
        return true;
      case "magin":
        this.tone("sine", 220, 140, 0.05, 0.42 * v);
        this.noise("bandpass", 1400, 1100, 0.035, 0.38 * v);
        this.tone("square", 900, 700, 0.02, 0.14 * v, 0.02);
        return true;
      case "rack":
        this.noise("bandpass", 2500, 2000, 0.03, 0.36 * v);
        this.noise("bandpass", 1700, 1400, 0.04, 0.36 * v, 0.07);
        this.tone("square", 2000, 1400, 0.02, 0.14 * v, 0.07);
        return true;
      case "shellin":
        this.noise("bandpass", 1300, 1000, 0.03, 0.32 * v);
        this.tone("square", 700 * r, 500, 0.025, 0.14 * v);
        this.tone("sine", 180, 120, 0.04, 0.26 * v);
        return true;
      case "pump":
        this.noise("bandpass", 1500, 1300, 0.04, 0.36 * v);
        this.noise("bandpass", 2300, 1900, 0.05, 0.4 * v, 0.1);
        this.tone("sine", 160, 90, 0.05, 0.3 * v, 0.1);
        return true;
      case "shell":
        this.tone("triangle", 4200 * r, 3400, 0.05, 0.1 * v);
        this.tone("triangle", 5600 * r, 5000, 0.03, 0.05 * v, 0.02);
        return true;
      case "shotgun":
        this.noise("highpass", 2800 * r, 1200, 0.06, 0.75 * v);
        this.noise("lowpass", 3800 * r, 130, 0.5, 1.15 * v, 0, 0.7);
        this.tone("sine", 105 * r, 26, 0.42, 1.2 * v);
        this.tone("sawtooth", 170, 36, 0.18, 0.4 * v);
        this.noise("lowpass", 900, 150, 0.4, 0.3 * v, 0.12, 0.7); // the boom rolls back off the walls
        this.noise("bandpass", 1500, 1300, 0.035, 0.24 * v, 0.26); // the pump: ch-
        this.noise("bandpass", 2300, 1900, 0.045, 0.28 * v, 0.36); // -chk
        return true;
      case "sniper":
        this.noise("highpass", 5200 * r, 2200, 0.04, 0.8 * v);
        this.noise("lowpass", 5200 * r, 140, 0.55, 1.0 * v, 0, 0.7);
        this.tone("sine", 170 * r, 26, 0.5, 1.0 * v);
        this.tone("square", 1800, 240, 0.05, 0.2 * v);
        this.noise("lowpass", 1400, 200, 0.3, 0.3 * v, 0.14, 0.6);       // the echo comes back off the buildings
        this.noise("lowpass", 900, 160, 0.34, 0.16 * v, 0.33, 0.6);
        return true;
      case "bazooka":
        this.noise("bandpass", 320, 2200, 0.4, 0.7 * v, 0, 0.3);
        this.tone("sawtooth", 95 * r, 48, 0.32, 0.6 * v);
        this.noise("highpass", 2800, 5200, 0.3, 0.25 * v, 0.03);
        return true;
      case "boom":
        this.noise("lowpass", 1500, 50, 0.95, 1.2 * v, 0, 0.8);
        this.tone("sine", 80 * r, 22, 0.85, 1.2 * v);
        this.tone("sawtooth", 130, 30, 0.3, 0.5 * v);
        this.noise("highpass", 3000, 900, 0.12, 0.6 * v);
        for (let i = 0; i < 4; i++) this.noise("bandpass", 900 + Math.random() * 1800, 300, 0.07, 0.22 * v, 0.18 + i * 0.09 + Math.random() * 0.05); // debris raining down
        return true;
      case "slash":
        this.noise("bandpass", 2400 * r, 7200, 0.11, 0.42 * v);
        this.noise("highpass", 6000, 9000, 0.07, 0.2 * v, 0.02);
        this.tone("triangle", 2700 * r, 1900, 0.09, 0.07 * v, 0.02);
        return true;
      case "whoosh":
        this.noise("bandpass", 420 * r, 1700, 0.2, 0.6 * v);
        this.noise("lowpass", 300, 900, 0.16, 0.3 * v, 0.02);
        return true;
      case "thunk":
        this.tone("sine", 160 * r, 42, 0.16, 1.0 * v);
        this.noise("lowpass", 1000, 180, 0.09, 0.7 * v, 0, 0.25);
        this.tone("square", 950 * r, 280, 0.03, 0.22 * v);
        this.noise("bandpass", 600, 200, 0.12, 0.3 * v, 0.02);
        return true;
      case "hit":
        this.noise("lowpass", 1500 * r, 260, 0.07, 0.55 * v);
        this.tone("sine", 190 * r, 80, 0.07, 0.4 * v);
        this.noise("bandpass", 700, 300, 0.05, 0.25 * v, 0.02);
        return true;
      case "squish":
        this.noise("bandpass", 800 * r, 180, 0.18, 0.7 * v);
        this.tone("sawtooth", 130 * r, 45, 0.16, 0.3 * v);
        this.noise("highpass", 2400, 1200, 0.05, 0.25 * v, 0.05);
        this.noise("lowpass", 500, 150, 0.12, 0.35 * v, 0.08);
        return true;
      case "crack":
        this.tone("square", 1900 * r, 180, 0.05, 0.35 * v);
        this.noise("highpass", 3200, 1500, 0.04, 0.5 * v);
        this.noise("bandpass", 700, 200, 0.16, 0.5 * v, 0.03);
        this.tone("sine", 140, 50, 0.12, 0.5 * v);
        return true;
      case "bite":
        this.noise("bandpass", 950 * r, 240, 0.1, 0.7 * v);
        this.tone("square", 320 * r, 90, 0.06, 0.3 * v);
        this.noise("highpass", 2600, 1400, 0.04, 0.3 * v, 0.03);
        this.voice(150 * r, 90, 0.22, 0.4 * v, 700, 40, 0.02, 0.2);
        return true;
      case "groan":
        this.voice(92 * r, 62 * r, 0.75 + Math.random() * 0.4, 0.5 * v, 520 + Math.random() * 260, 24);
        this.noise("bandpass", 700, 400, 0.5, 0.08 * v, 0.05);
        return true;
      case "roar":
        this.voice(84 * r, 40, 1.15, 0.95 * v, 430, 34, 0, 0.6);
        this.voice(126 * r, 60, 0.9, 0.4 * v, 900, 46, 0.04, 0.5);
        this.noise("lowpass", 900, 200, 0.9, 0.3 * v, 0, 0.5);
        return true;
      case "bark":
        this.voice(330 * r, 170, 0.1, 0.7 * v, 1150, 60, 0, 0.25);
        this.voice(300 * r, 150, 0.12, 0.6 * v, 1000, 60, 0.15, 0.25);
        this.noise("bandpass", 1600, 700, 0.08, 0.2 * v);
        return true;
      case "wall":
        this.noise("highpass", 2600 * r, 900, 0.05, 0.3 * v);
        this.tone("triangle", 1700 * r, 600, 0.05, 0.12 * v);
        return true;
      case "reload":
        this.noise("bandpass", 1900, 1700, 0.03, 0.3 * v);               // magazine out
        this.tone("square", 1300, 900, 0.02, 0.12 * v, 0.01);
        this.noise("bandpass", 1300, 1100, 0.035, 0.28 * v, 0.16);       // magazine in
        this.tone("square", 2100, 1500, 0.02, 0.14 * v, 0.3);            // bolt
        this.noise("bandpass", 2600, 2200, 0.03, 0.3 * v, 0.3);
        return true;
      case "step":
        this.noise("lowpass", 520 * r, 180, 0.045, 0.16 * v);
        return true;
      case "door":
        this.tone("sine", 140, 60, 0.12, 0.7 * v);
        this.noise("lowpass", 900, 200, 0.08, 0.5 * v, 0, 0.3);
        return true;
      case "engine":
        this.voice(46, 100, 1.9, 0.8 * v, 300, 21, 0.15, 0.3);
        this.noise("lowpass", 280, 760, 1.8, 0.3 * v, 0.15);
        this.tone("square", 70, 150, 1.7, 0.12 * v, 0.2);
        return true;
    }
    return false;
  }

  play(name: SfxName, v = 1) {
    if (!this.ctx || !this.master || this.muted || v < 0.03) return;
    const now = performance.now();
    if (now - (this.last[name] ?? 0) < 35) return;
    this.last[name] = now;
    try {
      if (this.rich(name, v)) return;
      switch (name) {
        case "pistol":
          this.noise("highpass", 1800, 900, 0.07, 0.5 * v);
          this.tone("square", 560, 170, 0.07, 0.3 * v);
          break;
        case "shotgun":
          this.noise("lowpass", 2600, 300, 0.24, 0.9 * v);
          this.tone("sawtooth", 170, 45, 0.16, 0.5 * v);
          break;
        case "sniper":
          this.noise("lowpass", 4500, 200, 0.4, 1.0 * v);
          this.tone("triangle", 260, 36, 0.32, 0.8 * v);
          this.tone("square", 1500, 300, 0.06, 0.2 * v);
          break;
        case "bazooka":
          this.noise("bandpass", 300, 2400, 0.35, 0.9 * v);
          this.tone("sawtooth", 120, 420, 0.3, 0.4 * v);
          this.tone("sine", 90, 40, 0.2, 0.7 * v);
          break;
        case "crack":
          this.noise("highpass", 2200, 900, 0.06, 0.6 * v);
          this.tone("square", 220, 70, 0.09, 0.5 * v);
          this.noise("lowpass", 700, 200, 0.14, 0.6 * v);
          break;
        case "bark":
          this.tone("sawtooth", 430, 170, 0.08, 0.4 * v);
          this.tone("square", 310, 130, 0.08, 0.25 * v, 0.1);
          this.noise("bandpass", 900, 500, 0.09, 0.3 * v);
          break;
        case "groan":
          this.tone("sawtooth", 92 + Math.random() * 44, 60, 0.5, 0.3 * v);
          this.tone("square", 138, 86, 0.42, 0.11 * v, 0.04);
          this.noise("bandpass", 420, 250, 0.45, 0.2 * v);
          break;
        case "thunder":
          this.noise("lowpass", 420, 60, 1.5, 1.1 * v);
          this.tone("sine", 58, 30, 1.1, 0.9 * v);
          this.noise("lowpass", 2400, 300, 0.25, 0.5 * v);
          break;
        case "alarm":
          for (let i = 0; i < 3; i++) {
            this.tone("square", 640, 640, 0.15, 0.2 * v, i * 0.36);
            this.tone("square", 470, 470, 0.15, 0.2 * v, i * 0.36 + 0.18);
          }
          break;
        case "ping":
          this.tone("sine", 1760, 1700, 0.07, 0.3 * v);
          this.tone("sine", 1760, 1700, 0.07, 0.11 * v, 0.1);
          break;
        case "heart":
          this.tone("sine", 74, 44, 0.1, 1.0 * v);
          this.tone("sine", 64, 40, 0.1, 0.8 * v, 0.17);
          break;
        case "screech":
          this.tone("sawtooth", 950, 2300, 0.2, 0.22 * v);
          this.tone("square", 1400, 700, 0.16, 0.12 * v, 0.05);
          this.noise("bandpass", 3200, 5200, 0.22, 0.3 * v);
          break;
        case "rumble":
          this.noise("lowpass", 190, 80, 0.6, 1.1 * v);
          this.tone("sine", 48, 34, 0.55, 0.8 * v);
          break;
        case "squish":
          this.noise("lowpass", 900, 200, 0.1, 0.5 * v);
          this.tone("sine", 320, 90, 0.09, 0.35 * v);
          break;
        case "roar":
          this.tone("sawtooth", 70, 150, 0.5, 0.6 * v);
          this.tone("square", 52, 96, 0.5, 0.35 * v);
          this.noise("bandpass", 300, 900, 0.5, 0.4 * v);
          break;
        case "beep":
          this.tone("square", 1250, 1250, 0.07, 0.25 * v);
          break;
        case "pod":
          this.noise("lowpass", 3000, 150, 0.35, 0.9 * v);
          this.tone("sine", 140, 40, 0.3, 0.9 * v);
          break;
        case "slash":
          this.noise("bandpass", 2500, 7000, 0.09, 0.45 * v);
          break;
        case "whoosh":
          this.noise("bandpass", 500, 1800, 0.16, 0.5 * v);
          break;
        case "thunk":
          this.noise("lowpass", 1100, 200, 0.12, 0.8 * v);
          this.tone("sine", 210, 70, 0.12, 0.8 * v);
          break;
        case "hit":
          this.tone("square", 340, 140, 0.05, 0.28 * v);
          break;
        case "hurt":
          this.tone("sawtooth", 200, 70, 0.14, 0.45 * v);
          break;
        case "ko":
          this.tone("triangle", 780, 780, 0.07, 0.5 * v);
          this.tone("triangle", 590, 590, 0.07, 0.5 * v, 0.07);
          this.tone("triangle", 390, 300, 0.14, 0.5 * v, 0.14);
          break;
        case "boom":
          this.noise("lowpass", 1400, 60, 0.6, 1.2 * v);
          this.tone("sine", 100, 28, 0.45, 1.0 * v);
          break;
        case "reload":
          this.tone("square", 950, 950, 0.025, 0.2 * v);
          this.tone("square", 1300, 1300, 0.025, 0.2 * v, 0.09);
          break;
        case "dash":
          this.noise("bandpass", 700, 2600, 0.13, 0.35 * v);
          break;
        case "deflect":
          this.tone("square", 1300, 2200, 0.09, 0.4 * v);
          this.tone("triangle", 2600, 2600, 0.12, 0.3 * v, 0.03);
          break;
        case "start":
          [440, 554, 659, 880].forEach((f, i) => this.tone("square", f, f, 0.09, 0.3 * v, i * 0.08));
          break;
        case "win":
          [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone("square", f, f, 0.12, 0.3 * v, i * 0.1));
          break;
        case "lose":
          [440, 370, 311, 233].forEach((f, i) => this.tone("triangle", f, f * 0.97, 0.16, 0.45 * v, i * 0.14));
          break;
        case "click":
          this.tone("square", 720, 900, 0.04, 0.22 * v);
          break;
        case "wall":
          this.noise("highpass", 3000, 3000, 0.03, 0.14 * v);
          break;
        case "pick":
          this.tone("square", 660, 660, 0.06, 0.3 * v);
          this.tone("square", 990, 990, 0.09, 0.3 * v, 0.06);
          break;
        case "tick":
          this.tone("square", 520, 520, 0.06, 0.3 * v);
          break;
      }
    } catch {
      /* audio is optional */
    }
  }
}

export const audio = new SoundKit();

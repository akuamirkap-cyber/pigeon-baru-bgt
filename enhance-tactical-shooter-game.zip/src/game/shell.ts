import { TILE } from "./defs";
import { BUILDINGS, HOUSES, MW } from "./map";

/**
 * Buildings as boxes standing on the ground. They are seen from above the camera target, so they lean away from it:
 * the walls that face you rise from the pavement to the roof, storey over storey, and slide as you walk past.
 */
type Cv = HTMLCanvasElement;
type Ctx = CanvasRenderingContext2D;
export interface Shell {
  /** the footprint on the ground (world px) */
  x: number; y: number; w: number; h: number;
  floors: number; house: number; shop: boolean;
  /** where the roof comes from (same world coordinates), wall colours */
  tex: Cv; wall: string; dark: string; seed: number;
  /** side: 0 north, 1 east, 2 south, 3 west; u = where along that wall; key = its tile */
  doors: { side: number; u: number; key: number }[];
  /** this frame: opacity (own, and as drawn), see-through because the camera target is behind it, footprint and roof on screen */
  a: number; base: number; ghost: boolean; gx: number; gy: number; rx: number; ry: number; rw: number; rh: number;
}
export interface StoreyInfo { squad: number; civ: number; sos: boolean; dead: number }
export interface ShellOpt { day: number; shut: (key: number) => boolean; storey: (house: number, lvl: number) => StoreyInfo | null }

const INK = "#0b0b10";
const HOUSE_COL: Record<number, string[]> = { 5: ["#8a4a3c", "#4a241c"], 6: ["#7d8c9a", "#3f4a56"], 7: ["#a8946a", "#5c4f34"], 8: ["#4f6a8a", "#263a50"] };
const BLOCK_COL: string[][] = [["#8a4a3c", "#4a241c"], ["#555866", "#2a2c36"], ["#555866", "#2a2c36"], ["#a39a80", "#5c563f"], ["#3f6a8a", "#1f3a50"]];
/** how much shade a wall is in, by the way it faces: at dawn the sun is in the east; at night only the street light from the south side */
const DAY_SH = [0.36, 0, 0.1, 0.42], NIGHT_SH = [0.4, 0.24, 0.1, 0.24];
const hs = (a: number, b: number, c: number) => {
  let n = Math.imul(a + 11, 374761393) ^ Math.imul(b + 7, 668265263) ^ Math.imul(c + 3, 982451653);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
};

/** every building of the loaded city: the houses you can enter (their roofs) and the solid blocks (their tops) */
export function buildShells(walls: Cv, roofs: Cv): Shell[] {
  const out: Shell[] = [];
  const mk = (x: number, y: number, w: number, h: number, floors: number, house: number, shop: boolean, tex: Cv, c: string[], seed: number): Shell => ({
    x: x * TILE, y: y * TILE, w: w * TILE, h: h * TILE, floors, house, shop, tex, wall: c[0], dark: c[1], seed, doors: [],
    a: 0, base: 0, ghost: false, gx: 0, gy: 0, rx: 0, ry: 0, rw: 0, rh: 0,
  });
  HOUSES.forEach((H, i) => {
    if (H.under !== undefined) return;
    const s = mk(H.x, H.y, H.w, H.h, H.shop ? 1.5 : H.floors ? H.floors.length : 1, i, H.shop, roofs, HOUSE_COL[H.style] ?? HOUSE_COL[5], i * 7 + 3);
    for (const d of H.doors) s.doors.push({ side: d.oy === -1 ? 0 : d.ox === 1 ? 1 : d.oy === 1 ? 2 : 3, u: d.oy ? (d.tx + 0.5 - H.x) / H.w : (d.ty + 0.5 - H.y) / H.h, key: d.ty * MW + d.tx });
    out.push(s);
  });
  BUILDINGS.forEach((b, i) => out.push(mk(b.x, b.y, b.w, b.h, 2 + ((b.x * 7 + b.y * 13 + b.style) % 3), -1, false, walls, BLOCK_COL[b.style] ?? BLOCK_COL[2], i * 11 + 5)));
  return out;
}

/** where the roof is on screen, seen from above the point (vx, vy): pushed away from it in proportion to the height, and lifted a little to the north */
export function project(s: Shell, vx: number, vy: number, cl: number, ct: number) {
  const k = 1 + 0.065 * s.floors, lift = Math.min(26, 7 * s.floors);
  s.gx = s.x - cl; s.gy = s.y - ct;
  s.rx = vx + (s.gx - vx) * k; s.ry = vy + (s.gy - vy) * k - lift; s.rw = s.w * k; s.rh = s.h * k;
}

type FaceFn = (side: number, ax: number, ay: number, bx: number, by: number, a2x: number, a2y: number, b2x: number, b2y: number) => void;
/** the walls that face the viewer: ground edge A-B, roof edge A2-B2 */
export function eachFace(s: Shell, fn: FaceFn) {
  const gx = s.gx, gy = s.gy, gr = gx + s.w, gb = gy + s.h, rx = s.rx, ry = s.ry, rr = rx + s.rw, rb = ry + s.rh;
  if (ry > gy + 0.5) fn(0, gx, gy, gr, gy, rx, ry, rr, ry);
  if (rr < gr - 0.5) fn(1, gr, gy, gr, gb, rr, ry, rr, rb);
  if (rb < gb - 0.5) fn(2, gx, gb, gr, gb, rx, rb, rr, rb);
  if (rx > gx + 0.5) fn(3, gx, gy, gx, gb, rx, ry, rx, rb);
}

/** is this point of the ground (screen px) hidden by the building - under its roof, or behind one of the walls that face you? */
export function covers(s: Shell, px: number, py: number): boolean {
  const gx = s.gx, gy = s.gy, gr = gx + s.w, gb = gy + s.h, rx = s.rx, ry = s.ry, rr = rx + s.rw, rb = ry + s.rh;
  if (px >= rx && px <= rr && py >= ry && py <= rb) return true;
  if (rb < gb && py >= rb && py <= gb) { const t = (gb - py) / (gb - rb); if (px >= gx + (rx - gx) * t && px <= gr + (rr - gr) * t) return true; }
  if (ry > gy && py >= gy && py <= ry) { const t = (py - gy) / (ry - gy); if (px >= gx + (rx - gx) * t && px <= gr + (rr - gr) * t) return true; }
  if (rx > gx && px >= gx && px <= rx) { const t = (px - gx) / (rx - gx); if (py >= gy + (ry - gy) * t && py <= gb + (rb - gb) * t) return true; }
  if (rr < gr && px >= rr && px <= gr) { const t = (gr - px) / (gr - rr); if (py >= gy + (ry - gy) * t && py <= gb + (rb - gb) * t) return true; }
  return false;
}

/** the long shadow a building throws to the west when the sun is low in the east */
export function shellShadow(ctx: Ctx, s: Shell, day: number) {
  const a = Math.min(46, 11 * s.floors), b = a * 0.42, x = s.gx, y = s.gy, r = x + s.w, bt = y + s.h;
  ctx.fillStyle = `rgba(8,10,34,${(0.3 * day).toFixed(3)})`;
  ctx.beginPath();
  ctx.moveTo(r, y); ctx.lineTo(r, bt); ctx.lineTo(r - a, bt + b); ctx.lineTo(x - a, bt + b); ctx.lineTo(x - a, y + b); ctx.lineTo(x, y);
  ctx.closePath();
  ctx.fill();
}

/** one building: the walls that face you (storeys, windows - lit, dark, or with eyes in them -, doors under their awnings), then the roof */
export function drawShell(ctx: Ctx, s: Shell, o: ShellOpt) {
  if (s.a < 0.02) return;
  const F = Math.max(1, Math.floor(s.floors)), day = o.day > 0.5;
  const info: (StoreyInfo | null)[] | null = s.house >= 0 && s.floors >= 2 ? Array.from({ length: F }, (_v, f) => o.storey(s.house, f + 1)) : null;
  ctx.save();
  ctx.globalAlpha = s.a;
  ctx.lineWidth = 1;
  eachFace(s, (side, ax, ay, bx, by, a2x, a2y, b2x, b2y) => {
    const len = side % 2 ? s.h : s.w, hpx = Math.hypot(a2x - ax, a2y - ay), q = [0, 0];
    const P = (u: number, t: number) => {
      const x0 = ax + (bx - ax) * u, y0 = ay + (by - ay) * u, x1 = a2x + (b2x - a2x) * u, y1 = a2y + (b2y - a2y) * u;
      q[0] = x0 + (x1 - x0) * t; q[1] = y0 + (y1 - y0) * t;
    };
    const quad = (u0: number, t0: number, u1: number, t1: number) => {
      P(u0, t0); ctx.moveTo(q[0], q[1]); P(u1, t0); ctx.lineTo(q[0], q[1]); P(u1, t1); ctx.lineTo(q[0], q[1]); P(u0, t1); ctx.lineTo(q[0], q[1]); ctx.closePath();
    };
    const fill = (col: string, u0: number, t0: number, u1: number, t1: number) => { ctx.fillStyle = col; ctx.beginPath(); quad(u0, t0, u1, t1); ctx.fill(); };
    fill(s.wall, 0, 0, 1, 1);
    const sh = (day ? DAY_SH : NIGHT_SH)[side];
    if (sh > 0) fill(`rgba(6,8,24,${sh})`, 0, 0, 1, 1);
    else if (day) fill("rgba(255,200,130,0.18)", 0, 0, 1, 1); // the wall the sun is on
    if (hpx >= 3) {
      const top = s.shop ? 0.66 : 1; // (the mart: one tall storey with its sign above)
      ctx.strokeStyle = s.dark;
      ctx.beginPath();
      for (let f = 1; f <= F; f++) { P(0, (f / F) * top); ctx.moveTo(q[0], q[1]); P(1, (f / F) * top); ctx.lineTo(q[0], q[1]); }
      ctx.stroke();
      if (s.shop) { fill("#c0392b", 0.04, 0.7, 0.96, 0.95); fill("#e8604c", 0.04, 0.88, 0.96, 0.95); }
      if (hpx / F >= 3.5) {
        const n = Math.max(1, Math.round(len / 22));
        const isDoor = (f: number, i: number) => f === 0 && s.doors.some((d) => d.side === side && Math.abs((i + 0.5) / n - d.u) < 15 / len);
        const lit = (f: number, i: number) => {
          if (day) return false;
          const st = info ? info[f] : null;
          return (!!st && st.squad + st.civ > 0) || hs(s.seed + side, f, i) < 0.18; // your people are on this floor - or somebody left a light on
        };
        for (let pass = 0; pass < 2; pass++) {
          ctx.fillStyle = pass ? "#ffd86b" : day ? "#86a8c6" : "#141c2a";
          ctx.beginPath();
          for (let f = 0; f < F; f++)
            for (let i = 0; i < n; i++) {
              if (isDoor(f, i) || lit(f, i) !== !!pass) continue;
              quad((i + 0.24) / n, ((f + 0.3) / F) * top, (i + 0.76) / n, ((f + 0.8) / F) * top);
            }
          ctx.fill();
        }
        if (info) {
          // eyes in the dark windows: the dead are on that floor
          ctx.fillStyle = "#ff4a4a";
          for (let f = 0; f < F; f++) {
            const st = info[f];
            if (!st || !st.dead || st.squad + st.civ > 0) continue;
            for (let i = f % 2; i < n && i >> 1 < st.dead; i += 2) {
              P((i + 0.5) / n, ((f + 0.55) / F) * top);
              ctx.fillRect(Math.round(q[0]) - 1, Math.round(q[1]), 1, 1);
              ctx.fillRect(Math.round(q[0]) + 1, Math.round(q[1]), 1, 1);
            }
          }
        }
      }
      for (const d of s.doors) {
        if (d.side !== side) continue;
        const u0 = d.u - 7 / len, u1 = d.u + 7 / len, th = (0.82 / F) * top, shut = o.shut(d.key);
        fill(INK, u0 - 1.5 / len, 0, u1 + 1.5 / len, th + (0.04 / F) * top);
        fill(shut ? "#8a6844" : "#2a1c16", u0, 0, u1, th);
        if (shut) fill("#c9cdd9", u0, th * 0.42, u1, th * 0.56); // barred
        fill(s.shop ? "#c0392b" : "#f5c542", u0 - 4 / len, th, u1 + 4 / len, th + (0.14 / F) * top);
      }
    }
    ctx.strokeStyle = INK;
    ctx.beginPath();
    quad(0, 0, 1, 1);
    ctx.stroke();
  });
  const rx = Math.round(s.rx), ry = Math.round(s.ry), rw = Math.round(s.rw), rh = Math.round(s.rh);
  ctx.drawImage(s.tex, s.x, s.y, s.w, s.h, rx, ry, rw, rh);
  if (day) { ctx.fillStyle = "rgba(255,214,150,0.1)"; ctx.fillRect(rx, ry, rw, rh); }
  ctx.strokeStyle = INK;
  ctx.strokeRect(rx + 0.5, ry + 0.5, rw - 1, rh - 1);
  ctx.restore();
}

/** roofs and facing walls as screen polygons (they are in view even where the ground behind them is not) */
export function shellPolys(shells: Shell[]): number[][] {
  const out: number[][] = [];
  for (const s of shells) {
    if (s.a < 0.5) continue;
    out.push([s.rx, s.ry, s.rx + s.rw, s.ry, s.rx + s.rw, s.ry + s.rh, s.rx, s.ry + s.rh]);
    eachFace(s, (_side, ax, ay, bx, by, a2x, a2y, b2x, b2y) => out.push([ax, ay, bx, by, b2x, b2y, a2x, a2y]));
  }
  return out;
}

/** torches on walls: every stretch of a facing wall gets the light of whoever points a beam at it (or stands next to it) */
export function litWalls(shells: Shell[], torches: { x: number; y: number; aim: number; r: number }[], cl: number, ct: number, cb: (q: number[], a: number) => void) {
  for (const s of shells) {
    if (s.a < 0.9) continue;
    eachFace(s, (_side, ax, ay, bx, by, a2x, a2y, b2x, b2y) => {
      const n = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay) / 24));
      for (let i = 0; i < n; i++) {
        const u0 = i / n, u1 = (i + 1) / n, um = (u0 + u1) / 2, mx = ax + (bx - ax) * um + cl, my = ay + (by - ay) * um + ct;
        let a = 0;
        for (const t of torches) {
          const dx = mx - t.x, dy = my - t.y, d = Math.hypot(dx, dy);
          if (d > t.r) continue;
          const da = Math.abs(((Math.atan2(dy, dx) - t.aim + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
          a = Math.max(a, d < 60 ? (1 - d / 60) * 0.7 : 0, da < 0.5 ? (1 - d / t.r) * (1 - da / 0.5) * 0.95 : 0);
        }
        if (a < 0.04) continue;
        cb([ax + (bx - ax) * u0, ay + (by - ay) * u0, ax + (bx - ax) * u1, ay + (by - ay) * u1, a2x + (b2x - a2x) * u1, a2y + (b2y - a2y) * u1, a2x + (b2x - a2x) * u0, a2y + (b2y - a2y) * u0], a);
      }
    });
  }
}

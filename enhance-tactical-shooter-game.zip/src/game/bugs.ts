import { isBat, isGun } from "./defs";
import type { WeaponId as WId } from "./defs";
import { TILE, WEAPONS, WEAPON_ORDER } from "./defs";
import type { BugKind, Hurt, WeaponDef, WeatherId } from "./defs";
import { CH, CRATES, HOUSES, MH, MW, NESTS, PAD, SPAWNS, TRUCK, zoneAt, blockAt, findPath, houseAtPx, kindAt, los, portalAt, roomAtPx, solidAt, walkClear, put, styleAt, WINDOWS } from "./map";
import type { Win } from "./map";
import { zombieSprites } from "./city";
import { drawText } from "./sprites";
import type { Bullet, Fighter, Game, Sortable } from "./engine";
import type { Atmosphere, Weather } from "./atmo";
import { nyEntrances, nyGoals, nyRoad } from "./nyc";

const STRAT_CD = [16, 34];
/** a subway station (one tiled hall, open tunnels): it cannot be barred */
const isStation = (H: { shop: boolean; rooms: { type: number }[] }) => !H.shop && H.rooms.length === 1 && H.rooms[0].type === 6;
/** how often a zombie that was shot dead still convulses on the floor: 0.4 % */
const SPASM_CHANCE = 0.004;
const POD_T = 0.5;
const SEARCH_T = 0.85;
/** the three things needed to call the evac helicopter */
export const ITEMS = [
  { name: "BATERAI", col: "#5ff0e0" },
  { name: "BENSIN", col: "#ff6b7a" },
  { name: "SUAR", col: "#ffb347" },
];
const GOAL = ["GELEDAH RUMAH BERTANDA", "KEMBALI KE ZONA EVAC", "BERTAHAN SAMPAI HELI TIBA", "NAIK HELIKOPTER!"];

export const BUG: Record<BugKind, { name: string; hp: number; speed: number; dmg: number; r: number; cd: number; mass: number; heart: number }> = {
  scav: { name: "ZOMBIE", hp: 45, speed: 46, dmg: 11, r: 5, cd: 0.7, mass: 1, heart: 0.05 },
  warrior: { name: "PELARI", hp: 55, speed: 86, dmg: 13, r: 5, cd: 0.6, mass: 1.2, heart: 0.1 },
  spitter: { name: "PEMUNTAH", hp: 80, speed: 46, dmg: 14, r: 6, cd: 2.2, mass: 1.6, heart: 0.12 },
  charger: { name: "BRUTAL", hp: 480, speed: 42, dmg: 36, r: 9, cd: 3.2, mass: 12, heart: 1 },
  titan: { name: "MUTAN", hp: 3000, speed: 30, dmg: 30, r: 15, cd: 1.6, mass: 1e6, heart: 1 },
  dog: { name: "ANJING", hp: 34, speed: 112, dmg: 14, r: 6, cd: 1.1, mass: 0.8, heart: 0.05 },
  tank: { name: "TANK", hp: 3200, speed: 92, dmg: 30, r: 11, cd: 1.1, mass: 30, heart: 1 },
};

/** eyes that glow in the dark: [pixel colour, tint key] */
const EYE: Record<BugKind, [string, string]> = {
  scav: ["#ffe9a0", "w"], warrior: ["#ff4a4a", "r"], spitter: ["#c8ff4a", "g"], charger: ["#ff4a4a", "r"], titan: ["#c8ff4a", "g"], dog: ["#ff4a4a", "r"], tank: ["#ff4a4a", "r"],
};

/** the night gets nastier as the mission goes on */
const SKY: Weather[] = [
  { dark: 0.7, fog: 0.28, rain: 0, bolt: 0.02, name: "MALAM" },
  { dark: 0.77, fog: 0.55, rain: 0, bolt: 0.04, name: "BERKABUT" },
  { dark: 0.8, fog: 0.4, rain: 1, bolt: 0.2, name: "HUJAN BADAI" },
  { dark: 0.84, fog: 0.95, rain: 0.3, bolt: 0.06, name: "KABUT TEBAL" },
  { dark: 0.85, fog: 0.6, rain: 1.8, bolt: 0.42, name: "BADAI PETIR" },
];
/** weather locked from the menu */
const FIXED: Record<Exclude<WeatherId, "auto">, Weather> = {
  rain: { dark: 0.86, fog: 0.5, rain: 2, bolt: 0.5, name: "HUJAN DERAS" },
  fog: { dark: 0.82, fog: 1.1, rain: 0, bolt: 0.03, name: "KABUT TEBAL" },
  clear: { dark: 0.6, fog: 0.08, rain: 0, bolt: 0, name: "MALAM CERAH" },
  day: { dark: 0.14, fog: 0.1, rain: 0, bolt: 0, name: "PAGI HARI", day: 1 },
};

/** crisp pixel line */
function pline(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, w: number) {
  const dx = x1 - x0, dy = y1 - y0, n = Math.max(1, Math.round(Math.max(Math.abs(dx), Math.abs(dy)))), o = w >> 1;
  for (let i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + (dx * i) / n) - o, Math.round(y0 + (dy * i) / n) - o, w, w);
}

export interface Bug {
  id: number; kind: BugKind; team: number; x: number; y: number; vx: number; vy: number; kx: number; ky: number;
  hp: number; max: number; alive: boolean; aim: number; t: number; atk: number; t2: number; t3: number;
  state: "emerge" | "walk" | "wind" | "charge" | "stun" | "sleep" | "down"; stT: number; path: number[]; pi: number; pathT: number;
  target: Fighter | null; thinkT: number; flash: number; hit: number[]; rot: number; vrot: number; deadT: number; strafe: number; bite: number;
  /** look variant + personal speed multiplier */
  v: number; sm: number;
  /** stagger after a hit, body tilt, ragdoll height, and whether the head is still on */
  hitT: number; tilt: number; z: number; vz: number; rest: boolean; noHead: boolean;
  /** spring state of both hands, and how high a dog is in its leap */
  arm: number[]; lz: number; onStair: boolean;
  /** how a corpse ends up lying: pose 0-3, tilt of the final angle, knees buckling */
  pose?: number; slump?: number; sag?: number;
  /** 0 weak, 1 normal, 2 tough: how many hits it takes; bite animation timer */
  tier?: number; chomp?: number; bit?: boolean;
  /** street crowd it belongs to, where that crowd stands, where it is shuffling to; and death convulsions left */
  herd?: number; hx?: number; hy?: number; wx?: number; wy?: number; spasm?: number;
  /** limbs: lost bit 1 / 2 = left / right arm gone; limp 1 = a ruined leg, 2 = the leg is gone and it crawls; what arms and leg can still take */
  lost?: number; limp?: number; ah?: number[]; lh?: number;
  /** rocking after a hit; frozen while a finisher is performed on it */
  wob?: number; fat?: number;
  /** how it rotted (bits, see figure()), and how wide / tall it is built */
  tr?: number; bw?: number; bh?: number;
  /** squashed for an instant when hit */
  pop?: number;
  /** a sprinter: twice as fast as the rest - and whether it has screamed yet */
  fast?: boolean; screamed?: boolean;
  /** a sleeper stirring: somebody is in the room (1 = walking, 2 = running), and for how long now */
  seenBy?: number; stir?: number;
}
export interface Turret { x: number; y: number; aim: number; life: number; cd: number; flash: number; by: Fighter }
export interface Pod { x: number; y: number; t: number; landed: boolean }
interface Glob { x: number; y: number; dx: number; dy: number; life: number }
interface Mortar { x: number; y: number; sx: number; sy: number; t: number; dur: number; rock?: boolean }
interface Breach { x: number; y: number; t: number; n: number }
interface Strike { x: number; y: number; t: number; n: number; beeps: number; by: Fighter; hits: number[] }
/** searchable furniture */
export interface Box { x: number; y: number; house: number; looted: boolean; item: number; /** how long a friend has been at it */ bt?: number }
interface Gib { x: number; y: number; z: number; vx: number; vy: number; vz: number; rot: number; vrot: number; kind: number; b: Bug | null; n: number }

const rand = Math.random;
const PI2 = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => {
  let d = (b - a) % PI2;
  if (d > Math.PI) d -= PI2;
  if (d < -Math.PI) d += PI2;
  return d;
};
const GOO = ["#a8202c", "#6e1420", "#d04a4a"];
const BILE = ["#c8ff4a", "#6fdc3e", "#3f9a2c"];
const RUBBLE = ["#4a4c56", "#6a6c76", "#22242b"];

/** Co-op zombie mission: search houses for three items, call the helicopter, hold out, escape. */
/** the people hiding in the city: one per level. They cannot fight - you find them, and then you keep them alive. */
const CIVS = [
  {
    name: "MAYA", cry: ["...tolong...", "...hiks...", "...ada orang...?"],
    found: ["K-kalian manusia? Tolong, jangan tinggalin aku!", "Aku sembunyi di sini dua hari... makasih, Kak..."],
    wait: ["Tunggu! Jangan cepat-cepat!", "Kak, tungguin aku!"], scared: ["Mereka datang! Aku takut!", "Kyaa! Jangan dekat-dekat!"], hurt: ["Sakit! Tolong aku!", "Aduh! Kak!"],
    calm: ["Makasih sudah jagain aku...", "Aku ikut di belakang ya, Kak.", "Kalau selamat, aku mau cari ibuku."],
  },
  {
    name: "PAK DARMA", cry: ["...siapa di sana...?", "...uhuk... tolong...", "...ada orang...?"],
    found: ["Syukurlah... masih ada orang baik. Kaki saya sudah tidak kuat lari.", "Saya kira saya akan mati sendirian di sini, Nak."],
    wait: ["Pelan-pelan, Nak! Kaki tua ini tidak secepat dulu!", "Tunggu saya, Nak!"], scared: ["Astaga, mereka datang lagi!", "Lindungi saya, Nak!"], hurt: ["Aduh! Tolong!", "Mereka menggigit saya!"],
    calm: ["Terima kasih, Nak. Saya tidak akan lupa.", "Dulu jalan ini ramai sekali tiap pagi...", "Saya ikut saja di belakang kalian."],
  },
  {
    name: "RINA", cry: ["...ada yang dengar...?", "...tolong, saya perawat...", "...hiks..."],
    found: ["Syukurlah! Saya perawat - saya bisa bantu kalau ada yang luka.", "Kalian datang... saya sudah kehabisan perban dan harapan."],
    wait: ["Tunggu, saya tidak bisa lari secepat itu!", "Jangan tinggalkan saya!"], scared: ["Mereka datang! Di belakang kalian!", "Ya Tuhan, banyak sekali!"], hurt: ["Akh! Saya digigit!", "Tolong! Tolong saya!"],
    calm: ["Tekan lukanya kalau berdarah, ya.", "Rumah sakit jatuh di hari pertama...", "Saya ikut di belakang kalian."],
  },
  {
    name: "DIMAS", cry: ["...halo? ada orang?", "...sinyal... tidak ada sinyal...", "...tolong saya..."],
    found: ["Manusia! Saya terjebak di sini sejak rapat pagi. Bawa saya pergi!", "Saya kira tidak akan ada yang datang. Terima kasih!"],
    wait: ["Hei, tunggu! Sepatu kantor ini licin!", "Pelan sedikit, tolong!"], scared: ["Itu mereka! Itu mereka!", "Jangan biarkan mereka mendekat!"], hurt: ["Aduh! Lengan saya!", "Tolong! Saya kena!"],
    calm: ["Saya traktir kopi kalau kita selamat.", "Kantor saya di lantai dua puluh. Dulu.", "Saya tetap di tengah, ya."],
  },
  {
    name: "BU SITI", cry: ["...ya Allah, tolong...", "...siapa di luar...?", "...nak...?"],
    found: ["Alhamdulillah... masih ada anak-anak baik. Ibu ikut kalian, ya.", "Ibu sudah tiga hari berdoa di sini. Terima kasih, Nak."],
    wait: ["Nak, tunggu Ibu! Lutut Ibu sakit!", "Pelan-pelan, Nak!"], scared: ["Astaghfirullah, mereka datang!", "Nak! Di sana, Nak!"], hurt: ["Aduh! Tolong Ibu!", "Ya Allah, sakit!"],
    calm: ["Kalian sudah makan? Kurus-kurus begini.", "Semoga anak Ibu juga ada yang menolong...", "Ibu doakan kalian semua selamat."],
  },
  {
    name: "TONI", cry: ["...mama...?", "...hiks... takut...", "...ada orang...?"],
    found: ["Kakak bukan zombie, kan?! Aku ikut! Aku ikut!", "Aku sembunyi terus... mama bilang jangan keluar..."],
    wait: ["Kak! Tungguin! Kakiku pendek!", "Jangan cepat-cepat, Kak!"], scared: ["Kak! Zombienya banyak!", "Aku takut! Aku takut!"], hurt: ["Sakit, Kak! Sakit!", "Huaa! Kakak!"],
    calm: ["Kak, senjatanya keren. Boleh pegang?", "Nanti kita cari mama, ya?", "Aku berani kok. Dikit."],
  },
];
/** one of the people to be rescued: found = walking with you, lost = did not make it */
/** eighteen people (six kinds, see the sprites): look index = position in this list, lines = CIVS[index % 6] */
const CIV_NAMES = ["MAYA", "PAK DARMA", "RINA", "DIMAS", "BU SITI", "TONI", "LALA", "PAK HARUN", "YUNI", "ANDRE", "BU ENDANG", "BAGAS", "CACA", "KAKEK WIRYO", "MIRA", "REZA", "BU NUR", "DODI"];
interface Civ { f: Fighter; info: (typeof CIVS)[number]; grp: number; found: boolean; lost: boolean; cryT: number; sayT: number; hurtAt: number }

export class BugMode {
  bugs: Bug[] = [];
  corpses: Bug[] = [];
  globs: Glob[] = [];
  mortars: Mortar[] = [];
  pods: Pod[] = [];
  turrets: Turret[] = [];
  strikes: Strike[] = [];
  breaches: Breach[] = [];
  queue: BugKind[] = [];
  spawnT = 0;
  queueT = 0;
  breachT = 20;
  pingT = 0;
  stepT = 0;
  lastArmor = -9;
  cd = [0, 0];
  combo = 0;
  comboT = 0;
  kills = 0;
  heads = 0;
  gibs: Gib[] = [];
  boss: Bug | null = null;
  // mission state
  live = false;
  /** 0 search houses, 1 return to evac, 2 hold out, 3 board the helicopter */
  stage = 0;
  found = [false, false, false];
  boxes: Box[] = [];
  objHouses: number[] = [];
  /** New York: the three crates that hold the items, and the landmarks they stand at */
  objBox: Box[] = [];
  objName: string[] = [];
  evacT = 0;
  heliT = 0;
  bossT = -1;
  bruteT = 0;
  rotorT = 0;
  search: Box | null = null;
  searchT = 0;
  /** weather locked from the menu (null = it changes with the mission) */
  fixed: Weather | null = null;
  /** the civilians hiding in this district; how many made it out so far, out of how many there were */
  civs: Civ[] = [];
  saved = 0;
  civAll = 0;
  /** who has been met in this run already */
  civUsed: number[] = [];
  // the pickup: where its gun points, when it fires next, the flash, blood on the ram
  private gunA = 0;
  private gunCd = 0;
  private gunFlash = 0;
  private ramT = 0;
  /** doors that have been shut (tile index); the building the player has barred himself into; and whether it is clear of the dead */
  shut = new Set<number>();
  sealed = -1;
  safe = -1;
  private safeT = 0;
  private bangs = new Map<number, number>();
  /** open windows (tile -> the wall style to put back), doors the Tank has smashed, how many blows a door has left */
  openWin = new Map<number, number>();
  broken = new Set<number>();
  private doorHp = new Map<number, number>();
  /** the Tank: countdown to its arrival, whether this map has had one */
  tankT = -1;
  tankDone = false;
  private fastAt = -9;
  /** the floor the camera is on has nothing dead left on it */
  floorClear = false;
  /** how many of the dead are on the player right now */
  pressure = 0;
  private floorT = 0;
  private wasClear = -1;
  /** the last shot fired down from a window: [how far it went, hits, what stopped it, where it started] (for testing) */
  lastSky: number[] = [];
  private civHintT = 22;
  private waitAt = -9;
  private mx = 0;
  private my = 0;
  private g: Game;
  private sp = zombieSprites();

  constructor(g: Game) {
    this.g = g;
  }

  reset() {
    this.bugs = []; this.corpses = []; this.globs = []; this.mortars = []; this.pods = []; this.turrets = []; this.strikes = []; this.breaches = [];
    this.queue = []; this.cd = [0, 0]; this.combo = 0; this.kills = 0; this.heads = 0; this.gibs = []; this.boss = null;
    this.live = false; this.stage = 0; this.found = [false, false, false]; this.boxes = []; this.objHouses = []; this.objBox = []; this.objName = [];
    this.evacT = 0; this.heliT = 0; this.bossT = -1; this.search = null; this.searchT = 0;
    this.civs = []; this.civHintT = 22;
    // every door is open again (only where the door is really still there: the map may have changed)
    for (const k of this.shut) { const tx = k % MW, ty = (k / MW) | 0; if (kindAt(tx, ty) === 2 && styleAt(tx, ty) === 40) put(tx, ty, 0, 0); }
    this.shut.clear(); this.bangs.clear(); this.sealed = this.safe = -1;
    for (const [k, st] of this.openWin) { const tx = k % MW, ty = (k / MW) | 0; if (kindAt(tx, ty) === 3 && styleAt(tx, ty) === 41) put(tx, ty, 1, st); }
    this.floorClear = false; this.wasClear = -1;
    this.openWin.clear(); this.broken.clear(); this.doorHp.clear(); this.tankT = -1; this.tankDone = false;
  }

  setWeather(id: WeatherId) {
    this.fixed = id === "auto" ? null : FIXED[id];
  }

  private get padX() { return (PAD.x + PAD.w / 2) * TILE; }
  private get padY() { return (PAD.y + PAD.h / 2) * TILE; }
  private count() { return this.found.filter(Boolean).length; }

  /** mission setup: hide the items, fill the houses with sleeping dead */
  start() {
    const g = this.g;
    this.reset();
    this.boxes = CRATES.map((c) => ({ x: (c.tx + 0.5) * TILE, y: (c.ty + 0.5) * TILE, house: c.house, looted: false, item: -1 }));
    const order = HOUSES.map((_, i) => i).filter((i) => HOUSES[i].under === undefined);
    for (let i = order.length - 1; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [order[i], order[j]] = [order[j], order[i]]; }
    this.objHouses = order.slice(0, 3);
    this.objHouses.forEach((h, i) => {
      const inside = this.boxes.filter((b) => (HOUSES[b.house].under ?? b.house) === h); // either floor
      if (inside.length) {
        // mostly on the top floor: the climb is the point
        const top = Math.max(...inside.map((b) => HOUSES[b.house].lvl ?? 1)), high = inside.filter((b) => (HOUSES[b.house].lvl ?? 1) === top);
        const pool = rand() < 0.7 ? high : inside;
        pool[(rand() * pool.length) | 0].item = i;
      }
    });
    HOUSES.forEach((h, i) => {
      const obj = this.objHouses.includes(h.under ?? i), n = Math.round(((h.w - 2) * (h.h - 2)) / 36) + (obj ? 3 : 0) + ((rand() * 2) | 0);
      for (let k = 0; k < n; k++)
        for (let tries = 0; tries < 20; tries++) {
          const tx = h.x + 1 + ((rand() * (h.w - 2)) | 0), ty = h.y + 1 + ((rand() * (h.h - 2)) | 0);
          if (kindAt(tx, ty) !== 0 || portalAt(tx, ty) >= 0) continue;
          this.spawn(obj && k < 2 ? "warrior" : h.shop && k === 2 ? "spitter" : k === n - 1 && rand() < 0.5 ? "dog" : "scav", (tx + 0.5) * TILE, (ty + 0.5) * TILE, true);
          break;
        }
    });
    if (g.art.ny) this.startNY();
    this.placeCivs();
    this.placeHerds();
    g.setBanner(`MAP ${g.ri + 1}/${g.route.length}: ${g.art.ny ? "NEW YORK" : g.level === 2 ? "KOTA TUA BERSALJU" : "PUSAT KOTA"}`, g.lastMap ? "Barang, penyintas - lalu helikopter menjemput semuanya" : "Barang, penyintas - lalu semua naik pickup ke kota berikutnya", "gold", 3.4);
  }

  private get goalX() { return this.stage === 1 && !this.g.lastMap ? TRUCK.x : this.padX; }
  private get goalY() { return this.stage === 1 && !this.g.lastMap ? TRUCK.y + 8 : this.padY; }

  /** New York: the three items are in supply crates at landmarks far apart; more crates with ordinary loot stand all over town */
  private startNY() {
    const s = SPAWNS[0][0], L = nyGoals(), pc = { x: this.padX, y: this.padY }, pick: { x: number; y: number; name: string }[] = [];
    for (let i = L.length - 1; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [L[i], L[j]] = [L[j], L[i]]; }
    for (const l of L) {
      if (pick.length >= 3) break;
      if (Math.hypot(l.x - s.x, l.y - s.y) < 520 || Math.hypot(l.x - pc.x, l.y - pc.y) < 380 || pick.some((q) => Math.hypot(q.x - l.x, q.y - l.y) < 620)) continue;
      if (!findPath(s.x, s.y, l.x, l.y).length) continue;
      pick.push(l);
    }
    this.objBox = pick.map((l, i) => ({ x: l.x, y: l.y, house: -1, looted: false, item: i }));
    this.objName = pick.map((l) => l.name);
    for (let i = pick.length; i < 3; i++) this.found[i] = true; // (never happens on this map, but nothing may be unreachable)
    // (the furniture inside the buildings stays searchable; the three items are in the marked crates out in the street)
    for (const b of this.boxes) b.item = -1;
    this.objHouses = [];
    this.boxes = this.boxes.concat(this.objBox);
    for (let n = 0, tries = 0; n < 44 && tries < 6000; tries++) {
      const tx = 3 + ((rand() * (MW - 6)) | 0), ty = 3 + ((rand() * (CH - 6)) | 0);
      if (kindAt(tx, ty) !== 0 || nyRoad(tx, ty) || kindAt(tx, ty - 1) !== 1) continue; // against a wall, off the road
      const x = (tx + 0.5) * TILE, y = (ty + 0.5) * TILE;
      if (this.boxes.some((b) => Math.hypot(b.x - x, b.y - y) < 150)) continue;
      this.boxes.push({ x, y, house: -1, looted: false, item: -1 });
      n++;
    }
  }

  /** a supply crate on the pavement (New York): the marked ones hold the items, the others whatever was left */
  private drawCrate(b: Box) {
    const g = this.g, ctx = g.ctx, x = Math.round(b.x) - g.cl, y = Math.round(b.y) - g.ct;
    const R = (c: string, a: number, q: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x + a, y + q, w, h); };
    R("rgba(0,0,0,0.3)", -7, 3, 15, 3);
    R("#0b0b10", -8, -9, 16, 13);
    R(b.looted ? "#4a3626" : "#8a6844", -7, -8, 14, 11);
    if (b.looted) { R("#1a1210", -6, -8, 12, 4); R("#6a4a2e", -7, -10, 14, 2); return; } // open and empty
    R("#a8834c", -7, -8, 14, 2);
    R("#6a4a2e", -7, -2, 14, 1);
    R("#6a4a2e", -1, -8, 2, 11);
    if (b.item >= 0) { R("#f5c542", -7, -5, 14, 2); R(ITEMS[b.item].col, -3, -7, 6, 6); R("#0b0b10", -1, -5, 2, 2); }
  }

  /** crowds of the dead standing in the streets: they mill about until one of them notices you - then all of them come */
  private placeHerds() {
    const g = this.g, spots: number[][] = [], want = g.art.ny ? 28 : g.level === 2 ? 9 : 7, s0 = SPAWNS[0][0];
    for (let tries = 0; tries < 700 && spots.length < want; tries++) {
      const tx = 3 + ((rand() * (MW - 6)) | 0), ty = 3 + ((rand() * (CH - 6)) | 0), z = zoneAt(tx, ty);
      if ((z !== 0 && z !== 2 && z !== 5 && z !== 6) || kindAt(tx, ty) !== 0 || houseAtPx(tx * TILE, ty * TILE) >= 0) continue;
      const x = (tx + 0.5) * TILE, y = (ty + 0.5) * TILE;
      if (Math.hypot(x - this.padX, y - this.padY) < 330 || Math.hypot(x - TRUCK.x, y - TRUCK.y) < 210 || Math.hypot(x - s0.x, y - s0.y) < 330) continue;
      if (spots.some((s) => Math.hypot(s[0] - x, s[1] - y) < 230)) continue;
      spots.push([x, y]);
    }
    spots.forEach((s, hi) => {
      const n = 9 + ((rand() * 6) | 0);
      for (let k = 0; k < n; k++)
        for (let t = 0; t < 12; t++) {
          const a = rand() * PI2, r = 6 + Math.sqrt(rand()) * 30, x = s[0] + Math.cos(a) * r, y = s[1] + Math.sin(a) * r * 0.75;
          if (solidAt(x - 5, y - 5) || solidAt(x + 5, y - 5) || solidAt(x - 5, y + 5) || solidAt(x + 5, y + 5)) continue;
          const b = this.spawn(k < 3 ? "warrior" : "scav", x, y, true);
          b.herd = hi; b.hx = s[0]; b.hy = s[1]; b.wx = x; b.wy = y; b.t3 = rand() * 3;
          b.aim = Math.atan2(s[1] - y, s[0] - x);
          break;
        }
    });
  }

  /** civilians that have been found and are still with you (alive or down) */
  private withYou() { return this.civs.filter((c) => c.found && !c.lost); }
  /** how many of them walk out of here alive */
  rescued() { return this.civs.filter((c) => c.found && !c.lost && c.f.alive).length; }
  /** the hidden ones send an SOS: always in New York (far too big to search blind), elsewhere once the items are done */
  private sos() { return true; }

  /**
   * people are still alive in this district. One building holds a whole group of three or four huddled together,
   * the others somebody on their own - all of them too scared to come out.
   */
  private placeCivs() {
    const g = this.g, ny = !!g.art.ny, s0 = SPAWNS[0][0];
    g.fighters = g.fighters.filter((f) => !f.civ);
    this.civs = [];
    // who: people that have not been met in this run yet
    let pool = CIV_NAMES.map((_, i) => i).filter((i) => !this.civUsed.includes(i));
    if (pool.length < 8) { this.civUsed = []; pool = CIV_NAMES.map((_, i) => i); }
    for (let i = pool.length - 1; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [pool[i], pool[j]] = [pool[j], pool[i]]; }
    const sizes = ny ? [rand() < 0.5 ? 3 : 4, rand() < 0.5 ? 3 : 1, 1] : [rand() < 0.5 ? 3 : 4, 1];
    const cand: number[][] = [], used: number[] = [], spots: number[][] = [];
    HOUSES.forEach((H, hi) => { if (H.shop || this.objHouses.includes(H.under ?? hi)) return; for (const r of H.rooms) if (r.type !== 1 && r.type !== 3 && r.type !== 6) cand.push([r.x, r.y, r.w, r.h, hi]); });
    if (cand.length < 8) HOUSES.forEach((H, hi) => { if (!H.shop) for (const r of H.rooms) if (r.type !== 6) cand.push([r.x, r.y, r.w, r.h, hi]); });
    const topFloors = HOUSES.map((H, i) => (H.tower && H.lvl === 4 && !this.objHouses.includes(H.under ?? i) ? i : -1)).filter((i) => i >= 0);
    sizes.forEach((n, grp) => {
      for (let tries = 0; tries < 160 && cand.length; tries++) {
        const c = cand[(rand() * cand.length) | 0], hi = c[4], home = HOUSES[hi].under ?? hi;
        if (tries < 110 && used.includes(home)) continue; // every hideout is a different building
        if (grp === 0 && tries < 70 && topFloors.length && !topFloors.includes(hi)) continue; // the big group: at the top of a tower, when there is one
        const tx = c[0] + ((rand() * c[2]) | 0), ty = c[1] + ((rand() * c[3]) | 0);
        if (kindAt(tx, ty) !== 0 || portalAt(tx, ty) >= 0) continue;
        if (n === 1 && tries < 60 && kindAt(tx - 1, ty) === 0 && kindAt(tx + 1, ty) === 0 && kindAt(tx, ty - 1) === 0) continue; // into a corner
        const x = (tx + 0.5) * TILE, y = (ty + 0.5) * TILE, q = g.gpos(x, y);
        if (ny && tries < 110 && (Math.hypot(q[0] - s0.x, q[1] - s0.y) < 380 || spots.some((p) => Math.hypot(p[0] - q[0], p[1] - q[1]) < 380))) continue;
        if (!findPath(s0.x, s0.y, x, y).length) continue; // must be reachable
        // the group huddles together: the free tiles closest to the first one, inside the same building
        const tiles = [[tx, ty]], seen = [ty * MW + tx];
        for (let k = 0; k < tiles.length && tiles.length < n; k++)
          for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const ax = tiles[k][0] + ox, ay = tiles[k][1] + oy, key = ay * MW + ax;
            if (seen.includes(key) || kindAt(ax, ay) !== 0 || portalAt(ax, ay) >= 0 || houseAtPx((ax + 0.5) * TILE, (ay + 0.5) * TILE) !== hi) continue;
            seen.push(key);
            tiles.push([ax, ay]);
          }
        if (tiles.length < n && tries < 110) continue;
        const rids: number[] = [];
        for (let m = 0; m < Math.min(n, tiles.length) && pool.length; m++) {
          const ci = pool.pop()!, fx = (tiles[m][0] + 0.5) * TILE + (m ? (rand() - 0.5) * 4 : 0), fy = (tiles[m][1] + 0.5) * TILE + (m ? (rand() - 0.5) * 4 : 0);
          this.civUsed.push(ci);
          const f = g.mkFighter(CIV_NAMES[ci], 0, ci, false, "pistol", 3);
          f.civ = true; f.hid = true; f.x = fx; f.y = fy; f.aim = Math.PI / 2;
          for (let k = 0; k < 6; k += 2) { f.scarf[k] = fx; f.scarf[k + 1] = fy; }
          g.fighters.push(f);
          this.civs.push({ f, info: CIVS[ci % 6], grp, found: false, lost: false, cryT: 2 + rand() * 3, sayT: 8 + rand() * 6, hurtAt: -9 });
          const rid = roomAtPx(fx, fy);
          if (rid >= 0 && !rids.includes(rid)) rids.push(rid);
        }
        used.push(home); spots.push(q);
        this.bugs = this.bugs.filter((b) => !(b.state === "sleep" && rids.includes(roomAtPx(b.x, b.y)))); // nothing sleeps in the room where people hide
        break;
      }
    });
    this.civAll += this.civs.length;
  }

  /** items done and nobody left to look for: on to the pickup (level 1) or to the helicopter (last level, New York) */
  private checkAdvance() {
    const g = this.g;
    if (this.stage !== 0 || this.count() < 3) return;
    const left = this.civs.filter((c) => !c.found && !c.lost).length;
    if (left) {
      g.setBanner("SEMUA BARANG DAPAT!", `Masih ada ${left} PENYINTAS - ikuti sinyal SOS merah muda`, "gold", 3.8);
      return;
    }
    this.stage = 1;
    if (!g.lastMap) {
      g.setBanner("SEMUA BERES!", "Bawa semua penyintas ke PICKUP PUTIH di alun-alun - lanjut ke kota berikutnya", "gold", 4.2);
      g.talk.say("truck", { force: true, cd: 0 });
    } else g.setBanner("SEMUA BERES!", g.art.ny ? "Bawa semua penyintas ke helikopter di BATTERY PARK" : "Bawa semua penyintas ke ZONA EVAC dan panggil helikopter", "gold", 4);
    g.hudDirty = true;
  }

  /** the rescue: they cry for help through the walls; once found they stick to you, say how they feel - and have to be kept alive */
  private civTick(dt: number) {
    const g = this.g, p = g.player, one = (a: string[]) => a[(rand() * a.length) | 0];
    this.civHintT -= dt;
    for (const c of this.civs) {
      const f = c.f, info = c.info;
      if (c.lost) continue;
      if (!f.alive) {
        if (!f.down) {
          c.lost = true;
          g.setBanner("PENYINTAS GUGUR...", `${f.name} tidak selamat`, "red", 3.2);
          g.hudDirty = true;
          this.checkAdvance();
        }
        continue;
      }
      if (f.hid) {
        f.fear = 1;
        if (!p || !p.alive) continue;
        const a = g.gpos(f.x, f.y), b = g.gpos(p.x, p.y), d = Math.hypot(a[0] - b[0], a[1] - b[1]);
        if ((c.cryT -= dt) <= 0 && d < 220) {
          c.cryT = 3.2 + rand() * 3;
          g.say(f.x, f.y - 16, one(info.cry), "#ff9df0"); // a voice through the walls
          g.snd("ping", f.x, f.y, 0.4);
        }
        if (this.civHintT <= 0 && d > 110 && d < 900) {
          this.civHintT = 36;
          const dx = a[0] - b[0], dy = a[1] - b[1];
          g.talk.say("civHear", { vars: { D: Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "TIMUR" : "BARAT") : dy > 0 ? "SELATAN" : "UTARA" }, cd: 30 });
        }
        // (any of you can find them: your friends search too)
        if (g.fighters.some((q) => q.alive && !q.civ && !q.gone && Math.hypot(f.x - q.x, f.y - q.y) < 30 && los(f.x, f.y, q.x, q.y))) {
          // find one and you have found everybody hiding with them
          const grp = this.civs.filter((q) => q.grp === c.grp && !q.lost && !q.found);
          for (const q of grp) { q.f.hid = false; q.f.fear = 0; q.f.joy = 2.5; q.found = true; }
          g.talk.civSay(f, one(info.found));
          const left = this.civs.filter((q) => !q.found && !q.lost).length;
          g.setBanner(grp.length > 1 ? `${grp.length} PENYINTAS DITEMUKAN!` : "PENYINTAS DITEMUKAN!", left ? `Jaga mereka - masih ${left} orang lagi menunggu` : "Jaga mereka - semua penyintas sudah bersamamu", "gold", 3.6);
          g.snd("win", f.x, f.y, 0.9);
          g.rings.push({ x: f.x, y: f.y, life: 0.05, r: 26 });
          g.zoom = Math.max(g.zoom, 0.05);
          g.talk.morale = Math.min(1, g.talk.morale + 0.2);
          g.talk.say("civFound", { force: true, cd: 0 });
          g.hudDirty = true;
          this.checkAdvance();
        }
        continue;
      }
      if ((c.sayT -= dt) <= 0) {
        c.sayT = 9 + rand() * 8;
        let near = 0;
        for (const z of this.bugs) if (z.state !== "sleep" && Math.hypot(z.x - f.x, z.y - f.y) < 90) near++;
        const far = !!p && p.alive && Math.hypot(p.x - f.x, p.y - f.y) > 110;
        const set = f.hp < 50 ? info.hurt : near ? info.scared : far ? info.wait : rand() < 0.45 ? info.calm : null;
        if (set) g.talk.civSay(f, one(set));
        if (near) f.fear = 1.5;
      }
      if (f.ouch > 0.4 && g.t - c.hurtAt > 9) {
        c.hurtAt = g.t;
        g.talk.civSay(f, one(info.hurt));
        g.talk.say("civHurt", { cd: 12, force: true });
      }
    }
    if (this.civHintT <= 0) this.civHintT = 6;
  }

  /** open / shut a window: an open one can be seen and shot through - from both sides - but nothing climbs through it */
  private toggleWin(w: Win) {
    const g = this.g, k = w.ty * MW + w.tx, cx = (w.tx + 0.5) * TILE, cy = (w.ty + 0.5) * TILE, st = this.openWin.get(k);
    if (st !== undefined) { put(w.tx, w.ty, 1, st); this.openWin.delete(k); g.say(cx, cy - 16, "JENDELA DITUTUP", "#ffd75e"); g.snd("door", cx, cy, 0.6); }
    else { this.openWin.set(k, styleAt(w.tx, w.ty)); put(w.tx, w.ty, 3, 41); g.say(cx, cy - 16, "JENDELA DIBUKA", "#7dff9a"); g.snd("click", cx, cy, 1); }
    g.visMem = {};
  }

  /** a window in the wall: glass when shut; open, a gap over a low sill with the panes swung aside */
  private drawWindow(w: Win) {
    const g = this.g, ctx = g.ctx, x = w.tx * TILE - g.cl, y = w.ty * TILE - g.ct;
    if (x < -20 || x > g.W + 4 || y < -20 || y > g.H + 12) return;
    const open = this.openWin.has(w.ty * MW + w.tx);
    const R = (c: string, a: number, b: number, ww: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x + a, y + b, ww, h); };
    if (w.horiz) {
      if (open) {
        R("#0b0b10", 0, -7, 16, 23); R("#10121c", 2, -6, 12, 14);
        R("#8d949e", 1, 8, 14, 2); R("#5d6470", 1, 10, 14, 6);
        R("#9cc6ea", 0, -6, 2, 13); R("#9cc6ea", 14, -6, 2, 13); R("#ffffff", 0, -6, 1, 4); R("#ffffff", 14, -6, 1, 4);
      } else {
        R("#8d949e", 2, 6, 12, 2);
        R("#0b0b10", 2, 8, 12, 8); R("#35557a", 3, 9, 10, 6); R("#9cc6ea", 4, 10, 3, 1); R("#0b0b10", 8, 9, 1, 6);
      }
    } else if (open) {
      R("#0b0b10", 2, -8, 12, 16); R("#10121c", 4, -6, 8, 12);
      R("#9cc6ea", 4, -8, 8, 2); R("#9cc6ea", 4, 6, 8, 2); R("#8d949e", 3, -8, 1, 16); R("#8d949e", 12, -8, 1, 16);
    } else {
      R("#0b0b10", 5, -6, 6, 12); R("#35557a", 6, -5, 4, 10); R("#9cc6ea", 6, -4, 1, 3); R("#0b0b10", 6, 0, 4, 1);
    }
  }

  /** the Tank goes through a barred door */
  private breakDoor(k: number) {
    const g = this.g, kx = k % MW, ky = (k / MW) | 0;
    for (const H of HOUSES)
      for (const d of H.doors) {
        if (Math.abs(d.tx - kx) + Math.abs(d.ty - ky) > 1 || !this.shut.has(d.ty * MW + d.tx)) continue;
        this.broken.add(d.ty * MW + d.tx);
        this.setDoor(d, false);
        const cx = (d.tx + 0.5) * TILE, cy = (d.ty + 0.5) * TILE;
        g.puff(cx, cy, 18, ["#8a6844", "#6a4a2e", "#c9a36a"], 130, { vz: 90, max: 0.7, size: 2, grav: 340, stamp: true });
        g.shake(9, cx, cy);
        g.snd("crack", cx, cy, 1.4);
      }
    g.setBanner("PINTU JEBOL!", "Tank menghancurkan pintunya - tempat ini tidak aman lagi", "red", 3);
    this.safeT = 0;
  }

  /** the boss of every map: it comes out of the ground some way off, and it comes for you */
  spawnTank() {
    const g = this.g, h = this.hole();
    this.spawn("tank", h.x, h.y);
    g.setBanner("TANK!", "Jangan sampai terpojok - pintu pun dijebolnya. Tembak kepalanya!", "red", 3.6);
    g.snd("alarm", g.cam.x, g.cam.y, 1);
    g.hudDirty = true;
  }

  /** a shot out of an upstairs window does not hit the sky: it comes down in the street below, on whatever stands in its way */
  skyShot(b: Bullet): boolean {
    const g = this.g, wx = Math.floor((b.x - b.dx * 5) / TILE), wy = Math.floor((b.y - b.dy * 5) / TILE);
    if (kindAt(wx, wy) !== 3 || styleAt(wx, wy) !== 41) return false;
    const sky = g.skyOf(houseAtPx((wx + 0.5) * TILE, (wy + 0.5) * TILE));
    if (!sky || houseAtPx(b.x, b.y) >= 0) return false;
    const X = sky.gx + (b.x - sky.cx) / sky.s, Y = sky.gy + (b.y - sky.cy) / sky.s, ground = sky.H.under!, w = WEAPONS[b.wid], rocket = b.wid === "bazooka";
    const rng = Math.min(460, (b.life * b.speed) / sky.s + 60);
    let d = 0, hits = 0, why = 0;
    for (; d < rng; d += 4) {
      const px = X + b.dx * d, py = Y + b.dy * d;
      if (px < 4 || py < 4 || px > MW * TILE - 4 || py > CH * TILE - 4) break;
      const hh = houseAtPx(px, py);
      if (hh === ground) continue;           // still over our own building
      const kk = kindAt(Math.floor(px / TILE), Math.floor(py / TILE));
      if (hh >= 0 || kk === 1 || kk === 2) { why = hh >= 0 ? 1 : 2; break; } // a roof, a wall, a wreck (from up here, lamp posts and trees are not in the way)
      let got: Bug | null = null;
      for (const z of this.bugs) {
        if (b.hit.includes(z.id) || Math.abs(z.x - px) > BUG[z.kind].r + 6 || Math.abs(z.y - 4 - py) > BUG[z.kind].r + 8) continue; // seen from above, a body is an easy mark
        got = z;
        break;
      }
      if (!got) continue;
      if (rocket) break;
      b.hit.push(got.id);
      const head = BUG[got.kind].mass < 5 && rand() < 0.3; // from up here, heads are easy
      this.hurt(got, b.dmg * (head ? 2.2 : 1.1), b.owner, b.wid, Math.atan2(b.dy, b.dx), w.knock * 0.5, false, head, head ? 0 : 1);
      hits++;
      if (!b.pierce || hits >= 3) break;
    }
    this.lastSky = [Math.round(d), hits, why, Math.round(X), Math.round(Y)];
    const ex = b.x + b.dx * d * sky.s, ey = b.y + b.dy * d * sky.s; // where that is, seen from up here
    g.tracers.push({ x0: b.x, y0: b.y, x1: ex, y1: ey, life: 0.12, color: "#ffe9a0" });
    g.hitFx(ex, ey, 0, hits ? 7 : 4, 0);
    if (hits) {
      g.puff(ex, ey, 4, GOO, 30, { z: 2, vz: 20, max: 0.3, size: 1, grav: 60 });
      if (b.owner.isPlayer) g.hitMark = 0.14;
    }
    if (rocket) {
      // the rocket goes off down there
      b.x = X + b.dx * d; b.y = Y + b.dy * d;
      g.rings.push({ x: ex, y: ey, life: 0, r: 26 });
      g.glows.push({ x: ex, y: ey, r: 40, life: 0.2, max: 0.2 });
      g.cam.shake = Math.min(10, g.cam.shake + 3);
    }
    return true;
  }

  /** who is on a storey: squad, people to rescue (with you, or still hiding), the dead */
  storey(fi: number) {
    const g = this.g;
    let squad = 0, civ = 0, sos = false, dead = 0;
    for (const f of g.fighters) {
      if (!f.alive || f.gone || houseAtPx(f.x, f.y) !== fi) continue;
      if (f.hid) sos = true;
      else if (f.civ) civ++;
      else squad++;
    }
    for (const z of this.bugs) if (houseAtPx(z.x, z.y) === fi) dead++;
    return { squad, civ, sos, dead };
  }

  /** inside a building with upper floors: a camera on the house across the street - the whole front, who is at which window, what waits at the door */
  towerHud() {
    const g = this.g, ctx = g.ctx, p = g.focus(), t = g.t;
    if (!p || p.gone) return;
    const hi = houseAtPx(p.x, p.y), H = hi >= 0 ? HOUSES[hi] : null;
    if (!H) return;
    const G = H.under !== undefined ? HOUSES[H.under] : H;
    if (!G.floors || G.floors.length < 2) return;
    const n = G.floors.length, lv0 = H.lvl ?? 1, PW = 78, fh = n > 2 ? 19 : 26, bw = 48, PH = 34 + n * fh + 22, x0 = g.W - PW - 6, y0 = 70;
    const R = (c: string, x: number, y: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x0 + x, y0 + y, w, h); };
    R("#0a0a0f", -2, -2, PW + 4, PH + 4); R("#a97a1c", -1, -1, PW + 2, PH + 2);
    // night sky, stars, the moon, the skyline behind
    R("#0c1230", 0, 0, PW, PH); R("#141c44", 0, (PH * 0.45) | 0, PW, PH - ((PH * 0.45) | 0));
    for (let i = 0; i < 9; i++) if (Math.sin(t * 1.5 + i * 2.1) > -0.7) R("#c9d6ff", (i * 37 + 11) % PW, 12 + ((i * 23) % 30), 1, 1);
    R("#fff6c0", PW - 17, 13, 8, 8); R("#0c1230", PW - 14, 11, 7, 7);
    for (let i = 0; i < 6; i++) { const bh = 14 + ((i * 29) % 22); R("#0a0e24", i * 14 - 2, PH - 16 - bh, 12, bh); if (i % 2) R("#8a7038", i * 14 + 2, PH - 12 - bh, 2, 2); }
    // the street
    R("#1a1c26", 0, PH - 16, PW, 16); R("#3a3d4a", 0, PH - 16, PW, 2);
    for (let i = 0; i < 7; i++) R("#b8964a", i * 12 + 2, PH - 6, 6, 1);
    // the building
    const bx = (PW - bw) >> 1, by = PH - 16 - n * fh;
    R("#0b0b10", bx - 2, by - 4, bw + 4, 4); R("#5d6470", bx - 1, by - 3, bw + 2, 3);
    if (n > 2) {
      R("#0b0b10", bx + 5, by - 13, 11, 10); R("#7a5446", bx + 6, by - 12, 9, 9); R("#9a7262", bx + 6, by - 12, 9, 1);
      R("#c9cdd9", bx + bw - 12, by - 16, 1, 13); R(Math.sin(t * 3) > 0 ? "#ff4d5e" : "#7a1420", bx + bw - 13, by - 18, 3, 2);
    } else { R("#0b0b10", bx + bw - 15, by - 11, 8, 8); R("#7a5446", bx + bw - 14, by - 10, 6, 7); }
    R("#0b0b10", bx - 1, by, bw + 2, n * fh);
    const mine = Math.min(3, Math.max(0, Math.floor(((p.x - H.x * TILE) / (H.w * TILE)) * 4)));
    for (let lv = n; lv >= 1; lv--) {
      const y = by + (n - lv) * fh, s = this.storey(G.floors[lv - 1]), cur = lv === lv0, wh = fh - 10;
      R(cur ? "#46557e" : "#2f3442", bx, y, bw, fh - 1); R("#1c1f27", bx, y + fh - 1, bw, 1);
      const who: string[] = ["", "", "", ""]; // who stands at which window
      let q = s.squad + (cur ? -1 : 0), c = s.civ;
      if (cur) who[mine] = "#ffffff";
      for (let i = 0; i < 4; i++) { if (who[i]) continue; if (q > 0) { who[i] = "#7dff9a"; q--; } else if (c > 0) { who[i] = "#ff9df0"; c--; } }
      for (let i = 0; i < 4; i++) {
        const wx = bx + 5 + i * 11, wy = y + 4, lit = cur || s.squad + s.civ > 0;
        R("#0b0b10", wx - 1, wy - 1, 9, wh + 2); R(cur ? "#ffd86b" : lit ? "#b8964a" : "#141c2a", wx, wy, 7, wh);
        if (!lit) R("#2c3a55", wx, wy, 3, 1);
        if (who[i]) { R("#0b0b10", wx + 1, wy + wh - 6, 5, 6); R(who[i], wx + 2, wy + wh - 5, 3, 3); if (who[i] === "#ffffff" && Math.sin(t * 8) > 0) R("#f5c542", wx + 3, wy + wh - 8, 1, 2); }
        else if (i < s.dead && Math.sin(t * 2 + i * 1.7 + lv) > -0.6) { R("#ff4a4a", wx + 1, wy + 3, 1, 1); R("#ff4a4a", wx + 4, wy + 3, 1, 1); } // eyes: the dead are on this floor
      }
      drawText(ctx, String(lv), x0 + bx - 6, y0 + y + (fh >> 1) - 3, cur ? "#fff0a8" : "#8a8f9c");
      if (s.sos && Math.sin(t * 6) > 0) drawText(ctx, "SOS", x0 + bx + bw + 8, y0 + y + (fh >> 1) - 3, "#ff9df0");
      if (cur) { ctx.strokeStyle = "#f5c542"; ctx.lineWidth = 1; ctx.strokeRect(x0 + bx + 0.5, y0 + y + 0.5, bw - 1, fh - 2); R("#f5c542", bx - 12, y + (fh >> 1) - 1, 3, 3); }
    }
    // the door (barred when you have shut it), and what is gathering in the street outside
    const barred = G.doors.some((d) => this.shut.has(d.ty * MW + d.tx));
    R("#0b0b10", bx + (bw >> 1) - 4, by + n * fh - 9, 8, 9); R(barred ? "#8a6844" : "#3a2a22", bx + (bw >> 1) - 3, by + n * fh - 8, 6, 8);
    if (barred) R("#c9cdd9", bx + (bw >> 1) - 3, by + n * fh - 5, 6, 1);
    let out = 0, tank = false;
    const gcx = (G.x + G.w / 2) * TILE, gcy = (G.y + G.h / 2) * TILE;
    for (const z of this.bugs) {
      if (z.y > CH * TILE || z.state === "sleep" || houseAtPx(z.x, z.y) >= 0 || Math.abs(z.x - gcx) > G.w * 8 + 150 || Math.abs(z.y - gcy) > G.h * 8 + 150) continue;
      out++;
      if (z.kind === "tank") tank = true;
    }
    for (let i = 0; i < Math.min(8, out); i++) {
      const zx = (i % 2 ? bx - 8 - (i >> 1) * 6 : bx + bw + 3 + (i >> 1) * 6) + (Math.sin(t * 3 + i) > 0 ? 1 : 0);
      R("#0b0b10", zx, PH - 14, 5, 8); R("#8fae7a", zx + 1, PH - 13, 3, 3); R("#ff4a4a", zx + 1, PH - 12, 1, 1); R("#4a5670", zx + 1, PH - 10, 3, 3);
    }
    if (tank) { R("#0b0b10", bx + bw + 3, PH - 23, 13, 17); R("#c08a7a", bx + bw + 4, PH - 22, 11, 10); R("#ff4a4a", bx + bw + 7, PH - 20, 1, 1); R("#ff4a4a", bx + bw + 10, PH - 20, 1, 1); R("#3a3a44", bx + bw + 6, PH - 12, 7, 5); }
    for (let y = 0; y < PH; y += 2) R("rgba(0,0,0,0.13)", 0, y, PW, 1); // camera lines
    drawText(ctx, "KAMERA LUAR", x0 + (PW >> 1) - 3, y0 + 3, "#c9cdd9");
    if (Math.sin(t * 4) > 0) R("#ff3030", PW - 7, 3, 4, 4);
    drawText(ctx, `LANTAI ${lv0} DARI ${n}`, x0 + (PW >> 1), y0 + PH + 5, "#f5c542");
  }

  /** where the dead stand when they beat on a shut door: the tile outside it (New York: the doorway in the facade) */
  private doorOut(d: { tx: number; ty: number; ox: number; oy: number }): [number, number] {
    const to = portalAt(d.tx, d.ty);
    return to >= 0 ? [((to % MW) + 0.5) * TILE, (((to / MW) | 0) + 0.5) * TILE] : [(d.tx + d.ox + 0.5) * TILE, (d.ty + d.oy + 0.5) * TILE];
  }

  /** E: open / shut the door you are standing at - or, from the middle of a building, bar every door at once */
  useDoor() {
    const g = this.g, p = g.player;
    if (!p || !p.alive || g.phase !== "live" || g.trans || g.climb || g.intro) return;
    // a window in reach? open it to see and shoot out
    let wbest: Win | null = null, wd = 26;
    for (const w of WINDOWS) {
      const q = Math.hypot((w.tx + 0.5) * TILE - p.x, (w.ty + 0.5) * TILE - p.y);
      if (q < wd) { wd = q; wbest = w; }
    }
    let bh = -1, bi = -1, bd = 40; // a door is in reach from a couple of steps away
    HOUSES.forEach((H, hi) => {
      if (isStation(H)) return;
      H.doors.forEach((d, i) => {
        const q = Math.hypot((d.tx + 0.5) * TILE - p.x, (d.ty + 0.5) * TILE - p.y);
        if (q < bd) { bd = q; bh = hi; bi = i; }
      });
    });
    if (wbest && (bh < 0 || wd <= bd)) { this.toggleWin(wbest); return; }
    const hin = houseAtPx(p.x, p.y), base = hin >= 0 ? HOUSES[hin].under ?? hin : -1;
    if (bh >= 0) {
      const d = HOUSES[bh].doors[bi], close = !this.shut.has(d.ty * MW + d.tx);
      if (close && this.broken.has(d.ty * MW + d.tx)) { g.say((d.tx + 0.5) * TILE, d.ty * TILE - 14, "PINTU RUSAK - TIDAK BISA DITUTUP", "#ff6b7a"); return; }
      for (const q of HOUSES[bh].doors) if (Math.abs(q.tx - d.tx) + Math.abs(q.ty - d.ty) <= 1) this.setDoor(q, close); // a double door moves as one
      g.say((d.tx + 0.5) * TILE, d.ty * TILE - 14, close ? "PINTU DITUTUP" : "PINTU DIBUKA", close ? "#7dff9a" : "#ffd75e");
    } else if (base >= 0 && hin !== base) { g.say(p.x, p.y - 26, "PINTU ADA DI LANTAI 1", "#c9cdd9"); return; }
    else if (base >= 0 && !isStation(HOUSES[base])) {
      const open = HOUSES[base].doors.filter((d) => !this.shut.has(d.ty * MW + d.tx) && !this.broken.has(d.ty * MW + d.tx));
      if (!open.length) { g.say(p.x, p.y - 26, "SEMUA PINTU SUDAH TERTUTUP", "#7dff9a"); return; }
      for (const d of open) this.setDoor(d, true);
      g.say(p.x, p.y - 26, "SEMUA PINTU DITUTUP!", "#7dff9a");
    } else { g.say(p.x, p.y - 26, "TIDAK ADA PINTU DI SINI", "#c9cdd9"); return; }
    // barred in: nobody of yours is left outside
    const hNow = houseAtPx(p.x, p.y), bNow = hNow >= 0 ? HOUSES[hNow].under ?? hNow : -1;
    if (bNow >= 0 && HOUSES[bNow].doors.length && HOUSES[bNow].doors.every((d) => this.shut.has(d.ty * MW + d.tx))) {
      let i = 1;
      for (const f of g.fighters) {
        if (f === p || !f.alive || f.gone || f.hid) continue;
        const fh = houseAtPx(f.x, f.y);
        if (fh >= 0 && (HOUSES[fh].under ?? fh) === bNow) continue;
        this.tuck(f, p.x, p.y, i++);
      }
    }
    this.safeT = 0;
    g.hudDirty = true;
  }

  private setDoor(d: { tx: number; ty: number; ox: number; oy: number }, close: boolean) {
    const g = this.g, k = d.ty * MW + d.tx, cx = (d.tx + 0.5) * TILE, cy = (d.ty + 0.5) * TILE;
    if (close === this.shut.has(k)) return;
    if (close) {
      this.shut.add(k);
      put(d.tx, d.ty, 2, 40);
      // whoever stands in the doorway steps inside; the dead are shoved back out (where there is an outside to shove them to)
      const ix = (d.tx - d.ox + 0.5) * TILE, iy = (d.ty - d.oy + 0.5) * TILE, out = kindAt(d.tx + d.ox, d.ty + d.oy) === 0;
      for (const f of g.fighters) if (Math.abs(f.x - cx) < 12.5 && Math.abs(f.y - cy) < 12.5) { f.x = ix; f.y = iy; }
      for (const z of this.bugs) if (Math.abs(z.x - cx) < 12.5 && Math.abs(z.y - cy) < 12.5) { z.x = out ? (d.tx + d.ox + 0.5) * TILE : ix; z.y = out ? (d.ty + d.oy + 0.5) * TILE : iy; }
      g.snd("door", cx, cy, 1);
      g.dust(cx, cy + 6, 4);
    } else {
      this.shut.delete(k);
      put(d.tx, d.ty, 0, 0);
      g.snd("click", cx, cy, 1);
    }
    for (const z of this.bugs) { z.pathT = 0; z.path = []; }
    for (const f of g.fighters) if (f.ai) { f.ai.pathT = 0; f.ai.path = []; }
    g.visMem = {};
  }

  /** put somebody on a free spot next to (px, py) */
  private tuck(f: Fighter, px: number, py: number, i: number) {
    const g = this.g;
    let x = px, y = py;
    for (let k = 0; k < 14; k++) {
      const a = i * 1.9 + k * 0.7, r = 12 + (i >> 2) * 7 + k * 2, qx = px + Math.cos(a) * r, qy = py + Math.sin(a) * r * 0.8;
      if (!g.boxHit(qx, qy) && los(px, py, qx, qy)) { x = qx; y = qy; break; }
    }
    f.x = x; f.y = y; f.vx = f.vy = f.kx = f.ky = 0; f.onStair = false;
    for (let k = 0; k < 6; k += 2) { f.scarf[k] = x; f.scarf[k + 1] = y; }
    if (f.ai) { f.ai.path = []; f.ai.pathT = 0; }
  }

  /** shelters: a building with every door shut is sealed; sealed and with nothing dead left inside, it is safe */
  private shelter(dt: number) {
    const g = this.g, p = g.player;
    for (const [k, v] of this.bangs) { if (v - dt <= 0) this.bangs.delete(k); else this.bangs.set(k, v - dt); }
    if ((this.safeT -= dt) > 0) return;
    this.safeT = 0.3;
    const was = this.safe;
    this.sealed = this.safe = -1;
    if (!p || !p.alive || !this.shut.size) return;
    const h = houseAtPx(p.x, p.y);
    if (h < 0) return;
    const base = HOUSES[h].under ?? h, H = HOUSES[base];
    if (!H.doors.length || isStation(H) || !H.doors.every((d) => this.shut.has(d.ty * MW + d.tx))) return;
    this.sealed = base;
    for (const z of this.bugs) {
      const zh = houseAtPx(z.x, z.y);
      if (zh >= 0 && (HOUSES[zh].under ?? zh) === base) return; // not yet: something is still in here with you
    }
    this.safe = base;
    for (const f of g.fighters) {
      // behind barred doors wounds close slowly, even without sitting down
      const fh = houseAtPx(f.x, f.y);
      if (f.alive && fh >= 0 && (HOUSES[fh].under ?? fh) === base && f.hp < 100) f.hp = Math.min(100, f.hp + 0.9);
    }
    if (was !== base) {
      g.setBanner("TEMPAT AMAN", "Semua pintu tertutup, tidak ada zombie di dalam - [C] istirahat sampai pulih", "gold", 3.6);
      g.snd("win", p.x, p.y, 0.6);
      g.talk.say("safe", { force: true, cd: 20 });
      for (const f of g.fighters) if (f.alive) f.joy = 2;
    }
    g.hudDirty = true;
  }

  /** how dangerous it is right now, 0..1 (drives the music) */
  danger() {
    const g = this.g, p = g.player;
    if (!p || !this.live || g.phase !== "live" || this.safe >= 0) return 0;
    let n = 0;
    for (const z of this.bugs) {
      if (z.state === "sleep") continue;
      const d = Math.abs(z.x - p.x) + Math.abs(z.y - p.y);
      if (d < 280) n += d < 120 ? 1 : 0.35;
    }
    return clamp(n / 5 + (this.stage === 2 ? 0.45 : 0) + (this.boss ? 0.4 : 0) + (p.alive && p.hp < 35 ? 0.2 : 0) + (p.down ? 0.5 : 0), 0, 1);
  }

  /** a shut door: planks and an iron bar - it shakes when they beat on it */
  private drawDoor(k: number) {
    const g = this.g, ctx = g.ctx, tx = k % MW, ty = (k / MW) | 0;
    const sh = this.bangs.has(k) ? Math.round(Math.sin(g.t * 70) * 1.5) : 0;
    const x = tx * TILE - g.cl + sh, y = ty * TILE - g.ct;
    if (x < -20 || x > g.W + 20 || y < -30 || y > g.H + 20) return;
    const R = (c: string, a: number, b: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x + a, y + b, w, h); };
    R("#0b0b10", 0, -8, 16, 24);
    R("#6a4a2e", 1, -7, 14, 14); R("#8a6844", 1, -7, 14, 1);
    for (let i = 4; i < 14; i += 4) R("#553a22", i, -7, 1, 14);
    R("#7a5636", 1, 8, 14, 7); R("#96704a", 1, 8, 14, 1);
    R("#3a3f4a", 0, 10, 16, 2); R("#8d949e", 0, 10, 16, 1);
    R("#c9cdd9", 12, 13, 1, 1);
    if (sh) R("#ffffff", 2, 9, 2, 1);
  }

  /** a marker on something you are looking for: rings on the floor, a diamond and a name over it, an arrow when it is off screen */
  private beacon(wx: number, wy: number, col: string, label: string) {
    const g = this.g, ctx = g.ctx, t = g.t;
    g.pointer(wx, wy, col, "#ffffff", label);
    const x = Math.round(wx) - g.cl, y = Math.round(wy) - g.ct;
    if (x < -30 || x > g.W + 30 || y < -30 || y > g.H + 30) return;
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    for (let i = 0; i < 2; i++) {
      const k = (t * 0.9 + i * 0.5) % 1;
      ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.ellipse(x, y + 5, 6 + 20 * k, 4 + 14 * k, 0, 0, PI2); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    const b = Math.round(Math.sin(t * 5) * 2), dy = y - 16 + b;
    ctx.fillStyle = "#0a0a0f";
    ctx.beginPath(); ctx.moveTo(x, dy - 7); ctx.lineTo(x + 7, dy); ctx.lineTo(x, dy + 7); ctx.lineTo(x - 7, dy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.moveTo(x, dy - 5); ctx.lineTo(x + 5, dy); ctx.lineTo(x, dy + 5); ctx.lineTo(x - 5, dy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 1, dy - 3, 2, 2);
    drawText(ctx, label, x, dy - 16, col);
  }

  /** the pickup at work: on the move its ram goes through whatever stands in the lane; parked, its machine gun keeps the dead away */
  private truckTick(dt: number) {
    const g = this.g, dx = g.truckDX();
    this.gunCd -= dt; this.gunFlash -= dt; this.ramT -= dt;
    if (dx !== 0) {
      const fx = TRUCK.x + dx;
      for (const z of this.bugs.slice()) {
        if (BUG[z.kind].mass > 20 || Math.abs(z.x - (fx + 10)) > 30 || Math.abs(z.y - TRUCK.y) > 16) continue;
        this.hurt(z, Math.ceil(z.hp) + 60, null, "boom", (rand() - 0.5) * 1.2, 360, true);
        g.shake(5, z.x, z.y);
        g.snd("thunk", z.x, z.y, 1.2);
        this.ramT = 4;
      }
      if (rand() < dt * 40) g.puff(fx - 7, TRUCK.y - 12, 1, ["#cfc8ba", "#8a8478", "#3a3832"], 14, { z: 10, vx: -34, vz: 30, max: 0.7, size: 3, grav: -16 });
      if (rand() < dt * 30) g.dust(fx - 22, TRUCK.y + 12, 1);
      this.gunA += clamp(angDiff(this.gunA, 0), -6 * dt, 6 * dt);
      return;
    }
    if (g.phase !== "live" || !this.live) return;
    const gx = TRUCK.x + 6, gy = TRUCK.y;
    let best: Bug | null = null, bd = 150;
    for (const z of this.bugs) {
      if (z.state === "sleep" || z.state === "emerge") continue;
      const d = Math.hypot(z.x - gx, z.y - gy);
      if (d >= bd) continue;
      const a = Math.atan2(z.y - gy, z.x - gx);
      if (d > 40 && !los(gx + Math.cos(a) * 34, gy + Math.sin(a) * 34, z.x, z.y)) continue; // (seen from just outside the truck itself)
      bd = d; best = z;
    }
    if (!best) { this.gunA += dt * 0.5; return; }
    const wantV = Math.atan2(best.y - 4 - (gy - 17), best.x - gx);
    this.gunA += clamp(angDiff(this.gunA, wantV), -9 * dt, 9 * dt);
    const owner = g.player ?? g.fighters[0];
    if (this.gunCd > 0 || !owner || Math.abs(angDiff(this.gunA, wantV)) > 0.25) return;
    this.gunCd = 0.2; this.gunFlash = 0.05;
    const a = Math.atan2(best.y - gy, best.x - gx) + (rand() - 0.5) * 0.07, c = Math.cos(a), s = Math.sin(a);
    const mx = gx + Math.cos(this.gunA) * 13, my = gy - 17 + Math.sin(this.gunA) * 13;
    if (bd < 40) this.hurt(best, 13, owner, "pistol", a, 40); // point blank, over the side
    else {
      const bx = gx + c * 34, by = gy + s * 34;
      g.bullets.push({ x: bx, y: by, dx: c, dy: s, speed: 930, team: 0, owner, dmg: 13, life: 0.3, max: 0.3, pierce: false, hit: [], wid: "pistol", ox: bx, oy: by, trav: 0 });
      g.tracers.push({ x0: mx, y0: my, x1: bx, y1: by - 3, life: 0.06, color: "#ffe9a0" });
    }
    g.glows.push({ x: mx, y: my, r: 14, life: 0.06, max: 0.06 });
    g.snd("pistol", gx, gy, 0.55);
  }

  /** a few of the dead are standing in the road where the pickup comes in: they do not stand there long */
  introCrowd() {
    const g = this.g;
    for (let i = 0; i < 5; i++) {
      const x = TRUCK.x - 64 - i * 36 - rand() * 12, y = TRUCK.y + (rand() - 0.5) * 12;
      if (g.boxHit(x, y)) continue;
      const z = this.spawn(i % 3 ? "scav" : "warrior", x, y);
      z.state = "walk"; z.stT = 0; z.atk = 3; z.aim = Math.PI;
      z.fat = 1.3; // caught in the headlights
    }
  }

  /** skip the search: everything is found, and everybody who is still alive gathers next to the pickup (the evac zone on the last map) */
  skip(): boolean {
    const g = this.g, p = g.player;
    if (!p || !p.alive || !this.live || g.phase !== "live" || g.trans || g.intro) return false;
    if (this.stage === 2) { this.evacT = Math.min(this.evacT, 0.5); return true; } // the hold-out: the helicopter is here now
    if (this.stage !== 0) return false;
    this.found = [true, true, true];
    for (const b of this.objBox) b.looted = true;
    const cx = g.lastMap ? this.padX : TRUCK.x, cy = g.lastMap ? this.padY : TRUCK.y, R0 = g.lastMap ? 88 : 58;
    // a free spot a few steps away from it: all that is left to do is walk over
    let px = cx, py = cy + R0;
    for (const a of [1.57, 1.1, 2.04, 0.5, 2.64, 0, 3.14, -1.57, -0.8, -2.3]) {
      const x = cx + Math.cos(a) * R0, y = cy + Math.sin(a) * R0;
      if (!g.boxHit(x, y)) { px = x; py = y; break; }
    }
    const move = (f: Fighter, i: number) => {
      let x = px, y = py;
      for (let k = 0; i > 0 && k < 12; k++) {
        const a = i * 1.9 + k * 0.7, r = 13 + (i >> 2) * 8 + k * 2, qx = px + Math.cos(a) * r, qy = py + Math.sin(a) * r * 0.8;
        if (!g.boxHit(qx, qy) && los(px, py, qx, qy)) { x = qx; y = qy; break; }
      }
      f.x = x; f.y = y; f.vx = f.vy = f.kx = f.ky = 0; f.onStair = false; f.climbY = 0;
      for (let k = 0; k < 6; k += 2) { f.scarf[k] = x; f.scarf[k + 1] = y; }
      if (f.ai) { f.ai.path = []; f.ai.pathT = 0; f.ai.target = null; }
    };
    this.bugs = this.bugs.filter((z) => z.kind === "titan" || z.kind === "tank" || Math.hypot(z.x - px, z.y - py) > 180); // nothing with teeth is waiting there
    move(p, 0);
    let i = 1;
    for (const f of g.fighters) {
      if (f === p) continue;
      if (f.civ) {
        const c = this.civs.find((q) => q.f === f);
        if (!c || c.lost) continue;
        c.found = true; f.hid = false; f.fear = 0;
      }
      if (f.down) this.revive(f, 60);
      if (f.alive) move(f, i++);
    }
    g.climb = null; g.cam.x = p.x; g.cam.y = p.y; g.visMem = {};
    this.checkAdvance();
    g.setBanner("MISI DILEWATI", g.lastMap ? "Semua berkumpul - masuk ZONA EVAC untuk memanggil helikopter" : "Semua berkumpul - tinggal naik PICKUP", "gold", 3.6);
    g.hudDirty = true;
    return true;
  }

  /** every body that can throw a shadow */
  shadows(cb: (x: number, y: number, w: number, tall: number) => void) {
    const g = this.g;
    for (const b of this.bugs) {
      if (b.state === "emerge" || g.hidden(b.x, b.y)) continue;
      const S = this.scale(b);
      cb(b.x, b.y + 4, 3.2 * S, (b.kind === "dog" ? 9 : (b.limp ?? 0) >= 2 || b.state === "down" ? 6 : 16) * S);
    }
  }

  /** the pickup, dressed for the end of the world: a spiked ram, armour plates, a machine gun on the cab, a light bar, twin exhaust stacks */
  private drawTruck() {
    const g = this.g, ctx = g.ctx, dx = g.truckDX(), moving = dx !== 0, aboard = moving || (!!g.intro && !g.intro.out);
    const x = Math.round(TRUCK.x + dx) - g.cl, y = Math.round(TRUCK.y) + 7 - g.ct;
    if (x < -90 || x > g.W + 90 || y < -50 || y > g.H + 50) return;
    const yb = moving ? Math.round(Math.sin(g.t * 42)) : 0;
    const R = (c: string, a: number, b: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x + a, y + b, w, h); };
    R("rgba(0,0,0,0.34)", -27, 5, 62, 4);
    // big knobbly tyres
    for (const wx of [-21, 8]) {
      R("#0b0b10", wx, -4, 12, 11); R("#26272e", wx + 1, -3, 10, 9);
      for (let i = 0; i < 3; i++) R("#3a3c46", wx + 1 + i * 4, -3, 2, 1);
      R("#8d949e", wx + 4, 0, 4, 3); R("#d9dee8", wx + 5, 1, 2, 1);
    }
    // body
    R("#0b0b10", -26, -10 + yb, 52, 13);
    R("#eef1f6", -25, -9 + yb, 50, 11); R("#ffffff", -25, -9 + yb, 50, 1); R("#c9d1de", -25, -1 + yb, 50, 3);
    // steel plates bolted over the doors and the bed
    R("#5d6470", -24, -7 + yb, 21, 6); R("#858c98", -24, -7 + yb, 21, 1); R("#3c424c", -24, -2 + yb, 21, 1);
    for (const rx of [-23, -16, -9, -5]) R("#c9cdd9", rx, -5 + yb, 1, 1);
    R("#7a4a30", -18, -4 + yb, 4, 2);
    R("#5d6470", 15, -7 + yb, 10, 5); R("#858c98", 15, -7 + yb, 10, 1); R("#c9cdd9", 16, -5 + yb, 1, 1); R("#c9cdd9", 23, -5 + yb, 1, 1);
    // the bed: ammunition boxes, a jerrycan
    R("#0b0b10", -24, -14 + yb, 22, 6); R("#4a505c", -23, -13 + yb, 20, 4);
    R("#4a5a34", -22, -13 + yb, 7, 3); R("#6a7a4a", -22, -13 + yb, 7, 1); R("#f5c542", -20, -12 + yb, 3, 1);
    R("#c0392b", -12, -13 + yb, 4, 3); R("#e8604c", -12, -13 + yb, 4, 1);
    // the cab: wire mesh over the glass
    R("#0b0b10", -3, -20 + yb, 19, 12); R("#eef1f6", -2, -19 + yb, 17, 11); R("#ffffff", -2, -19 + yb, 17, 1);
    R("#132238", 0, -17 + yb, 13, 7); R("#35557a", 1, -16 + yb, 11, 2);
    for (let i = 0; i < 4; i++) R("#7d8592", 2 + i * 3, -17 + yb, 1, 7);
    R("#7d8592", 0, -14 + yb, 13, 1);
    // a light bar on the roof
    R("#0b0b10", 0, -23 + yb, 14, 3);
    for (let i = 0; i < 4; i++) R("#fff3c0", 1 + i * 3, -22 + yb, 2, 1);
    R("#fff3c0", 23, -4 + yb, 2, 3); R("#d8433b", -25, -7 + yb, 1, 3);
    // twin exhaust stacks behind the cab
    for (const ex of [-6, -9]) { R("#0b0b10", ex, -26 + yb, 3, 13); R("#9aa2ae", ex + 1, -25 + yb, 1, 12); }
    // the ram: a steel wedge with teeth, welded to the frame
    R("#0b0b10", 25, -10 + yb, 6, 15); R("#8d949e", 26, -9 + yb, 4, 13); R("#c9cdd9", 26, -9 + yb, 1, 13); R("#5d6470", 29, -9 + yb, 1, 13);
    for (let i = 0; i < 4; i++) {
      const ty = -8 + yb + i * 3;
      R("#0b0b10", 30, ty - 1, 6 - (i % 2), 3); R("#d9dee8", 30, ty, 4 - (i % 2), 1); R("#ffffff", 33 - (i % 2), ty, 1, 1);
    }
    if (this.ramT > 0) { R("#a8202c", 27, -3 + yb, 3, 4); R("#d04a4a", 31, -2 + yb, 3, 1); R("#a8202c", 30, 1 + yb, 4, 1); } // fresh from the last one it hit
    // the machine gun on its pintle: it follows whatever comes too close
    ctx.save();
    ctx.translate(x + 6, y - 24 + yb);
    ctx.fillStyle = "#0b0b10"; ctx.fillRect(-2, 0, 5, 3);
    ctx.rotate(this.gunA);
    ctx.fillStyle = "#0b0b10"; ctx.fillRect(-5, -2, 18, 5);
    ctx.fillStyle = "#3a3f4a"; ctx.fillRect(-4, -1, 8, 3);
    ctx.fillStyle = "#8d949e"; ctx.fillRect(4, -1, 8, 1);
    ctx.fillStyle = "#5d6470"; ctx.fillRect(4, 0, 8, 1);
    ctx.fillStyle = "#4a5a34"; ctx.fillRect(-3, 2, 4, 2);
    if (this.gunFlash > 0) { ctx.fillStyle = "#ffd75e"; ctx.fillRect(13, -3, 6, 6); ctx.fillStyle = "#ffffff"; ctx.fillRect(13, -1, 4, 2); }
    ctx.restore();
    if (aboard) {
      // everybody is in the bed, heads over the side
      const cols = ["#c0392b", "#f5c542", "#3f7a4a", "#ff7ab0"];
      for (let i = 0; i < 4; i++) { R("#0b0b10", -22 + i * 5, -18 + yb, 5, 5); R(cols[i], -21 + i * 5, -17 + yb, 3, 2); R("#e0ac7e", -21 + i * 5, -15 + yb, 3, 1); }
      return;
    }
    // so you always find it again: a tag over the roof - and "get in" when it is time to leave
    const go = this.stage === 1 && !g.lastMap, b = Math.round(Math.sin(g.t * 6) * 2);
    drawText(ctx, go ? "NAIK!" : "VAN", x + 2, y - 36 + (go ? -10 : 0), go ? "#7dff9a" : "#5ff0e0");
    if (go) {
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(x - 4, y - 38 + b, 9, 3); ctx.fillRect(x - 3, y - 35 + b, 7, 2); ctx.fillRect(x - 1, y - 33 + b, 3, 2);
      ctx.fillStyle = "#7dff9a"; ctx.fillRect(x - 3, y - 37 + b, 7, 2); ctx.fillRect(x - 2, y - 35 + b, 5, 1); ctx.fillRect(x, y - 34 + b, 1, 2);
    }
  }


  /** the countdown is over */
  go() {
    const g = this.g;
    this.live = true;
    this.spawnT = 5;
    this.breachT = 26;
    g.setBanner(`3 BARANG + ${this.civs.length} PENYINTAS!`, g.art.ny ? "Buka peti suplai bertanda di 3 landmark, dan dengarkan suara minta tolong" : "Geledah rumah bertanda, dan dengarkan suara minta tolong", "white", 4);
    g.snd("start", g.cam.x, g.cam.y, 1);
    g.talk.say("start", { force: true, cd: 0, reply: "start" });
    g.hudDirty = true;
  }

  spawn(kind: BugKind, x: number, y: number, sleep = false): Bug {
    const g = this.g, info = BUG[kind];
    const hpMul = g.diff.id === "hard" ? 1.2 : g.diff.id === "easy" ? 0.85 : 1;
    const b: Bug = {
      id: g.ids++, kind, team: 1, x, y, vx: 0, vy: 0, kx: 0, ky: 0, hp: info.hp * hpMul, max: info.hp * hpMul, alive: true,
      aim: sleep ? rand() * PI2 : Math.atan2((MH * TILE) / 2 - y, (MW * TILE) / 2 - x), t: rand() * 3, atk: 0.4, t2: 3 + rand() * 2, t3: 5,
      state: sleep ? "sleep" : "emerge", stT: 0.5, path: [], pi: 0, pathT: 0, target: null, thinkT: rand() * 0.3, flash: 0, hit: [], rot: 0, vrot: 0, deadT: 0,
      strafe: rand() < 0.5 ? -1 : 1, bite: 0, hitT: 0, tilt: 0, z: 0, vz: 0, rest: false, noHead: false, arm: [0, 5, 0, 0, 0, 5, 0, 0], lz: 0, onStair: false,
      v: (rand() * 24) | 0, sm: kind === "scav" ? 0.75 + rand() * 0.55 : kind === "warrior" || kind === "spitter" || kind === "dog" ? 0.9 + rand() * 0.2 : 1,
    };
    // some die in one blow, others take two: you never know which until you hit them
    const tr = rand(), tier = tr < 0.3 ? 0 : tr < 0.72 ? 1 : 2;
    const tm = kind === "scav" ? [1.25, 1.9, 2.7][tier] : kind === "warrior" ? [1, 1.5, 2.1][tier] : kind === "dog" ? [1.1, 1.8, 2.4][tier] : 1;
    b.hp *= tm; b.max = b.hp; b.tier = tier;
    if (kind === "scav" && rand() < 0.17) {
      // a sprinter: twice as fast as the others, straight at you, not much to it once you hit it
      b.fast = true; b.sm = 2 + rand() * 0.2; b.tier = 0;
      b.hp = info.hp * hpMul * 1.2; b.max = b.hp;
    }
    if (kind === "scav" || kind === "warrior" || kind === "spitter") {
      // no two of them rotted the same way: 1 jaw hanging open, 2 broken neck, 4 ribs showing, 8 guts hanging, 16 bent double,
      // 32 run through with something, 64 an eye gone, 128 skull open, 256 one arm dead weight, 512 a twitching head
      const TR = [1, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512];
      b.tr = TR[(rand() * TR.length) | 0] | (rand() < 0.5 ? TR[(rand() * TR.length) | 0] : 0);
      const q = rand();
      b.bw = q < 0.2 ? 1.2 : q < 0.4 ? 0.93 : q < 0.5 ? 0.9 : 1; // fat, lanky, small
      b.bh = q < 0.2 ? 1.02 : q < 0.4 ? 1.13 : q < 0.5 ? 0.9 : 1;
    }
    this.bugs.push(b);
    if (sleep) return b;
    if (kind === "tank") { if (!this.boss) this.boss = b; g.shake(9, x, y); g.snd("roar", x, y, 1.4); g.talk.say("boss", { force: true, cd: 5 }); }
    else if (kind === "titan") { this.boss = b; g.shake(8, x, y); g.talk.say("boss", { force: true, cd: 5 }); }
    else if (kind === "dog") g.talk.say("dog", { cd: 45, near: b });
    else if (kind === "charger") g.talk.say("brute", { cd: 45 });
    g.puff(x, y, kind === "scav" ? 4 : 8, RUBBLE, 55, { z: 0, vz: 60, max: 0.5, size: 2, grav: 260 });
    if (rand() < 0.3) g.snd("groan", x, y, 0.9);
    return b;
  }

  /** a street hole close to the squad, but never right on top of it */
  private hole() {
    const g = this.g, p = g.player && g.player.alive ? g.player : g.fighters.find((f) => f.alive);
    if (!p) return NESTS[0];
    const at = g.gpos(p.x, p.y), d = (n: { x: number; y: number }) => Math.hypot(n.x - at[0], n.y - at[1]);
    const far = NESTS.filter((n) => d(n) > 170).sort((a, b) => d(a) - d(b));
    return far[(rand() * Math.min(3, far.length)) | 0] ?? NESTS[0];
  }

  private roll(k: number, hold: boolean): BugKind {
    const r = rand(), run = hold ? 0.28 : 0.08 + 0.08 * k, spit = hold ? 0.12 : k ? 0.04 + 0.03 * k : 0, dog = hold ? 0.13 : 0.05 + 0.04 * k;
    return r < run ? "warrior" : r < run + spit ? "spitter" : r < run + spit + dog ? "dog" : "scav";
  }

  /** an item was found: the noise brings a horde */
  private gain(i: number, b: Box) {
    const g = this.g, p = g.player;
    this.found[i] = true;
    for (const f of g.fighters) f.joy = 3;
    const k = this.count();
    if (k >= 2 && !this.tankDone) { this.tankDone = true; this.tankT = 8; } // ...and with the second one, something much bigger
    g.say(b.x, b.y - 22, `${ITEMS[i].name}!`, ITEMS[i].col);
    g.rings.push({ x: b.x, y: b.y, life: 0.05, r: 26 });
    g.snd("win", b.x, b.y, 1);
    g.zoom = Math.max(g.zoom, 0.05);
    for (let n = 0; n < 7 + 4 * k; n++) this.queue.push(this.roll(k, false));
    if (k >= 2) this.queue.push("charger");
    this.queue.push("dog", "dog");
    g.talk.item(k);
    this.queueT = 2;
    this.breachT = Math.min(this.breachT, 3.5);
    if (k >= 3) this.checkAdvance();
    else g.setBanner(`${ITEMS[i].name} DAPAT! ${k}/3`, "Suaranya memancing GEROMBOLAN!", "gold", 3);
    if (p) g.snd("alarm", p.x, p.y, 0.8);
    g.hudDirty = true;
  }

  /** ordinary loot from cupboards, fridges and lockers */
  private loot(b: Box) {
    const g = this.g, p = g.player!;
    const r = rand();
    if (r < 0.42) {
      if (p.hp < 100) { p.hp = Math.min(100, p.hp + 40); g.say(b.x, b.y - 22, "OBAT +40", "#7dff9a"); }
      else { g.pickups.push({ x: p.x, y: p.y, t: 0.5 }); g.say(b.x, b.y - 22, "OBAT", "#7dff9a"); }
      g.snd("pick", b.x, b.y, 1);
      g.talk.say("healed", { cd: 30 });
    } else if (r < 0.66) {
      const n = this.cd[0] > this.cd[1] || this.cd[1] <= 0 ? 0 : 1;
      this.cd[n] = 0;
      g.say(b.x, b.y - 22, n ? "TURRET SIAP!" : "RUDAL SIAP!", n ? "#8af0ff" : "#ff6b7a");
      g.snd("pick", b.x, b.y, 1);
    } else {
      g.say(b.x, b.y - 22, "KOSONG", "#9a9aa8");
      g.snd("click", b.x, b.y, 1);
      if (rand() < 0.4) g.talk.say("empty", { cd: 25 });
    }
    g.hudDirty = true;
  }

  /** objectives, spawning, win / lose */
  private director(dt: number) {
    const g = this.g, p = g.player;
    if (!g.fighters.some((f) => f.alive && !f.civ)) { g.endMission(false); return; }
    const k = this.count(), hold = this.stage >= 2;
    if (this.tankT > 0 && (this.tankT -= dt) <= 0) this.spawnTank();
    const m = g.diff.id === "hard" ? 1.3 : g.diff.id === "easy" ? 0.75 : 1;
    let awake = 0;
    for (const b of this.bugs) if (b.state !== "sleep") awake++;

    // steady trickle from the street holes
    this.spawnT -= dt;
    if (this.spawnT <= 0 && awake < (hold ? 66 : Math.round((18 + 9 * k + (this.stage ? 10 : 0)) * m))) {
      const h = this.hole(), n = hold ? 3 + ((rand() * 3) | 0) : 2 + ((rand() * 3) | 0); // they climb out in packs
      for (let i = 0; i < n; i++) this.spawn(this.roll(k, hold), h.x + (rand() - 0.5) * 14, h.y + (rand() - 0.5) * 8);
      this.spawnT = (hold ? 0.6 : Math.max(0.8, 2.1 - 0.4 * k)) / m;
    }
    // hordes
    if (this.queue.length && (this.queueT -= dt) <= 0 && awake < 68) {
      const h = this.hole();
      this.spawn(this.queue.shift()!, h.x + (rand() - 0.5) * 14, h.y + (rand() - 0.5) * 8);
      this.queueT = 0.3;
    }
    // they tunnel up right next to the squad
    this.breachT -= dt;
    if ((k >= 1 || hold) && this.breachT <= 0 && awake < 60) {
      const live = g.fighters.filter((f) => f.alive), f = live[(rand() * live.length) | 0];
      for (let tries = 0; tries < 12 && f; tries++) {
        const a = rand() * PI2, d = 70 + rand() * 70, bx = f.x + Math.cos(a) * d, by = f.y + Math.sin(a) * d;
        if (bx < 30 || by < 30 || bx > MW * TILE - 30 || by > MH * TILE - 30 || houseAtPx(bx, by) >= 0) continue;
        if (solidAt(bx, by) || solidAt(bx + 9, by) || solidAt(bx - 9, by) || solidAt(bx, by + 7) || solidAt(bx, by - 7)) continue;
        this.breaches.push({ x: bx, y: by, t: 0, n: 3 + k + (hold ? 2 : 0) });
        g.say(bx, by - 18, "MEREKA MUNCUL!", "#ff9a3c");
        g.talk.say("breach", { cd: 22 });
        g.snd("rumble", bx, by, 1.3);
        break;
      }
      this.breachT = (hold ? 11 : 24 - 3 * k) + rand() * 8;
    }

    if (this.stage === 1 && !g.lastMap) {
      // everything is done here: get everybody into the white pickup
      if (p && p.alive && !g.trans && Math.hypot(p.x - TRUCK.x, p.y - (TRUCK.y + 10)) < 42) {
        // nobody is left behind: everyone you found has to be standing next to the pickup
        const far = this.withYou().find((c) => c.f.down || (c.f.alive && Math.hypot(c.f.x - p.x, c.f.y - p.y) > 100));
        if (far) {
          if (g.t - this.waitAt > 3) { this.waitAt = g.t; g.say(p.x, p.y - 26, far.f.down ? `TOLONG ${far.f.name} DULU!` : `TUNGGU ${far.f.name}!`, "#ff9df0"); }
        } else g.boardTruck();
      }
    } else if (this.stage === 1) {
      if (p && p.alive && Math.abs(p.x - this.padX) < 72 && Math.abs(p.y - this.padY) < 72) {
        this.stage = 2;
        this.evacT = g.diff.id === "hard" ? 85 : g.diff.id === "easy" ? 55 : 70;
        this.bossT = 14;
        this.bruteT = 30;
        g.setBanner("HELIKOPTER DIPANGGIL!", `Bertahan ${this.evacT} detik di zona evac!`, "red", 3.6);
        g.snd("alarm", this.padX, this.padY, 1.2);
        g.talk.say("evacCall", { force: true, cd: 0 });
        g.hudDirty = true;
      }
    } else if (this.stage === 2) {
      this.evacT -= dt;
      if (this.bossT > 0 && (this.bossT -= dt) <= 0) {
        const far = NESTS.slice().sort((a, b) => Math.hypot(b.x - this.padX, b.y - this.padY) - Math.hypot(a.x - this.padX, a.y - this.padY))[(rand() * 4) | 0];
        this.spawn("titan", far.x, far.y);
        g.setBanner("MUTAN RAKSASA DATANG!", "Jangan sampai terkepung!", "red", 2.6);
        g.snd("roar", g.cam.x, g.cam.y, 1.2);
      }
      if ((this.bruteT -= dt) <= 0) { this.queue.push("charger"); this.bruteT = 24; }
      if (this.evacT <= 0) {
        this.stage = 3;
        g.setBanner("HELIKOPTER TIBA!", "Naik sekarang juga!", "gold", 3.2);
        g.snd("win", this.padX, this.padY, 1.2);
        g.talk.say("heli", { force: true, cd: 0 });
        g.hudDirty = true;
      }
    } else if (this.stage === 3 && this.heliT >= 1) {
      if (p && p.alive && Math.hypot(p.x - this.padX, p.y - this.padY) < 34) { this.saved += this.rescued(); g.talk.say("win", { force: true, cd: 0 }); g.endMission(true); }
    }
  }

  /** player stands next to unsearched furniture: rummage through it */
  private rummage(dt: number) {
    const g = this.g, p = g.player;
    let near: Box | null = null;
    if (p && p.alive && g.phase === "live") {
      const h = houseAtPx(p.x, p.y);
      if (h >= 0 || g.art.ny) { // New York: the crates stand in the street
        let bd = g.art.ny ? 22 : 19;
        for (const b of this.boxes) {
          if (b.looted || b.house !== h) continue;
          const d = Math.hypot(b.x - p.x, b.y - p.y);
          if (d < bd) { bd = d; near = b; }
        }
      }
    }
    if (near !== this.search) { this.search = near; this.searchT = 0; }
    if (!near) return;
    const before = Math.floor(this.searchT * 6);
    this.searchT += dt;
    if (Math.floor(this.searchT * 6) !== before) g.snd("click", near.x, near.y, 0.5);
    if (this.searchT >= SEARCH_T) {
      near.looted = true;
      this.search = null;
      if (near.item >= 0) this.gain(near.item, near);
      else this.loot(near);
    }
  }

  /** downed survivors bleed out unless a friend stays with them */
  private medic(dt: number) {
    const g = this.g;
    for (const f of g.fighters) {
      if (!f.down) continue;
      let helper: Fighter | null = null;
      if (f.deadT > 0.8) for (const m of g.fighters) if (m.alive && Math.hypot(m.x - f.x, m.y - f.y) < 22) { helper = m; break; }
      if (helper) {
        f.rev += dt * (helper.isPlayer ? 1 : helper.look === 2 && helper.skin === 1 ? 2.4 : 1.7); // your friends are quick at it - Sari, the medic, quickest of all
        if (f.rev >= 2) { this.revive(f, f.isPlayer ? 75 : 60); g.talk.revived(f, helper); }
      } else {
        f.rev = Math.max(0, f.rev - dt);
        f.bleed -= dt;
        if (f.bleed <= 0) {
          f.down = false;
          g.say(f.x, f.y - 20, "GUGUR...", "#ff6b7a");
          g.snd("lose", f.x, f.y, 0.8);
          g.hudDirty = true;
          if (f.isPlayer) g.endMission(false);
          else g.talk.dead(f);
        }
      }
    }
  }

  private revive(f: Fighter, hp: number) {
    const g = this.g;
    f.alive = true; f.down = false; f.gone = false; f.hp = hp; f.rev = 0;
    f.vx = f.vy = f.kx = f.ky = 0;
    f.z = f.vz = f.rot = f.vrot = 0; f.rest = true;
    f.cd = f.reloadT = f.swingT = f.dashT = f.dashCd = f.tilt = f.deadT = f.hitFlash = 0;
    for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
    for (const id of WEAPON_ORDER) f.ammo[id] = WEAPONS[id].mag;
    if (f.ai) { f.ai.target = null; f.ai.path = []; f.ai.pathT = 0; }
    if (f.isPlayer) g.spec = null;
    // shove the dead away so the survivor gets a second to breathe
    for (const b of this.bugs) {
      const dx = b.x - f.x, dy = b.y - f.y, d = Math.hypot(dx, dy) || 1;
      if (d < 44) { b.kx += ((dx / d) * 260) / Math.min(BUG[b.kind].mass, 6); b.ky += ((dy / d) * 260) / Math.min(BUG[b.kind].mass, 6); b.atk = Math.max(b.atk, 0.9); }
    }
    g.say(f.x, f.y - 26, "BANGKIT!", "#7dff9a");
    g.rings.push({ x: f.x, y: f.y, life: 0.05, r: 24 });
    g.snd("pick", f.x, f.y, 1.2);
    g.hudDirty = true;
  }

  /** where a squad bot should run to: a downed friend first, otherwise back to the player if it strayed */
  /** where the squad goes when somebody needs them: the closest ones to a friend who is down (the player first of all), otherwise back to the player */
  rally(f: Fighter): { x: number; y: number } | null {
    const g = this.g, p = g.player;
    let best: Fighter | null = null, bd = 900;
    for (const m of g.fighters) {
      if (!m.down || m === f) continue;
      const mine = Math.hypot(m.x - f.x, m.y - f.y);
      // not everybody runs: the nearest go, the others keep the dead off them
      let closer = 0;
      for (const o of g.fighters) if (o !== f && o.ai && !o.civ && o.alive && Math.hypot(o.x - m.x, o.y - m.y) < mine) closer++;
      if (closer >= (m.isPlayer ? 3 : 1)) continue;
      const d = mine * (m.isPlayer ? 0.5 : 1);
      if (d < bd) { bd = d; best = m; }
    }
    if (best) return best;
    if (!p || !p.alive) return null;
    return Math.hypot(p.x - f.x, p.y - f.y) > (this.needsHelp() ? 56 : 130) ? p : null;
  }

  /** the player is hurt or has too many of them on him: the squad closes in */
  needsHelp() {
    const p = this.g.player;
    return !!p && p.alive && (p.hp < 45 || this.pressure >= 3);
  }

  /** how much a zombie matters right now (px of distance it is worth): on you, on somebody down or helpless, fast, dangerous */
  threat(z: Bug): number {
    const g = this.g, p = g.player;
    let s = z.fast ? 40 : 0;
    if (z.kind === "dog" || z.kind === "spitter") s += 30;
    if (z.state === "sleep") s -= 60; // the ones that are awake first
    if (p && p.alive) {
      const d = Math.hypot(z.x - p.x, z.y - p.y);
      if (d < 90) s += 150 * (1 - d / 90) + (p.hp < 45 ? 60 : 0);
    }
    for (const f of g.fighters) if ((f.down || (f.civ && f.alive && !f.hid)) && Math.abs(z.x - f.x) < 60 && Math.abs(z.y - f.y) < 60) { s += 110; break; }
    return s;
  }

  /** the floor the player is searching (the squad clears it with him), or -1 */
  sweepFloor(): number {
    const p = this.g.player;
    if (!p || !p.alive || p.gone || !this.live) return -1;
    const hi = houseAtPx(p.x, p.y);
    return hi >= 0 && !isStation(HOUSES[hi]) ? hi : -1;
  }

  /**
   * Sweeping a building: every friend takes something different on the floor you are on - a sleeper to put down quietly,
   * the piece of furniture that holds the item, somebody who is hiding - so the place gets searched without you doing all of it.
   */
  sweepGoal(f: Fighter): { x: number; y: number } | null {
    const g = this.g, ai = f.ai!, hi = this.sweepFloor();
    if (hi < 0) { ai.goal = null; return null; }
    if (ai.goal && g.t < ai.goalT) return ai.goal;
    ai.goalT = g.t + 0.5;
    // cannot get there (cut off, pinned down)? After a while it lets go, and somebody else takes it
    if (ai.goal && g.t - ai.goalSince > 7) { ai.ban = ai.goalKey; ai.banT = g.t + 10; ai.goal = null; ai.goalKey = -1; }
    const taken = new Set<number>();
    if (g.t < ai.banT) taken.add(ai.ban);
    for (const o of g.fighters) if (o !== f && o.ai && o.alive && !o.civ && o.ai.goal) taken.add(o.ai.goalKey);
    let best: { x: number; y: number } | null = null, bk = -1, bd = 1e9;
    const consider = (x: number, y: number, key: number, w: number) => {
      if (taken.has(key)) return;
      const d = Math.hypot(x - f.x, y - f.y) * w;
      if (d < bd) { bd = d; best = { x, y }; bk = key; }
    };
    for (const z of this.bugs) if (z.state === "sleep" && z.herd === undefined && houseAtPx(z.x, z.y) === hi) consider(z.x, z.y, z.id, 1);
    if (this.stage === 0) {
      this.boxes.forEach((b, i) => {
        if (b.looted || b.item < 0 || b.house !== hi) return;
        // stand on a free tile next to it
        for (const [ox, oy] of [[0, 1], [1, 0], [-1, 0], [0, -1]]) {
          const tx = Math.floor(b.x / TILE) + ox, ty = Math.floor(b.y / TILE) + oy;
          if (kindAt(tx, ty) === 0) { consider((tx + 0.5) * TILE, (ty + 0.5) * TILE, 1e6 + i, 0.6); break; }
        }
      });
      for (const c of this.civs) if (!c.found && !c.lost && houseAtPx(c.f.x, c.f.y) === hi) consider(c.f.x, c.f.y, 2e6 + c.grp, 0.5);
    }
    if (bk !== ai.goalKey) ai.goalSince = g.t;
    ai.goal = best;
    ai.goalKey = bk;
    return best;
  }

  /** what the squad does with its hands: a friend standing at the furniture that holds an item takes it out */
  private squadWork(dt: number) {
    const g = this.g;
    if (this.stage !== 0) return;
    for (const b of this.boxes) {
      if (b.looted || b.item < 0) continue;
      let who: Fighter | null = null;
      for (const f of g.fighters) if (f.ai && !f.civ && f.alive && !f.gone && Math.abs(f.x - b.x) < 25 && Math.abs(f.y - b.y) < 25) { who = f; break; }
      if (!who) { b.bt = 0; continue; }
      if ((b.bt = (b.bt ?? 0) + dt) < 1.1) continue;
      b.looted = true;
      if (this.search === b) { this.search = null; this.searchT = 0; }
      g.say(who.x, who.y - 28, `${who.name}: DAPAT!`, "#7dff9a");
      who.joy = 2;
      this.gain(b.item, b);
    }
  }

  /** everyone sleeping in the same house wakes up together */
  private wake(b: Bug) {
    const g = this.g, r = roomAtPx(b.x, b.y);
    let n = 0;
    for (const o of this.bugs) {
      if (o.state !== "sleep" || (o !== b && !(r >= 0 && roomAtPx(o.x, o.y) === r) && !(b.herd !== undefined && o.herd === b.herd) && Math.hypot(o.x - b.x, o.y - b.y) > 64)) continue;
      o.vx = o.vy = 0;
      o.state = "walk"; o.thinkT = 0; o.atk = 0.5 + rand() * 0.4;
      if (n++ < 2) g.say(o.x, o.y - 22, "!", "#ff6b7a");
    }
    g.snd("groan", b.x, b.y, 1.3);
    if (n > 1) g.snd("screech", b.x, b.y, 0.8);
    if (b.herd !== undefined && n > 3) {
      // the whole crowd turns at once
      g.say(b.x, b.y - 32, "GEROMBOLAN!", "#ff6b7a");
      g.snd("roar", b.x, b.y, 0.8);
      g.shake(3, b.x, b.y);
      g.talk.say("surrounded", { cd: 25 });
    }
    g.talk.say("wake", { cd: 14, near: b });
  }

  update(dt: number) {
    const g = this.g;
    this.truckTick(dt);
    this.shelter(dt);
    if ((this.floorT -= dt) <= 0) {
      // is anything dead left on this floor? If not, the whole of it can be seen
      this.floorT = 0.25;
      const fo = g.focus(), hi = fo && fo.alive && !fo.gone ? houseAtPx(fo.x, fo.y) : -1;
      let clear = hi >= 0;
      if (clear) for (const z of this.bugs) if (houseAtPx(z.x, z.y) === hi) { clear = false; break; }
      this.floorClear = clear;
      const pl = g.player;
      let pr = 0;
      if (pl && pl.alive) for (const z of this.bugs) if (z.state !== "sleep" && Math.abs(z.x - pl.x) < 70 && Math.abs(z.y - pl.y) < 70) pr++;
      this.pressure = pr;
      if (clear && this.wasClear !== hi) {
        this.wasClear = hi;
        if (fo && fo.isPlayer && g.phase === "live") { g.say(fo.x, fo.y - 30, "LANTAI BERSIH!", "#7dff9a"); g.snd("ping", fo.x, fo.y, 0.5); }
      } else if (!clear && hi >= 0 && this.wasClear === hi) this.wasClear = -1;
    }
    if (g.phase === "live" && this.live) { this.director(dt); this.rummage(dt); this.squadWork(dt); this.medic(dt); this.civTick(dt); }
    // helicopter
    if (this.stage >= 3) {
      this.heliT = Math.min(1, this.heliT + dt / 2.6);
      if ((this.rotorT -= dt) <= 0) { this.rotorT = 0.11; g.snd("whoosh", this.padX, this.padY, 0.5 + 0.4 * this.heliT); }
      if (this.heliT < 1 && rand() < dt * 30) g.dust(this.padX + (rand() - 0.5) * 70, this.padY + (rand() - 0.5) * 50, 1);
    }
    for (let i = this.bugs.length - 1; i >= 0; i--) this.tick(this.bugs[i], dt);
    // bodies push each other
    const bs = this.bugs;
    for (let i = 0; i < bs.length; i++) {
      const a = bs[i];
      if (a.kind === "titan" || a.state === "sleep") continue;
      const ra = BUG[a.kind].r;
      for (let j = i + 1; j < bs.length; j++) {
        const b = bs[j];
        if (b.kind === "titan") continue;
        const dx = b.x - a.x, dy = b.y - a.y, min = ra + BUG[b.kind].r;
        if (Math.abs(dx) > min || Math.abs(dy) > min) continue;
        const d = Math.hypot(dx, dy);
        if (d < min && d > 0.01) {
          const o = (min - d) / 2, nx = dx / d, ny = dy / d;
          g.slide(a, -nx * o, -ny * o);
          g.slide(b, nx * o, ny * o);
          // momentum carries: a body shoved into the crowd takes the next one with it
          const ka = Math.hypot(a.kx, a.ky), kb = Math.hypot(b.kx, b.ky), hi = ka > kb ? a : b, lo = ka > kb ? b : a;
          if (Math.abs(ka - kb) > 45 && Math.max(ka, kb) > 75 && BUG[lo.kind].mass < 5 && lo.state !== "sleep") {
            lo.kx += hi.kx * 0.55; lo.ky += hi.ky * 0.55; hi.kx *= 0.62; hi.ky *= 0.62;
            lo.hitT = Math.max(lo.hitT, 0.22); lo.wob = 1; lo.tilt = hi.kx >= 0 ? 0.6 : -0.6; lo.chomp = 0;
          }
        }
      }
    }
    for (const f of g.fighters) {
      if (!f.alive) continue;
      for (const b of bs) {
        const min = BUG[b.kind].r + 4;
        const dx = f.x - b.x, dy = f.y - b.y;
        if (Math.abs(dx) > min || Math.abs(dy) > min) continue;
        const d = Math.hypot(dx, dy);
        if (d < min && d > 0.01) {
          const heavy = BUG[b.kind].mass > 5, o = min - d, nx = dx / d, ny = dy / d;
          g.slide(f, nx * o * (heavy ? 1 : 0.5), ny * o * (heavy ? 1 : 0.5));
          if (!heavy) g.slide(b, -nx * o * 0.5, -ny * o * 0.5);
        }
      }
    }
    // bodies: a short, heavy fall - then they twitch and bleed out before they become part of the floor
    for (let i = this.corpses.length - 1; i >= 0; i--) {
      const c = this.corpses[i], titan = c.kind === "titan";
      c.deadT += dt;
      this.arms(c, dt, true);
      c.t2 *= Math.exp(-dt * 10);
      if (titan && rand() < dt * 14) g.puff(c.x + (rand() - 0.5) * 40, c.y + (rand() - 0.5) * 30, 5, BILE, 90, { vz: 80, max: 0.5, size: 3, grav: 220, stamp: true });
      if (c.rest) {
        if ((c.stT -= dt) > 0) {
          // death throes: a leg kicks, an arm jerks, the pool spreads
          if ((c.spasm ?? 0) > 0) {
            c.spasm! -= dt;
            const kk = Math.min(1, c.spasm! / 0.5);
            if (rand() < dt * 30 * kk) {
              c.t2 = (rand() < 0.5 ? -1 : 1) * (2 + rand() * 2.5);
              for (const n of [0, 4]) if (rand() < 0.7) { c.arm[n + 2] += (rand() - 0.5) * 260; c.arm[n + 3] += (rand() - 0.5) * 260; }
            }
            if (rand() < dt * 6 * kk) this.bleed(c.x, c.y, rand() * PI2, 1, 34);
          }
          if (rand() < dt * 4.5) { c.t2 = 2.4; const n = rand() < 0.5 ? 0 : 4; c.arm[n + 2] += (rand() - 0.5) * 110; c.arm[n + 3] += (rand() - 0.5) * 110; }
          if ((c.t3 -= dt) <= 0) { c.t3 = 0.2; this.pool(c.x, c.y + 2, (titan ? 22 : c.kind === "charger" ? 14 : 10) * clamp(1.15 - c.stT, 0.35, 1)); }
          continue;
        }
        const fc = g.fctx;
        fc.save();
        fc.translate(c.x | 0, c.y | 0);
        fc.rotate(c.rot);
        fc.globalAlpha = 0.9;
        this.figure(fc, 0, 0, c, true, false);
        fc.restore();
        this.corpses.splice(i, 1);
        continue;
      }
      const sp = Math.hypot(c.kx, c.ky);
      if (sp > 75 && !titan)
        for (const o of this.bugs) {
          if (BUG[o.kind].mass >= 5 || Math.abs(o.x - c.x) > 9 || Math.abs(o.y - c.y) > 9) continue;
          // a flying body bowls over whoever it hits
          o.kx += c.kx * 0.5; o.ky += c.ky * 0.5; o.hitT = Math.max(o.hitT, 0.3); o.wob = 1; o.chomp = 0;
          if (o.state === "sleep") this.wake(o);
          else if (o.kind !== "dog" && o.state === "walk" && sp > 105) { o.state = "down"; o.stT = 0.8 + rand() * 0.5; o.vrot = c.kx >= 0 ? 1 : -1; o.rot = 0; }
          c.kx *= 0.55; c.ky *= 0.55;
          g.snd("thunk", c.x, c.y, 0.4);
          break;
        }
      if (g.slide(c, c.kx * dt, c.ky * dt, 0.25) && sp > 60) {
        // slams into a wall
        this.bleed(c.x, c.y, Math.atan2(-c.ky, -c.kx), 4, 50);
        g.snd("thunk", c.x, c.y, 0.5);
        c.vrot *= 0.4;
      }
      if (c.atk > 0) {
        // the moment before it goes down: it sways on buckling knees
        c.atk -= dt;
        c.sag = Math.min(1, (c.sag ?? 0) + dt * 6);   // the knees give way
        c.rot = Math.sin(c.deadT * 34) * 0.09 + (c.vrot > 0 ? 0.1 : -0.1) * c.sag;
        const fr = Math.exp(-dt * 10);
        c.kx *= fr; c.ky *= fr;
        continue;
      }
      c.z += c.vz * dt;
      c.vz -= 620 * dt;
      c.rot += c.vrot * dt;
      if (c.z > 0) { const fr = Math.exp(-dt * 1.2); c.kx *= fr; c.ky *= fr; continue; }
      c.z = 0;
      if (c.vz < -90) {
        // lands with one dull bounce
        c.vz *= -0.4; c.kx *= 0.64; c.ky *= 0.64; c.vrot *= 0.6; // it bounces, still turning
        this.bleed(c.x, c.y, Math.atan2(c.ky, c.kx), 3, 40);
        g.dust(c.x, c.y + 3, 2);
        g.snd("thunk", c.x, c.y, 0.45);
        continue;
      }
      c.vz = 0;
      const fr = Math.exp(-dt * 10);
      c.kx *= fr; c.ky *= fr;
      const flat = c.kind === "dog" ? Math.round(c.rot / Math.PI) * Math.PI : Math.round((c.rot - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2 + (c.slump ?? 0);
      const d = flat - c.rot;
      if (Math.abs(d) > 0.04) {
        // tipping over: slowly at first, then all at once
        c.vrot += Math.sign(d) * 24 * dt;
        if (Math.sign(flat - (c.rot + c.vrot * dt)) !== Math.sign(d)) {
          c.rot = flat; c.vrot = 0; c.t2 = 2;
          g.dust(c.x, c.y + 3, 2);
          g.snd("thunk", c.x, c.y, 0.4);
          this.bleed(c.x, c.y, rand() * PI2, 2, 30);
        }
      } else { c.rot = flat; c.vrot = 0; }
      if (sp > 25 && rand() < dt * 40 && !solidAt(c.x, c.y + 3)) { g.fctx.fillStyle = "rgba(122,14,24,0.5)"; g.fctx.fillRect(c.x | 0, (c.y + 3) | 0, 3, 2); }
      if ((sp < 8 && c.rot === flat && c.deadT > (titan ? 1.3 : 0.2)) || c.deadT > 4) { c.rot = flat; c.rest = true; c.stT = Math.max(titan ? 0.3 : 0.7 + rand() * 1.1, (c.spasm ?? 0) + 0.35); c.t3 = 0; }
    }
    // bile spit
    for (let i = this.globs.length - 1; i >= 0; i--) {
      const s = this.globs[i];
      s.life -= dt;
      let dead = s.life <= 0;
      for (let k = 0; k < 2 && !dead; k++) {
        s.x += s.dx * 100 * dt; s.y += s.dy * 100 * dt;
        if (blockAt(s.x, s.y)) dead = true;
        for (const f of g.fighters) {
          if (!f.alive || f.dashT > 0) continue;
          const dx = f.x - s.x, dy = f.y - 1 - s.y;
          if (dx * dx + dy * dy < 40) {
            g.mobName = BUG.spitter.name;
            g.damage(f, BUG.spitter.dmg, null, "bug", Math.atan2(s.dy, s.dx), 40, "", true);
            dead = true;
            break;
          }
        }
      }
      if (rand() < dt * 30) g.puff(s.x, s.y, 1, BILE, 6, { z: 4, vz: 0, max: 0.3, size: 1, grav: 60, stamp: true });
      if (dead) {
        g.puff(s.x, s.y, 6, BILE, 55, { max: 0.35, stamp: true });
        g.snd("squish", s.x, s.y, 0.6);
        this.globs.splice(i, 1);
      }
    }
    // mutant mortars
    for (let i = this.mortars.length - 1; i >= 0; i--) {
      const m = this.mortars[i];
      m.t += dt;
      if (m.t < m.dur) continue;
      if (m.rock) {
        // a slab of road, thrown by the Tank
        g.puff(m.x, m.y, 16, RUBBLE, 130, { vz: 90, max: 0.6, size: 3, grav: 300, stamp: true });
        g.dust(m.x, m.y + 2, 10);
        g.rings.push({ x: m.x, y: m.y, life: 0.05, r: 30 });
        g.shake(7, m.x, m.y);
        g.snd("boom", m.x, m.y, 0.8);
        for (const f of g.fighters) {
          if (!f.alive) continue;
          const d = Math.hypot(f.x - m.x, f.y - m.y);
          if (d < 30) { g.mobName = BUG.tank.name; g.damage(f, 26 * (1 - d / 56), null, "bug", Math.atan2(f.y - m.y, f.x - m.x), 300, "", true); }
        }
        this.shock(m.x, m.y, 24);
        this.mortars.splice(i, 1);
        continue;
      }
      g.puff(m.x, m.y, 14, BILE, 110, { vz: 70, max: 0.5, size: 3, grav: 220, stamp: true });
      g.rings.push({ x: m.x, y: m.y, life: 0.05, r: 28 });
      g.shake(4, m.x, m.y);
      g.snd("squish", m.x, m.y, 1.3);
      g.fctx.fillStyle = "rgba(63,154,44,0.45)";
      for (let k = 0; k < 10; k++) g.fctx.fillRect((m.x + (rand() - 0.5) * 34) | 0, (m.y + (rand() - 0.5) * 22) | 0, 3 + ((rand() * 6) | 0), 2 + ((rand() * 3) | 0));
      for (const f of g.fighters) {
        if (!f.alive) continue;
        const d = Math.hypot(f.x - m.x, f.y - m.y);
        if (d < 28) { g.mobName = BUG.titan.name; g.damage(f, 30 * (1 - d / 48), null, "bug", Math.atan2(f.y - m.y, f.x - m.x), 160, "", true); }
      }
      this.mortars.splice(i, 1);
    }
    // supply pods (turrets)
    for (let i = this.pods.length - 1; i >= 0; i--) {
      const p = this.pods[i];
      p.t += dt;
      if (!p.landed && p.t >= POD_T) {
        p.landed = true;
        g.shake(7, p.x, p.y);
        g.dust(p.x, p.y + 4, 10);
        g.rings.push({ x: p.x, y: p.y, life: 0.05, r: 30 });
        g.glows.push({ x: p.x, y: p.y, r: 40, life: 0.15, max: 0.15 });
        g.snd("pod", p.x, p.y, 1.2);
        this.blast(p.x, p.y, null, 34, 90, 260, "boom");
        g.fctx.fillStyle = "rgba(12,8,20,0.4)";
        for (let k = 0; k < 10; k++) g.fctx.fillRect((p.x + (rand() - 0.5) * 22) | 0, (p.y + 3 + (rand() - 0.5) * 12) | 0, 2 + ((rand() * 5) | 0), 2 + ((rand() * 2) | 0));
        this.turrets.push({ x: p.x, y: p.y, aim: g.player ? g.player.aim : 0, life: 22, cd: 0.6, flash: 0, by: g.player ?? g.fighters[0] });
      }
      if (p.t > 0.9) {
        g.puff(p.x, p.y, 6, ["#ffffff", "#c9cdd9", "#8d949e"], 30, { vz: 30, max: 0.5, size: 3, grav: -10 });
        this.pods.splice(i, 1);
      }
    }
    // sentry turrets
    for (let i = this.turrets.length - 1; i >= 0; i--) {
      const t = this.turrets[i];
      t.life -= dt; t.cd -= dt;
      if (t.flash > 0) t.flash -= dt;
      let best: Bug | null = null, bd = 190;
      for (const b of bs) {
        if (b.state === "sleep") continue;
        const d = Math.hypot(b.x - t.x, b.y - t.y);
        if (d < bd && los(t.x, t.y, b.x, b.y)) { bd = d; best = b; }
      }
      if (best) {
        const want = Math.atan2(best.y - t.y, best.x - t.x);
        t.aim += clamp(angDiff(t.aim, want), -11 * dt, 11 * dt);
        if (t.cd <= 0 && Math.abs(angDiff(t.aim, want)) < 0.2) {
          t.cd = 0.1; t.flash = 0.05;
          const a = t.aim + (rand() - 0.5) * 0.08, c = Math.cos(a), s = Math.sin(a), bx = t.x + c * 9, by = t.y + s * 9;
          g.bullets.push({ x: bx, y: by, dx: c, dy: s, speed: 930, team: 0, owner: t.by, dmg: 15, life: 0.45, max: 0.45, pierce: false, hit: [], wid: "pistol", ox: bx, oy: by, trav: 0 });
          g.glows.push({ x: bx, y: by - 5, r: 11, life: 0.06, max: 0.06 });
          g.snd("pistol", t.x, t.y, 0.5);
        }
      } else t.aim += dt * 1.2;
      if (t.life <= 0) {
        g.puff(t.x, t.y, 8, ["#ffffff", "#c9cdd9", "#f5c542"], 50, { vz: 50, max: 0.5 });
        this.turrets.splice(i, 1);
      }
    }
    // rocket strikes
    for (let i = this.strikes.length - 1; i >= 0; i--) {
      const s = this.strikes[i];
      s.t += dt;
      if (s.t < 1.2 && s.t > s.beeps * 0.24) { s.beeps++; g.snd("beep", s.x, s.y, 1); }
      while (s.n < 5 && s.t >= 1.2 + s.n * 0.13) {
        const a = rand() * PI2, r = s.n === 0 ? 0 : 14 + rand() * 24;
        const hx = s.x + Math.cos(a) * r, hy = s.y + Math.sin(a) * r * 0.8;
        g.blast(hx, hy, s.by, 50, 180, 320, "boom", false);
        s.hits.push(hx, hy, s.t);
        s.n++;
      }
      if (s.t > 2.1) this.strikes.splice(i, 1);
    }
    // the street splits open
    for (let i = this.breaches.length - 1; i >= 0; i--) {
      const br = this.breaches[i];
      br.t += dt;
      if (rand() < dt * 34) g.puff(br.x + (rand() - 0.5) * 22, br.y + (rand() - 0.5) * 12, 1, [...RUBBLE, "#ff9a3c"], 40, { z: 0, vz: 80, max: 0.5, size: 2, grav: 280 });
      if (rand() < dt * 6) g.shake(2.2, br.x, br.y);
      if (br.t < 1.6) continue;
      const fc = g.fctx;
      for (let j = -8; j <= 8; j++) {
        const w = Math.round(14 * Math.sqrt(1 - (j * j) / 64));
        fc.fillStyle = j < -4 ? "#5a5c66" : "#07070a";
        fc.fillRect((br.x - w) | 0, (br.y + j) | 0, w * 2, 1);
      }
      for (let k = 0; k < br.n; k++) this.spawn(rand() < 0.22 ? "warrior" : rand() < 0.2 ? "dog" : "scav", br.x + (rand() - 0.5) * 20, br.y + (rand() - 0.5) * 10);
      g.shake(7, br.x, br.y); g.dust(br.x, br.y, 12); g.rings.push({ x: br.x, y: br.y, life: 0.05, r: 30 });
      g.snd("groan", br.x, br.y, 1.3); g.snd("thunk", br.x, br.y, 1.2);
      this.breaches.splice(i, 1);
    }
    // flying pieces: drip, bounce, then soak into the floor
    for (let i = this.gibs.length - 1; i >= 0; i--) {
      const q = this.gibs[i];
      const nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
      if (solidAt(nx, ny)) { q.vx *= -0.4; q.vy *= -0.4; } else { q.x = nx; q.y = ny; }
      q.z += q.vz * dt;
      q.vz -= 600 * dt;
      q.rot += q.vrot * dt;
      if (q.z > 2 && rand() < dt * 22) g.puff(q.x, q.y, 1, GOO, 6, { z: q.z, vz: 0, max: 0.4, size: 1, grav: 300, stamp: true });
      if (q.z > 0) continue;
      q.z = 0;
      if (q.vz < -70 && q.n < 2) {
        q.n++;
        q.vz *= -0.42; q.vx *= 0.55; q.vy *= 0.55; q.vrot *= 0.6;
        this.bleed(q.x, q.y - 2, Math.atan2(q.vy, q.vx), 2, 30);
        if (q.kind === 0) g.snd("thunk", q.x, q.y, 0.5);
      } else {
        const fc = g.fctx;
        fc.save();
        fc.translate(q.x | 0, q.y | 0);
        fc.rotate(q.rot);
        this.drawGib(fc, q);
        fc.restore();
        this.gibs.splice(i, 1);
      }
    }
    // the dead are never quiet
    if (bs.length && rand() < dt * 0.5) { const z = bs[(rand() * bs.length) | 0]; g.snd("groan", z.x, z.y, 0.85); }
    // motion tracker: pings speed up as they close in (it also hears the ones hiding indoors)
    const pl = g.player;
    if (pl && pl.alive && bs.length) {
      this.pingT -= dt;
      if (this.pingT <= 0) {
        let nd = 1e9;
        for (const b of bs) { const d = Math.hypot(b.x - pl.x, b.y - pl.y); if (d < nd) nd = d; }
        if (nd < 330) g.snd("ping", g.cam.x, g.cam.y, 0.35 + 0.55 * clamp(1 - nd / 260, 0, 1));
        this.pingT = clamp(nd / 230, 0.17, 1.4);
      }
    }
    for (let i = 0; i < 2; i++) if (this.cd[i] > 0) { this.cd[i] -= dt; if (this.cd[i] <= 0) g.hudDirty = true; }
    if (this.comboT > 0 && (this.comboT -= dt) <= 0) this.combo = 0;
  }

  /* ───────────── zombie brains ───────────── */
  private seek(b: Bug, tx: number, ty: number, d: number, dt: number) {
    if (this.sealed >= 0) {
      // prey behind barred doors: all it can do is crowd the nearest door and beat on it
      const hb = houseAtPx(b.x, b.y), hg = houseAtPx(tx, ty);
      if (hg >= 0 && (HOUSES[hg].under ?? hg) === this.sealed && !(hb >= 0 && (HOUSES[hb].under ?? hb) === this.sealed)) {
        let bd = 1e9, dk = -1;
        for (const q of HOUSES[this.sealed].doors) {
          const o = this.doorOut(q), l = Math.hypot(o[0] - b.x, o[1] - b.y);
          if (l < bd) { bd = l; tx = o[0]; ty = o[1]; dk = q.ty * MW + q.tx; }
        }
        d = bd || 1;
        if (bd < 15) {
          this.mx = this.my = 0;
          if (b.kind === "tank") {
            // no door holds the Tank: three blows and it is through
            if (b.atk <= 0) {
              b.atk = 0.75; b.bite = 0.3;
              this.bangs.set(dk, 0.3);
              const left = (this.doorHp.get(dk) ?? 3) - 1;
              this.doorHp.set(dk, left);
              this.g.shake(6, tx, ty); this.g.snd("thunk", tx, ty, 1.6); this.g.dust(tx, ty, 5);
              if (left <= 0) this.breakDoor(dk);
            }
            return;
          }
          if (rand() < dt * 1.4) { this.bangs.set(dk, 0.22); this.g.snd("thunk", b.x, b.y, 0.5); this.g.dust(tx, ty, 1); b.bite = 0.15; }
          return;
        }
      }
    }
    if (d < 130 && walkClear(b.x, b.y, tx, ty, 4.5)) {
      this.mx = (tx - b.x) / d; this.my = (ty - b.y) / d;
      b.pathT = 0;
      return;
    }
    b.pathT -= dt;
    if (b.pathT <= 0) { b.path = findPath(b.x, b.y, tx, ty); b.pi = 0; b.pathT = 0.6 + rand() * 0.6; }
    const p = b.path;
    while (b.pi < p.length && Math.hypot(p[b.pi] - b.x, p[b.pi + 1] - b.y) < 6) b.pi += 2;
    let gx = tx, gy = ty;
    if (b.pi < p.length) { gx = p[b.pi]; gy = p[b.pi + 1]; }
    const dx = gx - b.x, dy = gy - b.y, l = Math.hypot(dx, dy) || 1;
    this.mx = dx / l; this.my = dy / l;
  }

  private bite(b: Bug, t: Fighter, dmg: number, ang: number, knock: number) {
    const g = this.g;
    b.atk = BUG[b.kind].cd;
    b.bite = 0.18;
    b.kx += Math.cos(ang) * 50; b.ky += Math.sin(ang) * 50;
    g.mobName = BUG[b.kind].name;
    g.snd("bite", t.x, t.y, 1);
    g.damage(t, dmg, null, "bug", ang, knock, "", true);
  }

  private tick(b: Bug, dt: number) {
    const g = this.g, info = BUG[b.kind];
    b.t += dt;
    if (b.flash > 0) b.flash -= dt;
    if ((b.pop ?? 0) > 0) b.pop! -= dt;
    if (b.hitT > 0) b.hitT -= dt;
    b.tilt *= Math.exp(-dt * 9);
    b.wob = (b.wob ?? 0) * Math.exp(-dt * 5);
    if ((b.fat ?? 0) > 0) { b.fat! -= dt; b.vx = b.vy = 0; b.hitT = Math.max(b.hitT, 0.1); this.arms(b, dt, b.state === "down"); return; } // it does not get away from a finisher
    b.lz = b.kind === "dog" && b.state === "charge" ? Math.sin(clamp(1 - b.stT / 0.34, 0, 1) * Math.PI) * 7 : 0;
    this.arms(b, dt, b.state === "down");
    if (b.state === "down") {
      // knocked flat: it lies there for a moment, then drags itself back up
      b.stT -= dt;
      b.rot += ((b.stT > 0.35 ? b.vrot * 1.5708 : 0) - b.rot) * Math.min(1, dt * (b.stT > 0.35 ? 16 : 8));
      const fd = Math.exp(-dt * 7);
      b.kx *= fd; b.ky *= fd; b.vx = b.vy = 0;
      g.slide(b, b.kx * dt, b.ky * dt);
      if (b.stT <= 0) { b.state = "walk"; b.rot = 0; b.atk = 0.4; }
      return;
    }
    if (b.state === "sleep") {
      // standing in the dark until someone comes too close
      if (b.herd !== undefined) {
        // a street crowd mills about: shuffle to a spot near the middle, stand, moan, pick another
        if ((b.t3 -= dt) <= 0) { b.t3 = 1.5 + rand() * 3.5; const a = rand() * PI2, r = rand() * 28; b.wx = b.hx! + Math.cos(a) * r; b.wy = b.hy! + Math.sin(a) * r * 0.75; }
        const wx = b.wx! - b.x, wy = b.wy! - b.y, wd = Math.hypot(wx, wy);
        if (wd > 3) {
          g.slide(b, (wx / wd) * 9 * dt, (wy / wd) * 9 * dt);
          b.vx = (wx / wd) * 9; b.vy = (wy / wd) * 9;
          b.aim += clamp(angDiff(b.aim, Math.atan2(wy, wx)), -3 * dt, 3 * dt);
        } else b.vx = b.vy = 0;
        if (rand() < dt * 0.04) g.snd("groan", b.x, b.y, 0.5);
      }
      if ((b.thinkT -= dt) > 0) return;
      b.thinkT = 0.2 + rand() * 0.15;
      const hb = houseAtPx(b.x, b.y), rb = roomAtPx(b.x, b.y);
      for (const f of g.fighters) {
        if (!f.alive || f.hid) continue;
        const d = Math.hypot(f.x - b.x, f.y - b.y);
        // they notice you in the same room, up close, or when a gun goes off in the house (melee is quiet!)
        if (b.herd !== undefined && f.loud > 0 && d < 280) { this.wake(b); break; } // a shot in the street turns every head
        if ((rb >= 0 && roomAtPx(f.x, f.y) === rb) || (d < (b.herd !== undefined ? 120 : 58) && los(b.x, b.y, f.x, f.y))) { if (b.herd !== undefined) this.wake(b); else b.seenBy = f.runK > 0.5 ? 2 : 1; break; } // (indoors it takes them a moment to come round)
        // heavy rain drowns out the shots
        if (hb >= 0 && f.loud > 0 && d < (g.atmo.cur.rain > 1.2 ? 100 : 190) && houseAtPx(f.x, f.y) === hb) {
          this.wake(b);
          if (f.isPlayer) g.talk.say("loud", { cd: 70 });
          break;
        }
      }
      if (b.state === "sleep") {
        // somebody is in the room: it stirs, and after a second or so it is awake - unless it has been dealt with by then (running wakes it twice as fast)
        if (b.seenBy) {
          const was = b.stir ?? 0;
          b.stir = was + 0.3 * b.seenBy;
          b.seenBy = 0;
          if (was < 0.5 && b.stir >= 0.5) g.say(b.x, b.y - 22, "?", "#ffd75e");
          if (b.stir >= 1.2) this.wake(b);
        } else b.stir = Math.max(0, (b.stir ?? 0) - 0.15);
      }
      return;
    }
    b.atk -= dt; b.t2 -= dt; b.t3 -= dt;
    if (b.bite > 0) b.bite -= dt;
    const fr = Math.exp(-dt * 8);
    b.kx *= fr; b.ky *= fr;
    if (b.state === "emerge") { b.stT -= dt; if (b.stT <= 0) b.state = "walk"; return; }
    b.thinkT -= dt;
    if (b.thinkT <= 0 || !b.target || !b.target.alive) {
      b.thinkT = 0.4 + rand() * 0.3;
      let best: Fighter | null = null, bd = 1e9;
      for (const f of g.fighters) {
        if (!f.alive || f.hid) continue; // nobody has noticed the one who is hiding
        const d = Math.hypot(f.x - b.x, f.y - b.y);
        if (d < bd) { bd = d; best = f; }
      }
      b.target = best;
    }
    const t = b.target;
    let mx = 0, my = 0;
    if (t) {
      const dx = t.x - b.x, dy = t.y - b.y, d = Math.hypot(dx, dy) || 1, nx = dx / d, ny = dy / d, ang = Math.atan2(dy, dx);
      const reach = info.r + 8;
      if (b.kind === "scav" || b.kind === "warrior") {
        if (b.fast && !b.screamed && d < 200) {
          // it has seen you: a scream, and it comes running
          b.screamed = true;
          g.snd("screech", b.x, b.y, 0.9);
          if (g.t - this.fastAt > 10) { this.fastAt = g.t; g.say(b.x, b.y - 26, "PELARI CEPAT!", "#ff4d5e"); }
        }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        // it goes straight for the closest victim; a bite is a real lunge, not a wave of the hand
        if ((b.chomp ?? 0) > 0) {
          b.chomp = (b.chomp ?? 0) - dt; mx *= 0.04; my *= 0.04; b.aim = ang;
          if (!b.bit && (b.chomp ?? 0) < 0.2) {
            b.bit = true;
            if (d < reach + 8) this.bite(b, t, info.dmg, ang, 40);
            else g.snd("squish", b.x, b.y, 0.3);
          }
        } else if (d < reach + 3 && b.atk <= 0) { b.chomp = 0.5; b.bit = false; b.atk = info.cd + 0.5; g.snd("groan", b.x, b.y, 0.6); }
      } else if (b.kind === "spitter") {
        const see = d < 180 && los(b.x, b.y, t.x, t.y);
        if (b.state === "wind") {
          b.aim = ang;
          b.stT -= dt;
          if (b.stT <= 0) {
            b.state = "walk";
            b.atk = info.cd * (0.8 + rand() * 0.4);
            const a = ang + (rand() - 0.5) * 0.16;
            this.globs.push({ x: b.x + Math.cos(a) * 6, y: b.y - 2 + Math.sin(a) * 6, dx: Math.cos(a), dy: Math.sin(a), life: 1.3 });
            g.snd("squish", b.x, b.y, 0.9);
          }
        } else {
          if (!see) { this.seek(b, t.x, t.y, d, dt); mx = this.mx; my = this.my; }
          else if (d < 85) { mx = -nx; my = -ny; }
          else { mx = -ny * b.strafe * 0.7; my = nx * b.strafe * 0.7; if (rand() < dt * 0.5) b.strafe = -b.strafe; }
          if (see && b.atk <= 0) { b.state = "wind"; b.stT = 0.45; }
        }
      } else if (b.kind === "dog") {
        if (b.state === "wind") {
          // crouch... then pounce
          b.stT -= dt;
          b.aim = ang;
          b.vx = b.vy = 0;
          if (b.stT <= 0) { b.state = "charge"; b.stT = 0.34; b.hit = []; g.snd("bark", b.x, b.y, 1); }
          return;
        }
        if (b.state === "charge") {
          b.stT -= dt;
          const c = Math.cos(b.aim), s = Math.sin(b.aim);
          const wall = g.slide(b, c * 290 * dt, s * 290 * dt, 0);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0 || b.hit.includes(f.id)) continue;
            if (Math.hypot(f.x - b.x, f.y - b.y) < 12) {
              b.hit.push(f.id);
              b.bite = 0.2;
              g.mobName = info.name;
              g.damage(f, info.dmg, null, "bug", b.aim, 130, "", true);
            }
          }
          if (wall || b.stT <= 0) { b.state = "walk"; b.atk = 0.9 + rand() * 0.6; }
          return;
        }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        // circle the prey instead of running straight in
        if (d < 110 && d > 30) { mx += -ny * b.strafe * 0.6; my += nx * b.strafe * 0.6; if (rand() < dt * 0.6) b.strafe = -b.strafe; }
        if (b.atk <= 0 && d < 80 && d > 16 && los(b.x, b.y, t.x, t.y)) { b.state = "wind"; b.stT = 0.28; g.snd("groan", b.x, b.y, 0.5); }
        else if (d < reach && b.atk <= 0) this.bite(b, t, info.dmg, ang, 60);
      } else if (b.kind === "charger") {
        if (b.state === "wind") {
          b.stT -= dt;
          if (b.stT > 0.15) b.aim = ang;
          if (b.stT <= 0) { b.state = "charge"; b.stT = 0.9; b.hit = []; g.snd("dash", b.x, b.y, 1.3); }
          b.vx = b.vy = 0;
          return;
        }
        if (b.state === "charge") {
          b.stT -= dt;
          const c = Math.cos(b.aim), s = Math.sin(b.aim);
          const wall = g.slide(b, c * 320 * dt, s * 320 * dt, 0);
          if (rand() < dt * 40) g.dust(b.x - c * 8, b.y + 5, 1);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0 || b.hit.includes(f.id)) continue;
            if (Math.hypot(f.x - b.x, f.y - b.y) < info.r + 7) {
              b.hit.push(f.id);
              g.mobName = info.name;
              g.damage(f, info.dmg, null, "bug", b.aim + (rand() - 0.5) * 0.7, 430, "", true);
            }
          }
          if (wall) {
            b.state = "stun"; b.stT = 1.4; b.atk = info.cd;
            g.shake(6, b.x, b.y); g.dust(b.x + c * 8, b.y, 8); g.snd("thunk", b.x, b.y, 1.3);
            g.say(b.x, b.y - 20, "PUSING!", "#8af0ff");
          } else if (b.stT <= 0) { b.state = "walk"; b.atk = info.cd; }
          return;
        }
        if (b.state === "stun") { b.stT -= dt; if (b.stT <= 0) b.state = "walk"; b.vx = b.vy = 0; return; }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        if (d < reach + 2 && b.t2 <= 0) { this.bite(b, t, 20, ang, 220); b.t2 = 1; }
        else if (b.atk <= 0 && d < 210 && d > 36 && los(b.x, b.y, t.x, t.y)) { b.state = "wind"; b.stT = 0.75; g.snd("roar", b.x, b.y, 0.8); }
      } else if (b.kind === "tank") {
        // the Tank: it runs you down, punches you across the street, rips up the road and throws it
        if (b.state === "wind") {
          b.stT -= dt; b.aim = ang; b.vx = b.vy = 0;
          if (rand() < dt * 30) g.dust(b.x + (rand() - 0.5) * 18, b.y + 6, 1);
          if (b.stT <= 0) {
            b.state = "walk"; b.t2 = 4.5 + rand() * 2;
            this.mortars.push({ x: t.x + t.vx * 0.4, y: t.y + t.vy * 0.4, sx: b.x, sy: b.y - 22, t: 0, dur: 0.75, rock: true });
            g.snd("whoosh", b.x, b.y, 1.4);
          }
          return;
        }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        if (d < reach + 8 && b.atk <= 0) {
          b.atk = 1.1; b.bite = 0.3;
          g.mobName = info.name;
          g.damage(t, info.dmg, null, "bug", ang, 560, "", true);
          g.hitFx(t.x, t.y - 4, ang, 16, 1);
          g.rings.push({ x: t.x, y: t.y, life: 0.05, r: 26 });
          g.shake(9, t.x, t.y);
          g.snd("thunk", t.x, t.y, 1.6);
        } else if (b.t2 <= 0 && d > 90 && d < 300 && los(b.x, b.y, t.x, t.y)) { b.state = "wind"; b.stT = 0.75; g.snd("roar", b.x, b.y, 1); }
        if (b.t3 <= 0 && (mx || my)) { b.t3 = 0.36; g.shake(2.4, b.x, b.y); g.snd("thunk", b.x, b.y, 0.45); g.dust(b.x + (rand() - 0.5) * 14, b.y + 8, 2); } // the ground shakes under it
      } else {
        // mutant: slow walking fortress
        if (d > 24) { this.seek(b, t.x, t.y, d, dt); mx = this.mx; my = this.my; }
        b.aim += clamp(angDiff(b.aim, ang), -1.6 * dt, 1.6 * dt);
        if (d < 36 && b.atk <= 0) {
          b.atk = info.cd; b.bite = 0.25;
          g.shake(8, b.x, b.y); g.rings.push({ x: b.x, y: b.y + 6, life: 0.05, r: 38 }); g.dust(b.x, b.y + 8, 12); g.snd("thunk", b.x, b.y, 1.5);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0) continue;
            const fd = Math.hypot(f.x - b.x, f.y - b.y);
            if (fd < 40) { g.mobName = info.name; g.damage(f, info.dmg, null, "bug", Math.atan2(f.y - b.y, f.x - b.x), 320, "", true); }
          }
        }
        if (b.t2 <= 0) {
          b.t2 = 4.2;
          g.snd("roar", b.x, b.y, 1.2);
          const live = g.fighters.filter((f) => f.alive);
          for (let i = 0; i < 4; i++) {
            const f = live[i % Math.max(1, live.length)];
            if (!f) break;
            const spread = i < live.length ? 6 : 34;
            this.mortars.push({ x: f.x + f.vx * 0.5 + (rand() - 0.5) * spread, y: f.y + f.vy * 0.5 + (rand() - 0.5) * spread, sx: b.x, sy: b.y - 14, t: -i * 0.18, dur: 1.05 });
          }
        }
        if (b.t3 <= 0) {
          b.t3 = 6.5;
          if (this.bugs.length < 60) for (let i = 0; i < 3; i++) this.spawn("scav", b.x + (rand() - 0.5) * 30, b.y + 10 + rand() * 8);
        }
      }
    }
    if (b.hp < b.max * 0.6 && rand() < dt * 4 && !solidAt(b.x, b.y + 5)) { const fc = g.fctx; fc.fillStyle = "rgba(130,16,28,0.7)"; fc.fillRect((b.x + (rand() - 0.5) * 4) | 0, (b.y + 5) | 0, 1 + ((rand() * 2) | 0), 1); } // dripping
    const l = Math.hypot(mx, my);
    if (b.fast && l > 0.1 && rand() < dt * 16) g.puff(b.x, b.y + 5, 1, ["#c9cdd9", "#8a8f9c"], 8, { z: 0, vz: 12, max: 0.3, size: 2, grav: 0 }); // dust at its heels
    if (l > 1) { mx /= l; my /= l; }
    if (b.hitT > 0) { mx *= 0.15; my *= 0.15; } // staggering
    const a = 1 - Math.exp(-dt * 9);
    // a shambling rhythm: lurch forward, drag, lurch again
    const lurch = b.fast ? 1 : b.kind === "scav" ? 0.62 + 0.55 * Math.max(0, Math.sin(b.t * 2.6 + b.id)) : b.kind === "warrior" ? 0.85 + 0.2 * Math.sin(b.t * 5 + b.id) : 1;
    // a ruined leg: it hobbles in fits and starts; no leg at all: it drags itself along
    const crip = b.limp === 2 ? 0.3 : b.limp === 1 ? 0.3 + 0.5 * Math.max(0, Math.sin(b.t * 5.2)) : 1;
    b.vx += (mx * info.speed * b.sm * lurch * crip - b.vx) * a;
    b.vy += (my * info.speed * b.sm * lurch * crip - b.vy) * a;
    if (b.kind === "titan") {
      g.slide(b, b.vx * dt, b.vy * dt);
      if (l > 0.1 && (this.stepT -= dt) <= 0) {
        this.stepT = 0.55;
        g.shake(3.5, b.x, b.y); g.snd("thunk", b.x, b.y, 0.9); g.dust(b.x + (rand() - 0.5) * 36, b.y + 10, 3);
      }
    } else {
      g.slide(b, (b.vx + b.kx) * dt, (b.vy + b.ky) * dt);
      if (g.stairs(b)) { b.pathT = 0; b.path = []; } // up or down the stairs after its prey
      if (Math.abs(b.kx) + Math.abs(b.ky) > 150 && rand() < dt * 24) g.dust(b.x, b.y + 4, 1); // skidding backwards
      if (l > 0.1 && b.state === "walk") b.aim += clamp(angDiff(b.aim, Math.atan2(my, mx)), -9 * dt, 9 * dt);
    }
  }

  /* ───────────── taking damage ───────────── */
  private scale(b: Bug) {
    const vs = this.sp[b.kind];
    return vs[b.v % vs.length].s;
  }

  /**
   * blood. A hit throws a burst from the wound (a fan of jets, for a few frames), drops that arc through the air and land as
   * round spots, and one splat on the floor: a dark core with streaks pulled out along the direction of the blow.
   */
  private bleed(x: number, y: number, ang: number, n: number, sp = 110) {
    const g = this.g, c = Math.cos(ang), s = Math.sin(ang);
    g.splash(x, y - 4, ang, 9 + n * 2.2);
    // drops: a few fat ones that fall close, a few small fast ones that fly far
    g.puff(x, y - 3, Math.ceil(n * 0.7), GOO, sp * 0.4, { z: 7, vx: c * sp * 0.8, vy: s * sp * 0.8, vz: 60, max: 0.5, size: 2, grav: 330, drag: 1.5, stamp: true });
    g.puff(x, y - 3, Math.ceil(n * 0.5), GOO, sp * 0.7, { z: 8, vx: c * sp * 1.5, vy: s * sp * 1.5, vz: 34, max: 0.36, size: 1, grav: 270, drag: 1, stamp: true });
    if (n >= 4) g.puff(x, y - 5, 2, ["rgba(168,32,44,0.45)", "rgba(120,14,24,0.4)"], 22, { z: 8, vx: c * 26, vy: s * 26, vz: 12, max: 0.4, size: 3, grav: -8, drag: 3 });
    this.splat(x + c * (5 + n), y + 4 + s * (4 + n) * 0.8, ang, 2 + n * 0.55);
  }

  /** one splat on the floor: an irregular core with a wet highlight, streaks thrown forwards, satellite drops around it */
  private splat(x: number, y: number, ang: number, r: number) {
    const fc = this.g.fctx;
    const dot = (px: number, py: number, w: number, h: number, col: string) => {
      if (solidAt(px, py)) return;
      fc.fillStyle = col;
      fc.fillRect(px | 0, py | 0, w, h);
    };
    for (let k = 0; k < 3; k++) {
      const cx = x + (rand() - 0.5) * r, cy = y + (rand() - 0.5) * r * 0.6, rr = Math.max(1, r * (0.45 + rand() * 0.4)), ry = Math.max(1, Math.round(rr * 0.6));
      for (let j = -ry; j <= ry; j++) {
        const w = Math.round(rr * Math.sqrt(Math.max(0, 1 - (j * j) / (ry * ry))));
        dot(cx - w, cy + j, w * 2 + 1, 1, k ? "rgba(104,12,22,0.6)" : "rgba(134,16,28,0.68)");
      }
    }
    dot(x - 1, y - 1, 2, 1, "rgba(214,66,70,0.6)");
    // streaks: thick at the root, thin at the tip, a drop at the end
    for (let i = 0, ns = 2 + ((r / 2) | 0); i < ns; i++) {
      const a = ang + (rand() - 0.5) * 0.9, dx = Math.cos(a), dy = Math.sin(a) * 0.8, L = r * (1.4 + rand() * 2.6);
      for (let d = 0; d < L; d++) dot(x + dx * d, y + dy * d, d < L * 0.4 ? 2 : 1, 1, "rgba(118,14,24,0.6)");
      if (i % 2) dot(x + dx * (L + 2), y + dy * (L + 2), 2, 2, "rgba(134,16,28,0.7)");
    }
    for (let i = 0; i < 3 + r; i++) {
      const a = ang + (rand() - 0.5) * 2.4, d = r * (1.2 + rand() * 3.6);
      dot(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.8, rand() < 0.3 ? 2 : 1, 1, i % 2 ? "rgba(110,12,22,0.66)" : "rgba(160,26,38,0.7)");
    }
  }

  /** a pool spreading under a body */
  private pool(x: number, y: number, r: number) {
    const fc = this.g.fctx;
    for (let k = 0; k < 3; k++) {
      const cx = x + (rand() - 0.5) * r, cy = y + (rand() - 0.5) * r * 0.5, rr = r * (0.5 + rand() * 0.5), ry = Math.max(2, Math.round(rr * 0.55));
      fc.fillStyle = k ? "rgba(104,12,22,0.24)" : "rgba(132,16,28,0.3)";
      for (let j = -ry; j <= ry; j++) {
        const w = Math.round(rr * Math.sqrt(1 - (j * j) / (ry * ry)));
        if (!solidAt(cx, cy + j)) fc.fillRect((cx - w) | 0, (cy + j) | 0, w * 2, 1);
      }
    }
    fc.fillStyle = "rgba(210,70,70,0.5)";
    fc.fillRect((x - r * 0.3) | 0, (y - 1) | 0, 2, 1);
  }

  /** a flying piece: kind 0 head, 1 flesh, 2 bone, 3 brain */
  /** which part of the body a shot goes through: 0 head, 1 torso, 2 arm, 3 leg. You only get the head by putting the crosshair on it. */
  private partOf(m: Bug, b: Bullet, S: number, inHead: boolean): number {
    if (m.kind === "dog") return 1;
    if (BUG[m.kind].mass >= 5) return inHead ? 0 : 1;
    const aimed = b.owner.isPlayer && b.ax !== undefined && b.ay !== undefined;
    if (!aimed) {
      // squad mates and turrets have no crosshair to read: they hit what they hit
      const r = rand(), hd = b.owner.ai ? 0.45 : 0.2; // your friends go for the head
      return r < hd ? 0 : r < 0.78 ? 1 : r < 0.89 ? 2 : 3;
    }
    if (m.state === "down" || (m.limp ?? 0) >= 2) {
      // lying on the ground: the head is where the body points
      const fc = m.state === "down" ? (m.vrot >= 0 ? 1 : -1) : Math.cos(m.aim) < 0 ? -1 : 1;
      return Math.hypot(b.ax! - (m.x + fc * 7 * S), b.ay! - m.y) < 5.5 * S ? 0 : 1;
    }
    const feet = m.y + 5;
    if (Math.abs(b.dx) > 0.3) {
      // the shot crosses the body at a certain height: that is the part it goes through
      const h = feet - (b.y + b.dy * ((m.x - b.x) / b.dx));
      if (h > 9.6 * S) return 0;
      if (h > 6.6 * S) return rand() < 0.5 ? 2 : 1; // shoulder height: the outstretched arms are in the way
      if (h > 3.2 * S) return 1;
      return 3;
    }
    // straight up or down the body: what counts is where the crosshair sits
    const ah = feet - b.ay!, ax = Math.abs(b.ax! - m.x);
    if (ax < 5 * S && ah > 9.6 * S && ah < 20 * S) return 0;
    if (Math.abs(b.x - m.x) > 3 * S) return rand() < 0.5 ? 2 : 3;
    return ah < 3.2 * S && ax < 6 * S ? 3 : 1;
  }

  /** an arm comes off: it flies, the stump bleeds - and the thing keeps coming */
  private sever(b: Bug, i: number, ang: number) {
    if (((b.lost ?? 0) >> i) & 1) i = 1 - i;
    if (((b.lost ?? 0) >> i) & 1) return;
    b.lost = (b.lost ?? 0) | (1 << i);
    this.gib(b.x, b.y - 5, 4, ang + (rand() - 0.5) * 1.2, 95, 140, b);
    this.bleed(b.x, b.y - 4, ang, 4, 80);
    this.g.snd("crack", b.x, b.y, 0.6);
  }

  /** a limb takes the hit instead of the body: arms are shot off, legs give way (first a limp, then it crawls) */
  private maim(b: Bug, part: number, amt: number, ang: number, mine: boolean) {
    const g = this.g;
    if (part === 2) {
      let i = rand() < 0.5 ? 0 : 1;
      if (((b.lost ?? 0) >> i) & 1) i = 1 - i;
      if (((b.lost ?? 0) >> i) & 1) return;
      const ah = (b.ah ??= [24, 24]);
      ah[i] -= amt * 2.9;
      b.aim += i ? 0.6 : -0.6; // the hit spins it half round
      if (ah[i] <= 0) {
        this.sever(b, i, ang);
        if (mine) g.say(b.x, b.y - 26, "TANGAN PUTUS!", "#ff9a3c");
      }
      return;
    }
    b.lh = (b.lh ?? 26) - amt * 2.55;
    b.hitT = Math.max(b.hitT, 0.34); // it stumbles
    if (b.lh <= 0 && (b.limp ?? 0) < 2) {
      b.limp = (b.limp ?? 0) + 1;
      b.lh = 30;
      if (b.limp === 2) {
        this.gib(b.x, b.y + 2, 5, ang + (rand() - 0.5), 80, 110, b);
        this.bleed(b.x, b.y + 3, ang, 5, 70);
        g.snd("crack", b.x, b.y, 0.6);
        b.chomp = 0;
      }
      if (mine) g.say(b.x, b.y - 26, b.limp === 2 ? "KAKI PUTUS!" : "PINCANG!", "#ff9a3c");
    }
  }

  /** a finisher lands: the cinematic kill of a zombie that was on the floor or on its last legs. kind 0 = skull smash, 1 = karambit */
  execute(z: Bug, by: Fighter, wid: WId, ang: number, kind: number) {
    const g = this.g;
    if (!z.alive) return;
    z.fat = 0;
    g.slowT = 0.55; g.hitStop = Math.max(g.hitStop, 0.13); g.zoom = Math.max(g.zoom, 0.11); g.whiteT = 0.05;
    g.shake(8, z.x, z.y);
    const dmg = Math.ceil(z.hp) + 1;
    if (kind === 0) {
      // the skull gives way under the blow
      for (let k = 0; k < 4; k++) this.bleed(z.x, z.y, rand() * PI2, 5, 100);
      this.pool(z.x, z.y + 2, 12);
      this.hurt(z, dmg, by, wid, ang, 20, true, true, 0);
    } else {
      // opened from throat to belly in one turn of the blade: a fountain, then it folds
      g.cut(z.x, z.y - 8, ang + 0.9); g.cut(z.x, z.y - 3, ang - 0.9); g.cut(z.x, z.y - 6, ang + 1.57);
      g.puff(z.x, z.y - 8, 28, GOO, 50, { z: 10, vz: 210, max: 0.9, size: 2, grav: 330, stamp: true });
      for (let k = 0; k < 3; k++) this.bleed(z.x, z.y - 5, ang + (k - 1) * 0.8, 5, 110);
      this.pool(z.x, z.y + 2, 11);
      this.sever(z, rand() < 0.5 ? 0 : 1, ang);
      this.hurt(z, dmg, by, wid, ang, 10, true, rand() < 0.65, 0);
      g.snd("slash", z.x, z.y, 1.3);
    }
    g.snd("crack", z.x, z.y, 1.2);
    g.streak = { id: g.ids++, text: "FATALITY!" }; g.streakT = 1.7; g.hudDirty = true; // after the kill, so nothing else takes the headline
    by.joy = 1.6;
    g.talk.say("smash", { cd: 20 });
  }

  private gib(x: number, y: number, kind: number, ang: number, sp: number, vz: number, b: Bug | null = null) {
    if (this.gibs.length > 70) return;
    const a = ang + (rand() - 0.5) * (kind ? 1.6 : 0.3), v = sp * (kind ? 0.4 + rand() * 0.8 : 1);
    this.gibs.push({ x, y, z: kind ? 6 : 12, vx: Math.cos(a) * v, vy: Math.sin(a) * v, vz: vz * (0.7 + rand() * 0.6), rot: rand() * PI2, vrot: (rand() - 0.5) * 30, kind, b, n: 0 });
  }

  hurt(b: Bug, amt: number, by: Fighter | null, wid: Hurt, ang: number, knock: number, explosive = false, head = false, part = head ? 0 : 1, crit = false) {
    if (!b.alive) return;
    const g = this.g, info = BUG[b.kind], S = this.scale(b);
    if (b.state === "sleep") {
      // a blade or a club on a sleeper, hard enough to finish it: nobody else in the room hears a thing
      if (b.herd === undefined && (wid === "karambit" || isBat(wid)) && amt >= b.hp) { b.state = "walk"; g.say(b.x, b.y - 26, "SENYAP!", "#8af0ff"); }
      else this.wake(b);
    }
    if (by && by.ai && !by.civ) amt *= 1.3; // your friends know where to hit
    if (by && by.ai && by.look === 2 && by.skin === 4) amt *= g.talk.rageT > 0 ? 1.6 : 1.15; // Bara hits hard, harder when angry
    if (by && by.isPlayer && by.look === 2 && by.skin === 9 && (wid === "axe" || wid === "shotgun")) amt *= 1.25; // the firefighter knows his tools
    if (b.kind === "charger" && !explosive) {
      if (b.state === "stun") amt *= 1.6;
      else if (Math.cos(angDiff(ang, b.aim)) < -0.35) {
        // riot armour on the front: flank it, stun it or blow it up
        amt *= 0.3;
        g.sparks.push({ x: b.x + Math.cos(b.aim) * 8, y: b.y - 4 + Math.sin(b.aim) * 8, life: 0.08 });
        if (g.t - this.lastArmor > 0.5) { this.lastArmor = g.t; g.say(b.x, b.y - 22, "ARMOR!", "#c9cdd9"); g.snd("deflect", b.x, b.y, 0.5); }
      }
    }
    amt = Math.max(1, Math.round(amt));
    if (by) by.dmg += Math.min(amt, b.hp);
    b.hp -= amt;
    b.flash = 0.05;
    b.pop = 0.12; // squashed by the blow for an instant
    const c = Math.cos(ang), s = Math.sin(ang);
    b.kx += (c * knock * 0.6) / info.mass; b.ky += (s * knock * 0.6) / info.mass;
    const kv = Math.hypot(b.kx, b.ky), cap = isBat(wid) || explosive ? 200 : 120; // shoved, not launched
    if (kv > cap) { b.kx *= cap / kv; b.ky *= cap / kv; }
    // the body is knocked back, the loose arms are left behind and then swing
    const imp = 50 + Math.min(110, amt * 2.2);
    for (let i = 0; i < 8; i += 4) { b.arm[i + 2] -= c * imp * (0.7 + rand() * 0.6); b.arm[i + 3] += (-s * 0.6 - 1) * imp * (0.6 + rand() * 0.6); }
    if (b.kind === "dog" && b.state === "wind") b.state = "walk"; // a hit interrupts the pounce
    if (info.mass < 5) {
      // stagger: the bite is interrupted, the body snaps back, the arms fly up
      b.hitT = Math.max(b.hitT, 0.22 + Math.min(0.3, amt / 160));
      b.chomp = 0; // a hit tears it off its prey
      b.tilt = clamp(b.tilt + (c >= 0 ? 1 : -1) * (0.4 + Math.min(0.5, amt / 80)), -1, 1);
      b.atk = Math.max(b.atk, 0.3);
      if (b.state === "walk" && rand() < 0.3) b.aim += (rand() - 0.5) * 1.8; // the impact twists it round
      // a really heavy hit puts it on the floor - and it gets up again
      if (b.hp > 0 && b.kind !== "dog" && b.state !== "down" && (isBat(wid) ? rand() < 0.55 : explosive || amt >= 55)) {
        b.state = "down"; b.stT = 1 + rand() * 0.7; b.vrot = c >= 0 ? 1 : -1; b.rot = 0;
        if (by?.isPlayer) g.talk.say("knockdown", { cd: 50 });
      }
    }
    b.wob = Math.min(1, (b.wob ?? 0) + 0.45 + amt / 90); // rocked by the blow
    if (b.hp > 0 && info.mass < 5 && b.kind !== "dog" && (part === 2 || part === 3)) this.maim(b, part, amt, ang, !!by?.isPlayer);
    this.bleed(b.x, b.y - (head ? 9 * S : 2), ang, head ? 6 : 2 + Math.min(3, (amt / 20) | 0));
    // a spurt of blood in the direction of the hit
    g.puff(b.x, b.y - (head ? 9 * S : 3), head ? 5 : 2 + Math.min(2, (amt / 40) | 0), GOO, 85, { vx: c * 75, vy: s * 75, vz: 55, max: 0.5, size: 2, grav: 300, stamp: true });
    if (head) g.sparks.push({ x: b.x, y: b.y - 9 * S, life: 0.07 });
    const col = head ? "#ff6b7a" : by?.isPlayer ? "#fff0a8" : "#ffffff";
    const old = g.texts.find((t) => t.v === b && t.life < 0.3);
    if (old) { old.amt += amt; old.text = String(old.amt); old.life = 0; old.color = col; }
    else if (g.texts.length < 40) g.texts.push({ x: b.x, y: b.y - info.r - 12, text: String(amt), color: col, life: 0, v: b, amt });
    if (by?.isPlayer) g.hitMark = 0.14;
    if (isGun(wid)) {
      g.hitFx(b.x - c * 3, b.y - (head ? 9 * S : part === 3 ? 0 : 4), ang, head ? 11 : 8, 0);
      // the round punches in: a white pop on the entry side, and the body jolts
      g.rings.push({ x: b.x - c * 4, y: b.y - 4 - s * 3, life: 0.2, r: wid === "sniper" ? 12 : 7 });
      g.puff(b.x - c * 4, b.y - 4, 3, ["#ffffff", "#ffe9a0"], 60, { vx: -c * 50, vy: -s * 50, max: 0.14, size: 1, grav: 0, drag: 6 });
      // ...and out the other side: a cone of blood thrown along the line of fire
      g.puff(b.x + c * 5, b.y - (head ? 9 * S : part === 3 ? -2 : 3) + s * 4, wid === "pistol" ? 4 : 6, GOO, 55, { z: 7, vx: c * 165, vy: s * 165, vz: 26, max: 0.42, size: 2, grav: 240, drag: 2.5, stamp: true });
      if (head) {
        // a headshot: pink mist, bone, and the crack of it
        g.puff(b.x, b.y - 9 * S, 7, ["#e88aa0", "#ffc0cc", "#a8202c"], 46, { z: 11, vx: c * 60, vy: s * 60, vz: 60, max: 0.5, size: 2, grav: 200, stamp: true });
        g.snd("crack", b.x, b.y, by?.isPlayer ? 0.7 : 0.3);
      }
      if (by?.isPlayer) g.hitStop = Math.max(g.hitStop, head ? 0.03 : 0.012); // every round that lands is felt
    }
    g.snd("hit", b.x, b.y, by?.isPlayer ? 0.8 : 0.4);
    if (b.hp <= 0) this.kill(b, by, wid, ang, head, crit);
  }

  private kill(b: Bug, by: Fighter | null, wid: Hurt, ang: number, head: boolean, crit = false) {
    const g = this.g, info = BUG[b.kind], S = this.scale(b);
    b.alive = false;
    const i = this.bugs.indexOf(b);
    if (i >= 0) this.bugs.splice(i, 1);
    const big = b.kind === "charger" || b.kind === "titan" || b.kind === "tank";
    const boom = wid === "boom" || wid === "bazooka", bat = isBat(wid), smash = bat && head;
    if (crit) g.say(b.x, b.y - 38, "KRITIS!", "#ffe45c");
    const power = (crit ? 2.1 : 1) * ((bat ? 88 : boom ? 90 : wid === "sniper" ? 55 : wid === "shotgun" ? 58 : wid === "goldgun" ? 52 : wid === "karambit" ? 16 : 24) * (0.75 + rand() * 0.5)) / Math.min(info.mass, 6);
    const dir = ang + (rand() - 0.5) * 0.3, side = Math.cos(ang) >= 0 ? 1 : -1;
    this.kills++;
    if (by) { by.kills++; by.roundKills++; if (wid === "karambit") by.spinT = 0.6; if (bat) by.bloody = 8; g.talk.kill(by, b.x, b.y); by.joy = Math.max(by.joy, head ? 1.4 : 0.5); }
    g.snd("squish", b.x, b.y, by?.isPlayer ? 1.1 : 0.6);
    if (rand() < info.heart) g.pickups.push({ x: b.x, y: b.y, t: 0 });
    this.bleed(b.x, b.y, ang, big ? 12 : 5, big ? 150 : 120);
    // rockets - and a shotgun fired point-blank - leave nothing to fall over
    if (!big && ((boom && rand() < 0.65) || (wid === "shotgun" && !!by && Math.hypot(by.x - b.x, by.y - b.y) < 46 && rand() < 0.5))) {
      // blown to pieces: nothing left to fall over
      for (let k = 0; k < 8; k++) this.gib(b.x, b.y, k < 5 ? 1 : k < 7 ? 2 : 3, rand() * PI2, 105, 150);
      this.gib(b.x, b.y, 0, rand() * PI2, 85, 160, b);
      for (let k = 0; k < 3; k++) this.bleed(b.x, b.y, rand() * PI2, 4, 90);
      this.pool(b.x, b.y + 3, 9);
    } else {
      // ragdoll: thrown off its feet in the direction of the hit
      // how a body falls depends on what hit it
      const heavy = bat || boom || wid === "shotgun" || wid === "sniper" || wid === "goldgun", wasDown = b.state === "down";
      b.kx = Math.cos(dir) * power; b.ky = Math.sin(dir) * power;
      b.rest = false; b.deadT = wasDown ? 0.2 : 0; b.hitT = 0; b.atk = 0; b.t2 = 0; b.t3 = 0; b.stT = 0; b.z = 0; b.vz = 0;
      if (wasDown) b.vrot = 0; // already on the floor: it just goes limp
      else if (heavy && !smash) {
        // staggers back with a small hop, already tipping: the rest of the fall is gravity, not a launch
        b.rot = 0; b.z = 1; b.vz = 26 + power * 0.3 + (crit ? 70 : 0);
        b.vrot = side * (b.kind === "dog" ? 4.5 : 2.6 + rand() * 1.6) * (crit ? 2.4 : 1); // a critical hit sends it spinning
        b.atk = 0;
      } else {
        // crumples: it sways for a heartbeat, the knees give way and it tips over - sometimes towards you
        b.rot = 0;
        b.atk = smash ? 0 : 0.1 + rand() * 0.16;
        b.vrot = (!head && rand() < 0.3 ? -side : side) * (smash ? 6 : 1.4 + rand() * 1.6);
      }
      b.pose = (rand() * 4) | 0; b.slump = (rand() - 0.5) * 0.95; b.sag = 0;
      if (!big && b.kind !== "dog" && (wid === "axe" ? rand() < 0.75 : wid === "shotgun" || boom ? rand() < 0.3 : false)) this.sever(b, rand() < 0.5 ? 0 : 1, ang); // heavy kills take an arm with them
      // shot dead - but the nerves have not got the message yet: the body will jerk and kick on the floor for a moment
      b.spasm = rand() < SPASM_CHANCE ? 1 + rand() * 1.2 : 0;
      if (smash) { b.kx *= 0.3; b.ky *= 0.3; }
      if (!big && b.kind !== "dog" && (head || crit || (bat && rand() < 0.55) || (wid === "sniper" && rand() < 0.5))) {
        // the head comes off
        b.noHead = true;
        this.heads++;
        if (smash) {
          for (let k = 0; k < 7; k++) this.gib(b.x, b.y - 2, k < 3 ? 3 : k < 6 ? 1 : 2, rand() * PI2, 95, 150);
          for (let k = 0; k < 3; k++) this.bleed(b.x, b.y, rand() * PI2, 4, 80);
          this.pool(b.x, b.y + 2, 8);
          g.say(b.x, b.y - 30, "REMUK!", "#ff6b7a");
        } else {
          this.gib(b.x, b.y, 0, ang, bat ? 190 : 105, bat ? 170 : 150, b);
          for (let k = 0; k < 2; k++) this.gib(b.x, b.y, 3, ang, 110, 150);
          g.say(b.x, b.y - 30, bat ? "HOMERUN!" : wid === "karambit" ? "PENGGAL!" : "HEADSHOT!", bat ? "#8af0ff" : "#ff6b7a");
        }
        g.puff(b.x, b.y - 8 * S, 9, GOO, 34, { z: 10, vz: 140, max: 0.7, size: 2, grav: 330, stamp: true });
        g.snd("crack", b.x, b.y, 1);
        if (by?.isPlayer) {
          g.talk.headshot(smash);
          g.hitStop = Math.max(g.hitStop, smash ? 0.07 : 0.04);
          if (this.heads % 10 === 0) { g.streak = { id: g.ids++, text: `${this.heads} HEADSHOT!` }; g.streakT = 1.6; }
        }
        g.hudDirty = true;
      }
      this.corpses.push(b);
    }
    if (big) {
      g.shake(b.kind === "titan" ? 10 : 6, b.x, b.y);
      g.rings.push({ x: b.x, y: b.y, life: 0, r: b.kind === "titan" ? 60 : 30 });
      g.say(b.x, b.y - 30, `${info.name} TUMBANG!`, "#ffe45c");
      g.feed.push({ id: g.ids++, killer: by ? by.name : "LEDAKAN", killerTeam: 0, victim: info.name, victimTeam: 1, weapon: wid, tag: "", me: !!by?.isPlayer, t: g.t });
      if (g.feed.length > 5) g.feed.shift();
      if (b.kind === "titan" || b.kind === "tank") {
        if (this.boss === b) this.boss = null;
        g.slowT = 1.4; g.zoom = 0.08; g.whiteT = 0.12;
        for (let k = 0; k < 2; k++) g.pickups.push({ x: b.x + (rand() - 0.5) * 30, y: b.y + (rand() - 0.5) * 20, t: 0 });
        g.setBanner(b.kind === "tank" ? "TANK TUMBANG!" : "MUTAN TUMBANG!", b.kind === "tank" ? "Jalan terbuka lagi" : "Tetap bertahan!", "gold", 2.4);
        g.talk.say("bossDead", { force: true, cd: 0 });
      }
      g.hudDirty = true;
    }
    if (by?.isPlayer) {
      g.killMark = 0.25;
      if (wid === "shotgun" || wid === "sniper" || wid === "goldgun") g.hitStop = Math.max(g.hitStop, 0.045); // the kill lands with weight
      if (big) { g.zoom = Math.max(g.zoom, 0.05); g.hitStop = Math.max(g.hitStop, 0.08); }
      this.combo++;
      this.comboT = 2.6;
      const n = this.combo;
      if (n === 10) g.talk.say("combo", { cd: 30 });
      if (n === 5 || n === 10 || n === 15 || (n >= 20 && n % 10 === 0)) {
        g.streak = { id: g.ids++, text: `COMBO x${n}!` };
        g.streakT = 1.6;
        g.hudDirty = true;
      }
    }
    if (this.kills % 3 === 0) g.hudDirty = true;
  }

  /** bullet vs zombies; returns true when the bullet is consumed. A path through the head is a headshot. */
  hitBullet(b: Bullet): boolean {
    for (const m of this.bugs) {
      if (b.hit.includes(m.id)) continue;
      const S = this.scale(m), R = BUG[m.kind].r + 3, hr = 3.8 * S;
      const dx = m.x - b.x, dy = m.y - 2 - b.y, hy = m.y - 9 * S - b.y;
      const dogK = m.kind === "dog", inHead = !dogK && dx * dx + hy * hy < hr * hr;
      if (!inHead && dx * dx + dy * dy >= R * R) continue;
      if (b.wid === "bazooka") return true;
      const w = WEAPONS[b.wid];
      // brutes wear riot helmets
      // where the shot goes in decides everything: the head ends it fast, limbs soak it up (and brutes wear riot helmets)
      const part = this.partOf(m, b, S, inHead), head = part === 0 && m.kind !== "charger";
      const mul = head ? (m.kind === "titan" ? 1.8 : m.kind === "tank" ? 1.6 : b.wid === "shotgun" ? 2 : 3) : part === 2 ? 0.35 : part === 3 ? 0.4 : 1; // a limb shot barely touches its life: it costs it the limb
      const fall = w.pellets > 1 ? 0.55 + 0.45 * clamp(b.life / b.max, 0, 1) : 1;
      this.hurt(m, b.dmg * fall * mul, b.owner, b.wid, Math.atan2(b.dy, b.dx), w.knock, false, head, part);
      if (b.pierce) { b.hit.push(m.id); continue; }
      return true;
    }
    return false;
  }

  /** explosions shred zombies and ignore armour */
  blast(x: number, y: number, by: Fighter | null, R: number, dmg: number, knock: number, wid: Hurt) {
    if (dmg > 0) {
      for (const m of this.bugs.slice()) {
        const dx = m.x - x, dy = m.y - y, d = Math.hypot(dx, dy), rr = R + BUG[m.kind].r;
        if (d < rr) this.hurt(m, dmg * 1.5 * (1 - d / (rr * 1.5)), by, wid, Math.atan2(dy, dx), knock, true);
      }
    }
    for (const c of this.corpses) {
      const dx = c.x - x, dy = c.y - y, d = Math.hypot(dx, dy) || 1;
      if (d < R && c.kind !== "titan") { c.kx += (dx / d) * 110; c.ky += (dy / d) * 110; c.vz = 120; c.z = Math.max(c.z, 1); c.rest = false; c.vrot = (rand() - 0.5) * 30; }
    }
  }

  /** melee vs zombies. kind 2 = overhead smash (narrow, always the head), 3 = spin (all around). Each zombie is hit once per swing. */
  melee(f: Fighter, w: WeaponDef, kind: number, skip: number[]): boolean {
    const g = this.g, smash = kind === 2, spin = kind === 3, range = w.range + (smash ? 6 : spin ? 7 : 0), arc = smash ? 1.2 : spin ? 7 : kind === 4 ? 4.8 : w.arc;
    const blunt = isBat(w.id), sweep = kind === 4;
    let hit = false;
    // nearest first: a bat, a stick, a hammer or an axe stops in the second body it meets
    const cand = this.bugs.filter((m) => !skip.includes(m.id) && (m.fat ?? 0) <= 0).sort((p, q) => Math.hypot(p.x - f.x, p.y - f.y) - Math.hypot(q.x - f.x, q.y - f.y));
    for (const m of cand) {
      if (blunt && skip.length >= (smash ? 99 : spin || sweep ? 4 : 2)) break; // the finishers reach further into the crowd
      const dx = m.x - f.x, dy = m.y - f.y, d = Math.hypot(dx, dy);
      if (d > range + BUG[m.kind].r + 4) continue;
      // forgiving cone: a fat target counts even when you only brush its edge
      if (d > 16 && Math.abs(angDiff(f.aim, Math.atan2(dy, dx))) > arc / 2 + Math.atan2(BUG[m.kind].r + 3, d)) continue;
      if (!los(f.x, f.y, m.x, m.y)) continue;
      skip.push(m.id);
      const back = w.id === "karambit" && Math.cos(angDiff(f.aim, m.aim)) > 0.35, light = BUG[m.kind].mass < 5, a = Math.atan2(dy, dx);
      let dmg = w.dmg * (back ? 3 : smash ? 2.6 : spin ? 1.8 : 1.2), crit = false, head = smash && m.kind !== "charger";
      if (blunt && light) {
        // it takes two or three good blows to put one down - unless the first one lands just right
        crit = !smash && !sweep && rand() < (w.id === "hammer" ? 0.24 : 0.14);
        const tough = m.tier === 2; // the hard ones shrug off four or five blows, and even a perfect hit only halves them
        dmg = crit ? (tough ? m.max * 0.5 : Math.ceil(m.hp) + 1)
          : tough ? m.max * (smash ? 0.42 : spin ? 0.36 : sweep ? 0.18 : 0.2 + rand() * 0.055)
          : m.max * (smash ? 0.78 : spin ? 0.66 : sweep ? 0.3 : 0.4 + rand() * 0.22) * (w.id === "hammer" ? 1.12 : w.id === "hockey" ? 0.92 : 1);
      }
      if (m.state === "sleep" && m.herd === undefined && light) dmg = Math.max(dmg, Math.ceil(m.hp) + 1); // caught asleep: one blow
      g.meleeFx(m.x, m.y, a, w.id, crit ? 2 : kind, f);
      this.hurt(m, dmg, f, w.id, a, crit ? w.knock * 1.5 : smash ? 30 : spin ? w.knock * 1.6 : w.knock, back || smash, head, head ? 0 : 1, crit);
      if (m.alive && light && m.kind !== "dog" && w.id === "axe" && rand() < (spin ? 0.85 : 0.4)) {
        // the axe takes limbs
        this.sever(m, rand() < 0.5 ? 0 : 1, a);
        if (f.isPlayer) g.say(m.x, m.y - 26, "TANGAN PUTUS!", "#ff9a3c");
      }
      if (sweep && m.alive && light && m.kind !== "dog" && m.state !== "down" && m.state !== "sleep") { m.state = "down"; m.stT = 1.1 + rand() * 0.5; m.vrot = dx >= 0 ? 1 : -1; m.rot = 0; m.chomp = 0; } // legs swept away
      hit = true;
    }
    return hit;
  }

  /** shockwave: everything close by staggers and gets shoved away */
  shock(x: number, y: number, R: number) {
    for (const m of this.bugs) {
      const dx = m.x - x, dy = m.y - y, d = Math.hypot(dx, dy) || 1, info = BUG[m.kind];
      if (d > R + info.r || info.mass > 5 || m.state === "sleep") continue;
      m.kx += (dx / d) * 150; m.ky += (dy / d) * 150;
      m.hitT = Math.max(m.hitT, 0.35); m.tilt = dx >= 0 ? 0.7 : -0.7; m.atk = Math.max(m.atk, 0.5);
      if (m.kind !== "dog" && m.state !== "down") { m.state = "down"; m.stT = 0.8 + rand() * 0.5; m.vrot = dx >= 0 ? 1 : -1; m.rot = 0; } // the shockwave floors them
    }
  }

  /* ───────────── air support ───────────── */
  useStrat(n: number) {
    const g = this.g, p = g.player;
    if (!p || !p.alive || g.phase !== "live" || g.paused || this.cd[n] > 0) return;
    const c = Math.cos(p.aim), s = Math.sin(p.aim);
    if (n === 0) {
      let tx = g.useTouch ? p.x + c * 100 : g.mx + g.cl, ty = g.useTouch ? p.y + s * 100 : g.my + g.ct;
      const d = Math.hypot(tx - p.x, ty - p.y);
      if (d > 230) { tx = p.x + ((tx - p.x) / d) * 230; ty = p.y + ((ty - p.y) / d) * 230; }
      tx = clamp(tx, 20, MW * TILE - 20); ty = clamp(ty, 20, MH * TILE - 20);
      this.strikes.push({ x: tx, y: ty, t: 0, n: 0, beeps: 0, by: p, hits: [] });
      g.say(p.x, p.y - 30, "RUDAL!", "#ff6b7a");
    } else {
      let tx = p.x + c * 24, ty = p.y + s * 24;
      if (solidAt(tx, ty)) { tx = p.x; ty = p.y + 3; }
      this.pods.push({ x: tx, y: ty, t: -0.15, landed: false });
      g.say(p.x, p.y - 30, "TURRET!", "#8af0ff");
    }
    this.cd[n] = STRAT_CD[n];
    g.snd("start", p.x, p.y, 0.8);
    g.hudDirty = true;
  }

  private sky() {
    return this.stage === 0 ? Math.min(2, this.count()) : this.stage === 1 ? 3 : 4;
  }

  hudInfo() {
    const p = this.g.player, ph = p ? houseAtPx(p.x, p.y) : -1;
    return {
      stage: this.stage, items: this.found.slice(),
      obj: `${this.g.art.ny ? "NYC" : "LV" + this.g.level} - ${this.stage === 0 ? (this.count() >= 3 ? "CARI PENYINTAS TERSEMBUNYI" : this.g.art.ny ? "BUKA 3 PETI SUPLAI BERTANDA" : GOAL[0]) : this.stage === 1 && !this.g.lastMap ? "NAIK PICKUP PUTIH" : GOAL[this.stage]}`,
      safe: ph < 0 || isStation(HOUSES[HOUSES[ph].under ?? ph]) ? 0 : this.safe >= 0 ? 3 : this.sealed >= 0 ? 2 : HOUSES[ph].under === undefined ? 1 : 0, // (the doors are on the ground floor)
      civ: this.civs.filter((c) => c.found && !c.lost).length, civN: this.civs.length, civD: this.civs.some((c) => c.found && !c.lost && c.f.down), level: this.g.level, evac: this.stage === 2 ? Math.max(0, Math.ceil(this.evacT)) : -1,
      kills: this.kills, strat: [clamp(1 - this.cd[0] / STRAT_CD[0], 0, 1), clamp(1 - this.cd[1] / STRAT_CD[1], 0, 1)] as [number, number],
      bossName: this.boss ? (this.boss.kind === "tank" ? "TANK" : "MUTAN RAKSASA") : "",
      boss: this.boss && this.boss.alive ? clamp(this.boss.hp / this.boss.max, 0, 1) : -1,
      weather: this.g.art.snow ? (this.fixed?.day ? "PAGI BERSALJU" : "SALJU") : (this.fixed ?? SKY[this.sky()]).name, bleed: p && p.down ? Math.max(0, Math.ceil(p.bleed)) : -1, heads: this.heads, floor: ph < 0 ? 0 : HOUSES[ph].lvl ? HOUSES[ph].lvl! : HOUSES[ph].under !== undefined ? 2 : HOUSES[ph].up !== undefined ? 1 : 0,
    };
  }

  /* ───────────── rendering ───────────── */
  drawGround() {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    // street holes glow toxic green
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < NESTS.length; i++) {
      const n = NESTS[i], k = 0.07 + 0.04 * Math.sin(t * 3 + i);
      if (n.x < cl - 40 || n.x > cl + g.W + 40 || n.y < ct - 40 || n.y > ct + g.H + 40) continue; // New York has a lot of them
      ctx.fillStyle = `rgba(110,255,90,${k.toFixed(3)})`;
      for (let q = 1; q <= 3; q++) { ctx.beginPath(); ctx.ellipse(n.x - cl, n.y + 2 - ct, 8 * q, 5 * q, 0, 0, PI2); ctx.fill(); }
    }
    ctx.globalCompositeOperation = "source-over";
    // the evac zone calls you back
    if (this.stage === 1 || (this.stage === 3 && this.heliT >= 1)) {
      const x = Math.round(this.goalX) - cl, y = Math.round(this.goalY) - ct, k = (t * 0.8) % 1;
      ctx.strokeStyle = "#7dff9a";
      ctx.lineWidth = 2;
      ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.ellipse(x, y, 30 + 46 * k, 22 + 34 * k, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    // mortar landing zones
    for (const m of this.mortars) {
      if (m.t < 0) continue;
      const k = m.t / m.dur, x = Math.round(m.x) - cl, y = Math.round(m.y) - ct;
      ctx.fillStyle = m.rock ? `rgba(255,120,60,${(0.12 + 0.25 * k).toFixed(3)})` : `rgba(134,240,78,${(0.12 + 0.25 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y, 28 * k, 20 * k, 0, 0, PI2); ctx.fill();
      ctx.strokeStyle = m.rock ? (Math.sin(t * 30) > 0 ? "#ffd0a0" : "#ff7a3c") : Math.sin(t * 30) > 0 ? "#d9ffa0" : "#6fdc3e";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 28, 20, 0, 0, PI2); ctx.stroke();
    }
    // rocket target markers
    for (const s of this.strikes) {
      if (s.t > 1.3) continue;
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct, k = (s.t * 3) % 1;
      ctx.strokeStyle = "#ff4d5e";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 50, 38, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 50 * k, 38 * k, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#ff4d5e";
      ctx.fillRect(x - 6, y, 13, 1); ctx.fillRect(x, y - 6, 1, 13);
    }
    // ground splitting open
    for (const br of this.breaches) {
      const k = br.t / 1.6, x = Math.round(br.x) - cl + Math.round(Math.sin(t * 50)), y = Math.round(br.y) - ct;
      ctx.fillStyle = "#120a1c";
      ctx.beginPath(); ctx.ellipse(x, y, 6 + 12 * k, 4 + 8 * k, 0, 0, PI2); ctx.fill();
      ctx.fillStyle = `rgba(255,122,60,${(0.3 + 0.5 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 1, 3 + 7 * k, 2 + 4 * k, 0, 0, PI2); ctx.fill();
      ctx.fillStyle = "#120a1c";
      for (let i = 0; i < 7; i++) { const a = i * 0.9 + br.x; ctx.fillRect(x + Math.round(Math.cos(a) * (10 + 16 * k)), y + Math.round(Math.sin(a) * (7 + 10 * k)), 4, 1); }
    }
    // incoming pod shadows
    for (const p of this.pods) {
      if (p.landed || p.t < -0.25) continue;
      const k = clamp((p.t + 0.25) / (POD_T + 0.25), 0, 1), x = Math.round(p.x) - cl, y = Math.round(p.y) - ct;
      ctx.fillStyle = `rgba(0,0,0,${(0.15 + 0.3 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 4, 4 + 8 * k, 2 + 4 * k, 0, 0, PI2); ctx.fill();
      ctx.strokeStyle = "#f5c542";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 4.5, 14, 9, 0, 0, PI2); ctx.stroke();
    }
    // helicopter shadow
    if (this.stage >= 3) {
      const k = this.heliT, x = Math.round(this.padX) - cl, y = Math.round(this.padY) - ct;
      ctx.fillStyle = `rgba(0,0,0,${(0.12 + 0.3 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 8, 18 + 22 * k, 7 + 9 * k, 0, 0, PI2); ctx.fill();
    }
  }

  addSortables(list: Sortable[]) {
    for (const b of this.bugs) list.push({ y: b.y + (b.kind === "titan" ? 8 : 0), bug: b });
    for (const c of this.corpses) list.push({ y: c.y, bug: c });
    for (const t of this.turrets) list.push({ y: t.y, tur: t });
    for (const p of this.pods) if (p.landed) list.push({ y: p.y, pod: p });
    list.push({ y: TRUCK.y + 9, truck: true });
    for (const k of this.shut) list.push({ y: (((k / MW) | 0) + 1) * TILE - 0.5, door: k });
    for (const w of WINDOWS) if (this.g.roofA[w.house] < 0.5) list.push({ y: (w.ty + 1) * TILE - 0.4, win: w }); // only from the inside: outside, the roof hides the walls
    const g = this.g;
    if (g.art.ny) for (const b of this.boxes) if (b.house < 0 && b.x > g.cl - 20 && b.x < g.cl + g.W + 20 && b.y > g.ct - 20 && b.y < g.ct + g.H + 20) list.push({ y: b.y + 3, box: b });
  }

  drawSortable(it: Sortable) {
    const g = this.g, ctx = g.ctx;
    if (it.bug) { this.drawBug(it.bug); return; }
    if (it.truck) { this.drawTruck(); return; }
    if (it.door !== undefined) { this.drawDoor(it.door); return; }
    if (it.win) { this.drawWindow(it.win); return; }
    if (it.box) { this.drawCrate(it.box); return; }
    if (it.tur) {
      const t = it.tur, x = Math.round(t.x) - g.cl, y = Math.round(t.y) - g.ct;
      const blink = t.life < 4 && Math.sin(g.t * 20) > 0;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x - 7, y + 3, 14, 3);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 7, y + 1, 3, 4); ctx.fillRect(x + 4, y + 1, 3, 4); ctx.fillRect(x - 5, y - 5, 10, 8);
      ctx.fillStyle = "#5c6675";
      ctx.fillRect(x - 6, y + 2, 1, 2); ctx.fillRect(x + 5, y + 2, 1, 2); ctx.fillRect(x - 4, y - 4, 8, 6);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 4, y, 8, 1);
      ctx.fillStyle = blink ? "#ff4d5e" : "#5ff0e0";
      ctx.fillRect(x - 1, y - 3, 2, 2);
      ctx.save();
      ctx.translate(x, y - 6);
      ctx.rotate(t.aim);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(-4, -3, 15, 6);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(-3, -2, 7, 4);
      ctx.fillStyle = "#737a96";
      ctx.fillRect(4, -1, 6, 2);
      if (t.flash > 0) { ctx.fillStyle = "#ffd75e"; ctx.fillRect(10, -2, 5, 4); ctx.fillStyle = "#ffffff"; ctx.fillRect(10, -1, 3, 2); }
      ctx.restore();
      return;
    }
    if (it.pod) {
      // landed supply pod shell
      const p = it.pod, x = Math.round(p.x) - g.cl, y = Math.round(p.y) - g.ct;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 6, y - 14, 12, 19);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(x - 5, y - 13, 10, 17);
      ctx.fillStyle = "#8d949e";
      ctx.fillRect(x + 1, y - 13, 4, 17);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 5, y - 9, 10, 3);
      ctx.fillStyle = "#1a1a22";
      ctx.fillRect(x - 3, y - 4, 6, 7);
      ctx.fillStyle = "#5ff0e0";
      ctx.fillRect(x - 1, y - 12, 2, 2);
    }
  }

  private drawBug(b: Bug) {
    const g = this.g, ctx = g.ctx;
    const x = Math.round(b.x) - g.cl, y = Math.round(b.y) - g.ct;
    if (x < -70 || x > g.W + 70 || y < -70 || y > g.H + 70) return;
    const vs = this.sp[b.kind], S = vs[b.v % vs.length].s, dead = !b.alive;
    const white = b.flash > 0 || (b.state === "wind" && Math.sin(b.t * 45) > 0);
    const sw = Math.max(3, Math.round(5 * S - (dead ? b.z * 0.1 : 0)));
    ctx.fillStyle = "rgba(0,0,0,0.32)";
    ctx.fillRect(x - sw, y + 4, sw * 2, Math.max(2, Math.round(2 * S)));
    if (dead) {
      // ragdoll: tumbling through the air, then sliding to a stop
      ctx.save();
      // convulsions: the whole body shudders, harder at first, then it ebbs away
      const cv = b.rest ? Math.min(1, (b.spasm ?? 0) / 0.45) : (b.spasm ?? 0) > 0 ? 0.5 : 0;
      ctx.translate(x + (cv ? Math.round(Math.sin(g.t * 63 + b.id) * 1.3 * cv) : 0), y + (cv ? Math.round(Math.cos(g.t * 51 + b.id) * 0.8 * cv) : 0) + (b.atk > 0 ? 2 : 0) + Math.round((b.sag ?? 0) * 3 * S) - Math.round(b.z + 4 * S * (1 - Math.min(1, b.deadT / 0.2))));
      ctx.rotate(b.rot + (cv ? Math.sin(g.t * 47 + b.id * 3) * 0.14 * cv : 0));
      this.figure(ctx, 0, 0, b, true, false);
      ctx.restore();
      return;
    }
    if (b.state === "down") {
      // flat on the floor, then pushing itself back up
      ctx.save();
      ctx.translate(x, y + 2 - Math.round(4 * S * (1 - Math.abs(b.rot) / 1.5708)));
      ctx.rotate(b.rot);
      this.figure(ctx, 0, 0, b, true, white);
      ctx.restore();
      return;
    }
    if ((b.limp ?? 0) >= 2) {
      // a leg is gone: it drags itself along the ground on its arms
      const fc = Math.cos(b.aim) < 0 ? -1 : 1;
      ctx.save();
      ctx.translate(x + Math.round(Math.sin(b.t * 6) * 1.2) * fc, y + 2);
      ctx.rotate(fc * 1.45);
      this.figure(ctx, 0, 0, b, true, white);
      ctx.restore();
      return;
    }
    let ox = 0, oy = 0;
    if (b.state === "wind") ox = Math.round(Math.sin(b.t * 60) * 1.3);
    if (b.bite > 0) { ox += Math.round(Math.cos(b.aim) * 3); oy += Math.round(Math.sin(b.aim) * 2); }
    if (b.state === "emerge") { ctx.globalAlpha = 1 - (b.stT / 0.5) * 0.5; oy += Math.round(b.stT * 18); }
    this.figure(ctx, x + ox, y + 5 + oy, b, false, white);
    ctx.globalAlpha = 1;
    const top = y + 3 - Math.round(20 * S);
    if (b.state === "stun")
      for (let i = 0; i < 3; i++) {
        const a = g.t * 6 + i * 2.094;
        ctx.fillStyle = i ? "#ffe45c" : "#ffffff";
        ctx.fillRect(x + Math.round(Math.cos(a) * 9), top + Math.round(Math.sin(a) * 3), 2, 2);
      }
    if (b.kind === "spitter" && b.state === "wind") {
      ctx.fillStyle = "#d9ffa0";
      ctx.fillRect(x + (Math.cos(b.aim) < 0 ? -5 : 3), y + 5 - Math.round(11 * S), 3, 3);
    }
    if (b.hp < b.max && b.kind !== "titan" && b.kind !== "tank" && (b.kind !== "scav" || b.tier === 2) && (b.kind !== "dog" || b.tier === 2)) {
      const bw = b.kind === "charger" ? 18 : 12;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - bw / 2 - 1, top - 3, bw + 2, 3);
      ctx.fillStyle = "#ff9a3c";
      ctx.fillRect(x - bw / 2, top - 2, Math.max(1, Math.round((b.hp / b.max) * bw)), 1);
    }
  }

  /** a human zombie: shambling legs, swaying body, arms stretched out towards its prey. (x, y) = feet, or body centre when dead */
  private figure(ctx: CanvasRenderingContext2D, x: number, y: number, b: Bug, dead: boolean, white: boolean) {
    if (b.kind === "dog") { this.dog(ctx, x, y, b, dead, white); return; }
    const vs = this.sp[b.kind], v = vs[b.v % vs.length], S = v.s, img = white ? v.white : v.img, t = this.g.t;
    const w = img.width, h = img.height, hh = Math.round(10 * S), face = Math.cos(b.aim) < 0 ? -1 : 1;
    const asleep = b.state === "sleep" && b.herd === undefined, hit = !dead && b.hitT > 0, fl = dead && !b.rest && b.z > 0 ? 1 : 0;
    const trS = b.tr ?? 0, tr = white ? 0 : trS, tx0 = -(w >> 1), P = (n: number) => Math.round(n * S);
    const run = b.kind === "warrior" || b.state === "charge" || !!b.fast || b.kind === "tank";
    const moving = !dead && (Math.hypot(b.vx, b.vy) > 6 || b.state === "charge");
    const step = moving ? Math.sin(b.t * (b.kind === "tank" ? 13 : run ? 22 : b.kind === "titan" ? 5 : 10)) : 0;
    const leg = Math.round(3 * S), lw = Math.max(2, Math.round(2 * S)), o1 = Math.round(S), dark = white ? "#ffffff" : "#0d0a0c";
    ctx.save();
    ctx.translate(Math.round(x), Math.round(y) + (dead ? (leg + h) >> 1 : 0));
    if (b.bw && (b.bw !== 1 || b.bh !== 1)) ctx.scale(b.bw, b.bh ?? 1);
    if (!dead && (b.pop ?? 0) > 0) { const pk = b.pop! / 0.12; ctx.scale(1 + 0.24 * pk, 1 - 0.2 * pk); }
    if (!dead) ctx.rotate(b.tilt * 0.6 + (asleep ? Math.sin(b.t * 1.6 + b.id) * 0.07 : run ? face * 0.26 : Math.sin(b.t * 2.1 + b.id) * 0.035 + (b.bite > 0 ? face * 0.16 : 0) + ((b.chomp ?? 0) > 0 ? face * 0.2 * Math.sin(clamp(1 - (b.chomp ?? 0) / 0.5, 0, 1) * Math.PI) : 0)) / Math.sqrt(S));
    if (!dead) {
      if (trS & 16) ctx.rotate(face * 0.3); // bent double, head first
      const wb = b.wob ?? 0;
      if (wb > 0.03) ctx.rotate(Math.sin(t * 24 + b.id) * 0.26 * wb); // rocking on its feet after a hit
      if (b.limp === 1 && moving) { ctx.rotate(Math.sin(b.t * 5.2) * 0.13); ctx.translate(0, Math.round(Math.max(0, -Math.sin(b.t * 5.2)) * 2)); } // dragging a ruined leg
    }
    // legs: shuffle when walking, kick while flying through the air
    const lx = Math.round(step * 1.5 * S), k1 = fl * Math.round(Math.sin(t * 24 + b.id) * 2 * S) + (dead && b.rest ? Math.round(b.t2 * S) : 0), k2 = fl * Math.round(Math.cos(t * 21 + b.id) * 2 * S);
    ctx.fillStyle = white ? "#ffffff" : v.pants;
    if (dead) {
      // a corpse never lies with straight legs: knees drift apart, one foot turns in
      const P = (b.pose ?? b.id) % 4, spl = [[-4, 3], [-2, 5], [-5, -1], [-3, 1]][P], bnd = [[2, -1], [-3, 2], [1, 4], [-2, -3]][P];
      for (let j = 0; j < 2; j++) {
        if (j && (b.limp ?? 0) >= 2) { ctx.fillStyle = white ? "#ffffff" : "#8a1420"; ctx.fillRect(o1, -leg, lw, 2); continue; } // a stump where the leg was
        const hx = (j ? o1 : -Math.round(3 * S)) + 1, kx = hx + bnd[j] * S, fx = hx + spl[j] * S + (j ? k2 : k1);
        pline(ctx, hx, -leg, kx, -Math.round(leg * 0.5), lw);
        pline(ctx, kx, -Math.round(leg * 0.5), fx, -1, lw);
      }
    } else {
      ctx.fillRect(-Math.round(3 * S) + lx + k1, -leg - (step > 0.4 ? 1 : 0), lw, leg);
      ctx.fillRect(o1 - lx + k2, -leg - (step < -0.4 ? 1 : 0), lw, leg);
    }
    // torso, then the head: it snaps back when hit, and it may be gone altogether
    const ty = -leg - (h - hh) + (moving && Math.abs(step) > 0.55 ? 1 : 0) + (asleep ? 1 : 0);
    ctx.save();
    ctx.scale(face, 1);
    ctx.drawImage(img, 0, hh, w, h - hh, -(w >> 1), ty, w, h - hh);
    if (b.kind === "tank") {
      // slabs of muscle: shoulders far wider than the waist (the body tapers down to it), a split chest, veins standing out
      ctx.fillStyle = dark; ctx.fillRect(-(w >> 1) - 7, ty - 4, w + 14, 11); ctx.fillRect(-(w >> 1) - 3, ty + 6, w + 6, 4);
      ctx.fillStyle = white ? "#ffffff" : v.skin; ctx.fillRect(-(w >> 1) - 6, ty - 3, w + 12, 9); ctx.fillRect(-(w >> 1) - 2, ty + 6, w + 4, 3);
      if (!white) {
        ctx.fillStyle = "#e8b8a8"; ctx.fillRect(-(w >> 1) - 5, ty - 3, w + 10, 2);
        ctx.fillStyle = "#8f5c50"; ctx.fillRect(-(w >> 1) - 6, ty + 4, w + 12, 2); ctx.fillRect(-1, ty - 1, 2, 8); ctx.fillRect(-(w >> 1) + 1, ty + 7, w - 2, 1);
        ctx.fillStyle = "#a8202c"; ctx.fillRect(-(w >> 1) - 3, ty, 4, 1); ctx.fillRect((w >> 1) - 2, ty + 1, 4, 1); ctx.fillRect(-(w >> 1) + 4, ty + 2, 1, 3);
      }
    }
    if (!b.noHead) {
      // the bite: the head rears back, then snaps forward and down onto the prey
      const cp = (b.chomp ?? 0) > 0 ? clamp(1 - (b.chomp ?? 0) / 0.5, 0, 1) : -1;
      const lunge = cp < 0 ? 0 : cp < 0.4 ? -1.6 * (cp / 0.4) : cp < 0.6 ? -1.6 + 6.4 * ((cp - 0.4) / 0.2) : 4.8 * (1 - (cp - 0.6) / 0.4);
      const hx = -(w >> 1) + (hit ? Math.round(face * Math.sign(b.tilt) * 2 * S) : 0) + Math.round(lunge * S), hy = ty - hh - (hit ? o1 : 0) + (cp > 0.45 && cp < 0.85 ? o1 : 0), P = (n: number) => Math.round(n * S);
      // a broken neck lets the head loll to one side; a twitcher's head jerks
      const nk = trS & 2 ? (b.id & 1 ? 0.5 : -0.5) + Math.sin(b.t * 2.2 + b.id) * 0.08 : trS & 512 && Math.sin(t * 23 + b.id) > 0.8 ? 0.32 : 0;
      if (nk) { ctx.save(); ctx.translate(hx + (w >> 1), hy + hh); ctx.rotate(nk); ctx.translate(-(hx + (w >> 1)), -(hy + hh)); }
      if (b.kind === "tank") ctx.drawImage(img, 0, 0, w, hh, hx + Math.round(w * 0.2), hy + Math.round(hh * 0.3), Math.round(w * 0.6), Math.round(hh * 0.6)); // a small head, sunk between the shoulders
      else ctx.drawImage(img, 0, 0, w, hh, hx, hy, w, hh);
      if (!white && b.kind !== "tank") {
        // the face: jaws work when it bites or moans, eyes screw shut when it is hurt, brows drop when it attacks
        const pain = hit || dead || b.state === "down", gape = pain || b.bite > 0 || run || Math.sin(b.t * 2.6 + b.id) > 0.45;
        if (cp >= 0 && cp < 0.62) {
          // jaws gape wide, teeth bared, before they snap shut
          const open = cp < 0.4 ? 1 + (cp / 0.4) * 2 : 3;
          ctx.fillStyle = "#3a0810"; ctx.fillRect(hx + P(3), hy + P(7), P(8), Math.max(2, P(open)));
          ctx.fillStyle = "#e9e2c8"; ctx.fillRect(hx + P(4), hy + P(7), P(1), o1 + 1); ctx.fillRect(hx + P(7), hy + P(7), P(1), o1 + 1); ctx.fillRect(hx + P(9), hy + P(7), P(1), o1 + 1);
        } else if (cp >= 0.62) { ctx.fillStyle = "#8a1420"; ctx.fillRect(hx + P(4), hy + P(8), P(6), o1); } // blood on the lips after the bite
        else if (gape) { ctx.fillStyle = "#3a0810"; ctx.fillRect(hx + P(4), hy + P(8), P(6), Math.max(1, P(pain || b.bite > 0 ? 2 : 1))); }
        if (pain || asleep) { ctx.fillStyle = "#241014"; ctx.fillRect(hx + P(2), hy + P(5), P(3), o1); ctx.fillRect(hx + P(8), hy + P(5), P(3), o1); }
        else if (b.bite > 0 || b.state === "wind" || b.state === "charge" || run) { ctx.fillStyle = "#0d0a0c"; ctx.fillRect(hx + P(2), hy + P(4), P(2), o1); ctx.fillRect(hx + P(9), hy + P(4), P(2), o1); }
      }
      if (tr & 1 && cp < 0) {
        // the jaw hangs open for good: a black hole with teeth round it, a tongue, the chin swinging below
        const jo = P(3) + (Math.sin(b.t * 3 + b.id) > 0 ? o1 : 0);
        ctx.fillStyle = "#22040a"; ctx.fillRect(hx + P(3), hy + P(7), P(8), jo);
        ctx.fillStyle = "#e9e2c8"; for (const q of [4, 6, 8, 10]) ctx.fillRect(hx + P(q) - o1, hy + P(7), o1, o1);
        ctx.fillStyle = "#b02a34"; ctx.fillRect(hx + P(5), hy + P(7) + jo - o1, P(3), o1);
        ctx.fillStyle = "#0d0a0c"; ctx.fillRect(hx + P(3), hy + P(7) + jo, P(8), o1 + 1);
        ctx.fillStyle = v.skin; ctx.fillRect(hx + P(4), hy + P(7) + jo, P(6), o1);
      }
      if (tr & 64) {
        // an eye gone: an empty socket, and what ran out of it
        ctx.fillStyle = "#12060a"; ctx.fillRect(hx + P(2), hy + P(4), P(3), P(2));
        ctx.fillStyle = "#8a1420"; ctx.fillRect(hx + P(3), hy + P(6), o1, P(2));
      }
      if (tr & 128) {
        // the skull is open
        ctx.fillStyle = "#8a1420"; ctx.fillRect(hx + P(4), hy + P(1), P(6), P(2));
        ctx.fillStyle = "#e88aa0"; ctx.fillRect(hx + P(4), hy, P(6), P(2));
        ctx.fillStyle = "#ffc0cc"; ctx.fillRect(hx + P(5), hy, P(2), o1);
      }
      if (nk) ctx.restore();
    }
    // what is left of the body: ribs laid open, guts swinging, whatever went through it
    if (tr & 4) {
      ctx.fillStyle = "#4a0a12"; ctx.fillRect(tx0 + P(4), ty + P(1), P(6), P(3));
      ctx.fillStyle = "#e9e2c8"; ctx.fillRect(tx0 + P(4), ty + P(1), P(6), o1); ctx.fillRect(tx0 + P(4), ty + P(3), P(6), o1);
      ctx.fillStyle = "#b9b3a0"; ctx.fillRect(tx0 + P(7) - o1, ty + P(1), o1, P(3));
    }
    if (tr & 8) {
      const gx = tx0 + P(6), gy = ty + P(4), sw = Math.round(Math.sin(b.t * 5 + b.id) * 1.6 * S);
      ctx.fillStyle = "#6e1420"; pline(ctx, gx, gy, gx + sw, gy + P(4), Math.max(2, P(2)));
      ctx.fillStyle = "#d04a4a"; ctx.fillRect(gx + sw - o1, gy + P(4), P(2), o1);
    }
    if (tr & 32) {
      ctx.fillStyle = "#0d0a0c"; pline(ctx, tx0 + P(1), ty - P(3), tx0 + P(12), ty + P(4), o1 + 2);
      ctx.fillStyle = "#aab2bd"; pline(ctx, tx0 + P(1), ty - P(3), tx0 + P(12), ty + P(4), o1);
      ctx.fillStyle = "#8a1420"; ctx.fillRect(tx0 + P(6), ty + P(1), P(2), o1);
    }
    ctx.restore();
    if (b.noHead) {
      ctx.fillStyle = white ? "#ffffff" : "#6e1420";
      ctx.fillRect(-Math.round(2 * S), ty - o1, Math.round(4 * S), o1 + 1);
      ctx.fillStyle = white ? "#ffffff" : "#d04a4a";
      ctx.fillRect(-o1, ty - o1, o1 * 2, o1);
    }
    // arms: loose two-part limbs driven by a little spring (see arms()), so they dangle, swing and flop instead of sticking out
    const sy = -leg - Math.round(5 * S), LEN = 6.4 * S, at = Math.max(2, Math.round(1.6 * S * (b.kind === "tank" ? 2.2 : 1)));
    for (let i = 0; i < 2; i++) {
      const o = i ? 1 : -1, x0 = o * Math.round(4 * S);
      if (((b.lost ?? 0) >> i) & 1) { ctx.fillStyle = white ? "#ffffff" : "#8a1420"; ctx.fillRect(x0 - 1, sy - 1, 2, 3); ctx.fillStyle = white ? "#ffffff" : "#d04a4a"; ctx.fillRect(x0 - 1, sy + 1, 2, 1); continue; } // a bleeding stump
      const ex = b.arm[i * 4] * S, ey = b.arm[i * 4 + 1] * S, d = Math.hypot(ex, ey) || 0.01;
      const x1 = x0 + ex, y1 = sy + ey;
      // elbow: the arm folds when the hand is closer than its full length
      const bend = d < LEN ? Math.sqrt((LEN * LEN - d * d) / 4) * 0.8 : 0;
      let nx = -ey / d, ny = ex / d;
      if (ny < 0) { nx = -nx; ny = -ny; }
      const xm = (x0 + x1) / 2 + nx * bend, ym = (sy + y1) / 2 + ny * bend;
      ctx.fillStyle = dark;
      pline(ctx, x0, sy, xm, ym, at + 2);
      pline(ctx, xm, ym, x1, y1, at + 2);
      ctx.fillStyle = white ? "#ffffff" : v.sleeve;
      pline(ctx, x0, sy, xm, ym, at);
      ctx.fillStyle = white ? "#ffffff" : v.skin;
      pline(ctx, xm, ym, x1, y1, at);
      if (b.kind === "tank") {
        // fists like paving stones
        const fx = Math.round(x1), fy = Math.round(y1);
        ctx.fillStyle = dark; ctx.fillRect(fx - 6, fy - 6, 12, 12);
        ctx.fillStyle = white ? "#ffffff" : v.skin; ctx.fillRect(fx - 5, fy - 5, 10, 10);
        ctx.fillStyle = white ? "#ffffff" : "#8f5c50"; ctx.fillRect(fx - 5, fy + 1, 10, 1); ctx.fillRect(fx - 1, fy - 5, 1, 6); ctx.fillRect(fx + 2, fy - 5, 1, 6);
      }
    }
    ctx.restore();
  }

  /** spring-driven hands in body space, [x, y, vx, vy] per arm: they reach for prey, go limp when hit, flail in the air and flop down at rest */
  private arms(b: Bug, dt: number, dead: boolean) {
    if (b.kind === "dog") return;
    const A = b.arm, t = this.g.t, air = dead && !b.rest && b.z > 0;
    for (let i = 0; i < 2; i++) {
      const o = i ? 1 : -1, n = i * 4;
      let tx: number, ty: number, k = 70, c = 8;
      if (!dead && (b.limp ?? 0) >= 2) { tx = o * 3; ty = -6 - 3 * Math.sin(b.t * 6 + i * Math.PI); k = 90; c = 10; } // crawling: one hand after the other
      else if (dead) {
        if (air) {
          const sp = Math.min(1, Math.abs(b.vrot) / 12);
          tx = o * (1.5 + 4.5 * sp) + Math.sin(t * 11 + i * 2.3 + b.id) * 1.5; ty = 4.5 - 6 * sp + Math.cos(t * 9 + i + b.id) * 1.5; k = 40; c = 5;
        } else {
          // every corpse ends up sprawled differently
          const P = (b.pose ?? b.id) % 4;
          if (P === 0) { tx = o * 7; ty = i ? -2.5 : 3.5; }             // flung wide
          else if (P === 1) { tx = o * 3.5; ty = i ? -4.5 : 2.5; }      // one hand by the head, one on the chest
          else if (P === 2) { tx = i ? 8 : 1.5; ty = i ? 1 : 4.5; }     // one arm flung out, the other under the body
          else { tx = o * 1.8; ty = 3 + i * 1.5; }                      // curled up
          k = 45; c = 6;
        }
      } else if (b.state === "sleep") { tx = o; ty = 5.5; k = 30; }
      else if (b.hitT > 0) { tx = o * 2 + Math.sin(t * 34 + i * 2.1 + b.id) * 3; ty = -2 + Math.cos(t * 29 + i + b.id) * 3.5; k = 26; c = 2.6; } // the hit throws the arms about: they flap loosely instead of staying stretched out
      else {
        if ((b.chomp ?? 0) > 0) { tx = Math.cos(b.aim) * 8.5; ty = Math.sin(b.aim) * 4 - 1.5 + (i ? 0.5 : -0.5); k = 160; c = 14; } // both hands grab for the victim
        else if ((b.tr ?? 0) & 256 && i === (b.id & 1)) { tx = o * 2.5 + Math.sin(b.t * 4 + b.id) * 1.2; ty = 6; k = 28; c = 3; } // one arm is dead weight
        else {
        const al = (b.bite > 0 ? 8 : 6) * (0.62 + 0.3 * Math.sin(b.t * 1.9 + b.id * 1.7 + i));
        tx = Math.cos(b.aim) * al; ty = Math.sin(b.aim) * 0.5 * al + Math.sin(b.t * 6 + o * 1.3 + b.id); k = 70; c = 9;
        }
      }
      A[n + 2] += (k * (tx - A[n]) - c * A[n + 2]) * dt;
      A[n + 3] += (k * (ty - A[n + 1]) - c * A[n + 3]) * dt;
      A[n] += A[n + 2] * dt;
      A[n + 1] += A[n + 3] * dt;
      const d = Math.hypot(A[n], A[n + 1]);
      if (d > 8.5) { A[n] *= 8.5 / d; A[n + 1] *= 8.5 / d; }
    }
  }

  /** zombie dog: all ribs, spine and teeth. Galloping legs with claws, hackles up and a crouch before the pounce, a jaw that hangs, snaps and drools. (x, y) = paws */
  private dog(ctx: CanvasRenderingContext2D, x: number, y: number, b: Bug, dead: boolean, white: boolean) {
    const vs = this.sp.dog, v = vs[b.v % vs.length], img = white ? v.white : v.img, t = this.g.t;
    const face = Math.cos(b.aim) < 0 ? -1 : 1, dark = white ? "#ffffff" : "#0d0a0c", fur = white ? "#ffffff" : v.skin, fur2 = white ? "#ffffff" : v.sleeve;
    const moving = !dead && (Math.hypot(b.vx, b.vy) > 8 || b.state === "charge"), lying = b.state === "sleep", wind = !dead && b.state === "wind", leap = !dead && b.state === "charge";
    ctx.save();
    ctx.translate(Math.round(x), Math.round(y) + (dead ? 6 : 0) - Math.round(b.lz));
    if (wind) ctx.rotate(face * 0.26); // crouched low in front, hindquarters up
    if (leap) ctx.rotate(-face * 0.3);
    ctx.scale(face, dead ? -1 : 1);
    const leg = lying ? 0 : 5, ph = b.t * 26, bob = moving && !leap ? Math.round(Math.sin(ph * 2) * 0.8) : 0;
    if (leg)
      for (let i = 0; i < 4; i++) {
        const lx = i < 2 ? -7 + i * 3 : 3 + (i - 2) * 3;
        const sw = leap ? (i < 2 ? -4 : 4) : moving ? Math.sin(ph + (i < 2 ? 0 : Math.PI) + (i % 2) * 0.9) * 3.4 : dead ? (i % 2 ? 2 : -1) : wind ? (i < 2 ? -1 : 2) : 0;
        ctx.fillStyle = dark;
        pline(ctx, lx, -leg, lx + sw, 0, 3);
        ctx.fillStyle = i % 2 ? fur2 : fur;
        pline(ctx, lx, -leg, lx + sw, -1, 1);
        // the paw, claws out
        ctx.fillStyle = dark;
        ctx.fillRect(Math.round(lx + sw) - 1, -1, 4, 2);
        if (!white) { ctx.fillStyle = "#e9e2c8"; ctx.fillRect(Math.round(lx + sw) + 2, 0, 1, 1); }
      }
    const by = -leg - 10 + (lying ? 2 : 0) + bob;
    ctx.drawImage(img, -11, by);
    // the lower jaw
    const open = dead ? 2 : lying ? 0 : leap ? 3 : b.bite > 0 ? (Math.sin(t * 40) > 0 ? 3 : 0) : wind ? 2 : Math.sin(b.t * 9 + b.id) > 0.2 ? 1 : 0;
    const jx = 4, jy = by + 7 + open;
    if (open && !white) {
      ctx.fillStyle = "#4a0a12"; ctx.fillRect(jx + 1, by + 7, 4, open); // down the throat
      ctx.fillStyle = "#c02a3a"; ctx.fillRect(jx + 1, jy - 1, 2, 1);    // tongue
    }
    ctx.fillStyle = dark; ctx.fillRect(jx, jy, 6, 3);
    ctx.fillStyle = fur2; ctx.fillRect(jx + 1, jy + 1, 4, 1);
    if (!white) {
      ctx.fillStyle = "#f2ecd8"; ctx.fillRect(jx + 1, jy, 1, 1); ctx.fillRect(jx + 3, jy, 1, 1); ctx.fillRect(jx + 5, jy - 1, 1, 2); // lower fangs
      if (!lying && !dead) {
        // a string of drool
        const k = (t * 1.7 + b.id * 0.3) % 1;
        ctx.fillStyle = "#c8ded8"; ctx.fillRect(jx + 4, jy + 3 + Math.round(k * 4), 1, 2);
      }
      if (wind || leap) {
        // hackles: the fur along the spine stands up when it is about to jump
        ctx.fillStyle = v.skin;
        for (let i = 0; i < 6; i++) ctx.fillRect(-8 + i * 2, by + 1 + (i % 2), 1, 2);
      }
    }
    ctx.restore();
  }

  private drawGib(ctx: CanvasRenderingContext2D, q: Gib) {
    if (q.kind >= 4 && q.b) {
      // a severed arm (sleeve and hand) or leg
      const vs = this.sp[q.b.kind], v = vs[q.b.v % vs.length];
      ctx.fillStyle = "#0d0a0c"; ctx.fillRect(-5, -2, 10, 4);
      ctx.fillStyle = q.kind === 4 ? v.sleeve : v.pants; ctx.fillRect(-4, -1, 4, 2);
      ctx.fillStyle = q.kind === 4 ? v.skin : v.pants; ctx.fillRect(0, -1, 4, 2);
      ctx.fillStyle = "#a8202c"; ctx.fillRect(-5, -1, 1, 2);
      return;
    }
    if (q.kind === 0 && q.b) {
      const vs = this.sp[q.b.kind], v = vs[q.b.v % vs.length], hh = Math.round(10 * v.s), w = v.img.width;
      ctx.drawImage(v.img, 0, 0, w, hh, -(w >> 1), -(hh >> 1), w, hh);
      ctx.fillStyle = "#8a1420";
      ctx.fillRect(-2, (hh >> 1) - 1, 4, 2);
    } else if (q.kind === 2) {
      ctx.fillStyle = "#0d0a0c"; ctx.fillRect(-3, -1, 7, 3);
      ctx.fillStyle = "#e9e2c8"; ctx.fillRect(-2, 0, 5, 1);
      ctx.fillStyle = "#a8202c"; ctx.fillRect(2, 0, 1, 1);
    } else {
      ctx.fillStyle = "#0d0a0c"; ctx.fillRect(-2, -2, 5, 5);
      ctx.fillStyle = q.kind === 3 ? "#e88aa0" : "#a8202c"; ctx.fillRect(-1, -1, 3, 3);
      ctx.fillStyle = q.kind === 3 ? "#ffc0cc" : "#d04a4a"; ctx.fillRect(-1, -1, 2, 1);
    }
  }

  /* ───────────── atmosphere hooks ───────────── */
  /** current target weather (muffled while indoors) */
  weather(): Weather {
    let w = this.fixed ?? SKY[this.sky()];
    if (this.g.art.ny) w = { ...w, dark: w.dark * 0.82 }; // the avenues are wide and the towers pale: New York nights are a little brighter
    // the old town lies under snow: no rain, no thunder - just flakes and the cold
    if (this.g.art.snow) w = { dark: Math.min(w.dark, 0.74), fog: Math.min(0.5, w.fog + 0.1), rain: 0, bolt: 0, name: w.day ? "PAGI BERSALJU" : "SALJU", snow: this.g.inside ? 0 : 1, day: w.day };
    return this.g.inside ? { ...w, rain: w.rain * 0.12, fog: w.fog * 0.35, dark: Math.min(0.88, w.dark + 0.04) } : w;
  }

  /** 0..1 pulsing during the hold-out (alarm lights) */
  alarm() {
    return this.stage >= 2 ? 0.5 + 0.5 * Math.sin(this.g.t * 6) : 0;
  }

  /** everything that pushes the darkness back */
  lights(A: Atmosphere) {
    const g = this.g, cl = g.cl, ct = g.ct, t = g.t;
    NESTS.forEach((n, i) => A.light(n.x - cl, n.y - ct, 36, 0.35 + 0.12 * Math.sin(t * 3 + i)));
    {
      // the pickup: headlights, the light bar on the roof, the gun when it fires
      const tx = TRUCK.x + g.truckDX();
      A.light(tx - cl, TRUCK.y - ct, 58, 0.8);
      A.beam(tx + 30 - cl, TRUCK.y + 2 - ct, 0, 150, 0.9);
      A.light(tx + 6 - cl, TRUCK.y - 14 - ct, 28, 0.6);
    }
    for (const tu of this.turrets) { A.light(tu.x - cl, tu.y - ct - 4, 50, 0.9); A.beam(tu.x - cl, tu.y - ct - 6, tu.aim, 130, 0.9); }
    for (const p of this.pods) {
      if (p.t < 0) continue;
      if (p.landed) A.light(p.x - cl, p.y - ct, 58, 1);
      else A.light(p.x - cl, p.y - (1 - p.t / POD_T) * 300 - ct - 20, 46, 1);
    }
    for (const s of this.strikes) if (s.t < 1.25) A.light(s.x - cl, s.y - ct, 52, 0.55 + 0.25 * Math.sin(t * 20));
    for (const s of this.globs) A.light(s.x - cl, s.y - ct, 16, 0.8);
    for (const m of this.mortars) if (m.t >= 0) A.light(m.x - cl, m.y - ct, 30, 0.35 + 0.4 * (m.t / m.dur));
    for (const br of this.breaches) A.light(br.x - cl, br.y - ct, 44, 0.5 + 0.3 * Math.sin(t * 16));
    for (const b of this.bugs) if (b.state === "wind") A.light(b.x - cl, b.y - ct - 4, 24, 0.6);
    if (this.stage >= 3) A.light(this.padX - cl, this.padY - ct, 130, 0.5 + 0.5 * this.heliT);
    if (this.search) A.light(this.search.x - cl, this.search.y - ct - 6, 26, 0.7);
  }

  /** glowing things drawn on top of the darkness: dead eyes in the night, toxic holes, bile */
  glowPass(A: Atmosphere) {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    NESTS.forEach((n, i) => A.tint(ctx, n.x - cl, n.y + 2 - ct, 28, "g", 0.3 + 0.1 * Math.sin(t * 3 + i)));
    for (const br of this.breaches) A.tint(ctx, br.x - cl, br.y - ct, 34, "o", 0.5 + 0.3 * Math.sin(t * 16));
    for (const s of this.globs) A.tint(ctx, s.x - cl, s.y - ct, 12, "g", 0.6);
    for (const s of this.strikes) if (s.t < 1.25) A.tint(ctx, s.x - cl, s.y - ct, 40, "r", 0.3);
    const fo = g.focus();
    for (const b of this.bugs) {
      if (b.state === "emerge" || b.state === "down" || b.hitT > 0 || (b.limp ?? 0) >= 2 || g.hidden(b.x, b.y) || g.behind(b.x, b.y)) continue;
      const x = Math.round(b.x) - cl, y = Math.round(b.y) - ct;
      if (x < -40 || x > g.W + 40 || y < -20 || y > g.H + 70) continue;
      if (g.inK > 0.5 && houseAtPx(b.x, b.y) !== g.inHouse && !(fo && los(fo.x, fo.y, b.x, b.y))) continue; // indoors, the street is out of sight
      if (b.state === "sleep" && b.herd === undefined) {
        // eyes shut: only a soft snore gives it away
        if (fo && !los(fo.x, fo.y, b.x, b.y)) continue;
        const k = (t * 0.8 + b.id * 0.37) % 1;
        ctx.globalAlpha = 0.8 * (1 - k);
        drawText(ctx, "Z", x + 5 + k * 5, y - 16 - k * 9, "#9ab0ff");
        ctx.globalAlpha = 1;
        continue;
      }
      if (b.kind === "dog") {
        const fd = Math.cos(b.aim) < 0 ? -1 : 1, ey = y - 7 - Math.round(b.lz);
        ctx.fillStyle = "#ff3030";
        ctx.fillRect(x + fd * 7 - (fd < 0 ? 1 : 0), ey, 2, 1);
        A.tint(ctx, x + fd * 7, ey, 9, "r", 0.5);
        continue;
      }
      const vs = this.sp[b.kind], S = vs[b.v % vs.length].s, face = Math.cos(b.aim) < 0 ? -1 : 1, eye = b.fast ? EYE.warrior : EYE[b.kind];
      const ey = y + 5 - Math.round(3 * S) - Math.round(10.5 * S), e = Math.max(1, Math.round(S));
      ctx.fillStyle = eye[0];
      ctx.fillRect(x + Math.round(face * -3.5 * S) - (e >> 1), ey, e, e);
      ctx.fillRect(x + Math.round(face * 2.5 * S) - (e >> 1), ey, e, e);
      A.tint(ctx, x, ey, 6 * S + 2, eye[1], b.state === "sleep" ? 0.09 : b.fast ? 0.6 : 0.28); // a crowd of eyes glints, it does not floodlight the street
    }
  }

  /** flying things and mission markers drawn above the whole world */
  drawTop() {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    for (const s of this.globs) {
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      ctx.fillStyle = "#16300f";
      ctx.fillRect(x - 3, y - 3, 6, 6);
      ctx.fillStyle = "#6fdc3e";
      ctx.fillRect(x - 2, y - 2, 4, 4);
      ctx.fillStyle = "#e6ffc0";
      ctx.fillRect(x - 1, y - 2, 2, 1);
    }
    for (const m of this.mortars) {
      if (m.t < 0) continue;
      const k = m.t / m.dur;
      const x = Math.round(m.sx + (m.x - m.sx) * k) - cl, y = Math.round(m.sy + (m.y - m.sy) * k - Math.sin(k * Math.PI) * 90) - ct;
      ctx.fillStyle = m.rock ? "#15151b" : "#16300f";
      ctx.fillRect(x - 3, y - 5, 6, 10); ctx.fillRect(x - 5, y - 3, 10, 6); ctx.fillRect(x - 4, y - 4, 8, 8);
      ctx.fillStyle = m.rock ? "#6a6c76" : "#6fdc3e";
      ctx.fillRect(x - 2, y - 4, 4, 8); ctx.fillRect(x - 4, y - 2, 8, 4); ctx.fillRect(x - 3, y - 3, 6, 6);
      ctx.fillStyle = m.rock ? "#a8aab6" : "#e6ffc0";
      ctx.fillRect(x - 2, y - 3, 3, 2);
    }
    for (const p of this.pods) {
      if (p.landed || p.t < 0) continue;
      const hgt = (1 - p.t / POD_T) * 300;
      const x = Math.round(p.x) - cl, y = Math.round(p.y - hgt) - ct;
      ctx.fillStyle = Math.sin(t * 60) > 0 ? "#ffe45c" : "#ff9a3c";
      ctx.fillRect(x - 3, y - 40, 6, 24);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(x - 1, y - 30, 2, 14);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 6, y - 16, 12, 21);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(x - 5, y - 15, 10, 19);
      ctx.fillStyle = "#8d949e";
      ctx.fillRect(x + 1, y - 15, 4, 19);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 5, y - 10, 10, 3);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 3, y + 4, 6, 3);
    }
    for (const s of this.strikes) {
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      if (s.t < 1.25) {
        ctx.fillStyle = `rgba(255,77,94,${(0.25 + 0.2 * Math.sin(t * 24)).toFixed(3)})`;
        ctx.fillRect(x - 1, 0, 3, Math.max(0, y));
        ctx.fillStyle = "#ff9aa5";
        ctx.fillRect(x, 0, 1, Math.max(0, y));
      }
      for (let i = 0; i < s.hits.length; i += 3) {
        const age = s.t - s.hits[i + 2];
        if (age > 0.14) continue;
        const hx = Math.round(s.hits[i]) - cl, hy = Math.round(s.hits[i + 1]) - ct, w = age < 0.06 ? 9 : 4;
        ctx.fillStyle = "rgba(160,235,255,0.75)";
        ctx.fillRect(hx - w, 0, w * 2, Math.max(0, hy));
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(hx - (w >> 1), 0, w, Math.max(0, hy));
      }
    }
    for (const q of this.gibs) {
      if (g.hidden(q.x, q.y)) continue;
      const x = Math.round(q.x) - cl, y = Math.round(q.y) - ct;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x - 2, y + 2, 4, 2);
      ctx.save();
      ctx.translate(x, y - Math.round(q.z));
      ctx.rotate(q.rot);
      this.drawGib(ctx, q);
      ctx.restore();
    }
    // furniture that can still be searched twinkles once you are inside
    this.boxes.forEach((b, i) => {
      if (b.looted || g.roofA[b.house] > 0.4) return;
      const x = Math.round(b.x) - cl, y = Math.round(b.y) - ct - 10;
      if (x < -10 || x > g.W + 10 || y < -10 || y > g.H + 10) return;
      const ph = (t * 1.6 + i * 0.37) % 1;
      if (ph > 0.45) return;
      const n = ph < 0.15 || ph > 0.3 ? 1 : 2;
      ctx.fillStyle = "#fff0a8";
      ctx.fillRect(x - n, y, n * 2 + 1, 1);
      ctx.fillRect(x, y - n, 1, n * 2 + 1);
    });
    if (this.search) {
      const b = this.search, x = Math.round(b.x) - cl, y = Math.round(b.y) - ct - 20;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 9, y - 1, 18, 5);
      ctx.fillStyle = "#3b3848";
      ctx.fillRect(x - 8, y, 16, 3);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 8, y, Math.round(16 * clamp(this.searchT / SEARCH_T, 0, 1)), 3);
    }
    // stairs: which way they lead
    const signs: [number, number, boolean, number][] = [];
    HOUSES.forEach((H, i) => {
      if (g.roofA[i] > 0.4) return;
      if (H.stair) signs.push([H.stair.tx, H.stair.ty, H.up !== undefined || !!H.stair2, H.lvl ?? 1]);
      if (H.stair2) signs.push([H.stair2.tx, H.stair2.ty, false, H.lvl ?? 1]);
    });
    signs.forEach(([stx, sty, up, lv]) => {
      const x = stx * TILE + 8 - cl, y = sty * TILE - ct - 4 + Math.round(Math.sin(t * 5) * 2);
      if (x < -20 || x > g.W + 20 || y < -20 || y > g.H + 20) return;
      drawText(ctx, up ? `NAIK LT${lv + 1}` : `TURUN LT${lv - 1}`, x, y - 8, "#f5c542");
      ctx.fillStyle = "#f5c542";
      for (let k = 0; k < 3; k++) ctx.fillRect(x - k - 1, y + (up ? k : 2 - k), 2 + k * 2, 1);
    });
    // New York: a bobbing marker over the crates that hold the items
    if (this.stage === 0)
      this.objBox.forEach((b, i) => {
        if (this.found[i]) return;
        const x = Math.round(b.x) - cl, y = Math.round(b.y) - ct - 24 + Math.round(Math.sin(t * 4 + i) * 2);
        if (x < -20 || x > g.W + 20 || y < -20 || y > g.H + 20) return;
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 6, y - 8, 12, 12); ctx.fillRect(x - 3, y + 4, 6, 3); ctx.fillRect(x - 1, y + 7, 2, 2);
        ctx.fillStyle = "#f5c542";
        ctx.fillRect(x - 5, y - 7, 10, 10); ctx.fillRect(x - 2, y + 3, 4, 3);
        ctx.fillStyle = ITEMS[i].col;
        ctx.fillRect(x - 3, y - 5, 6, 6);
      });
    // marked houses: a bobbing sign above the roof
    if (this.stage === 0)
      this.objHouses.forEach((h, i) => {
        if (this.found[i] || g.roofA[h] < 0.5) return;
        const H = HOUSES[h], x = Math.round((H.x + H.w / 2) * TILE) - cl, y = Math.round((H.y + H.h / 2) * TILE) - ct - 14 + Math.round(Math.sin(t * 4 + i) * 2);
        if (x < -20 || x > g.W + 20 || y < -20 || y > g.H + 20) return;
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 7, y - 9, 14, 14); ctx.fillRect(x - 3, y + 5, 6, 3); ctx.fillRect(x - 1, y + 8, 2, 2);
        ctx.fillStyle = "#f5c542";
        ctx.fillRect(x - 6, y - 8, 12, 12); ctx.fillRect(x - 2, y + 4, 4, 3);
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 1, y - 6, 2, 5); ctx.fillRect(x - 1, y, 2, 2);
      });
    // downed survivors call for help
    for (const f of g.fighters) {
      if (!f.down || f.deadT < 0.6) continue;
      const x = Math.round(f.x) - cl, y = Math.round(f.y) - ct - 18;
      if (Math.sin(t * 8) > -0.3) {
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 5, y - 9, 10, 10);
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(x - 4, y - 8, 8, 8);
        ctx.fillStyle = "#e0483e";
        ctx.fillRect(x - 1, y - 7, 2, 6); ctx.fillRect(x - 3, y - 5, 6, 2);
      }
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 9, y + 2, 18, 4);
      ctx.fillStyle = f.rev > 0 ? "#7dff9a" : "#e0483e";
      ctx.fillRect(x - 8, y + 3, Math.round(16 * (f.rev > 0 ? clamp(f.rev / 2, 0, 1) : clamp(f.bleed / 45, 0, 1))), 2);
    }
    if (this.stage >= 3) this.drawHeli();
  }

  private drawHeli() {
    const g = this.g, ctx = g.ctx, t = g.t;
    const k = this.heliT, alt = (1 - k) * (1 - k) * 230;
    const x = Math.round(this.padX) - g.cl, y = Math.round(this.padY - 12 - alt) - g.ct + (k >= 1 ? 0 : Math.round(Math.sin(t * 5) * 2));
    const INK = "#0a0a0f";
    // skids
    ctx.fillStyle = INK;
    ctx.fillRect(x - 20, y + 13, 42, 3); ctx.fillRect(x - 12, y + 8, 2, 6); ctx.fillRect(x + 10, y + 8, 2, 6);
    ctx.fillStyle = "#8d949e";
    ctx.fillRect(x - 19, y + 14, 40, 1);
    // tail boom + tail rotor
    ctx.fillStyle = INK;
    ctx.fillRect(x - 52, y - 5, 32, 8); ctx.fillRect(x - 56, y - 14, 7, 16);
    ctx.fillStyle = "#3d5a44";
    ctx.fillRect(x - 51, y - 4, 31, 6); ctx.fillRect(x - 55, y - 13, 5, 14);
    ctx.fillStyle = "#57785e";
    ctx.fillRect(x - 51, y - 4, 31, 1);
    ctx.fillStyle = "#e0483e";
    ctx.fillRect(x - 55, y - 13, 5, 3);
    ctx.fillStyle = "rgba(210,220,235,0.7)";
    const ta = t * 50;
    pline(ctx, x - 53 - Math.cos(ta) * 2, y - 6 - Math.sin(ta) * 7, x - 53 + Math.cos(ta) * 2, y - 6 + Math.sin(ta) * 7, 1);
    // cabin
    ctx.fillStyle = INK;
    ctx.fillRect(x - 22, y - 12, 44, 22); ctx.fillRect(x - 19, y - 14, 38, 26); ctx.fillRect(x + 20, y - 8, 6, 14);
    ctx.fillStyle = "#3d5a44";
    ctx.fillRect(x - 21, y - 11, 42, 20); ctx.fillRect(x - 18, y - 13, 36, 24); ctx.fillRect(x + 20, y - 7, 5, 12);
    ctx.fillStyle = "#57785e";
    ctx.fillRect(x - 18, y - 13, 36, 2);
    ctx.fillStyle = "#2c4233";
    ctx.fillRect(x - 21, y + 5, 42, 4);
    // cockpit glass, open door, markings
    ctx.fillStyle = INK;
    ctx.fillRect(x + 6, y - 10, 17, 12);
    ctx.fillStyle = "#8fd0e0";
    ctx.fillRect(x + 7, y - 9, 15, 10);
    ctx.fillStyle = "#d9f5f9";
    ctx.fillRect(x + 8, y - 8, 5, 2); ctx.fillRect(x + 8, y - 6, 2, 3);
    ctx.fillStyle = INK;
    ctx.fillRect(x - 12, y - 8, 14, 17);
    ctx.fillStyle = "#1c2a20";
    ctx.fillRect(x - 11, y - 7, 12, 16);
    ctx.fillStyle = "#f5c542";
    ctx.fillRect(x - 11, y + 7, 12, 2);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 19, y - 6, 6, 6);
    ctx.fillStyle = "#e0483e";
    ctx.fillRect(x - 17, y - 5, 2, 4); ctx.fillRect(x - 18, y - 4, 4, 2);
    ctx.fillStyle = Math.sin(t * 10) > 0 ? "#ff4d5e" : "#5a1a20";
    ctx.fillRect(x - 1, y - 15, 2, 2);
    // main rotor: a spinning blur
    ctx.fillStyle = INK;
    ctx.fillRect(x - 2, y - 19, 4, 6);
    const ra = t * 38;
    for (let i = 0; i < 2; i++) {
      const a = ra + i * 1.571, rx = Math.cos(a) * 50, ry = Math.sin(a) * 9;
      ctx.fillStyle = "rgba(10,10,15,0.75)";
      pline(ctx, x - rx, y - 19 - ry, x + rx, y - 19 + ry, 2);
      ctx.fillStyle = "rgba(210,220,235,0.5)";
      pline(ctx, x - rx * 0.96, y - 20 - ry, x + rx * 0.96, y - 20 + ry, 1);
    }
  }

  /** blips on the radar; the engine has already clipped and translated to tile coordinates. Upper floors show at their house. */
  drawRadar() {
    const g = this.g, ctx = g.ctx, blink = Math.sin(g.t * 8) > 0;
    const T = (x: number, y: number) => { const q = g.gpos(x, y); q[0] = Math.floor(q[0] / TILE); q[1] = Math.floor(q[1] / TILE); return q; };
    ctx.fillStyle = "#3f9a2c";
    for (const n of NESTS) ctx.fillRect(Math.floor(n.x / TILE) - 1, Math.floor(n.y / TILE) - 1, 3, 2);
    const frame = (x: number, y: number, w: number, h: number) => {
      ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + h - 1, w, 1); ctx.fillRect(x, y, 1, h); ctx.fillRect(x + w - 1, y, 1, h);
    };
    if (this.stage === 0) {
      this.objHouses.forEach((h, i) => {
        if (this.found[i]) return;
        ctx.fillStyle = blink ? "#f5c542" : "#a97a1c";
        frame(HOUSES[h].x, HOUSES[h].y, HOUSES[h].w, HOUSES[h].h);
      });
      this.objBox.forEach((b, i) => {
        if (this.found[i]) return;
        ctx.fillStyle = blink ? "#f5c542" : "#a97a1c";
        frame(Math.floor(b.x / TILE) - 2, Math.floor(b.y / TILE) - 2, 5, 5);
      });
    } else {
      ctx.fillStyle = blink ? "#7dff9a" : "#2f8a4a";
      if (this.stage === 1 && !g.lastMap) frame(Math.floor(TRUCK.x / TILE) - 2, Math.floor(TRUCK.y / TILE) - 1, 5, 3);
      else frame(PAD.x, PAD.y, PAD.w, PAD.h);
    }
    for (const b of this.bugs) {
      if (b.state === "sleep" && b.herd === undefined) continue; // street crowds show up on the radar: go around them, or get ready
      const s = b.kind === "titan" || b.kind === "tank" ? 3 : b.kind === "charger" ? 2 : 1, q = T(b.x, b.y);
      ctx.fillStyle = b.kind === "titan" || b.kind === "charger" || b.kind === "tank" ? "#ff4d5e" : b.kind === "dog" ? "#ffd75e" : "#ff9a3c";
      ctx.fillRect(q[0], q[1], s, s);
    }
    ctx.fillStyle = "#5ff0e0";
    for (const t of this.turrets) { const q = T(t.x, t.y); ctx.fillRect(q[0], q[1], 2, 2); }
    for (const f of g.fighters) if (f.down && blink) { const q = T(f.x, f.y); ctx.fillStyle = "#ffffff"; ctx.fillRect(q[0] - 1, q[1] - 1, 3, 3); }
    if (this.sos() && blink) for (const c of this.civs) if (!c.found && !c.lost) { const q = T(c.f.x, c.f.y); ctx.fillStyle = "#ff9df0"; ctx.fillRect(q[0] - 1, q[1] - 1, 3, 3); }
  }

  /** arrows at the screen edge: where to go, who needs help, what is coming */
  pointers() {
    const g = this.g;
    {
      const pl = g.player, hin = pl ? houseAtPx(pl.x, pl.y) : -1, base = hin >= 0 ? HOUSES[hin].under ?? hin : -1;
      // inside a marked house the search is not a guessing game: the piece of furniture that holds the item is lit up
      // (when it is on the other floor, the stairs are)
      if (this.stage === 0 && base >= 0)
        for (const b of this.boxes) {
          if (b.looted || b.item < 0 || b.house < 0 || (HOUSES[b.house].under ?? b.house) !== base) continue;
          const goUp = (HOUSES[b.house].lvl ?? 1) > (HOUSES[hin].lvl ?? 1), st = (!goUp && HOUSES[hin].stair2) || HOUSES[hin].stair;
          if (b.house === hin) this.beacon(b.x, b.y - 4, ITEMS[b.item].col, ITEMS[b.item].name);
          else if (st) this.beacon((st.tx + 0.5) * TILE, (st.ty + 0.5) * TILE, ITEMS[b.item].col, `${ITEMS[b.item].name}: ${goUp ? "NAIK" : "TURUN"} KE LT${HOUSES[b.house].lvl ?? 1}`);
        }
      // doors: what E will do here
      if (pl && pl.alive && !g.trans) {
        let bd = 40, bx = 0, by = 0, isShut = false;
        for (const H of HOUSES) {
          if (isStation(H)) continue;
          for (const d of H.doors) {
            const q = Math.hypot((d.tx + 0.5) * TILE - pl.x, (d.ty + 0.5) * TILE - pl.y);
            if (q < bd) { bd = q; bx = (d.tx + 0.5) * TILE; by = d.ty * TILE; isShut = this.shut.has(d.ty * MW + d.tx); }
          }
        }
        let wd = 26, wx = 0, wy = 0, wo = false;
        for (const w of WINDOWS) {
          const q = Math.hypot((w.tx + 0.5) * TILE - pl.x, (w.ty + 0.5) * TILE - pl.y);
          if (q < wd) { wd = q; wx = (w.tx + 0.5) * TILE; wy = w.ty * TILE; wo = this.openWin.has(w.ty * MW + w.tx); }
        }
        if (wd < 26 && wd <= bd) drawText(g.ctx, wo ? "E: TUTUP JENDELA" : "E: BUKA JENDELA", Math.round(wx) - g.cl, Math.round(wy) - g.ct - 18, wo ? "#ffd75e" : "#7dff9a");
        else if (bd < 40) drawText(g.ctx, isShut ? "E: BUKA PINTU" : "E: TUTUP PINTU", Math.round(bx) - g.cl, Math.round(by) - g.ct - 18, isShut ? "#ffd75e" : "#7dff9a");
      }
    }
    if (g.art.ny && g.inK < 0.5)
      // New York: a sign over every door you can go through - green for buildings, a blue M for the subway
      nyEntrances((ex, ey, kind) => {
        const c2 = g.ctx, x = Math.round(ex) - g.cl, y = Math.round(ey) - g.ct - 17 + Math.round(Math.sin(g.t * 4 + ex) * 2);
        if (x < -10 || x > g.W + 10 || y < -10 || y > g.H + 20) return;
        c2.fillStyle = "#0a0a0f"; c2.fillRect(x - 5, y - 5, 11, 11);
        c2.fillStyle = kind ? "#2b5fb0" : "#2f8a4a"; c2.fillRect(x - 4, y - 4, 9, 9);
        c2.fillStyle = "#ffffff";
        if (kind) { c2.fillRect(x - 3, y - 3, 1, 7); c2.fillRect(x + 3, y - 3, 1, 7); c2.fillRect(x - 2, y - 2, 1, 1); c2.fillRect(x + 2, y - 2, 1, 1); c2.fillRect(x - 1, y - 1, 1, 1); c2.fillRect(x + 1, y - 1, 1, 1); c2.fillRect(x, y, 1, 1); }
        else { c2.fillRect(x - 2, y - 3, 5, 7); c2.fillStyle = "#2f8a4a"; c2.fillRect(x - 1, y - 2, 3, 6); c2.fillStyle = "#ffffff"; c2.fillRect(x + 1, y, 1, 1); }
      });
    if (this.stage === 0) {
      this.objHouses.forEach((h, i) => {
        if (this.found[i]) return;
        const H = HOUSES[h];
        g.pointer((H.x + H.w / 2) * TILE, (H.y + H.h / 2) * TILE, "#f5c542", "#fff0a8");
      });
      this.objBox.forEach((b, i) => { if (!this.found[i]) g.pointer(b.x, b.y, "#f5c542", "#fff0a8"); });
    } else g.pointer(this.goalX, this.goalY, "#7dff9a", "#ffffff", this.stage === 1 && !g.lastMap ? "VAN" : "EVAC");
    // the pickup can always be found: an arrow with its name on it
    if (this.stage === 0 || (this.stage === 1 && g.lastMap)) g.pointer(TRUCK.x, TRUCK.y, "#5ff0e0", "#ffffff", "VAN");
    const sos = this.sos(), ctx = g.ctx, t = g.t;
    const marked: number[] = [];
    for (const c of this.civs) {
      if (c.lost) continue;
      if (c.found) { if (c.f.alive) g.pointer(c.f.x, c.f.y, "#ff9df0", "#ffffff"); continue; }
      if (!sos || marked.includes(c.grp)) continue; // one signal per hideout
      marked.push(c.grp);
      // an SOS over the building they are hiding in (and an arrow at the edge of the screen when it is out of sight)
      g.pointer(c.f.x, c.f.y, "#ff9df0", "#ff4d8a");
      const ch = houseAtPx(c.f.x, c.f.y);
      if (g.inK > 0.5 && ch >= 0 && g.inHouse >= 0 && (HOUSES[ch].under ?? ch) === (HOUSES[g.inHouse].under ?? g.inHouse)) {
        // same building: a beacon on the very spot (on the stairs when they are on the other floor)
        const goUp = (HOUSES[ch].lvl ?? 1) > (HOUSES[g.inHouse].lvl ?? 1), st = (!goUp && HOUSES[g.inHouse].stair2) || HOUSES[g.inHouse].stair;
        if (ch === g.inHouse) this.beacon(c.f.x, c.f.y, "#ff9df0", "SOS");
        else if (st) this.beacon((st.tx + 0.5) * TILE, (st.ty + 0.5) * TILE, "#ff9df0", `SOS: ${goUp ? "NAIK" : "TURUN"} KE LT${HOUSES[ch].lvl ?? 1}`);
        continue;
      }
      const q = g.gpos(c.f.x, c.f.y), x = Math.round(q[0]) - g.cl, y = Math.round(q[1]) - g.ct - 30 + Math.round(Math.sin(t * 5) * 2);
      if (x > -20 && x < g.W + 20 && y > -20 && y < g.H + 20) drawText(ctx, (HOUSES[ch]?.lvl ?? 1) > 1 ? `SOS LT${HOUSES[ch].lvl}` : "SOS", x, y, Math.sin(t * 8) > 0 ? "#ff9df0" : "#ffffff");
    }
    for (const f of g.fighters) if (f.down) g.pointer(f.x, f.y, "#5ff0e0", "#ffffff");
    for (const b of this.bugs) if ((b.kind === "titan" || b.kind === "charger" || b.kind === "tank") && b.state !== "sleep") g.pointer(b.x, b.y, "#ff4d5e", "#ffd0d0");
  }
}

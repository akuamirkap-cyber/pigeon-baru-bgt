export const TILE = 16;
/** how many px wall tops are lifted to fake the 3/4 RPG perspective */
export const RAISE = 8;
export const WIN_ROUNDS = 4;
export const ROUND_TIME = 90;
export const TEAM_SIZE = 5;
export const MAX_HP = 100;

export type WeaponId = "sniper" | "shotgun" | "pistol" | "bazooka" | "karambit" | "bat" | "hockey" | "hammer" | "axe" | "ak47" | "goldgun";
export const WEAPON_ORDER: WeaponId[] = ["sniper", "shotgun", "pistol", "bazooka", "karambit", "bat", "hockey", "hammer", "axe", "ak47", "goldgun"];
/** everything that fires bullets (not the rocket launcher) */
export const isGun = (id: string) => id === "pistol" || id === "shotgun" || id === "sniper" || id === "ak47" || id === "goldgun";
/** the blunt and heavy ones are all swung like the baseball bat: two swings, then an overhead smash */
export const isBat = (id: string) => id === "bat" || id === "hockey" || id === "hammer" || id === "axe";

export interface WeaponDef {
  id: WeaponId;
  name: string;
  desc: string;
  melee: boolean;
  dmg: number;
  cd: number;
  mag: number;
  reload: number;
  speed: number;
  spread: number;
  pellets: number;
  life: number;
  pierce: boolean;
  kick: number;
  shake: number;
  moveMul: number;
  knock: number;
  /** distance from grip to muzzle in sprite px */
  len: number;
  tail: number;
  // melee only
  range: number;
  arc: number;
  lunge: number;
  swing: number;
}

const gun = { melee: false, range: 0, arc: 0, lunge: 0, swing: 0 };
const blade = { melee: true, mag: 0, reload: 0, speed: 0, spread: 0, pellets: 0, life: 0, pierce: false, kick: 0, len: 8, tail: 0 };

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  sniper: {
    ...gun, id: "sniper", name: "SNIPER", desc: "Sekali kena langsung KO. Peluru tembus musuh.",
    dmg: 100, cd: 0.7, mag: 4, reload: 1.3, speed: 1950, spread: 0, pellets: 1, life: 0.3, pierce: true,
    kick: 9, shake: 5, moveMul: 0.85, knock: 260, len: 19, tail: 30,
  },
  shotgun: {
    ...gun, id: "shotgun", name: "SHOTGUN", desc: "7 peluru sekaligus. Ganas di jarak dekat.",
    dmg: 14, cd: 0.5, mag: 6, reload: 1.25, speed: 750, spread: 0.2, pellets: 9, life: 0.18, pierce: false,
    kick: 10, shake: 6.5, moveMul: 0.96, knock: 95, len: 12, tail: 6,
  },
  pistol: {
    ...gun, id: "pistol", name: "PISTOL", desc: "Rentetan cepat dan akurat. Serba bisa.",
    dmg: 22, cd: 0.1, mag: 14, reload: 0.7, speed: 870, spread: 0.05, pellets: 1, life: 0.53, pierce: false,
    kick: 2.2, shake: 1.4, moveMul: 1, knock: 50, len: 8, tail: 8,
  },
  bazooka: {
    ...gun, id: "bazooka", name: "BAZOOKA", desc: "Roket meledak sapu banyak musuh. Awas kena sendiri!",
    dmg: 105, cd: 0.45, mag: 1, reload: 1.5, speed: 255, spread: 0, pellets: 1, life: 1.07, pierce: false,
    kick: 13, shake: 7, moveMul: 0.8, knock: 340, len: 14, tail: 0,
  },
  karambit: {
    ...blade, id: "karambit", name: "KARAMBIT", desc: "Kombo 3 tebasan: yang ke-3 berputar! Belakang = 3x.",
    dmg: 50, cd: 0.28, shake: 3, moveMul: 1.12, knock: 70, range: 27, arc: 3.3, lunge: 150, swing: 0.27,
  },
  bat: {
    ...blade, id: "bat", name: "BASEBALL", desc: "Kombo 3 pukulan: yang ke-3 hantam kepala! Mantulin peluru.",
    dmg: 65, cd: 0.42, shake: 6, moveMul: 1.0, knock: 260, range: 34, arc: 3.6, lunge: 110, swing: 0.37,
  },
  hockey: {
    ...blade, id: "hockey", name: "STIK HOKI", desc: "Jangkauan paling jauh, ayunan paling cepat. Dipakai seperti baseball.",
    dmg: 55, cd: 0.36, shake: 5, moveMul: 1.04, knock: 220, range: 40, arc: 3.8, lunge: 110, swing: 0.33,
  },
  hammer: {
    ...blade, id: "hammer", name: "PALU", desc: "Pendek dan lambat, tapi paling sering KRITIS. Dipakai seperti baseball.",
    dmg: 85, cd: 0.5, shake: 8, moveMul: 0.96, knock: 320, range: 28, arc: 3.2, lunge: 120, swing: 0.41,
  },
  axe: {
    ...blade, id: "axe", name: "KAPAK DAMKAR", desc: "Kapak pemadam: memutus tangan zombie. Dipakai seperti baseball.",
    dmg: 78, cd: 0.44, shake: 7, moveMul: 0.98, knock: 240, range: 33, arc: 3.4, lunge: 115, swing: 0.39,
  },
  ak47: {
    ...gun, id: "ak47", name: "AK-47", desc: "Senapan serbu otomatis: 30 peluru, hentakannya liar.",
    dmg: 27, cd: 0.095, mag: 30, reload: 1.5, speed: 1150, spread: 0.075, pellets: 1, life: 0.42, pierce: false,
    kick: 3.4, shake: 2.2, moveMul: 0.92, knock: 70, len: 15, tail: 14,
  },
  goldgun: {
    ...gun, id: "goldgun", name: "GOLD GUN", desc: "Pistol emas kaliber besar: 7 peluru, tembus badan, mematikan.",
    dmg: 95, cd: 0.4, mag: 7, reload: 1.15, speed: 1400, spread: 0.01, pellets: 1, life: 0.4, pierce: true,
    kick: 8, shake: 5, moveMul: 1, knock: 220, len: 9, tail: 22,
  },
};

export type BugKind = "scav" | "warrior" | "spitter" | "charger" | "titan" | "dog" | "tank";
/** weather of the zombie city: changing with the mission, or locked */
export type WeatherId = "auto" | "rain" | "fog" | "clear" | "day";
export type GameMode = "pvp" | "bugs";
/** anything that can hurt: a weapon, an explosion or a bug */
export type Hurt = WeaponId | "boom" | "bug";

export const TEAMS = [
  { name: "GOLD", color: "#f5c542", dark: "#a97a1c", bullet: "#ffe58a" },
  { name: "CRIMSON", color: "#ff4d5e", dark: "#9c1f33", bullet: "#ff9aa5" },
];

export const SKINS = ["VIPER", "BRICK", "ONI", "GHOST", "SHADE"];
/** civilians of the zombie mode */
/** the five friends - and four outfits only you can wear (the squad is always made up of the friends) */
export const SURVIVORS = ["JAKA", "SARI", "BIMO", "NADIA", "BARA", "HAZMAT", "GASMASK", "HOODIE", "HOKI", "MILLER", "SWAT"];
export const ENEMY_NAMES = ["RAZOR", "MAMBA", "KOBRA", "HYENA", "JACKAL"];

export type DiffId = "easy" | "normal" | "hard";
export interface Difficulty {
  id: DiffId;
  label: string;
  react: number;
  aimErr: number;
  dmgMul: number;
  dodge: number;
}
export const DIFFS: Record<DiffId, Difficulty> = {
  easy: { id: "easy", label: "SANTAI", react: 0.6, aimErr: 0.24, dmgMul: 0.42, dodge: 0 },
  normal: { id: "normal", label: "NORMAL", react: 0.4, aimErr: 0.14, dmgMul: 0.62, dodge: 0.5 },
  hard: { id: "hard", label: "BRUTAL", react: 0.24, aimErr: 0.07, dmgMul: 0.95, dodge: 1 },
};

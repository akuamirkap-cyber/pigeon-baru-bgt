import { DIFFS, ENEMY_NAMES, MAX_HP, RAISE, ROUND_TIME, SKINS, SURVIVORS, TEAMS, TEAM_SIZE, TILE, WEAPONS, WEAPON_ORDER, WIN_ROUNDS, isBat } from "./defs";
import type { DiffId, Difficulty, GameMode, Hurt, WeaponDef, WeaponId, WeatherId } from "./defs";
import { BARREL_SPOTS, CH, FLAGS, HOUSES, LANES, MH, MW, PALMS, SPAWNS, TRUCK, blockAt, findPath, houseAtPx, kindAt, los, portalAt, rayEnd, solidAt, styleAt, walkClear } from "./map";
import { cityLamps, mapArt } from "./city";
import type { Lamp, MapArt } from "./city";
import { BugMode } from "./bugs";
import { Atmosphere } from "./atmo";
import type { Box, Bug, Pod, Turret } from "./bugs";
import { nyDraw, nyLamps, nyLights, nyPlace, nySortables } from "./nyc";
import { buildShells, covers, drawShell, litWalls, project, shellPolys, shellShadow } from "./shell";
import type { Shell } from "./shell";
import type { NyItem } from "./nyc";
import type { Flag, Prop, Pt, Win } from "./map";
import { Chatter } from "./talk";
import type { ChatLine } from "./talk";
import { LOOK_PAL, WBARREL, WPIVOT, drawText, initSprites } from "./sprites";
import type { Sprites } from "./sprites";
import { audio } from "./audio";
import type { SfxName } from "./audio";

/* ───────────── public types ───────────── */
export type Phase = "freeze" | "live" | "end" | "over";
export interface FeedItem { id: number; killer: string; killerTeam: number; victim: string; victimTeam: number; weapon: Hurt; tag: string; me: boolean; t: number }
export interface Banner { id: number; title: string; sub: string; tone: "gold" | "red" | "white" }
export interface HudState {
  mode: "demo" | "play"; phase: Phase; round: number; score: [number, number]; alive: [number, number];
  time: number; count: number; hp: number; weapon: WeaponId; ammo: number; mag: number; reload: number; dash: number; stam: number; exh: boolean; resting: boolean;
  dead: boolean; spectating: string; feed: FeedItem[]; banner: Banner | null; streak: { id: number; text: string } | null;
  paused: boolean; muted: boolean; touch: boolean;
  game: GameMode; stage: number; items: boolean[]; obj: string; evac: number; kills: number; strat: [number, number]; boss: number; weather: string; bleed: number; heads: number; chat: ChatLine[]; floor: number; civ: number; civN: number; civD: boolean; level: number; safe: number; music: boolean; bossName: string;
}
export interface ResultRow { name: string; team: number; skin: number; kills: number; deaths: number; dmg: number; me: boolean }
export interface MatchResult { win: boolean; score: [number, number]; rows: ResultRow[]; mvp: string; game: GameMode; wave: number; waves: number; kills: number }
export interface Callbacks { onHud: (h: HudState) => void; onMatchEnd: (r: MatchResult) => void; onChat?: (open: boolean) => void }

/* ───────────── internal types ───────────── */
/** anything a bot can aim at (enemy operator or bug) */
export interface Target { x: number; y: number; vx: number; vy: number; alive: boolean; team: number; state?: string }
/** anything that slides along walls */
export interface Body { x: number; y: number; vx: number; vy: number; kx: number; ky: number }
interface AI {
  role: WeaponId; melee: WeaponId; target: Target | null; hunt: Target | null; seen: number; thinkT: number;
  path: number[]; pi: number; pathT: number; err: number; errT: number; strafe: number; strafeT: number;
  charge: number; tapT: number; wp: Pt | null; stuckT: number; lastX: number; lastY: number; unstickT: number; ux: number; uy: number;
  /** sweeping a building: what this one is going for (and which thing it is, so two friends do not take the same), until when */
  goal: Pt | null; goalKey: number; goalT: number;
  /** since when it has had this goal; a goal it gave up on (and until when it leaves it to the others) */
  goalSince: number; ban: number; banT: number;
}
export interface Fighter {
  id: number; name: string; team: number; skin: number; isPlayer: boolean;
  x: number; y: number; vx: number; vy: number; kx: number; ky: number;
  hp: number; alive: boolean; aim: number; weapon: WeaponId; lastWeapon: WeaponId; ammo: Record<WeaponId, number>;
  cd: number; reloadT: number; reloadDur: number; swingT: number; swingDur: number; swingDir: number;
  dashT: number; dashCd: number; dashX: number; dashY: number; ghostT: number;
  walkT: number; moving: boolean; stepT: number; hitFlash: number; recoil: number; flash: number; tilt: number;
  kills: number; deaths: number; dmg: number; roundKills: number; deadT: number;
  // ragdoll
  z: number; vz: number; rot: number; vrot: number; rest: boolean;
  scarf: number[];
  /** hidden (waiting for a drop pod) */
  gone: boolean;
  /** which sprite set to wear: 0 gold squad, 1 crimson squad, 2 survivors */
  look: number;
  /** zombie mode: knocked down, bleeding out, being helped up */
  down: boolean; bleed: number; rev: number;
  /** bat combo step (2 = overhead smash), delayed smash impact, blood on the bat, gunfire noise */
  combo: number; lastSwing: number; swingKind: number; pend: number; bloody: number; loud: number;
  /** ids already hit by the current swing */
  swingHit: number[];
  /** on a staircase tile; face timers (pain, joy, fear); shotgun pump, barrel smoke, muzzle flash seed */
  onStair: boolean; ouch: number; joy: number; fear: number; pump: number; smokeT: number; seed: number;
  /** assisted melee angle (NaN = none), sad/angry face timers, chat reaction timer */
  sAim: number; sad: number; mad: number; talkT: number;
  /** stamina 0-100, running blend, exhausted, resting (sitting down) blend, bottle timer, climbing offset, delayed lunge */
  stam: number; runK: number; exh: boolean; resting: boolean; restK: number; drinkT: number; drinkIn: number; climbY: number; lungeT: number; lungeV: number; lungeA: number;
  /** an unarmed civilian to be escorted - and whether they are still hiding */
  civ: boolean; hid: boolean;
  /** karambit flourish: the blade spinning round the finger, and when the next one is due */
  spinT: number; spinIn: number;
  /** a flurry of rapid blows: how many are left, how many it had, when the last one was */
  rush: number; rushN: number; rushAt: number;
  /** a moment of grace after a bite; how long since the last hit (wounds close when left alone); a second wind left for this map */
  guardT: number; calmT: number; wind: boolean;
  ai: AI | null; killer: Fighter | null;
}
export interface Bullet {
  x: number; y: number; dx: number; dy: number; speed: number; team: number; owner: Fighter; dmg: number;
  life: number; max: number; pierce: boolean; hit: number[]; wid: WeaponId; ox: number; oy: number; trav: number;
  /** where the crosshair was when the shot was fired (player only): decides which part of a zombie it goes through */
  ax?: number; ay?: number;
}
interface Part { x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number; max: number; color: string; size: number; grav: number; drag: number; stamp: boolean; shell?: number }
interface PartOpt { z?: number; vx?: number; vy?: number; vz?: number; max?: number; size?: number; grav?: number; drag?: number; stamp?: boolean; shell?: number }
interface Barrel { x: number; y: number; hp: number; alive: boolean; flash: number; fuse: number; by: Fighter | null }
interface Slash { f: Fighter; ang: number; r: number; arc: number; life: number; max: number; dir: number; kind: number; wid: WeaponId }
interface FloatText { x: number; y: number; text: string; color: string; life: number; v: object | null; amt: number }
interface Tracer { x0: number; y0: number; x1: number; y1: number; life: number; color: string }
interface Ring { x: number; y: number; life: number; r: number }
interface Ghost { x: number; y: number; team: number; look: number; skin: number; flip: boolean; life: number }
interface Pickup { x: number; y: number; t: number }
interface Drop { x: number; y: number; z: number; vx: number; vy: number; vz: number; rot: number; vrot: number; team: number; wid: WeaponId }
interface Glow { x: number; y: number; r: number; life: number; max: number }
interface Spark { x: number; y: number; life: number }
export interface Sortable { y: number; f?: Fighter; b?: Barrel; palm?: Prop; flag?: Flag; bug?: Bug; tur?: Turret; pod?: Pod; truck?: boolean; box?: Box; nyo?: NyItem; door?: number; win?: Win }

/** what each survivor carries: Jaka, Sari, Bimo, Nadia, Bara */
const ROLE: WeaponId[] = ["shotgun", "pistol", "sniper", "pistol", "bazooka"];
const GOODS = ["#d8433b", "#f5c542", "#3b6ea8", "#3f8a5a", "#e6e0d0", "#d07a2a"];
const WALK = 72, RUN = 124, BOT = 80;
const SPEED = 108, DASH_SPEED = 310, DASH_TIME = 0.18, DASH_CD = 0.9, HALF = 4.5, SNIPE_CHARGE = 0.6, GRAV = 600;
const PI2 = Math.PI * 2;
/** how the friends in the zombie city fight: quick to react, steady hands */
const SQUAD: Difficulty = { id: "normal", label: "", react: 0.14, aimErr: 0.045, dmgMul: 1, dodge: 0.5 };
/** the maps of the zombie campaign */
const MAP_NAME: Record<number, string> = { 1: "PUSAT KOTA", 2: "KOTA TUA BERSALJU", 3: "NEW YORK" };
/** how each weapon ends its three-hit combo */
const COMBO_NAME: Partial<Record<WeaponId, string>> = { bat: "HANTAM!", hammer: "GEMPA!", axe: "TEBAS PUTAR!", hockey: "SAPUAN!", karambit: "PUTARAN!" };
const rand = Math.random;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => {
  let d = (b - a) % PI2;
  if (d > Math.PI) d -= PI2;
  if (d < -Math.PI) d += PI2;
  return d;
};
function shuffle<T>(a: T[]): T[] {
  for (let i = a.length - 1; i > 0; i--) {
    const j = (rand() * (i + 1)) | 0;
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export class Game {
  canvas: HTMLCanvasElement;
  cb: Callbacks;
  ctx: CanvasRenderingContext2D;
  fctx: CanvasRenderingContext2D;
  sp: Sprites;
  art: MapArt;
  game: GameMode = "pvp";
  bug: BugMode;
  mobName = "ZOMBIE";
  atmo = new Atmosphere();
  /** static lights of the night city (street lamps, neon, evac zone) */
  lamps: Lamp[] = [];
  /** roof opacity per house: fades out while you are inside */
  roofA: number[] = [];
  inside = false;
  heartT = 0;
  talk: Chatter;
  /** 0..1 how far "indoors" the view is, and which building */
  inK = 0;
  inHouse = -1;
  /** the chat box is open: the keyboard belongs to it */
  typing = false;
  /** another mode owns the screen: stop simulating and drawing */
  halt = false;
  /** zombie city: which district (1 downtown, 2 snowy old town), and the pickup ride between them */
  level = 1;
  startLevel = 1;
  trans: { t: number; swapped: boolean; intro?: boolean } | null = null;
  /** the campaign: which maps, in which order (the last one ends with the helicopter, the others with the pickup), and where we are */
  route: number[] = [1];
  ri = 0;
  get lastMap() { return this.ri >= this.route.length - 1; }
  /** the squad arriving in the pickup at the start of a map */
  intro: { t: number; out: boolean } | null = null;
  /** holding SPACE to skip the search */
  skipT = 0;
  skipLock = false;
  /** a finisher in progress (kind 0 skull smash, 1 karambit), and when the last one happened */
  fat: { z: Bug; t: number; kind: number } | null = null;
  fatAt = -9;
  /** how tense the music is, and how far the lights are up in a shelter (both eased) */
  tense = 0;
  /** set while the camera is on an upper floor: the city is drawn far below it */
  skyNow: ReturnType<Game["skyOf"]> = null;
  cozy = 0;
  clearK = 0;
  /** the buildings of the city as boxes (see shell.ts), and the ones on screen this frame, farthest first */
  shells: Shell[] = [];
  live3: Shell[] = [];
  wantRun = false;
  climb: { t: number; up: boolean; swapped: boolean; step: number } | null = null;
  floorTitle = { text: "", t: 0 };
  visMem: Record<number, number[]> = {};
  /** blink of darkness when changing floors */
  fade = 0;
  cuts: { x: number; y: number; ang: number; life: number; star: boolean }[] = [];
  bursts: { x: number; y: number; ang: number; life: number; max: number; r: number; seed: number }[] = [];
  flashes: { x: number; y: number; ang: number; life: number; max: number; r: number; kind: number }[] = [];
  vig: HTMLCanvasElement | null = null;
  abort = new AbortController();
  raf = 0;
  lastT = 0;
  W = 480;
  H = 270;

  mode: "demo" | "play" = "demo";
  phase: Phase = "freeze";
  phaseT = 0;
  round = 0;
  roundT = 0;
  timeLeft = ROUND_TIME;
  score: [number, number] = [0, 0];
  winner = -1;
  matchDone = false;
  diff: Difficulty = DIFFS.normal;
  paused = false;
  t = 0;
  slowT = 0;
  hitStop = 0;
  ids = 1;

  fighters: Fighter[] = [];
  bullets: Bullet[] = [];
  parts: Part[] = [];
  barrels: Barrel[] = [];
  slashes: Slash[] = [];
  texts: FloatText[] = [];
  tracers: Tracer[] = [];
  rings: Ring[] = [];
  ghosts: Ghost[] = [];
  pickups: Pickup[] = [];
  drops: Drop[] = [];
  glows: Glow[] = [];
  sparks: Spark[] = [];
  motes: number[] = [];
  player: Fighter | null = null;
  spec: Fighter | null = null;
  specT = 0;

  cam = { x: 480, y: 300, shake: 0, kx: 0, ky: 0 };
  cl = 0;
  ct = 0;
  zoom = 0;
  lastZoom = -1;
  hurtT = 0;
  hitMark = 0;
  killMark = 0;
  lastDeflect = -9;
  whiteT = 0;

  keys = new Set<string>();
  mx = 240;
  my = 135;
  down = false;
  wantDash = false;
  useTouch = false;
  tMove = { x: 0, y: 0 };
  tAim = { x: 1, y: 0, active: false, fire: false };
  ix = 0;
  iy = 0;

  feed: FeedItem[] = [];
  banner: Banner | null = null;
  bannerT = 0;
  streak: { id: number; text: string } | null = null;
  streakT = 0;
  hudT = 0;
  hudDirty = true;

  constructor(canvas: HTMLCanvasElement, cb: Callbacks) {
    this.canvas = canvas;
    this.cb = cb;
    this.ctx = canvas.getContext("2d")!;
    this.sp = initSprites();
    this.art = mapArt(0);
    this.fctx = this.art.floor.getContext("2d")!;
    this.bug = new BugMode(this);
    this.talk = new Chatter(this);
    this.resize();
    for (let i = 0; i < 28; i++) this.motes.push(rand() * 700, rand() * 400, 0.4 + rand());
    const o = { signal: this.abort.signal };
    window.addEventListener("resize", () => this.resize(), o);
    window.addEventListener("keydown", (e) => this.onKey(e), o);
    window.addEventListener("keyup", (e) => this.keys.delete(e.code), o);
    window.addEventListener("blur", () => { this.keys.clear(); this.down = false; }, o);
    window.addEventListener("mousemove", (e) => this.onMouse(e), o);
    window.addEventListener("mousedown", (e) => this.onDown(e), o);
    window.addEventListener("mouseup", (e) => { if (e.button === 0) this.down = false; }, o);
    window.addEventListener("contextmenu", (e) => { if (this.mode === "play") e.preventDefault(); }, o);
    window.addEventListener("wheel", (e) => { if (this.active()) this.cycle(e.deltaY > 0 ? 1 : -1); }, { ...o, passive: true });
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    this.abort.abort();
    cancelAnimationFrame(this.raf);
  }

  /* ───────────── public controls ───────────── */
  startDemo() {
    this.mode = "demo";
    this.game = "pvp";
    this.paused = false;
    this.diff = DIFFS.normal;
    this.setup(null);
  }
  /** level: 1 the zombie city (then the old town), 3 the same co-op game on the streets of New York */
  startMatch(skin: number, diff: DiffId, game: GameMode = "pvp", weather: WeatherId = "auto", level = 1) {
    this.startLevel = level;
    audio.unlock();
    this.mode = "play";
    this.game = game;
    this.bug.setWeather(weather);
    this.paused = false;
    this.diff = DIFFS[diff];
    this.down = false;
    this.setup(skin);
  }
  togglePause(force?: boolean) {
    if (this.mode !== "play" || this.phase === "over") return;
    this.paused = force ?? !this.paused;
    this.down = false;
    this.keys.clear();
    this.hudDirty = true;
  }
  toggleMute() {
    audio.setMuted(!audio.muted);
    this.hudDirty = true;
  }
  /** background music: off until you switch it on */
  toggleMusic() {
    audio.unlock();
    audio.setMusic(!audio.musicOn);
    this.hudDirty = true;
  }
  selectWeapon(i: number) {
    const p = this.player;
    if (p && p.alive && this.active() && WEAPON_ORDER[i]) this.switchWeapon(p, WEAPON_ORDER[i]);
  }
  setTouchMove(x: number, y: number) {
    this.useTouch = true;
    this.tMove.x = x;
    this.tMove.y = y;
  }
  setTouchAim(x: number, y: number, active: boolean, fire: boolean) {
    this.useTouch = true;
    audio.unlock();
    if (active && (x || y)) { this.tAim.x = x; this.tAim.y = y; }
    this.tAim.active = active;
    this.tAim.fire = fire;
    if (!active) this.nextSpec();
  }
  action(a: "dash" | "reload" | "next" | "strat1" | "strat2") {
    const p = this.player;
    if (!p || !this.active()) return;
    if (a === "strat1" || a === "strat2") { if (this.game === "bugs") this.bug.useStrat(a === "strat1" ? 0 : 1); }
    else if (a === "dash") this.wantDash = true;
    else if (a === "reload") this.reload(p);
    else this.cycle(1);
  }

  /* ───────────── input ───────────── */
  active() { return this.mode === "play" && !this.paused && this.phase !== "over"; }

  resize() {
    const iw = window.innerWidth, ih = window.innerHeight;
    let s = Math.min(Math.max(iw, ih) / 420, Math.min(iw, ih) / 236);
    s = s >= 2 ? Math.floor(s) : Math.max(1, s);
    const W = (this.W = Math.ceil(iw / s)), H = (this.H = Math.ceil(ih / s));
    this.canvas.width = W;
    this.canvas.height = H;
    this.canvas.style.width = `${W * s}px`;
    this.canvas.style.height = `${H * s}px`;
    this.ctx.imageSmoothingEnabled = false;
    // warm vignette for depth
    const v = document.createElement("canvas");
    v.width = W; v.height = H;
    const g = v.getContext("2d")!;
    const gr = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.38, W / 2, H / 2, Math.hypot(W, H) * 0.56);
    gr.addColorStop(0, "rgba(46,18,52,0)");
    gr.addColorStop(1, "rgba(46,18,52,0.4)");
    g.fillStyle = gr;
    g.fillRect(0, 0, W, H);
    this.vig = v;
    this.atmo.resize(W, H);
  }

  setRest(f: Fighter, on: boolean) {
    if (f.resting === on) return;
    f.resting = on;
    if (on) { f.drinkIn = 1.2; this.say(f.x, f.y - 24, "ISTIRAHAT...", "#8af0ff"); }
    else if (f.restK > 0.3) this.say(f.x, f.y - 24, "SEGAR!", "#7dff9a");
    this.hudDirty = true;
  }
  toggleRest() {
    const p = this.player;
    if (!p || !p.alive || !this.active() || this.game !== "bugs" || this.typing || this.climb) return;
    if (!p.resting && (p.swingT > 0 || p.dashT > 0)) return;
    this.setRest(p, !p.resting);
  }

  openChat() {
    if (this.typing || performance.now() - this.chatShut < 250 || !this.active() || this.game !== "bugs" || !this.player) return;
    this.typing = true;
    this.keys.clear();
    this.down = false;
    this.cb.onChat?.(true);
  }
  chatShut = 0;
  closeChat() {
    if (!this.typing) return;
    this.typing = false;
    this.chatShut = performance.now();
    this.keys.clear();
    this.cb.onChat?.(false);
  }

  onKey(e: KeyboardEvent) {
    if (this.mode !== "play" || this.typing) return;
    audio.unlock();
    const c = e.code;
    if (c === "Space" || c.startsWith("Arrow")) e.preventDefault();
    if (e.repeat) return;
    if (c === "Escape" || c === "KeyP") { this.togglePause(); return; }
    if (c === "KeyM") { this.toggleMute(); return; }
    if (c === "KeyN") { this.toggleMusic(); return; }
    if ((c === "KeyT" || c === "Enter") && this.game === "bugs" && this.active()) { e.preventDefault(); this.openChat(); return; }
    if (!this.active()) return;
    this.keys.add(c);
    const p = this.player;
    if (!p || !p.alive) return;
    if (c.startsWith("Digit")) this.selectWeapon(c === "Digit0" ? 9 : +c.slice(5) - 1);
    else if (c === "Minus") this.selectWeapon(10);
    else if (c === "KeyQ") this.switchWeapon(p, p.lastWeapon);
    else if (c === "KeyR") this.reload(p);
    else if (c === "Space" || (c === "ShiftLeft" && this.game !== "bugs")) this.wantDash = true;
    else if (c === "KeyC") this.toggleRest();
    else if (this.game === "bugs" && c === "KeyE") this.bug.useDoor();   // open / shut doors
    else if (this.game === "bugs" && c === "KeyF") this.skipMission();   // skip the search
    else if (this.game === "bugs" && (c === "KeyZ" || c === "KeyX")) this.bug.useStrat(c === "KeyZ" ? 0 : 1);
  }

  onMouse(e: MouseEvent) {
    const r = this.canvas.getBoundingClientRect();
    this.mx = ((e.clientX - r.left) / r.width) * this.W;
    this.my = ((e.clientY - r.top) / r.height) * this.H;
    this.useTouch = false;
  }

  onDown(e: MouseEvent) {
    audio.unlock();
    if (!this.active() || this.typing) return;
    if ((e.target as HTMLElement | null)?.closest?.("button")) return;
    this.onMouse(e);
    if (e.button === 2) { this.wantDash = true; return; }
    if (e.button !== 0) return;
    if (this.player && !this.player.alive) this.nextSpec();
    this.down = true;
  }

  cycle(d: number) {
    const p = this.player;
    if (!p || !p.alive) return;
    const i = WEAPON_ORDER.indexOf(p.weapon);
    this.switchWeapon(p, WEAPON_ORDER[(i + d + WEAPON_ORDER.length) % WEAPON_ORDER.length]);
  }

  nextSpec() {
    const p = this.player;
    if (!p || p.alive) return;
    const mates = this.fighters.filter((f) => f.alive && f.team === p.team && !f.civ);
    if (!mates.length) return;
    const i = this.spec ? mates.indexOf(this.spec) : -1;
    this.spec = mates[(i + 1) % mates.length];
    this.hudDirty = true;
  }

  /* ───────────── match / round flow ───────────── */
  mkFighter(name: string, team: number, skin: number, isPlayer: boolean, role: WeaponId, look = team): Fighter {
    const isMelee = WEAPONS[role].melee;
    return {
      id: this.ids++, name, team, skin, isPlayer, x: 0, y: 0, vx: 0, vy: 0, kx: 0, ky: 0, hp: MAX_HP, alive: true, aim: 0,
      weapon: isPlayer ? "shotgun" : role, lastWeapon: isPlayer ? "bazooka" : "pistol",
      ammo: { sniper: 0, shotgun: 0, pistol: 0, bazooka: 0, karambit: 0, bat: 0, hockey: 0, hammer: 0, axe: 0, ak47: 0, goldgun: 0 },
      cd: 0, reloadT: 0, reloadDur: 1, swingT: 0, swingDur: 0.2, swingDir: 1, dashT: 0, dashCd: 0, dashX: 0, dashY: 0, ghostT: 0,
      walkT: rand() * 3, moving: false, stepT: 0, hitFlash: 0, recoil: 0, flash: 0, tilt: 0, kills: 0, deaths: 0, dmg: 0, roundKills: 0,
      deadT: 0, z: 0, vz: 0, rot: 0, vrot: 0, rest: true, scarf: [0, 0, 0, 0, 0, 0], gone: false, look, down: false, bleed: 0, rev: 0, combo: 0, lastSwing: -9, swingKind: 0, pend: 0, bloody: 0, loud: 0, swingHit: [], onStair: false, ouch: 0, joy: 0, fear: 0, pump: 0, smokeT: 0, seed: 0, sAim: NaN, sad: 0, mad: 0, talkT: 0, stam: 100, runK: 0, exh: false, resting: false, restK: 0, drinkT: 0, drinkIn: 8 + rand() * 14, climbY: 0, lungeT: 0, lungeV: 0, lungeA: 0, civ: false, hid: false, spinT: 0, spinIn: 2, rush: 0, rushN: 0, rushAt: -9, guardT: 0, calmT: 0, wind: true, killer: null,
      ai: isPlayer ? null : {
        role, melee: isMelee ? role : (["karambit", "bat", "hockey", "hammer", "axe"] as WeaponId[])[(rand() * 5) | 0], target: null, hunt: null, seen: 0, thinkT: 0,
        path: [], pi: 0, pathT: 0, err: 0, errT: 0, strafe: 1, strafeT: 0, charge: 0, tapT: 0, wp: null,
        stuckT: 0, lastX: 0, lastY: 0, unstickT: 0, ux: 0, uy: 0, goal: null, goalKey: -1, goalT: 0, goalSince: 0, ban: -1, banT: 0,
      },
    };
  }

  setup(skin: number | null) {
    this.fighters = [];
    this.score = [0, 0];
    this.round = 0;
    this.feed = [];
    this.streak = null;
    this.matchDone = false;
    this.spec = null;
    const bugs = this.game === "bugs";
    this.route = bugs && skin !== null ? (this.startLevel === 3 ? [3, 1, 2] : [1, 2, 3]) : [1];
    this.ri = 0;
    this.level = this.route[0];
    this.intro = null;
    this.trans = null;
    this.fat = null;
    this.bug.saved = 0;
    this.bug.civAll = 0;
    this.bug.civUsed = [];
    this.art = mapArt(bugs ? this.level : 0);
    this.fctx = this.art.floor.getContext("2d")!;
    this.fctx.drawImage(this.art.clean, 0, 0); // wipe old stains and bodies
    this.parts = []; this.texts = []; this.glows = []; this.sparks = []; this.rings = [];
    this.bug.reset();
    this.talk.reset();
    this.inK = 0;
    this.cuts = [];
    this.climb = null;
    this.visMem = {};
    this.lamps = bugs ? cityLamps() : [];
    this.shells = bugs && !this.art.ny && this.art.roofs ? buildShells(this.art.walls, this.art.roofs) : [];
    if (this.art.ny) nyLights((x, y, r, a, house, fl) => this.lamps.push({ x, y, r, a, col: "w", pad: false, house, fx: fl ? 1 : undefined }));
    this.roofA = HOUSES.map(() => 1);
    this.inside = false;
    const r0 = bugs ? shuffle<WeaponId>(["shotgun", "sniper", "bazooka", "pistol"]) : shuffle(WEAPON_ORDER.slice()), r1 = shuffle(WEAPON_ORDER.slice());
    const others = [0, 1, 2, 3, 4].filter((s) => s !== skin);
    for (let i = 0; i < (bugs ? 4 : TEAM_SIZE); i++) {
      if (skin !== null && i === 0) this.fighters.push(this.mkFighter("KAMU", 0, skin, true, "shotgun", bugs ? 2 : 0));
      else {
        const s = skin !== null ? others[i - 1] : i;
        this.fighters.push(this.mkFighter((bugs ? SURVIVORS : SKINS)[s], 0, s, false, bugs ? ROLE[s] : r0[i], bugs ? 2 : 0));
      }
    }
    if (!bugs) for (let i = 0; i < TEAM_SIZE; i++) this.fighters.push(this.mkFighter(ENEMY_NAMES[i], 1, i, false, r1[i]));
    this.player = skin !== null ? this.fighters[0] : null;
    if (bugs && skin === 10 && this.player) { this.player.weapon = "ak47"; this.player.lastWeapon = "pistol"; } // SWAT: the rifle in his hands, the sidearm one key (Q) away
    if (bugs && skin === 9 && this.player) this.player.lastWeapon = "axe"; // the firefighter: shotgun in his hands, the axe one key (Q) away
    this.nextRound();
    if (bugs) this.bug.start();
    if (bugs && skin !== null) this.startIntro();
    const f = this.focus();
    if (f) { this.cam.x = f.x; this.cam.y = f.y; }
  }

  nextRound() {
    this.round++;
    this.phase = "freeze";
    this.phaseT = 3;
    this.roundT = 0;
    this.timeLeft = ROUND_TIME;
    this.winner = -1;
    this.slowT = 0;
    this.bullets = [];
    this.pickups = [];
    this.slashes = [];
    this.tracers = [];
    this.ghosts = [];
    this.drops = [];
    this.barrels = BARREL_SPOTS.map((p) => ({ x: p.x, y: p.y, hp: 40, alive: true, flash: 0, fuse: 0, by: null }));
    const order = [shuffle([0, 1, 2, 3, 4]), shuffle([0, 1, 2, 3, 4])];
    const lanes = [shuffle([0, 1, 2, 3, (rand() * 4) | 0]), shuffle([0, 1, 2, 3, (rand() * 4) | 0])];
    const n = [0, 0];
    for (const f of this.fighters) {
      const i = n[f.team]++;
      const s = SPAWNS[f.team][order[f.team][i]];
      f.x = s.x; f.y = s.y; f.vx = f.vy = f.kx = f.ky = 0;
      f.hp = MAX_HP; f.alive = true; f.aim = f.team === 0 ? 0 : Math.PI;
      f.cd = f.reloadT = f.swingT = f.dashT = f.dashCd = f.hitFlash = f.recoil = f.flash = f.deadT = f.tilt = 0;
      f.z = f.vz = f.rot = f.vrot = 0; f.rest = true;
      f.roundKills = 0; f.killer = null; f.gone = false; f.down = false; f.rev = 0; f.pend = 0; f.combo = 0; f.bloody = 0; f.loud = 0; f.onStair = false; f.ouch = f.joy = f.fear = f.pump = f.smokeT = 0;
      f.rush = 0; f.guardT = 0; f.calmT = 0; f.wind = true;
      f.stam = 100; f.runK = 0; f.restK = 0; f.resting = false; f.drinkT = 0; f.exh = false; f.climbY = 0; f.lungeT = 0;
      for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
      for (const id of WEAPON_ORDER) f.ammo[id] = WEAPONS[id].mag;
      if (f.ai) {
        const ai = f.ai;
        f.weapon = ai.role;
        ai.target = ai.hunt = null; ai.seen = 0; ai.thinkT = rand() * 0.2; ai.path = []; ai.pi = 0; ai.pathT = 0;
        ai.charge = 0; ai.unstickT = 0; ai.stuckT = 0; ai.lastX = f.x; ai.lastY = f.y;
        ai.wp = LANES[lanes[f.team][i]];
      }
    }
    this.spec = null;
    this.setBanner(`RONDE ${this.round}`, "Lumpuhkan semua musuh!", "white", 2.6);
    this.hudDirty = true;
  }

  aliveCount(team: number) {
    let n = 0;
    for (const f of this.fighters) if (f.alive && f.team === team && !f.civ) n++;
    return n;
  }

  checkRoundEnd() {
    if (this.phase !== "live" || this.game === "bugs") return;
    const a = this.aliveCount(0), b = this.aliveCount(1);
    if (a === 0 || b === 0) this.endRound(a > 0 ? 0 : b > 0 ? 1 : -1, false);
  }

  timeout() {
    const a = this.aliveCount(0), b = this.aliveCount(1);
    let w = a > b ? 0 : b > a ? 1 : -1;
    if (w < 0) {
      const hp = [0, 0];
      for (const f of this.fighters) if (f.alive) hp[f.team] += f.hp;
      w = hp[0] > hp[1] ? 0 : hp[1] > hp[0] ? 1 : -1;
    }
    this.endRound(w, true);
  }

  endRound(w: number, timeout: boolean) {
    if (this.phase !== "live") return;
    this.phase = "end";
    this.phaseT = 3.6;
    this.winner = w;
    this.slowT = timeout ? 0 : 1.0;
    if (w >= 0) this.score[w]++;
    this.matchDone = w >= 0 && this.score[w] >= WIN_ROUNDS;
    this.zoom = 0.07;
    if (this.mode === "play") {
      if (w === 0) {
        this.setBanner(this.matchDone ? "MATCH MENANG!" : "RONDE MENANG!", timeout ? "Waktu habis - tim kamu unggul" : "Semua musuh lumpuh!", "gold", 3.3);
        audio.play("win");
      } else if (w === 1) {
        this.setBanner(this.matchDone ? "MATCH KALAH" : "RONDE KALAH", timeout ? "Waktu habis - musuh unggul" : "Tim kamu lumpuh...", "red", 3.3);
        audio.play("lose");
      } else this.setBanner("SERI!", "Ronde diulang", "white", 3.3);
    }
    this.hudDirty = true;
  }

  /** bug mode: the mission is won (all waves cleared) or lost (squad wiped) */
  endMission(win: boolean) {
    if (this.phase !== "live") return;
    this.phase = "end";
    this.phaseT = 4.2;
    this.winner = win ? 0 : 1;
    this.score = [win ? 1 : 0, win ? 0 : 1];
    this.matchDone = true;
    this.slowT = 1.2;
    this.zoom = 0.07;
    if (win) { this.setBanner("BERHASIL KABUR!", `Helikopter membawa tim keluar - penyintas diselamatkan: ${this.bug.saved}/${this.bug.civAll}`, "gold", 4.2); audio.play("win"); }
    else { this.setBanner("MISI GAGAL", "Tim tidak selamat dari kota ini...", "red", 4); audio.play("lose"); }
    this.hudDirty = true;
  }

  finishMatch() {
    if (this.mode === "demo") { this.setup(null); return; }
    this.phase = "over";
    this.down = false;
    const rows: ResultRow[] = this.fighters.filter((f) => !f.civ).map((f) => ({ name: f.name, team: f.team, skin: f.skin, kills: f.kills, deaths: f.deaths, dmg: Math.round(f.dmg), me: f.isPlayer }));
    const win = this.score[0] > this.score[1];
    const best = rows.filter((r) => r.team === (win ? 0 : 1)).sort((a, b) => b.kills - a.kills || b.dmg - a.dmg)[0];
    this.cb.onMatchEnd({ win, score: [this.score[0], this.score[1]], rows, mvp: best ? best.name : "", game: this.game, wave: this.bug.found.filter(Boolean).length, waves: 3, kills: this.bug.kills });
    this.hudDirty = true;
  }

  setBanner(title: string, sub: string, tone: Banner["tone"], dur: number) {
    this.banner = { id: this.ids++, title, sub, tone };
    this.bannerT = dur;
    this.hudDirty = true;
  }

  /* ───────────── helpers ───────────── */
  focus(): Fighter | null {
    const p = this.player;
    if (p) {
      if (p.alive) return p;
      if (!this.spec || !this.spec.alive) {
        let best: Fighter | null = null, bd = 1e9;
        for (const f of this.fighters) {
          if (!f.alive || f.team !== p.team || f.civ) continue;
          const d = Math.hypot(f.x - p.x, f.y - p.y);
          if (d < bd) { bd = d; best = f; }
        }
        this.spec = best ?? (p.killer && p.killer.alive ? p.killer : null);
        if (this.spec) this.hudDirty = true;
      }
      return this.spec ?? p;
    }
    if (!this.spec || !this.spec.alive || this.specT <= 0) {
      const live = this.fighters.filter((f) => f.alive);
      if (live.length) { this.spec = live[(rand() * live.length) | 0]; this.specT = 7; }
    }
    return this.spec;
  }

  snd(name: SfxName, x: number, y: number, base = 1) {
    if (this.mode !== "play") return;
    const d = Math.hypot(x - this.cam.x, y - this.cam.y);
    audio.play(name, base * clamp(1.15 - d / 340, 0, 1));
  }

  shake(amt: number, x: number, y: number) {
    const d = Math.hypot(x - this.cam.x, y - this.cam.y);
    const s = amt * clamp(1.1 - d / 300, 0, 1);
    this.cam.shake = Math.min(10, this.cam.shake + s * 0.75);
  }

  puff(x: number, y: number, n: number, colors: string[], sp: number, o: PartOpt = {}) {
    if (this.parts.length > 600) return;
    for (let i = 0; i < n; i++) {
      const a = rand() * PI2, v = sp * (0.3 + rand() * 0.7);
      this.parts.push({
        x, y, z: o.z ?? 3, vx: Math.cos(a) * v + (o.vx ?? 0), vy: Math.sin(a) * v * 0.75 + (o.vy ?? 0),
        vz: o.vz ?? 20 + rand() * 40, life: 0, max: (o.max ?? 0.4) * (0.6 + rand() * 0.6),
        color: colors[(rand() * colors.length) | 0], size: o.size ?? 2, grav: o.grav ?? 160, drag: o.drag ?? 3, stamp: o.stamp ?? false, shell: o.shell,
      });
    }
  }

  dust(x: number, y: number, n: number) {
    this.puff(x, y, n, ["#f3deb0", "#e9d3a4", "#ffffff"], 32, { z: 0, vz: 22, max: 0.45, size: 3, grav: 30 });
  }

  say(x: number, y: number, text: string, color: string) {
    this.texts.push({ x: x + (rand() - 0.5) * 6, y, text, color, life: 0, v: null, amt: 0 });
  }

  boxHit(x: number, y: number) {
    return solidAt(x - HALF, y - HALF) || solidAt(x + HALF, y - HALF) || solidAt(x - HALF, y + HALF) || solidAt(x + HALF, y + HALF);
  }

  /** move with wall sliding; returns true when a wall was hit */
  slide(f: Body, dx: number, dy: number, bounce = 0.3): boolean {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 4));
    let hit = false;
    dx /= n; dy /= n;
    for (let i = 0; i < n; i++) {
      if (dx) {
        if (!this.boxHit(f.x + dx, f.y)) f.x += dx;
        else { f.vx = 0; f.kx *= -bounce; dx = -dx * bounce; hit = true; }
      }
      if (dy) {
        if (!this.boxHit(f.x, f.y + dy)) f.y += dy;
        else { f.vy = 0; f.ky *= -bounce; dy = -dy * bounce; hit = true; }
      }
    }
    return hit;
  }

  /* ───────────── actions ───────────── */
  switchWeapon(f: Fighter, id: WeaponId) {
    if (f.weapon === id) return;
    f.lastWeapon = f.weapon;
    f.weapon = id;
    f.reloadT = 0;
    f.swingT = 0;
    f.pend = 0;
    f.cd = Math.max(f.cd, 0.12);
    f.rush = 0;
    if (id === "karambit") f.spinT = 0.6; // drawn with a flourish
    if (f.isPlayer) { audio.play("click"); this.hudDirty = true; }
  }

  reload(f: Fighter) {
    const w = WEAPONS[f.weapon];
    if (w.melee || f.reloadT > 0 || f.ammo[w.id] >= w.mag) return;
    f.reloadT = f.reloadDur = w.reload;
  }

  /** the sounds and the leftovers of a reload, each at its own moment (a = progress before this frame, b = after) */
  reloadFx(f: Fighter, w: WeaponDef, a: number, b: number) {
    const at = (q: number) => a < q && b >= q, v = f.isPlayer ? 1 : 0.45, c = Math.cos(f.aim), s = Math.sin(f.aim);
    if (w.id === "shotgun") {
      for (let i = 0; i < 6; i++) if (at((i + 0.42) / 6.6)) this.snd("shellin", f.x, f.y, v); // one shell after the other
      if (at(0.92)) this.snd("pump", f.x, f.y, v);
    } else if (w.id === "bazooka") {
      if (at(0.2)) this.snd("magout", f.x, f.y, v);
      if (at(0.6)) this.snd("magin", f.x, f.y, v * 1.2);
      if (at(0.9)) this.snd("rack", f.x, f.y, v);
    } else {
      if (at(0.18)) {
        // the empty magazine drops out and stays on the floor
        this.snd("magout", f.x, f.y, v);
        this.puff(f.x + c * 3, f.y + s * 3 + 2, 1, ["#2c2f3d"], 10, { z: 6, vz: 10, max: 0.5, size: 2, grav: 330, drag: 1, stamp: true, shell: 3 });
      }
      if (at(0.72)) this.snd("magin", f.x, f.y, v);
      if (at(0.9)) this.snd("rack", f.x, f.y, v);
    }
  }

  dash(f: Fighter, dx: number, dy: number) {
    if (f.dashCd > 0 || f.dashT > 0 || !f.alive) return;
    if (this.game === "bugs" && f.isPlayer) { if (f.stam < 25) { if (this.t - this.lastDeflect > 0.6) { this.lastDeflect = this.t; this.say(f.x, f.y - 22, "CAPEK!", "#ffb347"); } return; } f.stam -= 25; this.setRest(f, false); }
    let l = Math.hypot(dx, dy);
    if (l < 0.2) { dx = Math.cos(f.aim); dy = Math.sin(f.aim); l = 1; }
    f.dashX = dx / l; f.dashY = dy / l;
    f.dashT = DASH_TIME; f.dashCd = DASH_CD; f.ghostT = 0;
    this.snd("dash", f.x, f.y, 0.9);
    this.dust(f.x, f.y + 5, 5);
  }

  tryFire(f: Fighter) {
    if (f.cd > 0 || f.reloadT > 0 || f.dashT > 0) return;
    const w = WEAPONS[f.weapon];
    if (f.resting) this.setRest(f, false);
    f.drinkT = 0;
    if (w.melee) { this.swing(f); return; }
    if (f.ammo[w.id] <= 0) { this.reload(f); return; }
    f.ammo[w.id]--;
    f.cd = w.cd;
    f.recoil = 1;
    f.flash = 0.075;
    f.seed = rand();
    f.loud = 0.7;
    f.smokeT = w.id === "pistol" ? 0.4 : 0.9;
    const rocket = w.id === "bazooka";
    const c = Math.cos(f.aim), s = Math.sin(f.aim);
    let bx = f.x + c * (w.len + 2), by = f.y + 1 + s * (w.len + 2);
    if (blockAt(bx, by) || !los(f.x, f.y, bx, by)) { bx = f.x + c * 2; by = f.y + s * 2; }
    for (let i = 0; i < w.pellets; i++) {
      const a = f.aim + (rand() - 0.5) * 2 * w.spread;
      const life = w.life * (w.pellets > 1 ? 0.75 + rand() * 0.4 : 1);
      this.bullets.push({
        x: bx, y: by, dx: Math.cos(a), dy: Math.sin(a), speed: w.speed * (w.pellets > 1 ? 0.85 + rand() * 0.3 : 1),
        team: f.team, owner: f, dmg: w.dmg, life, max: life, pierce: w.pierce, hit: [], wid: w.id, ox: bx, oy: by, trav: 0,
        ax: f.isPlayer && !this.useTouch ? this.mx + this.cl : undefined, ay: f.isPlayer && !this.useTouch ? this.my + this.ct : undefined,
      });
    }
    // every shot leaves a bright streak, and the barrel throws a short cone of light down the line of fire
    if (!rocket && w.id !== "sniper") {
      const tl = Math.min(w.speed * w.life * 0.5, 170);
      for (let i = 0; i < Math.min(w.pellets, 4); i++) {
        const a = f.aim + (rand() - 0.5) * 2 * w.spread, L = rayEnd(bx, by, a, tl);
        this.tracers.push({ x0: bx + Math.cos(a) * 6, y0: by + Math.sin(a) * 6, x1: bx + Math.cos(a) * L, y1: by + Math.sin(a) * L, life: 0.09, color: w.id === "goldgun" ? "#ffd700" : w.id === "pistol" ? "#ffe9a0" : "#ffd27a" });
      }
    }
    this.glows.push({ x: bx + c * 16, y: by + s * 16, r: w.id === "shotgun" ? 38 : 28, life: 0.07, max: 0.07 });
    if (f.isPlayer && w.id !== "pistol") this.zoom = Math.max(this.zoom, w.id === "shotgun" ? 0.034 : w.id === "ak47" ? 0.007 : 0.022); // the whole view punches in with the big guns
    if (w.id === "shotgun") {
      // a cone of burning powder and a ring of smoke - and the whole world stops for a blink
      this.puff(bx, by, 8, ["#ffffff", "#ffd27a", "#ff7a3c"], 110, { z: 6, vx: c * 260, vy: s * 260, vz: 4, max: 0.2, size: 2, grav: 0, drag: 9 });
      this.rings.push({ x: bx + c * 8, y: by + s * 8, life: 0.1, r: 20 });
      this.glows.push({ x: bx + c * 10, y: by + s * 10, r: 46, life: 0.1, max: 0.1 });
      if (f.isPlayer) this.hitStop = Math.max(this.hitStop, 0.018);
      this.puff(bx, by, 10, ["#ffffff", "#ffe45c", "#ff9a3c"], 70, { z: 6, vx: c * 210, vy: s * 210, vz: 6, max: 0.16, size: 1, grav: 0, drag: 8 });
      this.puff(bx + c * 6, by + s * 6, 5, ["#e9e2d2", "#b9b3a8", "#8a8478"], 26, { z: 7, vx: c * 40, vy: s * 40, vz: 10, max: 0.7, size: 3, grav: -16, drag: 3 });
    } else if (w.id === "sniper") {
      this.puff(bx, by, 8, ["#ffffff", "#e9e2d2"], 30, { z: 7, vx: c * 90, vy: s * 90, vz: 8, max: 0.5, size: 2, grav: -10, drag: 4 });
      this.rings.push({ x: bx + c * 10, y: by + s * 10, life: 0.1, r: 16 });
    } else if (w.id === "goldgun") {
      // gold dust off the muzzle, and a ring
      this.puff(bx, by, 9, ["#fff6c0", "#ffd700", "#f5c542"], 60, { z: 7, vx: c * 120, vy: s * 120, vz: 20, max: 0.45, size: 1, grav: 60, drag: 4 });
      this.rings.push({ x: bx + c * 8, y: by + s * 8, life: 0.1, r: 14 });
    }
    f.kx -= c * w.kick * 9; f.ky -= s * w.kick * 9;
    if (f === this.focus()) {
      this.cam.kx -= c * w.kick; this.cam.ky -= s * w.kick;
      this.cam.shake = Math.min(10, this.cam.shake + w.shake * 0.7);
    } else this.shake(w.shake * 0.5, f.x, f.y);
    this.snd(w.id as SfxName, f.x, f.y);
    this.glows.push({ x: bx, y: by, r: rocket ? 30 : w.id === "pistol" ? 14 : w.id === "sniper" ? 26 : 22, life: 0.08, max: 0.08 });
    if (rocket) {
      // back-blast
      this.puff(f.x - c * 9, f.y - s * 9, 9, ["#ffffff", "#ffd27a", "#ff9a3c", "#b9b3a8"], 45, { z: 6, vx: -c * 110, vy: -s * 110, vz: 16, max: 0.5, size: 3, grav: -12 });
      this.glows.push({ x: f.x - c * 10, y: f.y - s * 10, r: 22, life: 0.1, max: 0.1 });
    } else if (w.id === "shotgun") f.pump = 0.34; // the shell comes out when the action is worked
    else this.shell(f, w.id);
    // muzzle: a puff of smoke, and sparks spat out along the barrel
    this.puff(bx, by, w.id === "pistol" ? 1 : 3, ["#ffffff", "#e9e2d2", "#cfc8ba"], 14, { z: 6, vx: c * 26, vy: s * 26, vz: 14, max: 0.4, grav: -14 });
    this.puff(bx, by, w.id === "pistol" ? 2 : w.id === "shotgun" ? 7 : 4, ["#ffffff", "#ffe45c", "#ffb347"], 45, { z: 6, vx: c * 170, vy: s * 170, vz: 8, max: 0.13, size: 1, grav: 0, drag: 7 });
    if (w.id === "sniper") this.rings.push({ x: bx, y: by, life: 0.12, r: 10 });
    if (f.isPlayer) this.hudDirty = true;
  }

  /** a spent case spins out of the gun and stays on the floor */
  shell(f: Fighter, wid: WeaponId) {
    const c = Math.cos(f.aim), s = Math.sin(f.aim), side = c < 0 ? -1 : 1; // thrown up and back, away from the face
    this.puff(f.x + c * 3, f.y + s * 3, 1, ["#f1cf6a"], 14, { z: 9, vx: -s * 42 * side - c * 22, vy: c * 42 * side - s * 22 - 6, vz: 105 + rand() * 30, max: 0.7, size: 2, grav: 360, drag: 1, stamp: true, shell: wid === "shotgun" ? 2 : 1 });
  }

  /** a bullet hit something solid: what flies off depends on what it was */
  impact(x: number, y: number, dx: number, dy: number, big: boolean) {
    const k = kindAt(Math.floor(x / TILE), Math.floor(y / TILE)), st = styleAt(Math.floor(x / TILE), Math.floor(y / TILE));
    const px = x - dx * 3, py = y - dy * 3, back = { vx: -dx * 45, vy: -dy * 45 }, city = this.game === "bugs";
    this.sparks.push({ x: px, y: py, life: 0.07 });
    this.hitFx(px, py, Math.atan2(-dy, -dx), big ? 8 : 5, 0);
    if (city && k === 2 && st >= 1 && st <= 5) {
      // car: a shower of sparks and a little glass
      this.puff(px, py, big ? 8 : 5, ["#ffffff", "#ffe45c", "#ffb347"], 95, { ...back, vz: 60, size: 1, grav: 380, max: 0.35 });
      this.puff(px, py, 2, ["#8fd0e0", "#d9f5f9"], 50, { ...back, vz: 70, size: 1, grav: 380, max: 0.5, stamp: true });
      this.snd("deflect", px, py, 0.3);
    } else if (city && k === 2 && (st === 14 || st === 15)) {
      // shop shelves and fridges: the goods go flying
      this.puff(px, py, big ? 8 : 4, GOODS, 70, { ...back, vz: 95, size: 2, grav: 360, max: 0.7, stamp: true });
    } else if (city && k === 2 && st >= 10) {
      // furniture: splinters
      this.puff(px, py, big ? 7 : 4, ["#8a6844", "#6a4a2e", "#c9a36a"], 60, { ...back, vz: 85, size: 1, grav: 360, max: 0.6, stamp: true });
    } else {
      // wall: dust and chips
      this.puff(px, py, big ? 5 : 3, ["#ffffff", "#d9d2c0", "#8a8478"], 50, { ...back, max: 0.28 });
      this.puff(px, py, 2, ["#6a665c", "#3a3832"], 40, { ...back, vz: 60, size: 1, grav: 340, max: 0.6, stamp: true });
    }
    if (!solidAt(px, py + 2)) { this.fctx.fillStyle = "rgba(10,8,12,0.55)"; this.fctx.fillRect(px | 0, (py + 2) | 0, 2, 1); } // scorch mark
    this.snd("wall", px, py, 0.6);
  }

  /** closest enemy roughly in front: melee swings pull towards it */
  meleeTarget(f: Fighter, R: number, half: number): Pt | null {
    const pool: Pt[] = this.fighters.filter((e) => e.alive && e.team !== f.team);
    if (this.game === "bugs" && f.team === 0) for (const z of this.bug.bugs) pool.push(z);
    let best: Pt | null = null, bd = R;
    for (const e of pool) {
      const dx = e.x - f.x, dy = e.y - f.y, d = Math.hypot(dx, dy);
      if (d < bd && (d < 10 || Math.abs(angDiff(f.aim, Math.atan2(dy, dx))) < half)) { bd = d; best = e; }
    }
    return best;
  }

  /** melee: every third swing is a finisher (baseball: overhead smash on the head, karambit: a spin that cuts all around) */
  swing(f: Fighter) {
    const w = WEAPONS[f.weapon];
    const tgt = this.meleeTarget(f, w.range + 32, 1.45);
    if (tgt && this.tryFatality(f, w, tgt)) return;
    let la = f.aim, push = 1;
    f.sAim = NaN;
    if (tgt) {
      la = Math.atan2(tgt.y - f.y, tgt.x - f.x);
      f.sAim = la; // magnetism: the swing locks onto whatever is in front of you
      if (f.ai) f.aim = la;
      if (Math.hypot(tgt.x - f.x, tgt.y - f.y) < w.range * 0.6) push = 0.25; // already in reach: don't run past it
    }
    // the step forward covers exactly the gap to the target, so the weapon visibly lands on it
    const gap = tgt ? Math.hypot(tgt.x - f.x, tgt.y - f.y) : -1;
    const step = (base: number) => (gap >= 0 ? clamp((gap - w.range * 0.62) * 9, 0, 250) : base * push);
    const c = Math.cos(la), s = Math.sin(la);
    // a flurry: now and then the blows come like from somebody who has done this all their life - four or five in a breath
    if (f.isPlayer && this.game === "bugs" && f.rush <= 0 && tgt && this.t - f.rushAt > 3.5 && rand() < ((tgt as Bug).tier === 2 ? 0.65 : 0.22)) {
      f.rush = f.rushN = 4 + (rand() < 0.5 ? 1 : 0);
      this.say(f.x, f.y - 40, "RUSH!", "#ff9df0");
      this.zoom = Math.max(this.zoom, 0.045);
      this.snd("dash", f.x, f.y, 0.7);
    }
    if (f.rush > 0 && !tgt) f.rush = 0; // nothing left to hit
    const rushing = f.rush > 0;
    if (rushing) {
      f.rush--; f.rushAt = this.t;
      f.combo = f.rush === 0 ? 2 : f.rush % 2; // the last one is the weapon's own finisher
      this.ghosts.push({ x: f.x, y: f.y, team: f.team, look: f.look, skin: f.skin, flip: Math.cos(la) < 0, life: 0.2 });
    } else f.combo = this.t - f.lastSwing < 1.4 ? (f.combo + 1) % 3 : 0;
    if (f.isPlayer && this.game === "bugs") f.stam = Math.max(0, f.stam - (rushing ? 3 : f.combo === 2 ? 14 : 8)); // heavy swings tire you out
    f.lastSwing = this.t;
    // every weapon ends its combo its own way: bat and hammer come down from above (the hammer shakes the ground),
    // the axe and the karambit go all the way round, the hockey stick sweeps the legs away
    const kind = f.combo === 2 ? (w.id === "axe" || w.id === "karambit" ? 3 : w.id === "hockey" ? 4 : 2) : 0;
    if (f.isPlayer && (f.combo || rushing)) this.say(f.x, f.y - 30, kind ? COMBO_NAME[w.id] ?? "KOMBO!" : rushing ? `x${f.rushN - f.rush + 1}` : "x2", kind ? "#8af0ff" : rushing ? "#ff9df0" : "#c9f6ff");
    f.swingKind = kind;
    f.swingDir = -f.swingDir;
    f.swingHit.length = 0;
    if (kind === 2) {
      // overhead smash: a long, heavy wind-up, then everything lands at once
      f.cd = 0.5; f.swingDur = 0.44; f.swingT = 0.44; f.pend = 0.24;
      f.kx -= c * 30; f.ky -= s * 30; f.lungeT = 0.16; f.lungeV = step(85); f.lungeA = la;
      this.slashes.push({ f, ang: la, r: 31, arc: 0, life: 0.48, max: 0.48, dir: 1, kind: 2, wid: w.id });
      this.snd("whoosh", f.x, f.y, 1.2);
      return;
    }
    if (kind === 3) {
      f.cd = 0.45; f.swingDur = 0.39; f.swingT = 0.39;
      f.kx -= c * 24; f.ky -= s * 24; f.lungeT = 0.07; f.lungeV = step(190); f.lungeA = la;
      this.slashes.push({ f, ang: la, r: w.id === "axe" ? 29 : 24, arc: PI2, life: 0.39, max: 0.39, dir: f.swingDir, kind: 3, wid: w.id });
      this.snd("slash", f.x, f.y, 1.2);
      this.snd("whoosh", f.x, f.y, 0.7);
    } else {
      // pull back slowly, then step into the blow: the lunge only happens when the weapon whips through
      const q = rushing ? 0.42 : 1; // in a flurry there is no wind-up to speak of
      f.cd = w.cd * (rushing ? 0.4 : 1); f.swingDur = w.swing * q; f.swingT = w.swing * q;
      f.kx -= c * 28 * q; f.ky -= s * 28 * q; f.lungeT = w.swing * 0.38 * q; f.lungeV = step(w.lunge); f.lungeA = la;
      this.slashes.push({ f, ang: la, r: isBat(w.id) ? w.range - 6 : 21, arc: kind === 4 ? 4.8 : w.arc, life: w.swing * q + 0.09, max: w.swing * q + 0.09, dir: f.swingDir, kind: 0, wid: w.id });
    }
  }

  /**
   * A finisher: when the zombie in front of you is on the floor or nearly done, the next blow with a bat-like weapon or the karambit
   * becomes an execution - a jump and a skull smash, or a blur through the target with the blade spinning.
   */
  tryFatality(f: Fighter, w: WeaponDef, tgt: Pt): boolean {
    if (!f.isPlayer || this.game !== "bugs" || this.fat || this.t - this.fatAt < 4.5) return false;
    const z = tgt as Bug;
    if (z.kind === undefined || !z.alive || z.kind === "charger" || z.kind === "titan" || z.kind === "tank" || z.kind === "dog") return false;
    if (z.state !== "down" && z.hp > z.max * 0.4) return false;
    const bat = isBat(w.id), a = Math.atan2(z.y - f.y, z.x - f.x), c = Math.cos(a), s = Math.sin(a), d = Math.hypot(z.x - f.x, z.y - f.y);
    this.fatAt = this.t;
    this.fat = { z, t: 0, kind: bat ? 0 : 1 };
    z.fat = 1.3; z.kx = z.ky = 0;
    f.swingHit.length = 0; f.lastSwing = this.t; f.combo = 2; f.swingDir = 1;
    this.zoom = Math.max(this.zoom, 0.07);
    if (bat) {
      // up over the head... and down on the skull
      f.aim = a; f.sAim = a;
      f.swingKind = 2; f.cd = 0.75; f.swingDur = 0.44; f.swingT = 0.44; f.pend = 0.24;
      f.lungeT = 0.11; f.lungeV = clamp((d - 15) * 9, 0, 260); f.lungeA = a;
      this.slashes.push({ f, ang: a, r: 31, arc: 0, life: 0.48, max: 0.48, dir: 1, kind: 2, wid: w.id });
      this.snd("whoosh", f.x, f.y, 1.3);
    } else {
      // through the target in a blur, afterimages trailing, blade spinning
      const nx = z.x + c * 15, ny = z.y + s * 15, flip = c < 0;
      for (let i = 0; i < 6; i++) this.ghosts.push({ x: f.x + ((nx - f.x) * i) / 6, y: f.y + ((ny - f.y) * i) / 6, team: f.team, look: f.look, skin: f.skin, flip, life: 0.2 + i * 0.035 });
      if (!this.boxHit(nx, ny)) {
        f.x = nx; f.y = ny; f.vx = f.vy = f.kx = f.ky = 0;
        for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
      }
      f.aim = Math.atan2(z.y - f.y, z.x - f.x); f.sAim = f.aim;
      f.swingKind = 3; f.cd = 0.6; f.swingDur = 0.34; f.swingT = 0.34; f.spinT = 0;
      this.slashes.push({ f, ang: f.aim, r: 24, arc: PI2, life: 0.34, max: 0.34, dir: 1, kind: 3, wid: w.id });
      this.cut(z.x, z.y - 5, a + 0.8); this.cut(z.x, z.y - 5, a - 0.8);
      this.snd("slash", f.x, f.y, 1.3);
      this.snd("dash", f.x, f.y, 0.8);
    }
    return true;
  }

  /** the juice of a melee hit: directional spray, shock ring, flash, camera punch */
  meleeFx(x: number, y: number, ang: number, wid: WeaponId, kind: number, f: Fighter) {
    const bat = isBat(wid), c = Math.cos(ang), s = Math.sin(ang), big = kind >= 2;
    this.sparks.push({ x, y: y - 4, life: 0.09 });
    this.hitFx(x, y - 4, ang + (bat ? 0.4 : 1.2), bat ? 13 : 10, bat ? 1 : 2);
    this.glows.push({ x, y: y - 4, r: bat ? 28 : 22, life: 0.1, max: 0.1 });
    this.puff(x, y - 4, bat ? 10 : 8, bat ? ["#ffffff", "#ffe45c", "#ffb347"] : ["#ffffff", "#8af0ff", "#c9f6ff"], bat ? 130 : 160, { vx: c * 70, vy: s * 70, max: 0.24, size: 1, grav: 0, drag: 6 });
    this.puff(x, y - 4, big ? 12 : 6, ["#a8202c", "#d04a4a", "#6e1420"], 95, { vx: c * 85, vy: s * 85, vz: 50, max: 0.55, size: 2, grav: 300, stamp: true });
    this.rings.push({ x, y: y - 3, life: 0.1, r: bat ? 18 : 12 });
    this.cut(x, y - 4, ang + (f.swingDir || 1) * 1.1, bat);
    if (!bat) this.cut(x, y - 4, ang - (f.swingDir || 1) * 1.1); // the karambit always cuts twice: an X
    if (f === this.focus()) {
      this.cam.kx += c * (bat ? 5 : 3); this.cam.ky += s * (bat ? 5 : 3);
      this.cam.shake = Math.min(10, this.cam.shake + (bat ? 4 : 2.5));
    }
    this.snd(bat ? "thunk" : "slash", x, y, 1.1);
  }

  /** resolve melee hits; called every frame while the swing is active, each target is hit once. kind 2 = smash, 3 = spin */
  strike(f: Fighter, w: WeaponDef, kind: number) {
    const smash = kind === 2, spin = kind === 3, range = w.range + (smash ? 6 : spin ? 7 : 0), arc = smash ? 1.2 : spin ? 7 : kind === 4 ? 4.8 : w.arc;
    let hit = false;
    for (const e of this.fighters) {
      if (!e.alive || e.team === f.team || e.dashT > 0 || f.swingHit.includes(e.id)) continue;
      const dx = e.x - f.x, dy = e.y - f.y, d = Math.hypot(dx, dy);
      if (d > range + 7) continue;
      if (d > 14 && Math.abs(angDiff(f.aim, Math.atan2(dy, dx))) > arc / 2 + Math.atan2(7, d)) continue;
      if (!los(f.x, f.y, e.x, e.y)) continue;
      f.swingHit.push(e.id);
      let dmg = w.dmg * (smash ? 1.5 : spin ? 1.3 : 1), tag = smash ? "SMASH!" : "";
      if (w.id === "karambit" && Math.cos(angDiff(f.aim, e.aim)) > 0.35) { dmg *= 3; tag = "BACKSTAB!"; }
      this.meleeFx(e.x, e.y, Math.atan2(dy, dx), w.id, kind, f);
      this.damage(e, dmg, f, w.id, Math.atan2(dy, dx), smash ? 150 : w.knock, tag);
      hit = true;
    }
    if (smash && this.fat && this.fat.kind === 0 && f.isPlayer && this.fat.z.alive) { this.bug.execute(this.fat.z, f, w.id, f.aim, 0); hit = true; } // the finisher lands
    if (this.game === "bugs" && this.bug.melee(f, w, kind, f.swingHit)) hit = true;
    if (smash) {
      const ix = f.x + Math.cos(f.aim) * range * 0.8, iy = f.y + Math.sin(f.aim) * range * 0.8;
      const quake = w.id === "hammer"; // the hammer's finisher is a ground pound: everything around it goes down
      if (this.game === "bugs") this.bug.shock(ix, iy, quake ? 50 : 24);
      this.rings.push({ x: ix, y: iy + 3, life: 0.1, r: quake ? 48 : 20 });
      if (quake) { this.rings.push({ x: ix, y: iy + 3, life: 0, r: 30 }); this.dust(ix, iy + 4, 12); this.cam.shake = Math.min(10, this.cam.shake + 5); }
      if (!solidAt(ix, iy + 3)) {
        // the floor cracks where the bat comes down
        const fc = this.fctx;
        fc.fillStyle = "rgba(8,6,10,0.6)";
        for (let i = 0; i < 6; i++) {
          const a = i * 1.05 + rand(), L = 5 + rand() * 9;
          for (let d = 2; d < L; d++) fc.fillRect((ix + Math.cos(a) * d + Math.sin(d * 1.7) * 0.8) | 0, (iy + 3 + Math.sin(a) * d * 0.7) | 0, 1, 1);
        }
      }
      this.dust(ix, iy + 4, 5);
      this.shake(hit ? 7 : 3, ix, iy);
      this.snd("thunk", ix, iy, hit ? 1.5 : 0.8);
      if (hit && f.isPlayer) this.hitStop = Math.max(this.hitStop, 0.09);
      return;
    }
    if (hit) {
      if (f === this.focus()) { this.cam.kx += Math.cos(f.aim) * 3; this.cam.ky += Math.sin(f.aim) * 3; } // the camera follows the blow
      this.snd(isBat(w.id) ? "thunk" : "hit", f.x, f.y, 1.1);
      this.shake(w.shake * (spin ? 1.5 : 1), f.x, f.y);
      if (f.isPlayer) this.hitStop = Math.max(this.hitStop, isBat(w.id) ? 0.085 : 0.055);
    }
  }

  /** stepping onto the top of a staircase takes a body to the other floor */
  stairs(e: Body & { onStair: boolean }): boolean {
    const to = portalAt(Math.floor(e.x / TILE), Math.floor(e.y / TILE));
    if (to < 0) { e.onStair = false; return false; }
    if (kindAt(to % MW, (to / MW) | 0) !== 0) { e.onStair = false; return false; } // the door on the other side is shut
    if (e.onStair) return false;
    e.onStair = true;
    e.x = ((to % MW) + 0.5) * TILE;
    e.y = (((to / MW) | 0) + 0.5) * TILE;
    return true;
  }

  /** the rescued civilian: no weapon, no courage - sticks to the player like a chick to its hen */
  controlCiv(f: Fighter, dt: number) {
    const ai = f.ai!;
    if (f.hid) { f.aim = Math.PI / 2 + Math.sin(this.t * 0.7 + f.id) * 0.5; return; }
    let lead: Fighter | null = this.player && this.player.alive ? this.player : null;
    if (!lead) {
      let bd = 1e9;
      for (const m of this.fighters) if (m.alive && !m.civ) { const q = Math.hypot(m.x - f.x, m.y - f.y); if (q < bd) { bd = q; lead = m; } }
    }
    if (!lead) return;
    const dx = lead.x - f.x, dy = lead.y - f.y, d = Math.hypot(dx, dy) || 1;
    // the nearest threat: shrink away from it, towards the leader
    let zx = 0, zy = 0, zd = 70;
    for (const z of this.bug.bugs) {
      if (z.state === "sleep") continue;
      const q = Math.hypot(z.x - f.x, z.y - f.y);
      if (q < zd) { zd = q; zx = (f.x - z.x) / (q || 1); zy = (f.y - z.y) / (q || 1); }
    }
    let mx = 0, my = 0;
    if (d > (zd < 70 ? 12 : 22)) {
      if (d < 140 && walkClear(f.x, f.y, lead.x, lead.y)) { mx = dx / d; my = dy / d; ai.path = []; }
      else {
        if ((ai.pathT -= dt) <= 0 || !ai.path.length) { ai.path = findPath(f.x, f.y, lead.x, lead.y); ai.pi = 0; ai.pathT = 0.5; }
        while (ai.pi < ai.path.length - 2 && Math.hypot(ai.path[ai.pi] - f.x, ai.path[ai.pi + 1] - f.y) < 7) ai.pi += 2;
        if (ai.pi < ai.path.length) { const wx = ai.path[ai.pi] - f.x, wy = ai.path[ai.pi + 1] - f.y, wl = Math.hypot(wx, wy) || 1; mx = wx / wl; my = wy / wl; }
      }
    }
    if (zd < 70) { mx += zx * 0.7; my += zy * 0.7; f.fear = Math.max(f.fear, 0.6); }
    this.ix = mx; this.iy = my;
    f.aim += clamp(angDiff(f.aim, mx || my ? Math.atan2(my, mx) : Math.atan2(dy, dx)), -8 * dt, 8 * dt);
  }

  /** everybody climbs into the white pickup: it drives off, the screen goes dark, and the next district loads */
  boardTruck() {
    if (this.trans) return;
    this.trans = { t: 0, swapped: false };
    this.bug.saved += this.bug.rescued();
    this.phase = "freeze";
    this.phaseT = 3;
    this.bug.live = false;
    for (const f of this.fighters) { f.gone = true; f.vx = f.vy = f.kx = f.ky = 0; }
    audio.play("door");
    audio.play("engine", 1);
    this.setBanner("SEMUA NAIK!", "Pickup tancap gas ke kota berikutnya...", "gold", 1.8);
  }

  loadLevel(n: number) {
    this.level = n;
    const kills = this.bug.kills, heads = this.bug.heads;
    this.fighters = this.fighters.filter((f) => !f.civ);
    this.art = mapArt(n);
    this.fctx = this.art.floor.getContext("2d")!;
    this.fctx.drawImage(this.art.clean, 0, 0);
    this.parts = []; this.texts = []; this.glows = []; this.sparks = []; this.rings = []; this.cuts = [];
    this.climb = null;
    this.visMem = {};
    this.lamps = cityLamps();
    this.shells = !this.art.ny && this.art.roofs ? buildShells(this.art.walls, this.art.roofs) : [];
    if (this.art.ny) nyLights((x, y, r, a, house, fl) => this.lamps.push({ x, y, r, a, col: "w", pad: false, house, fx: fl ? 1 : undefined }));
    this.fat = null;
    this.bursts = [];
    this.roofA = HOUSES.map(() => 1);
    this.inside = false; this.inK = 0; this.inHouse = -1;
    this.nextRound();
    this.bug.start();
    this.bug.kills = kills; this.bug.heads = heads;
    const f = this.focus();
    if (f) { this.cam.x = f.x; this.cam.y = f.y; }
    this.talk.say(n === 2 ? "level2" : n === 3 ? "levelNY" : "levelCity", { force: true, cd: 0 });
    for (const q of this.fighters) if (!q.civ) q.gone = true; // still in the pickup: they get out when it has stopped
    this.hudDirty = true;
  }

  /** an upper floor in its place above the city: how the hidden strip maps onto the street below. s < 1: the higher up, the smaller the street */
  skyOf(hi: number) {
    const H = hi >= 0 ? HOUSES[hi] : null;
    if (!H || H.under === undefined || this.art.ny || this.game !== "bugs") return null;
    const lvl = H.lvl ?? 2, s = 1 / (1 + 0.2 * (lvl - 1)), cx = (H.x + H.w / 2) * TILE, cy = (H.y + H.h / 2) * TILE;
    return { H, lvl, s, cx, cy, gx: cx - H.dx * TILE, gy: cy - H.dy * TILE };
  }

  /** blocks sight. (Upstairs, what lies beyond an open window is open air: you look down on the street.) */
  opaque(x: number, y: number) {
    const tx = Math.floor(x / TILE), ty = Math.floor(y / TILE), k = kindAt(tx, ty);
    if (k === 1 && this.skyNow && styleAt(tx, ty) === 9) return false;
    return k !== 0 && k !== 3;
  }

  /** what lies around an upper floor: the city, far below - streets and roofs, the pickup, and whoever is walking down there */
  drawBelow(sky: NonNullable<ReturnType<Game["skyOf"]>>) {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, W = this.W, H = this.H, B = sky.H, s = sky.s;
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.rect(B.x * TILE - cl, B.y * TILE - RAISE - ct, B.w * TILE, B.h * TILE + RAISE);
    ctx.clip("evenodd");
    ctx.fillStyle = "#070912";
    ctx.fillRect(0, 0, W, H);
    ctx.translate(sky.cx - cl, sky.cy - ct);
    ctx.scale(s, s);
    ctx.translate(-sky.gx, -sky.gy);
    const x0 = Math.max(0, Math.floor(sky.gx - (sky.cx - cl) / s)), y0 = Math.max(0, Math.floor(sky.gy - (sky.cy - ct) / s));
    const x1 = Math.min(MW * TILE, Math.ceil(sky.gx + (cl + W - sky.cx) / s)), y1 = Math.min(CH * TILE, Math.ceil(sky.gy + (ct + H - sky.cy) / s));
    if (x1 > x0 && y1 > y0) {
      const w = x1 - x0, h = y1 - y0;
      ctx.drawImage(this.art.floor, x0, y0, w, h, x0, y0, w, h);
      ctx.drawImage(this.art.walls, x0, y0, w, h, x0, y0 - RAISE, w, h);
      if (this.art.roofs) ctx.drawImage(this.art.roofs, x0, y0, w, h, x0, y0 - RAISE, w, h);
      const R = (c: string, a: number, b: number, ww: number, hh: number) => { ctx.fillStyle = c; ctx.fillRect(a, b, ww, hh); };
      R("#0b0b10", TRUCK.x - 27, TRUCK.y - 13, 56, 22); R("#eef1f6", TRUCK.x - 25, TRUCK.y - 11, 52, 18); R("#132238", TRUCK.x + 2, TRUCK.y - 9, 12, 8);
      for (const z of this.bug.bugs) {
        if (z.x < x0 - 10 || z.x > x1 + 10 || z.y < y0 - 10 || z.y > y1 + 10 || houseAtPx(z.x, z.y) >= 0) continue;
        const k = z.kind === "tank" ? 2 : z.kind === "titan" ? 3 : 1;
        R("#0b0b10", z.x - 4 * k, z.y - 12 * k, 8 * k, 16 * k);
        R(z.kind === "tank" ? "#c08a7a" : "#8fae7a", z.x - 3 * k, z.y - 11 * k, 6 * k, 6 * k);
        R("#4a5670", z.x - 3 * k, z.y - 5 * k, 6 * k, 6 * k);
        if (z.fast || z.kind === "tank" || z.kind === "warrior") { R("#ff3030", z.x - 2 * k, z.y - 9 * k, k, k); R("#ff3030", z.x + k, z.y - 9 * k, k, k); }
      }
      for (const f of this.fighters) {
        if (!f.alive || f.gone || f.y > CH * TILE || houseAtPx(f.x, f.y) >= 0) continue;
        R("#0b0b10", f.x - 4, f.y - 12, 8, 16); R(f.civ ? "#ff9df0" : "#7dff9a", f.x - 3, f.y - 11, 6, 14);
      }
    }
    ctx.restore();
    // the air between here and the ground
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.rect(B.x * TILE - cl, B.y * TILE - RAISE - ct, B.w * TILE, B.h * TILE + RAISE);
    ctx.clip("evenodd");
    ctx.fillStyle = `rgba(20,28,56,${(0.1 * (sky.lvl - 1)).toFixed(2)})`;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  /**
   * An upper floor the way it looks from outside the building: under the floor you stand on, the storeys below drop away
   * towards the street - narrowing with the distance, your people at the lit windows, eyes in the dark ones -
   * with the lights of the city far below and clouds drifting past.
   */
  drawExterior(sky: NonNullable<ReturnType<Game["skyOf"]>>) {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, W = this.W, H = this.H, B = sky.H, s = sky.s, t = this.t, A = this.atmo;
    const X = B.x * TILE - cl, Y = (B.y + B.h) * TILE - ct, BW = B.w * TILE, n = sky.lvl - 1, FH = 34, D = n * FH;
    const G = HOUSES[B.under!], floors = G.floors ?? [];
    const sx = (wx: number) => (wx - sky.gx) * s + sky.cx - cl, sy = (wy: number) => (wy - sky.gy) * s + sky.cy - ct;
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.rect(X, B.y * TILE - RAISE - ct, BW, B.h * TILE + RAISE);
    ctx.clip("evenodd");
    // the lights of the city, far below: street lamps, the pickup's headlights, the eyes of whatever walks down there
    for (const l of this.lamps) {
      if (l.house !== undefined || l.r < 40 || l.a < 0.4) continue;
      const lx = sx(l.x), ly = sy(l.y);
      if (lx > -20 && lx < W + 20 && ly > -20 && ly < H + 20) A.tint(ctx, lx, ly, 20 * s + 6, l.col, 0.55);
    }
    A.tint(ctx, sx(TRUCK.x + 26), sy(TRUCK.y), 12, "w", 0.7);
    ctx.fillStyle = "#ff4a4a";
    for (const z of this.bug.bugs) {
      if (z.y > CH * TILE || z.state === "sleep" || houseAtPx(z.x, z.y) >= 0) continue;
      const zx = Math.round(sx(z.x)), zy = Math.round(sy(z.y - 9));
      if (zx > 0 && zx < W && zy > 0 && zy < H) { ctx.fillRect(zx - 1, zy, 1, 1); ctx.fillRect(zx + 1, zy, 1, 1); }
    }
    if (n > 0 && Y < H + 4) {
      const ins = (d: number) => BW * 0.06 * n * (d / D);
      ctx.fillStyle = "rgba(0,0,6,0.5)"; // its shadow on the street
      ctx.beginPath(); ctx.ellipse(X + BW / 2, Y + D + 6, BW * 0.36, 9, 0, 0, PI2); ctx.fill();
      for (let k = 1; k <= n; k++) {
        const lv = sky.lvl - k, y0 = Y + (k - 1) * FH, y1 = y0 + FH, a0 = ins(y0 - Y), a1 = ins(y1 - Y), sh = 46 - k * 5;
        ctx.fillStyle = `rgb(${sh},${sh + 5},${sh + 20})`;
        ctx.beginPath(); ctx.moveTo(X + a0, y0); ctx.lineTo(X + BW - a0, y0); ctx.lineTo(X + BW - a1, y1); ctx.lineTo(X + a1, y1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.1)"; ctx.fillRect(X + a0, y0, BW - 2 * a0, 2);
        ctx.fillStyle = "rgba(0,0,0,0.35)"; ctx.fillRect(X + a1, y1 - 2, BW - 2 * a1, 2);
        const st = floors[lv - 1] !== undefined ? this.bug.storey(floors[lv - 1]) : { squad: 0, civ: 0, sos: false, dead: 0 };
        const am = (a0 + a1) / 2, xl = X + am, fw = BW - 2 * am, m = 8, ww = Math.max(4, Math.round((fw / m) * 0.56)), wh = Math.round(FH * 0.5 * (1 - 0.07 * k)), wy = Math.round(y0 + FH * 0.24);
        const mine = st.squad + st.civ;
        for (let i = 0; i < m; i++) {
          const wx = Math.round(xl + ((i + 0.5) / m) * fw - ww / 2), on = mine > 0 || (i * 7 + lv * 13 + B.x) % 6 === 0;
          ctx.fillStyle = "#0b0b10"; ctx.fillRect(wx - 1, wy - 1, ww + 2, wh + 2);
          ctx.fillStyle = mine ? "#ffd86b" : on ? "#8a7038" : "#141c2a"; ctx.fillRect(wx, wy, ww, wh);
          if (!on) { ctx.fillStyle = "#2c3a55"; ctx.fillRect(wx, wy, Math.max(1, ww >> 1), 1); }
          ctx.fillStyle = "#0b0b10"; ctx.fillRect(wx + (ww >> 1), wy, 1, wh);
          if (i >= 1 && i <= mine) {
            // one of yours at the window
            ctx.fillStyle = "#0b0b10"; ctx.fillRect(wx + 1, wy + wh - 7, ww - 2, 7);
            ctx.fillStyle = i <= st.squad ? "#7dff9a" : "#ff9df0"; ctx.fillRect(wx + 2, wy + wh - 6, Math.max(2, ww - 4), 3);
          } else if (!mine && i % 2 === lv % 2 && i >> 1 < st.dead && Math.sin(t * 2 + i * 1.7 + lv) > -0.6) {
            ctx.fillStyle = "#ff4a4a"; ctx.fillRect(wx + 1, wy + 3, 1, 1); ctx.fillRect(wx + ww - 2, wy + 3, 1, 1); // the dead are on this floor
          }
        }
        drawText(ctx, `LT${lv}`, xl + 10, y0 + FH - 9, "#8a8f9c");
        if (st.sos && Math.sin(t * 6) > 0) drawText(ctx, "SOS", xl + fw - 10, y0 + FH - 9, "#ff9df0");
      }
      // street level: the entrance under its awning (barred, when you have shut it), the pavement
      const aB = ins(D), cxB = X + BW / 2, barred = G.doors.some((d) => this.bug.shut.has(d.ty * MW + d.tx));
      ctx.fillStyle = "#0b0b10"; ctx.fillRect(cxB - 7, Y + D - 13, 14, 13);
      ctx.fillStyle = barred ? "#8a6844" : "#3a2a22"; ctx.fillRect(cxB - 6, Y + D - 12, 12, 12);
      if (barred) { ctx.fillStyle = "#c9cdd9"; ctx.fillRect(cxB - 6, Y + D - 7, 12, 1); }
      for (let i = 0; i < 6; i++) { ctx.fillStyle = i % 2 ? "#f3ead8" : "#c0392b"; ctx.fillRect(cxB - 9 + i * 3, Y + D - 16, 3, 3); }
      ctx.fillStyle = "#5b5d69"; ctx.fillRect(X + aB - 6, Y + D, BW - 2 * aB + 12, 4);
      ctx.fillStyle = "#3c3e48"; ctx.fillRect(X + aB - 6, Y + D + 4, BW - 2 * aB + 12, 2);
      // the cut edge of the floor you are standing on
      ctx.fillStyle = "#7d8592"; ctx.fillRect(X, Y, BW, 2);
      ctx.fillStyle = "#0b0b10"; ctx.fillRect(X, Y + 2, BW, 1);
    }
    if (sky.lvl >= 3) {
      // this high up, cloud drifts past between you and the street
      ctx.fillStyle = `rgba(200,215,255,${(0.045 * (sky.lvl - 2)).toFixed(3)})`;
      for (let i = 0; i < 5; i++) {
        const cx = ((i * 131 + t * (5 + i * 2)) % (W + 200)) - 100, cy = (i * 67 + 30) % H;
        for (const [ox, oy, rx, ry] of [[0, 0, 46, 9], [30, 5, 34, 7], [-26, 4, 28, 6]]) { ctx.beginPath(); ctx.ellipse(cx + ox, cy + oy, rx, ry, 0, 0, PI2); ctx.fill(); }
      }
    }
    ctx.restore();
  }

  /** behind a building, seen from where the camera is: out of sight */
  behind(x: number, y: number) {
    const px = x - this.cl, py = y - this.ct + 2;
    for (const s of this.live3) if (!s.ghost && s.a > 0.9 && covers(s, px, py)) return true;
    return false;
  }
  /** close enough to a building for its wall to be drawn over them by mistake */
  nearShell(x: number, y: number) {
    for (const s of this.live3) if (x > s.x - 26 && x < s.x + s.w + 26 && y > s.y - 26 && y < s.y + s.h + 30) return true;
    return false;
  }

  /** how far the pickup is from its parking spot: rolling in at the start of a map (negative), pulling away at the end (positive) */
  truckDX() {
    const tr = this.trans, I = this.intro;
    if (tr && !tr.swapped) return Math.pow(Math.max(0, tr.t - 0.45), 2) * 230;
    if (tr && !tr.intro) return -300; // between two maps: still on the road
    if (I && I.t < 1.9) return -300 * Math.pow(1 - I.t / 1.9, 2);
    return 0;
  }

  /** the squad arrives: the pickup comes down the road, through whatever stands in it, and everybody jumps off */
  startIntro() {
    if (this.game !== "bugs" || this.mode !== "play") return;
    this.intro = { t: 0, out: false };
    for (const f of this.fighters) if (!f.civ) f.gone = true;
    this.bug.introCrowd();
    audio.play("engine", 0.9);
  }

  /** the countdown waits while the pickup is still on its way */
  holding() {
    const tr = this.trans;
    return (!!tr && (!tr.swapped || !tr.intro)) || (!!this.intro && !this.intro.out);
  }

  /** skip the search of this map (F, or the button): everybody gathers at the pickup */
  skipMission() {
    if (!this.bug.skip()) return;
    this.fade = 0.3;
    audio.play("win");
    this.hudDirty = true;
  }

  /** bodies throw shadows: long ones away from your torch when they stand in its beam, short ones away from the nearest lamp */
  castShadows() {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, W = this.W, H = this.H, p = this.focus();
    const lamps: number[] = [];
    for (const l of this.lamps) if (l.house === undefined && l.a >= 0.5 && l.r >= 40 && l.x > cl - 90 && l.x < cl + W + 90 && l.y > ct - 90 && l.y < ct + H + 90) lamps.push(l.x, l.y, l.r);
    if (this.art.ny) nyLamps((x, y, r) => lamps.push(x, y, r * 2.4));
    const torch = p && p.alive && !p.gone ? p : null;
    const one = (x: number, y: number, w: number, tall: number) => {
      if (x < cl - 30 || x > cl + W + 30 || y < ct - 30 || y > ct + H + 30) return;
      let k = 0, sx = 0, sy = 0, L = 0;
      if (torch) {
        const dx = x - torch.x, dy = y - torch.y, d = Math.hypot(dx, dy);
        if (d > 12 && d < 160 && Math.abs(angDiff(torch.aim, Math.atan2(dy, dx))) < 0.5) { k = 0.46 * (1 - d / 160); sx = dx / d; sy = dy / d; L = tall * 1.25; }
      }
      for (let i = 0; i < lamps.length; i += 3) {
        const dx = x - lamps[i], dy = y - lamps[i + 1], d = Math.hypot(dx, dy), r = lamps[i + 2], kk = 0.34 * (1 - d / r);
        if (kk > k && d > 3) { k = kk; sx = dx / d; sy = dy / d; L = tall * (0.35 + 0.9 * (d / r)); }
      }
      const day = this.atmo.cur.day ?? 0;
      if (day > 0.3) { k = 0.3 * day; sx = -0.92; sy = 0.4; L = tall * 1.5; } // the low morning sun: long shadows to the west
      if (k < 0.05) return;
      const ex = x + sx * L, ey = y + sy * L * 0.8, px = -sy * w, py = sx * w * 0.8;
      ctx.fillStyle = `rgba(2,2,10,${k.toFixed(2)})`;
      ctx.beginPath();
      ctx.moveTo(x - px - cl, y - py - ct);
      ctx.lineTo(x + px - cl, y + py - ct);
      ctx.lineTo(ex + px * 1.3 - cl, ey + py * 1.3 - ct);
      ctx.lineTo(ex - px * 1.3 - cl, ey - py * 1.3 - ct);
      ctx.closePath();
      ctx.fill();
    };
    for (const f of this.fighters) if (f.alive && !f.gone && !this.hidden(f.x, f.y)) one(f.x, f.y + 4, 3.4, 17);
    this.bug.shadows(one);
    for (const b of this.barrels) if (b.alive) one(b.x, b.y + 2, 3.5, 9);
  }

  /** the player reaches a staircase: climb it step by step instead of teleporting */
  stairCheck(f: Fighter) {
    if (portalAt(Math.floor(f.x / TILE), Math.floor(f.y / TILE)) < 0) {
      f.onStair = false;
      // New York: doors are one tile wide - pushing against one, anywhere in front of it, is enough to go through
      const ax = Math.abs(this.ix) > Math.abs(this.iy) ? Math.sign(this.ix) : 0, ay = ax ? 0 : Math.sign(this.iy);
      if (!this.art.ny || this.climb || (!ax && !ay)) return;
      let tx = -1, ty = -1;
      for (const o of [0, -7, 7]) {
        // (the whole width of the body counts, so being half a step to the side still finds the door)
        const qx = Math.floor((f.x + ax * 9 + (ax ? 0 : o)) / TILE), qy = Math.floor((f.y + ay * 9 + (ay ? 0 : o)) / TILE);
        if (portalAt(qx, qy) >= 0) { tx = qx; ty = qy; break; }
      }
      if (tx < 0) return;
      f.x = (tx + 0.5) * TILE; f.y = (ty + 0.5) * TILE;
    }
    if (f.onStair || this.climb) return;
    const h = houseAtPx(f.x, f.y);
    const to = portalAt(Math.floor(f.x / TILE), Math.floor(f.y / TILE)), th = to >= 0 ? houseAtPx(((to % MW) + 0.5) * TILE, (((to / MW) | 0) + 0.5) * TILE) : -1;
    this.climb = { t: 0, up: this.art.ny ? f.y < CH * TILE : h >= 0 && th >= 0 && (HOUSES[th].lvl ?? 1) > (HOUSES[h].lvl ?? 1), swapped: false, step: 0 };
    f.vx = f.vy = f.kx = f.ky = 0;
    this.setRest(f, false);
    f.drinkT = 0;
  }
  tickClimb(f: Fighter, dt: number) {
    const c = this.climb!, dir = c.up ? 1 : -1;
    c.t += dt;
    f.vx = f.vy = f.kx = f.ky = 0;
    f.moving = true;
    f.walkT += dt * 1.5;
    f.aim = c.up ? -Math.PI / 2 : Math.PI / 2;
    if (!c.swapped) {
      const k = Math.min(1, c.t / 0.5);
      f.climbY = dir * 10 * k * k;
      if (c.t >= 0.5) {
        c.swapped = true;
        if (this.stairs(f)) this.tookStairs(f);
        this.floorTitle = { text: this.art.ny ? nyPlace(houseAtPx(f.x, f.y)) ?? "NEW YORK" : `LANTAI ${HOUSES[houseAtPx(f.x, f.y)]?.lvl ?? (c.up ? 2 : 1)}`, t: 2.2 };
      }
    } else f.climbY = dir * 10 * (1 - Math.min(1, (c.t - 0.5) / 0.45));
    if ((c.step -= dt) <= 0) { c.step = 0.13; this.snd("click", f.x, f.y, 0.25); this.dust(f.x, f.y + 4, 1); }
    if (c.t >= 1.0) { this.climb = null; f.climbY = 0; }
  }

  /** a fighter just changed floors */
  tookStairs(f: Fighter) {
    for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
    if (f.ai) { f.ai.pathT = 0; f.ai.path = []; f.ai.target = null; }
    if (f !== this.focus()) return;
    // the camera follows through a blink of darkness
    if (!this.climb) this.fade = 0.32;
    this.cam.x = f.x; this.cam.y = f.y;
    const h = houseAtPx(f.x, f.y);
    if (h >= 0) { this.roofA[h] = 0; this.inHouse = h; this.inK = 1; }
    this.snd("dash", f.x, f.y, 0.6);
  }

  /** where a position is in the city: upper floors are mapped back onto their house */
  gpos(x: number, y: number): [number, number] {
    const h = y > CH * TILE ? houseAtPx(x, y) : -1;
    return h >= 0 ? [x - HOUSES[h].dx * TILE, y - HOUSES[h].dy * TILE] : [x, y];
  }

  /** the instant something lands: a white-hot core with rays. kind 0 = a bullet, 1 = a blunt blow (a star), 2 = a blade (one long line) */
  hitFx(x: number, y: number, ang: number, r: number, kind: number) {
    if (this.flashes.length < 40) this.flashes.push({ x, y, ang, r, kind, life: 0, max: kind === 1 ? 0.14 : 0.1 });
  }

  /** a burst of blood at a wound: a few frames of spray thrown along the direction of the hit */
  splash(x: number, y: number, ang: number, r: number) {
    if (this.bursts.length < 48) this.bursts.push({ x, y, ang, life: 0, max: 0.17, r, seed: rand() * 100 });
  }

  /** a quick white slash mark where a blade or bat lands */
  cut(x: number, y: number, ang: number, star = false) {
    if (this.cuts.length < 24) this.cuts.push({ x, y, ang, life: 0.16, star });
  }

  /** tapered crescent: the trail of a swing */
  crescent(x: number, y: number, r: number, a0: number, a1: number, thick: number, col: string) {
    const ctx = this.ctx, n = Math.max(6, Math.ceil(Math.abs(a1 - a0) * 7));
    ctx.fillStyle = col;
    ctx.beginPath();
    for (let i = 0; i <= n; i++) { const a = a0 + ((a1 - a0) * i) / n; ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r * 0.88); }
    for (let i = n; i >= 0; i--) { const k = i / n, a = a0 + (a1 - a0) * k, rr = r - thick * k * k; ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.88); }
    ctx.closePath();
    ctx.fill();
  }

  /** everything a light at (x, y) can reach: rays stop at walls and tall furniture, plus a few pixels so the surface itself is lit */
  visPoly(x: number, y: number, R: number, n: number, key?: number): number[] {
    const out: number[] = [], mem = key !== undefined ? (this.visMem[key] ??= []) : null;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * PI2, c = Math.cos(a), s = Math.sin(a);
      let d = 4;
      for (; d < R; d += 4) if (this.opaque(x + c * d, y + s * d)) break;
      d = Math.min(R, d + 11);
      if (mem) { const pv = mem[i]; if (pv !== undefined && Math.abs(pv - d) < 60) d = pv + (d - pv) * 0.38; mem[i] = d; } // light and shadow glide instead of popping
      out.push(x + c * d - this.cl, y + s * d - this.ct);
    }
    return out;
  }

  deflect(f: Fighter) {
    const w = WEAPONS.bat;
    for (const b of this.bullets) {
      if (b.team === f.team) continue;
      const dx = b.x - f.x, dy = b.y - f.y;
      if (Math.hypot(dx, dy) > w.range + 8) continue;
      if (Math.abs(angDiff(f.aim, Math.atan2(dy, dx))) > w.arc / 2) continue;
      b.team = f.team; b.owner = f; b.dx = Math.cos(f.aim); b.dy = Math.sin(f.aim);
      b.dmg *= 1.5; b.life = b.max; b.hit = []; b.ox = b.x; b.oy = b.y; b.trav = 0;
      if (b.wid === "bazooka") b.speed = 420;
      if (this.t - this.lastDeflect > 0.35) { this.lastDeflect = this.t; this.say(f.x, f.y - 26, "DEFLECT!", "#8af0ff"); }
      this.snd("deflect", f.x, f.y);
      this.puff(b.x, b.y, 5, ["#ffffff", "#8af0ff"], 60, { max: 0.25, grav: 0 });
      this.sparks.push({ x: b.x, y: b.y, life: 0.12 });
      this.shake(2.5, f.x, f.y);
      if (f.isPlayer) this.hitStop = Math.max(this.hitStop, 0.05);
    }
  }

  damage(v: Fighter, amt: number, by: Fighter | null, wid: Hurt, ang: number, knock: number, tag = "", mob = false) {
    if (!v.alive || this.phase === "freeze") return;
    if (v.isPlayer && this.fat) return; // untouchable in the middle of a finisher
    if (mob && v.guardT > 0) return; // just been bitten: a moment to tear loose and get away
    const foe = !!by && by.team !== v.team;
    if (v.isPlayer && (mob || (by && !by.isPlayer))) amt *= this.diff.dmgMul;
    if (v.isPlayer && v.look === 2 && v.skin === 10) amt *= 0.85; // SWAT wears a vest
    else if (mob && !v.isPlayer) amt *= v.civ ? 0.6 : 0.7; // friends and the people you rescue are harder to bring down
    else if (!v.isPlayer && by && !by.isPlayer && wid !== "boom") amt *= 0.6; // bot duels last longer so the player matters
    amt = Math.max(1, Math.round(amt));
    if (foe) by!.dmg += Math.min(amt, v.hp);
    v.hp -= amt;
    if (mob) { v.guardT = v.isPlayer ? 0.6 : 0.3; v.calmT = 0; }
    if (v.hp <= 0 && v.isPlayer && v.wind && this.game === "bugs") {
      // a second wind, once per map: instead of going down you throw them off and get a few seconds to run
      v.wind = false; v.hp = 35; v.guardT = 2.2;
      this.bug.shock(v.x, v.y, 80);
      this.rings.push({ x: v.x, y: v.y, life: 0, r: 60 });
      this.slowT = 0.7; this.whiteT = 0.08; this.zoom = Math.max(this.zoom, 0.06);
      this.setBanner("NAPAS KEDUA!", "Nyaris tumbang - mundur, biar teman-teman yang menahan", "gold", 2.8);
      audio.play("win");
      this.talk.say("hurt", { force: true, cd: 0, near: v });
    }
    v.hitFlash = 0.04;
    v.ouch = 0.45;
    v.drinkT = 0;
    if (v.resting) this.setRest(v, false);
    const c = Math.cos(ang), s = Math.sin(ang);
    v.kx += c * knock; v.ky += s * knock;
    // flinch: body snaps away from the hit
    v.tilt = clamp(v.tilt + (c >= 0 ? 1 : -1) * (0.3 + Math.min(0.4, amt / 110)), -0.8, 0.8);
    const tc = TEAMS[v.team];
    this.sparks.push({ x: v.x - c * 4, y: v.y - 4 - s * 4, life: 0.11 });
    this.puff(v.x, v.y - 3, 5, ["#ffffff", tc.color, tc.dark], 60, { vx: c * 55, vy: s * 55, max: 0.35 });
    this.puff(v.x, v.y - 3, 2, [tc.color, tc.dark, "#2a2c3a"], 40, { z: 6, vx: c * 80, vy: s * 80, vz: 70, max: 0.7, size: 1, grav: 340, drag: 1, stamp: true });
    // merge rapid hits (shotgun pellets) into one readable number
    const col = v.isPlayer ? "#ff6b7a" : by?.isPlayer ? "#fff0a8" : "#ffffff";
    const old = this.texts.find((t) => t.v === v && t.life < 0.3);
    if (old) { old.amt += amt; old.text = String(old.amt); old.life = 0; old.color = col; }
    else this.texts.push({ x: v.x, y: v.y - 20, text: String(amt), color: col, life: 0, v, amt });
    if (v.isPlayer) {
      this.hurtT = 0.4;
      this.cam.shake = Math.min(10, this.cam.shake + 3);
      this.cam.kx += c * 4; this.cam.ky += s * 4;
      audio.play("hurt");
    } else this.snd("hit", v.x, v.y, by?.isPlayer ? 1 : 0.6);
    if (by?.isPlayer && foe) {
      this.hitMark = 0.14;
      this.hitStop = Math.max(this.hitStop, 0.025);
    }
    if (v.ai && foe && by!.alive && !v.ai.target) {
      v.ai.target = by;
      v.ai.seen = 0.1;
    }
    if (v.hp <= 0) this.kill(v, by, wid, ang, tag);
    else if (tag) this.say(v.x, v.y - 28, tag, "#ff9df0");
    if (v.isPlayer) this.hudDirty = true;
  }

  kill(v: Fighter, by: Fighter | null, wid: Hurt, ang: number, tag: string) {
    v.hp = 0; v.alive = false; v.deadT = 0; v.deaths++;
    v.reloadT = 0; v.dashT = 0; v.killer = by;
    // ragdoll launch
    const power = isBat(wid) ? 470 : wid === "boom" || wid === "bazooka" ? 400 : wid === "sniper" ? 330 : wid === "shotgun" ? 280 : wid === "karambit" ? 140 : 190;
    const dir = ang + (rand() - 0.5) * 0.35;
    v.kx = Math.cos(dir) * power; v.ky = Math.sin(dir) * power;
    v.z = 1; v.vz = 90 + power * 0.24 + rand() * 40;
    v.rot = 0; v.vrot = (Math.cos(ang) >= 0 ? 1 : -1) * (9 + rand() * 8 + power * 0.014);
    v.rest = false;
    if (this.game === "bugs" && v.team === 0) { v.down = true; v.bleed = 55; v.rev = 0; this.talk.down(v); } // knocked down: a friend can still help
    else this.drops.push({
      x: v.x, y: v.y, z: 6, vx: Math.cos(dir + 0.9) * 70 + v.kx * 0.2, vy: Math.sin(dir + 0.9) * 70 + v.ky * 0.2,
      vz: 120 + rand() * 60, rot: v.aim, vrot: (rand() - 0.5) * 36, team: v.look, wid: v.weapon,
    });
    const foe = !!by && by.team !== v.team;
    if (foe) { by!.kills++; by!.roundKills++; }
    const label = tag || (isBat(wid) ? "HOMERUN!" : wid === "boom" || wid === "bazooka" ? "BOOM!" : "KO!");
    this.say(v.x, v.y - 30, label, isBat(wid) ? "#8af0ff" : tag ? "#ff9df0" : "#ffe45c");
    this.puff(v.x, v.y - 4, 12, ["#ffe45c", "#ffffff", TEAMS[v.team].color], 90, { vz: 80, max: 0.6, grav: 240 });
    this.dust(v.x, v.y + 3, 6);
    this.rings.push({ x: v.x, y: v.y - 3, life: 0.14, r: 12 });
    if (this.game !== "bugs" && rand() < 0.75) this.pickups.push({ x: v.x, y: v.y, t: 0 });
    this.snd("ko", v.x, v.y, by?.isPlayer || v.isPlayer ? 1.2 : 0.7);
    this.shake(4, v.x, v.y);
    this.feed.push({ id: this.ids++, killer: by ? by.name : wid === "bug" ? this.mobName : "???", killerTeam: by ? by.team : wid === "bug" ? 1 : v.team, victim: v.name, victimTeam: v.team, weapon: wid, tag, me: !!by?.isPlayer || v.isPlayer, t: this.t });
    if (this.feed.length > 5) this.feed.shift();
    if (by?.isPlayer && foe) {
      this.zoom = Math.max(this.zoom, 0.045);
      this.killMark = 0.3;
      this.hitStop = Math.max(this.hitStop, 0.09);
      const n = by.roundKills;
      if (n >= 2) {
        this.streak = { id: this.ids++, text: n === 2 ? "DOUBLE KILL!" : n === 3 ? "TRIPLE KILL!" : n === 4 ? "QUAD KILL!" : "ACE!!!" };
        this.streakT = 2;
      }
    }
    if (v.isPlayer) { this.spec = null; this.down = false; }
    const p = this.player;
    if (p && p.alive && v.team === 0 && this.aliveCount(0) === 1 && this.aliveCount(1) > 0)
      this.setBanner("CLUTCH TIME!", `1 VS ${this.aliveCount(1)} - kamu harapan terakhir`, "gold", 2);
    this.hudDirty = true;
    this.checkRoundEnd();
  }

  /** area explosion (barrels hurt everyone, rockets hurt enemies + the shooter) */
  blast(x: number, y: number, by: Fighter | null, R: number, dmg: number, knock: number, wid: Hurt, all: boolean) {
    this.snd("boom", x, y, 1.2);
    this.shake(10, x, y);
    if (Math.hypot(x - this.cam.x, y - this.cam.y) < 200) this.whiteT = 0.09;
    this.rings.push({ x, y, life: 0, r: R });
    this.glows.push({ x, y, r: R * 1.7, life: 0.2, max: 0.2 });
    this.puff(x, y, 18, ["#ffffff", "#ffe45c", "#ff9a3c", "#ff5a3c"], 160, { vz: 70, max: 0.5, size: 3, grav: 60, drag: 4 });
    this.puff(x, y, 12, ["#4a4048", "#6b5e66", "#2e272c"], 60, { vz: 55, max: 1.1, size: 4, grav: -22, drag: 2 });
    this.puff(x, y, 8, ["#5a4a3a", "#3a2e28", "#8a7658"], 120, { z: 4, vz: 150, max: 0.9, size: 2, grav: 420, drag: 1, stamp: true });
    this.fctx.fillStyle = "rgba(40,24,20,0.3)";
    for (let i = 0; i < 18; i++) {
      const a = rand() * PI2, r = rand() * R * 0.5;
      this.fctx.fillRect((x + Math.cos(a) * r) | 0, (y + Math.sin(a) * r * 0.8) | 0, 2 + ((rand() * 6) | 0), 2 + ((rand() * 4) | 0));
    }
    for (const f of this.fighters) {
      const dx = f.x - x, dy = f.y - y, d = Math.hypot(dx, dy);
      if (d >= R) continue;
      if (!f.alive) {
        // juggle ragdolls
        const a = Math.atan2(dy, dx);
        f.rest = false; f.kx += Math.cos(a) * 220; f.ky += Math.sin(a) * 220; f.vz = 150; f.z = Math.max(f.z, 1); f.vrot = (rand() - 0.5) * 30;
        continue;
      }
      if (!all && by && f.team === by.team && f !== by) continue;
      if (dmg <= 0 || (d > 14 && !los(x, y, f.x, f.y))) continue;
      this.damage(f, dmg * (1 - d / (R * 1.3)) * (f === by ? 0.45 : 1), by, wid, Math.atan2(dy, dx), knock * (1 - d / (R * 2)));
    }
    for (const o of this.barrels) {
      if (o.alive && o.hp > 0 && Math.hypot(o.x - x, o.y - y) < R + 6) { o.hp = 0; o.by = by; o.fuse = 0.13; }
    }
    if (this.game === "bugs") this.bug.blast(x, y, by, R, dmg, knock, wid);
    for (const d of this.drops) {
      const dx = d.x - x, dy = d.y - y;
      if (Math.hypot(dx, dy) < R) { d.vx = dx * 5; d.vy = dy * 5; d.vz = 160; d.vrot = (rand() - 0.5) * 40; }
    }
  }

  /* ───────────── controllers ───────────── */
  controlPlayer(f: Fighter) {
    const k = this.keys;
    let mx = this.tMove.x, my = this.tMove.y;
    if (k.has("KeyW") || k.has("ArrowUp")) my -= 1;
    if (k.has("KeyS") || k.has("ArrowDown")) my += 1;
    if (k.has("KeyA") || k.has("ArrowLeft")) mx -= 1;
    if (k.has("KeyD") || k.has("ArrowRight")) mx += 1;
    this.ix = mx; this.iy = my;
    this.wantRun = k.has("ShiftLeft") || k.has("ShiftRight") || Math.hypot(this.tMove.x, this.tMove.y) > 0.93;
    if ((mx || my) && f.resting) this.setRest(f, false);
    if (this.useTouch) {
      if (this.tAim.active) f.aim = Math.atan2(this.tAim.y, this.tAim.x);
      else if (Math.hypot(mx, my) > 0.25) f.aim = Math.atan2(my, mx);
    } else f.aim = Math.atan2(this.my + this.ct - (f.y + 1), this.mx + this.cl - f.x);
    if (f.swingT > 0 && !Number.isNaN(f.sAim) && WEAPONS[f.weapon].melee) f.aim = f.sAim; // the blade follows its target through the swing
    if (this.phase === "freeze" || this.phase === "over") { this.wantDash = false; return; }
    if (this.wantDash) { this.wantDash = false; this.dash(f, mx, my); }
    if (this.down || this.tAim.fire || (f.rush > 0 && WEAPONS[f.weapon].melee)) this.tryFire(f); // a flurry plays itself out
  }

  controlBot(f: Fighter, dt: number) {
    const ai = f.ai!;
    const squad = this.game === "bugs" && f.team === 0; // the friends in the zombie city: they are good at this
    const prm = squad ? SQUAD : f.team === 1 && this.mode === "play" ? this.diff : DIFFS.normal;
    let mx = 0, my = 0, hurry = false;
    ai.thinkT -= dt;
    if (ai.thinkT <= 0) {
      ai.thinkT = 0.12 + rand() * 0.1;
      let best: Target | null = null, bd = 1e9, near: Target | null = null, nd = 1e9;
      const foes: Target[] = this.game === "bugs" ? this.bug.bugs : this.fighters;
      // the squad picks its targets like people who want everybody to get home: whatever is on you, on somebody who is down
      // or on somebody who cannot fight comes first; sprinters before shamblers. While you search a building, they clear it with you.
      const sweepHi = squad ? this.bug.sweepFloor() : -1;
      for (const e of foes) {
        if (!e.alive || e.team === f.team) continue;
        const d = Math.hypot(e.x - f.x, e.y - f.y);
        if (e.state === "sleep" && !(sweepHi >= 0 && d < 130 && houseAtPx(e.x, e.y) === sweepHi)) continue; // otherwise: let sleeping zombies lie
        if (d < nd) { nd = d; near = e; }
        const sc = squad ? d - this.bug.threat(e as unknown as Bug) : d;
        if (d < (squad ? 340 : 300) && sc < bd && los(f.x, f.y, e.x, e.y)) { bd = sc; best = e; }
      }
      if (best !== ai.target) { ai.target = best; ai.seen = 0; ai.charge = 0; }
      ai.hunt = near;
    }
    const t = ai.target;
    if (t && t.alive) {
      ai.seen += dt;
      const dx = t.x - f.x, dy = t.y - f.y, d = Math.hypot(dx, dy) || 1;
      const nx = dx / d, ny = dy / d;
      const roleMelee = WEAPONS[ai.role].melee;
      const zb = squad ? (t as unknown as Bug) : null, isTank = zb?.kind === "tank", asleep = zb?.state === "sleep";
      let want: WeaponId;
      if ((d < 28 && !isTank) || asleep) want = ai.melee; // (a sleeper gets the blade: quiet, and nobody else wakes up)
      else if (roleMelee) want = d < 110 ? ai.role : "pistol";
      else if (ai.role === "sniper") want = d < 80 ? "pistol" : "sniper";
      else if (ai.role === "bazooka") want = d < 78 ? "pistol" : "bazooka";
      else want = ai.role;
      if (f.weapon !== want && f.swingT <= 0) this.switchWeapon(f, want);
      const w = WEAPONS[f.weapon];
      ai.strafeT -= dt;
      if (ai.strafeT <= 0) { ai.strafe = rand() < 0.5 ? -1 : 1; ai.strafeT = 0.35 + rand() * 0.8; }
      const px = -ny * ai.strafe, py = nx * ai.strafe;
      let desired = Math.atan2(dy, dx);
      if (w.melee) {
        mx = nx + px * 0.3; my = ny + py * 0.3;
        if (d < w.range + 3 && ai.seen > prm.react * 0.5) this.tryFire(f);
        if (d > 38 && d < 100 && f.dashCd <= 0 && rand() < dt * 3) this.dash(f, nx, ny);
      } else {
        const lo = w.id === "sniper" ? 130 : w.id === "shotgun" ? 28 : w.id === "bazooka" ? 100 : 70;
        const hi = w.id === "sniper" ? 250 : w.id === "shotgun" ? 62 : w.id === "bazooka" ? 220 : 150;
        const fwd = isTank ? (d > 230 ? 1 : d < 150 ? -1 : 0) : d > hi ? 1 : d < lo ? -0.8 : 0; // nobody stands within reach of the Tank
        const st = w.id === "sniper" ? 0.3 : 0.75;
        mx = nx * fwd + px * st; my = ny * fwd + py * st;
        ai.errT -= dt;
        if (ai.errT <= 0) { ai.err = (rand() - 0.5) * 2 * prm.aimErr; ai.errT = 0.25 + rand() * 0.3; }
        if (w.id === "bazooka") {
          const lead = (d / 380) * 0.7;
          desired = Math.atan2(dy + t.vy * lead, dx + t.vx * lead);
        } else if (squad) {
          const lead = d / w.speed; // they lead a moving target
          desired = Math.atan2(dy + t.vy * lead, dx + t.vx * lead);
        }
        desired += ai.err;
        if (prm.dodge > 0 && f.dashCd <= 0 && rand() < dt * 0.4 * prm.dodge) this.dash(f, px, py);
        if (squad && d < 30 && !asleep && f.dashCd <= 0) this.dash(f, -nx + px * 0.5, -ny + py * 0.5); // too close for a gun: out of its reach first
      }
      const turn = 10 * dt, df = angDiff(f.aim, desired);
      f.aim += clamp(df, -turn, turn);
      const aligned = Math.abs(angDiff(f.aim, desired)) < 0.14;
      if (!w.melee) {
        if (ai.seen > prm.react && aligned && f.reloadT <= 0) {
          if (w.id === "sniper") {
            ai.charge += dt;
            if (ai.charge >= SNIPE_CHARGE) { this.tryFire(f); ai.charge = 0; }
          } else if (w.id === "shotgun") {
            if (d < 115) this.tryFire(f);
          } else if (w.id === "bazooka") {
            ai.tapT -= dt;
            if (ai.tapT <= 0 && rayEnd(f.x, f.y + 1, f.aim, 64) >= 62) { this.tryFire(f); ai.tapT = 0.3 + rand() * 0.4; }
          } else {
            ai.tapT -= dt;
            if (ai.tapT <= 0) { this.tryFire(f); ai.tapT = 0.12 + rand() * 0.2; }
          }
        } else if (w.id === "sniper") ai.charge = Math.max(0, ai.charge - dt * 2);
        if (f.ammo[w.id] <= 0) this.reload(f);
      }
    } else {
      ai.target = null;
      ai.charge = 0;
      if (f.weapon !== ai.role && f.swingT <= 0) this.switchWeapon(f, ai.role);
      this.reload(f);
      let dest: Pt | null = null;
      if (ai.wp && this.roundT < 10 && Math.hypot(ai.wp.x - f.x, ai.wp.y - f.y) > 26) dest = ai.wp;
      else if (this.game === "bugs") {
        // stay with the squad: follow the player, otherwise hold the landing pad
        const p = this.player, lead = p && p.alive ? p : null, to = this.bug.rally(f), downed = !!to && !!(to as Fighter).down;
        // somebody down comes first; then the building you are searching (sleepers, the item, people hiding); then staying close to you
        const sw = downed ? null : this.bug.sweepGoal(f), home: Pt = (downed ? to : sw) ?? to ?? lead ?? LANES[0];
        dest = Math.hypot(home.x - f.x, home.y - f.y) > (!downed && sw ? 14 : to ? 13 : lead ? 54 : 40) ? home : null;
        hurry = downed && Math.hypot(home.x - f.x, home.y - f.y) > 70;
      } else { ai.wp = null; dest = ai.hunt && ai.hunt.alive ? ai.hunt : null; }
      if (dest) {
        ai.pathT -= dt;
        if (ai.pathT <= 0) { ai.path = findPath(f.x, f.y, dest.x, dest.y); ai.pi = 0; ai.pathT = 0.4 + rand() * 0.3; }
        const p = ai.path;
        while (ai.pi < p.length && Math.hypot(p[ai.pi] - f.x, p[ai.pi + 1] - f.y) < 6) ai.pi += 2;
        if (ai.pi + 2 < p.length && Math.hypot(p[ai.pi + 2] - f.x, p[ai.pi + 3] - f.y) < 110 && walkClear(f.x, f.y, p[ai.pi + 2], p[ai.pi + 3])) ai.pi += 2;
        let gx = dest.x, gy = dest.y;
        if (ai.pi < p.length) { gx = p[ai.pi]; gy = p[ai.pi + 1]; }
        const dx = gx - f.x, dy = gy - f.y, d = Math.hypot(dx, dy) || 1;
        mx = dx / d; my = dy / d;
        if (hurry && f.dashCd <= 0) this.dash(f, mx, my); // a friend is down: run
        const turn = 8 * dt;
        f.aim += clamp(angDiff(f.aim, Math.atan2(dy, dx)), -turn, turn);
      }
    }
    if (this.game === "bugs" && ai.target) {
      // even mid-fight: run to a downed friend, and never stray far from the player
      const to = this.bug.rally(f);
      if (to && ((to as Fighter).down || this.bug.needsHelp() || this.bug.sweepFloor() < 0)) { // (while a building is being swept they hold their rooms - unless you need them)
        if (Math.hypot(to.x - f.x, to.y - f.y) < 13) mx = my = 0;
        else {
          ai.pathT -= dt;
          if (ai.pathT <= 0) { ai.path = findPath(f.x, f.y, to.x, to.y); ai.pi = 0; ai.pathT = 0.4 + rand() * 0.3; }
          const p = ai.path;
          while (ai.pi < p.length && Math.hypot(p[ai.pi] - f.x, p[ai.pi + 1] - f.y) < 6) ai.pi += 2;
          let gx = to.x, gy = to.y;
          if (ai.pi < p.length) { gx = p[ai.pi]; gy = p[ai.pi + 1]; }
          const d = Math.hypot(gx - f.x, gy - f.y) || 1;
          mx = (gx - f.x) / d; my = (gy - f.y) / d;
        }
      }
    }
    // unstick
    ai.stuckT += dt;
    if (ai.stuckT > 0.5) {
      if (Math.hypot(mx, my) > 0.5 && Math.hypot(f.x - ai.lastX, f.y - ai.lastY) < 4) {
        const a = rand() * PI2;
        ai.unstickT = 0.3; ai.ux = Math.cos(a); ai.uy = Math.sin(a); ai.pathT = 0;
      }
      ai.stuckT = 0; ai.lastX = f.x; ai.lastY = f.y;
    }
    if (ai.unstickT > 0) { ai.unstickT -= dt; mx = ai.ux; my = ai.uy; }
    this.ix = mx; this.iy = my;
  }

  /* ───────────── simulation ───────────── */
  tickFighter(f: Fighter, mx: number, my: number, dt: number) {
    const w = WEAPONS[f.weapon];
    const len = Math.hypot(mx, my);
    if (len > 1) { mx /= len; my /= len; }
    const city = this.game === "bugs";
    let spd = SPEED, run = false;
    if (city) {
      if (f.isPlayer) {
        // walking is the default; running burns energy, and an empty tank means walking until it recovers
        run = this.wantRun && len > 0.3 && !f.exh && f.stam > 0 && !f.resting && this.phase === "live";
        f.runK += ((run ? 1 : 0) - f.runK) * Math.min(1, dt * 7);
        spd = f.resting ? 0 : (run ? RUN : f.exh ? WALK * 0.82 : WALK);
        if (run) {
          f.stam = Math.max(0, f.stam - 22 * dt);
          if (f.stam <= 0) { f.exh = true; this.say(f.x, f.y - 24, "KECAPEKAN!", "#ffb347"); }
        } else f.stam = Math.min(100, f.stam + (f.restK > 0.9 ? 46 : len > 0.15 ? 11 : 24) * dt);
        if (f.exh && f.stam >= 30) f.exh = false;
        if (f.resting) {
          f.restK += (1 - f.restK) * Math.min(1, dt * 3);
          if (f.restK > 0.9) {
            { const cap = this.bug.safe >= 0 ? 100 : 80; if (f.hp < cap) { f.hp = Math.min(cap, f.hp + (this.bug.safe >= 0 ? 10 : 3) * dt); this.hudDirty = true; } } // in a shelter you heal all the way, and fast
            if (rand() < dt * 1.6) this.puff(f.x + (rand() - 0.5) * 10, f.y - 4, 1, ["#7dff9a", "#ffffff"], 6, { z: 8, vz: 24, max: 0.9, size: 1, grav: -18 });
          }
          if (((this.t * 4) | 0) !== (((this.t - dt) * 4) | 0)) {
            if (this.bug.safe < 0) for (const z of this.bug.bugs) if (z.state !== "sleep" && Math.hypot(z.x - f.x, z.y - f.y) < 64) { this.setRest(f, false); this.say(f.x, f.y - 26, "ADA ZOMBIE!", "#ff6b7a"); break; }
          }
        } else f.restK *= Math.exp(-dt * 6);
      } else {
        const pl = this.player, far = pl && pl.alive && Math.hypot(pl.x - f.x, pl.y - f.y) > 150 ? 1.5 : 1;
        spd = f.civ ? (f.hid ? 0 : 90) : BOT * far; // squad mates keep up with you; the civilian is a little slower than a run
      }
    }
    const sp = spd * w.moveMul;
    const a = 1 - Math.exp(-dt * (city ? 12 : 18));
    f.vx += (mx * sp - f.vx) * a;
    f.vy += (my * sp - f.vy) * a;
    f.moving = len > 0.15 && sp > 0;
    if (f.lungeT > 0 && (f.lungeT -= dt) <= 0) {
      f.kx += Math.cos(f.lungeA) * f.lungeV; f.ky += Math.sin(f.lungeA) * f.lungeV;
      this.dust(f.x, f.y + 5, 2);
      this.snd(isBat(f.weapon) ? "whoosh" : "slash", f.x, f.y, 1);
    }
    if (f.moving) {
      // stride length follows real speed: slow plodding when walking, quick strides when running
      f.walkT += dt * Math.max(0.4, Math.hypot(f.vx, f.vy) / 100);
      f.stepT -= dt;
      if (f.stepT <= 0) {
        f.stepT = run ? 0.12 : 0.28;
        if (f.isPlayer) this.snd("step", f.x, f.y, run ? 0.9 : 0.6);
        if (run || !city) this.puff(f.x, f.y + 5, 1, ["#f1dcae", "#e6cc98"], 8, { z: 0, vz: 12, max: 0.3, grav: 20 });
      }
    }
    // now and then somebody takes a swig from a water bottle
    if (city && this.mode === "play" && this.phase === "live") {
      if (f.drinkT > 0) {
        f.drinkT -= dt;
        if ((f.moving && Math.hypot(f.vx, f.vy) > 30) || f.recoil > 0.2 || f.swingT > 0 || f.ouch > 0 || f.fear > 0) f.drinkT = 0;
        else if (f.drinkT <= 0 && f.isPlayer) f.stam = Math.min(100, f.stam + 15);
        const pp = 1 - f.drinkT / 2.4;
        if (f.drinkT > 0 && pp > 0.3 && pp < 0.75 && rand() < dt * 7) this.puff(f.x + (Math.cos(f.aim) < 0 ? -3 : 3), f.y - 3, 1, ["#9fd8ff", "#ffffff"], 8, { z: 6, vz: 14, max: 0.35, size: 1, grav: 220 });
      } else if ((f.drinkIn -= dt) <= 0) {
        f.drinkIn = f.resting ? 4 + rand() * 3 : 18 + rand() * 26;
        let calm = !f.moving && f.cd <= 0 && f.swingT <= 0 && f.ouch <= 0 && f.fear <= 0;
        if (calm) for (const z of this.bug.bugs) if (z.state !== "sleep" && Math.hypot(z.x - f.x, z.y - f.y) < 150) { calm = false; break; }
        if (calm) { f.drinkT = 2.4; this.snd("pick", f.x, f.y, 0.3); } else f.drinkIn = 3;
      }
    }
    if (f.cd > 0) f.cd -= dt;
    if (f.reloadT > 0) {
      const r0 = 1 - f.reloadT / f.reloadDur;
      f.reloadT -= dt;
      this.reloadFx(f, w, r0, 1 - Math.max(0, f.reloadT) / f.reloadDur);
      if (f.reloadT <= 0) {
        f.ammo[f.weapon] = w.mag;
        if (f.isPlayer) this.hudDirty = true;
      }
    } else if (!w.melee && f.ammo[w.id] <= 0 && f.cd <= 0) this.reload(f);
    if (f.pend > 0 && (f.pend -= dt) <= 0) this.strike(f, isBat(f.weapon) ? WEAPONS[f.weapon] : WEAPONS.bat, 2);
    if (f.ouch > 0) f.ouch -= dt;
    if (f.guardT > 0) f.guardT -= dt;
    f.calmT += dt;
    if (this.game === "bugs" && f.team === 0 && !f.civ && f.calmT > (f.isPlayer ? 4 : 3) && f.hp < (f.isPlayer ? 70 : 90)) {
      // left alone for a few seconds, wounds close on their own (part of the way for you, further for your friends)
      f.hp = Math.min(f.isPlayer ? 70 : 90, f.hp + (f.isPlayer ? 4 : 6) * dt);
      if (f.isPlayer) this.hudDirty = true;
    }
    if (f.joy > 0) f.joy -= dt;
    if (f.sad > 0) f.sad -= dt;
    if (f.mad > 0) f.mad -= dt;
    if (f.talkT > 0) f.talkT -= dt;
    // the karambit never rests: every few seconds it is spun round the finger
    if (f.spinT > 0) f.spinT -= dt;
    else if (f.weapon === "karambit" && f.swingT <= 0 && (f.spinIn -= dt) <= 0) {
      f.spinT = 0.6; f.spinIn = 2.2 + rand() * 3;
      if (f.isPlayer) this.snd("slash", f.x, f.y, 0.22);
    }
    if (f.fear > 0) f.fear -= dt;
    if (f.pump > 0) {
      // working the action throws the empty shell out
      const before = f.pump;
      f.pump -= dt;
      if (before > 0.17 && f.pump <= 0.17) { this.shell(f, "shotgun"); this.snd("click", f.x, f.y, 0.6); }
    }
    if (f.smokeT > 0) {
      // a hot barrel keeps smoking
      f.smokeT -= dt;
      if (!w.melee && rand() < dt * 24) this.puff(f.x + Math.cos(f.aim) * (w.len + 3), f.y + 1 + Math.sin(f.aim) * (w.len + 3), 1, ["#e9e2d2", "#b9b3a8"], 5, { z: 7, vz: 10, max: 0.5, size: 1, grav: -24, drag: 2 });
    }
    if (f.bloody > 0) f.bloody -= dt;
    if (f.loud > 0) f.loud -= dt;
    if (f.swingT > 0) {
      f.swingT -= dt;
      if (isBat(f.weapon)) this.deflect(f);
      // active frames: anything that walks into the swing still gets hit
      // active frames: the hit lands as the weapon whips through, and anything that walks into it is still caught
      const sp = 1 - f.swingT / f.swingDur;
      const lo = f.swingKind === 3 ? 0.2 : 0.4, hi = f.swingKind === 3 ? 0.9 : 0.74;
      if (w.melee && f.swingKind !== 2 && sp >= lo && sp <= hi) this.strike(f, w, f.swingKind);
    }
    if (f.dashT > 0) {
      f.dashT -= dt;
      f.ghostT -= dt;
      if (f.ghostT <= 0) {
        f.ghostT = 0.03;
        this.ghosts.push({ x: f.x, y: f.y, team: f.team, look: f.look, skin: f.skin, flip: Math.cos(f.aim) < 0, life: 0.22 });
      }
    }
    if (f.dashCd > 0) f.dashCd -= dt;
    if (f.hitFlash > 0) f.hitFlash -= dt;
    if (f.flash > 0) f.flash -= dt;
    f.recoil *= Math.exp(-dt * 16);
    f.tilt *= Math.exp(-dt * 11);
    // scarf chain trails behind the neck
    const sc = f.scarf, back = Math.cos(f.aim) < 0 ? 1 : -1;
    let ax = f.x + back * 4, ay = f.y - 5;
    for (let i = 0; i < 6; i += 2) {
      const k = Math.min(1, dt * (30 - i * 4));
      sc[i] += (ax + back * 1.6 - sc[i]) * k;
      sc[i + 1] += (ay + 1.4 - sc[i + 1]) * k;
      ax = sc[i]; ay = sc[i + 1];
    }
  }

  /** ragdoll: fly, spin, bounce off floor and walls, slide to a stop */
  tickCorpse(f: Fighter, dt: number) {
    f.deadT += dt;
    if (f.rest) return;
    const sp = Math.hypot(f.kx, f.ky);
    if (this.slide(f, f.kx * dt, f.ky * dt, 0.55) && sp > 70) {
      this.dust(f.x, f.y, 4);
      this.snd("thunk", f.x, f.y, 0.5);
      this.shake(1.5, f.x, f.y);
      f.vrot *= -0.7;
    }
    f.z += f.vz * dt;
    f.vz -= GRAV * dt;
    f.rot += f.vrot * dt;
    if (f.z <= 0) {
      f.z = 0;
      if (f.vz < -95) {
        f.vz *= -0.42; f.kx *= 0.62; f.ky *= 0.62; f.vrot *= 0.6;
        this.dust(f.x, f.y + 3, 4);
        this.snd("thunk", f.x, f.y, 0.4);
      } else {
        f.vz = 0;
        const fr = Math.exp(-dt * 7);
        f.kx *= fr; f.ky *= fr; f.vrot *= Math.exp(-dt * 9);
        const target = Math.round((f.rot - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2;
        f.rot += (target - f.rot) * Math.min(1, dt * 9);
        if (sp > 30 && rand() < dt * 25) this.puff(f.x, f.y + 3, 1, ["#f1dcae", "#e6cc98"], 10, { z: 0, vz: 14, max: 0.35, grav: 20 });
        if (sp < 6 && Math.abs(target - f.rot) < 0.06) { f.rot = target; f.rest = true; f.kx = f.ky = 0; }
      }
    } else {
      const fr = Math.exp(-dt * 0.8);
      f.kx *= fr; f.ky *= fr;
    }
  }

  update(rdt: number) {
    this.t += rdt;
    this.specT -= rdt;
    if (this.banner && (this.bannerT -= rdt) <= 0) { this.banner = null; this.hudDirty = true; }
    if (this.streak && (this.streakT -= rdt) <= 0) { this.streak = null; this.hudDirty = true; }
    if (this.feed.length && this.t - this.feed[0].t > 6) { this.feed.shift(); this.hudDirty = true; }
    this.floorTitle.t -= rdt;
    this.cozy += ((this.game === "bugs" && this.bug.safe >= 0 ? 1 : 0) - this.cozy) * Math.min(1, rdt * 2.2);
    this.clearK += ((this.game === "bugs" && this.bug.floorClear ? 1 : 0) - this.clearK) * Math.min(1, rdt * 3);
    if (this.fat) {
      const F = this.fat, pl = this.player;
      F.t += rdt;
      if (F.kind === 1 && F.t >= 0.16 && F.z.alive && pl) this.bug.execute(F.z, pl, "karambit", Math.atan2(F.z.y - pl.y, F.z.x - pl.x), 1);
      if (F.t > 1.15) this.fat = null;
    }
    this.hurtT -= rdt; this.hitMark -= rdt; this.killMark -= rdt; this.whiteT -= rdt; this.fade -= rdt;
    this.zoom *= Math.exp(-rdt * 5);
    if (this.game === "bugs") {
      // lift the roof of the house the camera target is standing in
      const fo = this.focus(), hi = fo ? houseAtPx(fo.x, fo.y) : -1;
      this.inside = hi >= 0;
      for (let i = 0; i < this.roofA.length; i++) this.roofA[i] += ((i === hi ? 0 : 1) - this.roofA[i]) * Math.min(1, rdt * 9);
      if (hi >= 0) this.inHouse = hi;
      this.inK += ((hi >= 0 ? 1 : 0) - this.inK) * Math.min(1, rdt * 7);
      this.atmo.update(rdt, this.bug.weather());
      if (this.atmo.thunder) {
        this.atmo.thunder = false;
        if (this.mode === "play") audio.play("thunder", 0.9);
        if (rand() < 0.5) this.talk.say("thunder", { cd: 30 });
        this.cam.shake = Math.min(10, this.cam.shake + 1.5);
      }
    }
    this.talk.update(rdt);
    const hp = this.player;
    if (hp && hp.alive && hp.hp < 35 && this.mode === "play" && (this.heartT -= rdt) <= 0) {
      this.heartT = 0.62;
      audio.play("heart", 0.9);
    }

    if (this.trans) {
      const tr = this.trans;
      tr.t += rdt;
      if (!tr.swapped && tr.t >= 2.1) { tr.swapped = true; this.ri++; this.loadLevel(this.route[this.ri]); }
      else if (tr.swapped && !tr.intro && tr.t >= 3.5) { tr.intro = true; this.startIntro(); }
      if (tr.t >= 5) this.trans = null;
    }
    if (this.intro) {
      const I = this.intro;
      I.t += rdt;
      if (!I.out && I.t >= 2) {
        // it has stopped: everybody over the side
        I.out = true;
        for (const f of this.fighters) if (!f.civ && f.gone) { f.gone = false; this.dust(f.x, f.y + 4, 3); }
        audio.play("door");
        this.phaseT = Math.min(this.phaseT, 1.6);
        this.cam.shake = Math.min(10, this.cam.shake + 2);
      }
      if (I.t >= 2.8) this.intro = null;
    }
    if (this.phase === "freeze" && !this.holding()) {
      const before = Math.ceil(this.phaseT);
      this.phaseT -= rdt;
      if (Math.ceil(this.phaseT) !== before) {
        if (this.phaseT > 0 && this.mode === "play") audio.play("tick");
        this.hudDirty = true;
      }
      if (this.phaseT <= 0) {
        this.phase = "live";
        if (this.game === "bugs") this.bug.go();
        else {
          this.setBanner("GAS!", "Lumpuhkan semua musuh!", "white", 1.2);
          if (this.mode === "play") audio.play("start");
        }
      }
    } else if (this.phase === "live") {
      this.roundT += rdt;
      if (this.game === "pvp") {
        this.timeLeft -= rdt;
        if (this.timeLeft <= 0) this.timeout();
      }
    } else if (this.phase === "end") {
      this.phaseT -= rdt;
      if (this.phaseT <= 0) {
        if (this.matchDone) this.finishMatch();
        else this.nextRound();
      }
    }

    if (this.hitStop > 0) { this.hitStop -= rdt; this.updateCamera(rdt); return; }
    const dt = rdt * (this.slowT > 0 ? 0.28 : 1);
    this.slowT -= rdt;

    // fighters
    for (const f of this.fighters) {
      if (!f.alive) { this.tickCorpse(f, dt); continue; }
      this.ix = this.iy = 0;
      if (f.isPlayer && this.climb) { this.tickClimb(f, dt); continue; }
      if (f.isPlayer) this.controlPlayer(f);
      else if (this.phase === "live") { if (f.civ) this.controlCiv(f, dt); else this.controlBot(f, dt); }
      const can = this.phase !== "freeze";
      this.tickFighter(f, can ? this.ix : 0, can ? this.iy : 0, dt);
      let vx = f.vx + f.kx, vy = f.vy + f.ky;
      if (f.dashT > 0) { vx = f.dashX * DASH_SPEED; vy = f.dashY * DASH_SPEED; }
      this.slide(f, vx * dt, vy * dt);
      if (this.game === "bugs") { if (f.isPlayer) this.stairCheck(f); else if (this.stairs(f)) this.tookStairs(f); }
      const fr = Math.exp(-dt * 9);
      f.kx *= fr; f.ky *= fr;
    }
    // separation + barrels
    const fs = this.fighters;
    for (let i = 0; i < fs.length; i++) {
      const a = fs[i];
      if (!a.alive) continue;
      for (let j = i + 1; j < fs.length; j++) {
        const b = fs[j];
        if (!b.alive) continue;
        const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
        if (d < 9 && d > 0.01) {
          const o = (9 - d) / 2, nx = dx / d, ny = dy / d;
          this.slide(a, -nx * o, -ny * o);
          this.slide(b, nx * o, ny * o);
        }
      }
      for (const b of this.barrels) {
        if (!b.alive) continue;
        const dx = a.x - b.x, dy = a.y - b.y, d = Math.hypot(dx, dy);
        if (d < 9.5 && d > 0.01) this.slide(a, (dx / d) * (9.5 - d), (dy / d) * (9.5 - d));
      }
    }
    for (const b of this.barrels) {
      if (!b.alive) continue;
      if (b.flash > 0) b.flash -= dt;
      if (b.hp <= 0) {
        b.fuse -= dt;
        if (b.fuse <= 0) { b.alive = false; this.blast(b.x, b.y, b.by, 48, 110, 330, "boom", true); }
      }
    }
    if (this.game === "bugs") this.bug.update(dt);
    this.updateBullets(dt);
    // dropped weapons tumble
    for (const d of this.drops) {
      if (d.z <= 0 && d.vz <= 0) continue;
      const nx = d.x + d.vx * dt, ny = d.y + d.vy * dt;
      if (solidAt(nx, ny)) { d.vx *= -0.4; d.vy *= -0.4; } else { d.x = nx; d.y = ny; }
      d.z += d.vz * dt; d.vz -= GRAV * dt; d.rot += d.vrot * dt;
      if (d.z <= 0) {
        d.z = 0;
        if (d.vz < -80) { d.vz *= -0.38; d.vx *= 0.5; d.vy *= 0.5; d.vrot *= 0.5; }
        else { d.vz = 0; d.vx = d.vy = d.vrot = 0; }
      }
    }
    // pickups
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.t += dt;
      if (p.t < 0.4) continue;
      for (const f of this.fighters) {
        if (f.alive && f.hp < MAX_HP && Math.hypot(f.x - p.x, f.y - p.y) < 10) {
          f.hp = Math.min(MAX_HP, f.hp + 35);
          this.say(f.x, f.y - 20, "+35", "#7dff9a");
          this.snd("pick", f.x, f.y);
          this.pickups.splice(i, 1);
          if (f.isPlayer) this.hudDirty = true;
          break;
        }
      }
    }
    // particles & fx
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life += dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      p.vz -= p.grav * dt;
      if (p.z < 0) { p.z = 0; p.vz *= -0.4; p.vx *= 0.5; p.vy *= 0.5; }
      const dr = Math.exp(-p.drag * dt);
      p.vx *= dr; p.vy *= dr;
      if (p.life >= p.max) {
        if (p.stamp && !solidAt(p.x, p.y)) {
          const fc = this.fctx, x = p.x | 0, y = p.y | 0;
          if (p.shell) {
            // a spent case (2 = shotgun shell, 3 = empty magazine) comes to rest - and stays where it fell
            const flat = ((x + y) & 1) === 0;
            if (p.shell === 3) { fc.fillStyle = "#0b0b10"; fc.fillRect(x - 1, y - 1, 5, 6); fc.fillStyle = "#3a3f4a"; fc.fillRect(x, y, 3, 4); fc.fillStyle = "#6a7280"; fc.fillRect(x, y, 3, 1); }
            else if (p.shell === 2) { fc.fillStyle = "#0b0b10"; fc.fillRect(x - 1, y - 1, flat ? 6 : 4, flat ? 4 : 6); fc.fillStyle = "#d8433b"; fc.fillRect(x, y, flat ? 4 : 2, flat ? 2 : 4); fc.fillStyle = "#f1cf6a"; fc.fillRect(x, y, flat ? 1 : 2, flat ? 2 : 1); }
            else { fc.fillStyle = "#6a4c14"; fc.fillRect(x, y, flat ? 3 : 1, flat ? 1 : 3); fc.fillStyle = "#f1cf6a"; fc.fillRect(x, y, flat ? 2 : 1, flat ? 1 : 2); fc.fillStyle = "#fff6c0"; fc.fillRect(x, y, 1, 1); }
            if (p.shell !== 3 && rand() < 0.7) this.snd("shell", p.x, p.y, 0.5);
          } else { fc.fillStyle = p.color; fc.fillRect(x, y, p.size, 1); }
        }
        this.parts[i] = this.parts[this.parts.length - 1];
        this.parts.pop();
      }
    }
    for (let i = this.texts.length - 1; i >= 0; i--) { const t = this.texts[i]; t.life += dt; t.y -= (22 - t.life * 18) * dt; if (t.life > 0.85) this.texts.splice(i, 1); }
    for (let i = this.slashes.length - 1; i >= 0; i--) if ((this.slashes[i].life -= dt) <= 0) this.slashes.splice(i, 1);
    for (let i = this.cuts.length - 1; i >= 0; i--) if ((this.cuts[i].life -= dt) <= 0) this.cuts.splice(i, 1);
    for (let i = this.bursts.length - 1; i >= 0; i--) if ((this.bursts[i].life += dt) >= this.bursts[i].max) this.bursts.splice(i, 1);
    for (let i = this.flashes.length - 1; i >= 0; i--) if ((this.flashes[i].life += dt) >= this.flashes[i].max) this.flashes.splice(i, 1);
    for (let i = this.tracers.length - 1; i >= 0; i--) if ((this.tracers[i].life -= dt) <= 0) this.tracers.splice(i, 1);
    for (let i = this.rings.length - 1; i >= 0; i--) if ((this.rings[i].life += dt) > 0.3) this.rings.splice(i, 1);
    for (let i = this.ghosts.length - 1; i >= 0; i--) if ((this.ghosts[i].life -= dt) <= 0) this.ghosts.splice(i, 1);
    for (let i = this.glows.length - 1; i >= 0; i--) if ((this.glows[i].life -= dt) <= 0) this.glows.splice(i, 1);
    for (let i = this.sparks.length - 1; i >= 0; i--) if ((this.sparks[i].life -= dt) <= 0) this.sparks.splice(i, 1);
    this.updateCamera(rdt);
  }

  updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      const rocket = b.wid === "bazooka";
      b.life -= dt;
      let dead = b.life <= 0;
      if (rocket) {
        b.speed = Math.min(705, b.speed + 960 * dt);
        this.puff(b.x - b.dx * 6, b.y - b.dy * 6, 1, ["#ffffff", "#e3ddd0", "#ffb347", "#b9b3a8"], 9, { z: 5, vz: 8, max: 0.55, size: rand() < 0.5 ? 2 : 3, grav: -20, drag: 2 });
      }
      const dist = b.speed * dt, n = Math.max(1, Math.ceil(dist / 3)), st = dist / n;
      for (let s = 0; s < n && !dead; s++) {
        b.x += b.dx * st; b.y += b.dy * st; b.trav += st;
        if (blockAt(b.x, b.y)) {
          dead = true;
          if (this.game === "bugs" && b.team === 0 && this.bug.skyShot(b)) break; // out of an upstairs window: it comes down in the street below
          if (!rocket) this.impact(b.x, b.y, b.dx, b.dy, b.wid === "sniper");
          b.x -= b.dx * 3; b.y -= b.dy * 3;
          break;
        }
        for (const bar of this.barrels) {
          if (!bar.alive || bar.hp <= 0) continue;
          const dx = bar.x - b.x, dy = bar.y - 2 - b.y;
          if (dx * dx + dy * dy < 42) {
            bar.hp -= b.dmg; bar.flash = 0.1; bar.by = b.owner;
            if (bar.hp <= 0) bar.fuse = 0.05;
            this.snd("hit", bar.x, bar.y, 0.7);
            this.sparks.push({ x: b.x, y: b.y, life: 0.07 });
            dead = true;
            break;
          }
        }
        if (dead) break;
        if (this.game === "bugs" && b.team === 0 && this.bug.hitBullet(b)) { dead = true; break; }
        for (const f of this.fighters) {
          if (!f.alive || f.team === b.team || f.dashT > 0 || b.hit.includes(f.id)) continue;
          const dx = f.x - b.x, dy = f.y - 1 - b.y;
          if (dx * dx + dy * dy < 40) {
            if (rocket) { dead = true; break; }
            const w = WEAPONS[b.wid];
            const fall = w.pellets > 1 ? 0.55 + 0.45 * clamp(b.life / b.max, 0, 1) : 1;
            this.damage(f, b.dmg * fall, b.owner, b.wid, Math.atan2(b.dy, b.dx), w.knock);
            if (b.pierce) b.hit.push(f.id);
            else { dead = true; break; }
          }
        }
      }
      if (dead) {
        if (rocket) this.blast(b.x, b.y, b.owner, 46, b.dmg, WEAPONS.bazooka.knock, "bazooka", false);
        else if (b.wid === "sniper") {
          // the round leaves a glowing line and a thread of vapour behind it
          this.tracers.push({ x0: b.ox, y0: b.oy, x1: b.x, y1: b.y, life: 0.25, color: TEAMS[b.team].bullet });
          const L = Math.min(320, Math.hypot(b.x - b.ox, b.y - b.oy));
          for (let d = 10; d < L; d += 18) this.puff(b.ox + b.dx * d, b.oy + b.dy * d, 1, ["#cfd6e2", "#9aa3b5"], 4, { z: 5, vz: 4, max: 0.7, size: 1, grav: -8 });
        }
        this.bullets.splice(i, 1);
      }
    }
  }

  updateCamera(rdt: number) {
    const f = this.focus(), cam = this.cam;
    if (f) {
      let lx = Math.cos(f.aim) * 26, ly = Math.sin(f.aim) * 26, k = 4;
      if (f.isPlayer && f.alive) {
        k = 10;
        if (this.useTouch) {
          const a = this.tAim.active ? 50 : 18;
          lx = Math.cos(f.aim) * a; ly = Math.sin(f.aim) * a;
        } else {
          const la = (f.weapon === "sniper" ? 0.62 : f.weapon === "bazooka" ? 0.45 : 0.32) + (this.game === "bugs" ? 0.1 : 0);
          lx = (this.mx - this.W / 2) * la; ly = (this.my - this.H / 2) * la;
        }
      }
      const a = 1 - Math.exp(-rdt * k);
      cam.x += (f.x + lx - cam.x) * a;
      cam.y += (f.y - 3 + ly - cam.y) * a;
    }
    const mw = MW * TILE, mh = (f && f.y > CH * TILE ? MH : CH) * TILE, pad = 18; // the upper floors lie below the city
    cam.x = this.W >= mw + pad * 2 ? mw / 2 : clamp(cam.x, this.W / 2 - pad, mw - this.W / 2 + pad);
    cam.y = this.H >= mh + pad * 2 ? mh / 2 : clamp(cam.y, this.H / 2 - pad, mh - this.H / 2 + pad);
    cam.shake *= Math.exp(-rdt * 11);
    const kd = Math.exp(-rdt * 13);
    cam.kx *= kd; cam.ky *= kd;
  }

  hud(): HudState {
    const p = this.player;
    const w = WEAPONS[p ? p.weapon : "pistol"];
    return {
      mode: this.mode, phase: this.phase, round: this.round, score: [this.score[0], this.score[1]],
      alive: [this.aliveCount(0), this.aliveCount(1)], time: Math.max(0, Math.ceil(this.timeLeft)),
      count: this.phase === "freeze" && !this.holding() ? Math.ceil(this.phaseT) : 0, hp: p ? Math.max(0, Math.ceil(p.hp)) : 0,
      weapon: w.id, ammo: p ? p.ammo[w.id] : 0, mag: w.mag, reload: p && p.reloadT > 0 ? 1 - p.reloadT / p.reloadDur : -1,
      dash: p ? clamp(1 - p.dashCd / DASH_CD, 0, 1) : 1, stam: p ? clamp(p.stam / 100, 0, 1) : 1, exh: !!p && p.exh, resting: !!p && p.resting, dead: !!p && !p.alive && !p.gone,
      spectating: p && !p.alive && this.spec ? this.spec.name : "", feed: this.feed.slice(), banner: this.banner, streak: this.streak,
      paused: this.paused, muted: audio.muted, touch: this.useTouch,
      game: this.game, ...this.bug.hudInfo(), music: audio.musicOn,
      chat: this.talk.log.filter((l) => this.t - l.t < 11).slice(-4),
    };
  }

  loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    if (this.halt) { this.lastT = now; return; }
    const rdt = clamp((now - this.lastT) / 1000, 0, 0.05);
    this.lastT = now;
    if (!this.paused) this.update(rdt);
    this.render(rdt);
    const amb = this.mode === "play" && this.game === "bugs" && !this.paused && this.phase !== "over";
    audio.ambience(amb ? 0.7 + 0.3 * Math.min(1, this.atmo.cur.rain) : 0, 0.4 + 0.6 * Math.min(1, Math.max(this.atmo.cur.rain, this.atmo.cur.fog * 0.6)), amb ? this.atmo.cur.rain : 0);
    // the music follows the danger: quiet chords when nothing is near (or behind barred doors), a driving pulse when they are on you
    const want = this.mode !== "play" || this.paused || this.phase === "over" ? 0 : this.game === "bugs" ? this.bug.danger() : this.phase === "live" ? 0.8 : 0.25;
    this.tense += (want - this.tense) * Math.min(1, rdt * (want > this.tense ? 1.8 : 0.45));
    audio.music(this.tense);
    this.hudT -= rdt;
    if (this.hudT <= 0 || this.hudDirty) {
      this.hudT = 0.1;
      this.hudDirty = false;
      this.cb.onHud(this.hud());
    }
  };

  /* ───────────── rendering ───────────── */
  drawWeapon(f: Fighter, x: number, y: number) {
    const ctx = this.ctx, w = WEAPONS[f.weapon], img = this.sp.weapon[f.look][f.weapon], pv = WPIVOT[f.weapon];
    const left = Math.cos(f.aim) < 0, sgn = left ? -1 : 1, hand = LOOK_PAL[f.look][f.skin].F;
    let ang = f.aim, lift = 0, stretch = 1, ghost = 0, ext = 0;
    let magX = 0, magY = 0, magK = 0; // what the other hand is feeding the gun during a reload: 1 shell, 2 rocket, 3 magazine, 4 AK magazine
    let rc = Math.round(f.recoil * (f.weapon === "bazooka" ? 7 : f.weapon === "sniper" ? 6 : f.weapon === "shotgun" ? 7 : f.weapon === "goldgun" ? 5 : 3));
    const reloading = !w.melee && f.reloadT > 0;
    if (w.melee) {
      const p = f.swingT > 0 ? 1 - f.swingT / f.swingDur : 1;
      if (f.swingKind === 2 && isBat(f.weapon) && p < 1) {
        // overhead smash: wind up above the head, then bring it straight down along the aim
        const d = angDiff(-Math.PI / 2, f.aim), sg = d < 0 ? -1 : 1, T = Math.abs(d) + 0.7;
        if (p < 0.4) { const e = 1 - (1 - p / 0.4) ** 2; ang = f.aim - sg * T * e; lift = 8 * e; stretch = 1 - 0.3 * e; }
        else { const k = Math.min(1, (p - 0.4) / 0.13), e = k * k; ang = f.aim - sg * T * (1 - e) + sg * 0.3 * e; lift = 8 * (1 - e); stretch = 0.7 + 0.5 * e; if (k < 1) ghost = sg; }
        ext = 3 + 4 * Math.min(1, p / 0.5);
      } else if (f.swingKind === 3 && p < 1) {
        ang = f.aim + f.swingDir * (p * PI2 - 0.8); // spin: the blade goes all the way round
        ghost = f.swingDir; stretch = 1.15; ext = 3 + 5 * Math.sin(p * Math.PI);
      } else {
        // wind up, whip through, settle - then drift back to a ready stance
        const idle = clamp((this.t - f.lastSwing - f.swingDur) / 0.45, 0, 1);
        let a = 1.25 - 0.55 * idle;
        if (p < 0.4) { const k = p / 0.4, e = 1 - (1 - k) * (1 - k); a = a + (-2.1 - a) * e; stretch = 1 - 0.1 * e; } // slow, heavy pull back
        else if (p < 0.72) { const k = (p - 0.4) / 0.32, e = k * k * (3 - 2 * k); a = -2.1 + 3.8 * e; ghost = f.swingDir; stretch = 1 + 0.25 * Math.sin(k * Math.PI); } // the whip: all the weight arrives here
        else if (p < 1) a = 1.7 - 0.45 * ((p - 0.72) / 0.28);
        // the arm is pulled in for the wind-up and thrown out to full length as the blow lands
        ext = p >= 1 ? 2 : p < 0.4 ? 2 - p / 0.4 : p < 0.72 ? 1 + 6 * Math.sin(((p - 0.4) / 0.32) * Math.PI * 0.5) : 7 - 5 * ((p - 0.72) / 0.28);
        ang += f.swingDir * a * (isBat(f.weapon) ? 1 : 0.8);
        if (f.weapon === "karambit" && f.spinT > 0 && p >= 1) { ang = f.aim + sgn * (1 - f.spinT / 0.6) * PI2 * 2; ghost = sgn; ext = 3; } // two full turns round the ring finger
      }
    } else if (reloading) {
      // every gun is reloaded its own way: magazines dropped and slapped home, shells thumbed in one by one, a rocket slid into the tube
      const p = 1 - f.reloadT / f.reloadDur, wid = f.weapon, small = wid === "pistol" || wid === "goldgun";
      const k = p < 0.15 ? p / 0.15 : p > 0.85 ? (1 - p) / 0.15 : 1;
      ang += sgn * (small ? -0.6 : 0.7) * k; // handguns tip up, long guns down
      if (wid === "goldgun" && p > 0.86) ang += ((p - 0.86) / 0.14) * PI2 * sgn; // and because it is gold: a spin to finish
      if (wid === "shotgun") {
        if (p < 0.9) { magX = 6; magY = 3 + (1 - Math.min(1, ((p * 6.6) % 1) * 2.4)) * 5; magK = 1; }
        else rc += Math.round(3 * Math.sin(((p - 0.9) / 0.1) * Math.PI)); // the pump
      } else if (wid === "bazooka") {
        if (p > 0.2 && p < 0.75) { magX = -4 - (1 - Math.min(1, (p - 0.2) / 0.4)) * 10; magY = -2; magK = 2; }
      } else {
        if (p > 0.3 && p < 0.72) { magX = wid === "ak47" ? 6 : wid === "sniper" ? 5 : 1; magY = 3 + (1 - Math.min(1, (p - 0.3) / 0.3)) * 7; magK = wid === "ak47" ? 4 : 3; }
        if (p > 0.72 && p < 0.8) rc -= 1; // slapped home
        if (p > 0.86) rc += Math.round(3 * Math.sin(((p - 0.86) / 0.14) * Math.PI)); // the bolt, the slide
      }
    } else ang -= sgn * f.recoil * (f.weapon === "pistol" || f.weapon === "goldgun" ? 0.5 : f.weapon === "shotgun" ? 0.34 : 0.22); // muzzle climb
    ctx.save();
    ctx.translate(x + Math.round(Math.cos(f.aim) * (w.melee ? 1 : 2)), y + (w.melee ? -1 : 1) - Math.round(lift));
    if (ghost) {
      // motion blur: fading copies of the weapon trail behind the swing
      const ga = ctx.globalAlpha;
      for (let i = 3; i >= 1; i--) {
        ctx.save();
        ctx.rotate(ang - ghost * 0.24 * i);
        if (left) ctx.scale(1, -1);
        ctx.globalAlpha = ga * 0.34 * (1 - i / 4.5);
        ctx.drawImage(img, -pv[0] + 2, -pv[1]);
        ctx.restore();
      }
      ctx.globalAlpha = ga;
    }
    ctx.rotate(ang);
    if (w.melee) {
      // the arm: from the shoulder out to the grip, so the weapon never floats away from the body
      const al = Math.round(ext) + 1;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(-1, -2, al + 2, 4);
      ctx.fillStyle = LOOK_PAL[f.look][f.skin].B;
      ctx.fillRect(0, -1, al, 2);
      ctx.translate(Math.round(ext), 0);
    }
    if (left) ctx.scale(1, -1);
    if (stretch !== 1) ctx.scale(stretch, 1);
    ctx.drawImage(img, -pv[0] + 2 - rc, -pv[1]);
    if (f.bloody > 0 && isBat(f.weapon)) {
      ctx.fillStyle = "#a8202c";
      ctx.fillRect(12 - rc, -1, 5, 1); ctx.fillRect(14 - rc, 0, 3, 2);
      ctx.fillStyle = "#d04a4a";
      ctx.fillRect(15 - rc, -1, 2, 1);
    }
    // hands
    ctx.fillStyle = "#0a0a0f";
    ctx.fillRect(-rc, -1, 4, 4);
    ctx.fillStyle = hand;
    ctx.fillRect(1 - rc, 0, 2, 2);
    if (magK) {
      // what goes into the gun - a shell, a rocket, a fresh magazine - and the hand that brings it
      const mx = Math.round(magX) - rc, my = Math.round(magY), hy = magK === 2 ? 2 : magK === 1 ? 2 : 4;
      ctx.fillStyle = "#0a0a0f";
      if (magK === 1) { ctx.fillRect(mx - 1, my - 1, 5, 4); ctx.fillStyle = "#e0524a"; ctx.fillRect(mx, my, 3, 2); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 1, 2); }
      else if (magK === 2) { ctx.fillRect(mx - 1, my - 1, 9, 5); ctx.fillStyle = "#566b3e"; ctx.fillRect(mx, my, 6, 3); ctx.fillStyle = "#e0483e"; ctx.fillRect(mx + 5, my, 2, 3); }
      else { ctx.fillRect(mx - 1, my - 1, 5, 7); ctx.fillStyle = magK === 4 ? "#7a4a28" : "#3a3f4a"; ctx.fillRect(mx, my, 3, 5); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 3, 1); }
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(mx - 1, my + hy, 4, 3);
      ctx.fillStyle = hand;
      ctx.fillRect(mx, my + hy, 2, 2);
    }
    if (!magK && !w.melee && f.weapon !== "pistol" && f.weapon !== "goldgun") {
      // the support hand works the pump or the magazine
      const hx = reloading ? 4 : 8 - (f.weapon === "shotgun" && f.pump > 0 ? Math.round(Math.sin((1 - f.pump / 0.34) * Math.PI) * 3) : 0), hy = reloading ? 1 : -1;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(hx - rc, hy, 4, 3);
      ctx.fillStyle = hand;
      ctx.fillRect(hx + 1 - rc, hy, 2, 2);
    } else if (isBat(f.weapon)) {
      ctx.fillStyle = hand;
      ctx.fillRect(4 - rc, 0, 2, 2);
    }
    if (f.flash > 0 && !w.melee) {
      // muzzle flash: a different star every shot
      const m = img.width - pv[0] + 2 - rc, by = WBARREL[f.weapon] + 0.5, k = f.flash / 0.06, sd = f.seed;
      const L = (f.weapon === "sniper" ? 22 : f.weapon === "shotgun" ? 20 : f.weapon === "bazooka" || f.weapon === "ak47" ? 13 : f.weapon === "goldgun" ? 15 : 9) * (0.75 + 0.5 * sd) * (0.45 + 0.55 * k);
      const Wd = (f.weapon === "shotgun" ? 13 : f.weapon === "sniper" ? 6 : f.weapon === "bazooka" ? 8 : 4.5) * (1.2 - 0.4 * sd);
      const star = (l: number, wd: number) => {
        ctx.beginPath();
        ctx.moveTo(m, by - wd * 0.3); ctx.lineTo(m + l * 0.3, by - wd); ctx.lineTo(m + l * 0.42, by - wd * 0.28); ctx.lineTo(m + l, by);
        ctx.lineTo(m + l * 0.42, by + wd * 0.28); ctx.lineTo(m + l * 0.3, by + wd); ctx.lineTo(m, by + wd * 0.3);
        ctx.closePath();
        ctx.fill();
      };
      ctx.fillStyle = "#ff9a3c"; star(L, Wd);
      ctx.fillStyle = "#ffe45c"; star(L * 0.75, Wd * 0.7);
      ctx.fillStyle = "#ffffff"; star(L * 0.45, Wd * 0.4);
      if (f.weapon === "bazooka") { ctx.fillStyle = "#ffd75e"; ctx.fillRect(-pv[0] - 7 - rc, by - 3.5, 9, 7); }
    }
    ctx.restore();
  }

  /** body parts in a local frame whose origin is the feet */
  drawBody(look: number, skin: number, white: boolean, step: number, bob: number, f: Fighter | null = null) {
    const ctx = this.ctx, sp = this.sp, pal = LOOK_PAL[look][skin];
    ctx.fillStyle = white ? "#ffffff" : pal.D;
    const lx = Math.round(step * 1.5);
    ctx.fillRect(-3 + lx, -3 - (step > 0.4 ? 1 : 0), 2, 3);
    ctx.fillRect(1 - lx, -3 - (step < -0.4 ? 1 : 0), 2, 3);
    if (!white) {
      ctx.fillStyle = pal.K;
      ctx.fillRect(-3 + lx, -1 - (step > 0.4 ? 1 : 0), 2, 1);
      ctx.fillRect(1 - lx, -1 - (step < -0.4 ? 1 : 0), 2, 1);
    }
    if (pal.P) {
      // backpack
      ctx.fillStyle = white ? "#ffffff" : pal.K;
      ctx.fillRect(-10, -10 + bob, 5, 9);
      if (!white) {
        ctx.fillStyle = pal.P;
        ctx.fillRect(-9, -9 + bob, 3, 7);
        ctx.fillStyle = "rgba(255,255,255,0.3)";
        ctx.fillRect(-9, -9 + bob, 3, 1);
        ctx.fillStyle = pal.K;
        ctx.fillRect(-9, -5 + bob, 3, 1);
      }
    }
    ctx.drawImage(white ? sp.torsoW[look][skin] : sp.torso[look][skin], -7, -9 + bob);
    // the head leads the body: it dips over a reload, snaps back with the recoil and ducks when hurt
    const hx = f && f.recoil > 0.5 ? -1 : 0, hy = -19 + bob + (f ? (f.reloadT > 0 ? 1 : 0) + (f.ouch > 0.3 ? 1 : 0) : 0);
    ctx.drawImage(white ? sp.headW[look][skin] : sp.head[look][skin], -7 + hx, hy);
    if (f && !white && look >= 2) this.face(f, -7 + hx, hy);
  }

  /** survivors wear their feelings on their faces: pain, effort, fear, joy, talking, blinking */
  face(f: Fighter, ox: number, oy: number) {
    if (f.look === 2 && (f.skin === 5 || f.skin === 6 || f.skin === 8 || f.skin === 10)) return; // nothing to read behind a visor, a gas mask or a hockey mask
    const ctx = this.ctx, t = this.t, skin = LOOK_PAL[f.look][f.skin].F, dark = "#1a1014";
    const shades = f.look === 2 && f.skin === 4, mask = f.look === 2 && f.skin === 3, ex = [ox + 3, ox + 8], ey = oy + 6, mx = ox + 5, my = oy + 8;
    const talking = (f.talkT > 0 || this.talk.bubbles.some((b) => b.f === f)) && Math.sin(t * 17 + f.id) > 0;
    // 1 hurt, 2 effort, 3 scared, 4 happy, 5 sad, 6 angry
    const mood = f.ouch > 0 ? 1 : f.mad > 0 ? 6 : f.swingT > 0 || f.recoil > 0.25 ? 2 : f.joy > 0 ? 4 : f.sad > 0 ? 5 : f.fear > 0 || f.hp < 35 ? 3 : 0;
    if (mood === 5 && !shades) {
      // sad: droopy eyes looking down, inner brows raised, a tear rolling
      ctx.fillStyle = skin; for (const x of ex) ctx.fillRect(x, ey - 1, 2, 2);
      ctx.fillStyle = "#ffffff"; for (const x of ex) ctx.fillRect(x, ey, 2, 1);
      ctx.fillStyle = dark; ctx.fillRect(ex[0] + 1, ey, 1, 1); ctx.fillRect(ex[1], ey, 1, 1);
      ctx.fillRect(ex[0], ey - 2, 1, 1); ctx.fillRect(ex[0] + 1, ey - 3, 1, 1); ctx.fillRect(ex[1] + 1, ey - 2, 1, 1); ctx.fillRect(ex[1], ey - 3, 1, 1);
      const k = (t * 1.1 + f.id * 0.3) % 1;
      ctx.fillStyle = "#8fd0ff"; ctx.fillRect(ex[0], ey + 1 + Math.round(k * 4), 1, 2);
    }
    if (mood === 6) {
      // angry: slanted brows, narrowed eyes, a throbbing vein
      if (!shades) { ctx.fillStyle = skin; for (const x of ex) ctx.fillRect(x, ey - 1, 2, 1); }
      ctx.fillStyle = dark;
      const by = shades ? ey - 2 : ey - 1;
      ctx.fillRect(ex[0] - 1, by - 1, 1, 1); ctx.fillRect(ex[0], by, 2, 1); ctx.fillRect(ex[1] + 2, by - 1, 1, 1); ctx.fillRect(ex[1], by, 2, 1);
      if (Math.sin(t * 14) > -0.2) { ctx.fillStyle = "#ff3040"; ctx.fillRect(ox + 11, oy + 1, 1, 2); ctx.fillRect(ox + 10, oy + 2, 3, 1); }
    }
    const blink = mood === 0 && ((t * 0.6 + f.id * 0.37) % 1 > 0.955 || (f.drinkT > 0.3 && f.drinkT < 2));
    if (!shades) {
      if (mood === 1 || mood === 4 || blink) {
        // eyes shut
        ctx.fillStyle = skin;
        for (const x of ex) ctx.fillRect(x, ey, 2, 1);
        ctx.fillStyle = dark;
        for (const x of ex) ctx.fillRect(x, ey, 2, 1);
        if (mood === 4) { ctx.fillStyle = skin; ctx.fillRect(ex[0], ey, 1, 1); ctx.fillRect(ex[1] + 1, ey, 1, 1); ctx.fillStyle = dark; ctx.fillRect(ex[0], ey + 1, 1, 1); ctx.fillRect(ex[1] + 1, ey + 1, 1, 1); } // smiling eyes
      } else if (mood === 3) {
        // wide eyes, tiny pupils
        ctx.fillStyle = "#ffffff";
        for (const x of ex) ctx.fillRect(x, ey - 1, 2, 2);
        ctx.fillStyle = dark;
        ctx.fillRect(ex[0] + 1, ey, 1, 1); ctx.fillRect(ex[1], ey, 1, 1);
      }
    }
    if (mood === 1 || mood === 2) {
      // brows pulled down
      const by = shades ? ey - 2 : ey - 1;
      ctx.fillStyle = dark;
      ctx.fillRect(ex[0], by - 1, 1, 1); ctx.fillRect(ex[0] + 1, by, 1, 1);
      ctx.fillRect(ex[1] + 1, by - 1, 1, 1); ctx.fillRect(ex[1], by, 1, 1);
    }
    if (!mask) {
      if (mood === 5) { ctx.fillStyle = dark; ctx.fillRect(mx, my + 1, 1, 1); ctx.fillRect(mx + 1, my, 2, 1); ctx.fillRect(mx + 3, my + 1, 1, 1); } // frown
      else if (mood === 6) { ctx.fillStyle = dark; ctx.fillRect(mx - 1, my - 1, 6, 3); ctx.fillStyle = "#ffffff"; ctx.fillRect(mx, my - 1, 4, 1); ctx.fillRect(mx, my + 1, 4, 1); } // bared teeth
      else if (mood === 1) { ctx.fillStyle = "#4a0c14"; ctx.fillRect(mx + 1, my, 2, 2); } // "ow!"
      else if (mood === 2) { ctx.fillStyle = dark; ctx.fillRect(mx, my, 4, 1); ctx.fillStyle = "#ffffff"; ctx.fillRect(mx + 1, my, 2, 1); } // gritted teeth
      else if (mood === 4) { ctx.fillStyle = dark; ctx.fillRect(mx, my - 1, 1, 1); ctx.fillRect(mx + 3, my - 1, 1, 1); ctx.fillRect(mx + 1, my, 2, 1); } // grin
      else if (mood === 3) { ctx.fillStyle = dark; ctx.fillRect(mx + 1, my, 2, 1); ctx.fillRect(mx + (Math.sin(t * 30) > 0 ? 0 : 3), my, 1, 1); } // trembling
      else if (talking) { ctx.fillStyle = "#4a0c14"; ctx.fillRect(mx + 1, my, 2, 1); }
    }
    if (mood === 3) {
      // a drop of sweat runs down the temple
      const k = (t * 1.6 + f.id * 0.3) % 1;
      ctx.fillStyle = "#8fd0ff";
      ctx.fillRect(ox + 12, oy + 2 + Math.round(k * 5), 1, 2);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(ox + 12, oy + 2 + Math.round(k * 5), 1, 1);
    } else if (mood === 4) {
      ctx.fillStyle = "#ff9aa5";
      ctx.fillRect(ox + 2, ey + 1, 1, 1); ctx.fillRect(ox + 11, ey + 1, 1, 1);
    }
    if (shades && this.talk.rageT > 0 && Math.sin(t * 12) > -0.5) {
      // Bara has had enough
      ctx.fillStyle = "#ff3040";
      ctx.fillRect(ox + 12, oy, 1, 3); ctx.fillRect(ox + 11, oy + 1, 3, 1);
    }
  }

  drawFighter(f: Fighter) {
    const ctx = this.ctx;
    const x = Math.round(f.x) - this.cl, y = Math.round(f.y) - this.ct;
    if (x < -40 || x > this.W + 40 || y < -40 || y > this.H + 40) return;
    const cheer = (this.phase === "end" || this.phase === "over") && f.team === this.winner;
    const z = cheer ? Math.round(Math.abs(Math.sin(this.t * 9 + f.id)) * 5) : 0;
    const step = f.moving ? Math.sin(f.walkT * 24) : 0;
    const bob = f.moving ? (Math.abs(step) > 0.55 ? 1 : 0) : Math.sin(this.t * 2.6 + f.id) > 0.55 ? 1 : 0;
    const flip = Math.cos(f.aim) < 0;
    const up = Math.sin(f.aim) < -0.3;
    const ca = Math.cos(f.aim), sa = Math.sin(f.aim);
    let rot = f.tilt + (f.moving ? clamp(f.vx / SPEED, -1, 1) * 0.1 : 0) - (flip ? -1 : 1) * f.recoil * 0.2;
    // guns shove the shooter back; a melee swing takes the whole body with it
    let lx = -ca * f.recoil * 1.5, ly = -sa * f.recoil, hop = 0, sx = 1, sy = 1;
    if (f.swingT > 0 && WEAPONS[f.weapon].melee) {
      const p = 1 - f.swingT / f.swingDur;
      if (f.swingKind === 2) {
        // overhead smash: jump, hang, slam
        const rise = p < 0.4 ? Math.sin((p / 0.4) * Math.PI * 0.5) : Math.max(0, 1 - (p - 0.4) / 0.13);
        hop = rise * 6; sy = 1 + 0.12 * rise; sx = 1 - 0.08 * rise;
        if (p > 0.53) { const k = 1 - Math.min(1, (p - 0.53) / 0.25); sy = 1 - 0.2 * k; sx = 1 + 0.16 * k; lx = ca * 3; ly = sa * 2; }
      } else if (f.swingKind === 3) {
        // spin: the body whips round with the blade
        sx = Math.cos(p * PI2);
        if (Math.abs(sx) < 0.2) sx = sx < 0 ? -0.2 : 0.2;
        const k = Math.sin(p * Math.PI);
        lx = ca * 4 * k; ly = sa * 3 * k;
      } else {
        // lean back, then step into it
        const wind = p < 0.4 ? Math.sin((p / 0.4) * Math.PI * 0.5) : Math.max(0, 1 - (p - 0.4) / 0.14);
        const hit = p > 0.4 ? Math.sin(Math.min(1, (p - 0.4) / 0.45) * Math.PI) : 0;
        lx = ca * (hit * 4 - wind * 2); ly = sa * (hit * 3 - wind * 1.5);
        rot += f.swingDir * (hit * 0.28 - wind * 0.2);
        sx = 1 + 0.1 * hit; sy = 1 - 0.07 * hit + 0.05 * wind;
      }
    }
    const drinking = f.drinkT > 0, dp = drinking ? 1 - f.drinkT / 2.4 : 0;
    if (f.civ && (f.hid || f.fear > 0)) { sy *= 0.84; sx *= 1.06; ly += 2; lx += Math.sin(this.t * 38 + f.id) * 0.7; } // cowering, trembling
    if (f.restK > 0.05) { sy *= 1 - 0.2 * f.restK; sx *= 1 + 0.08 * f.restK; ly += 3 * f.restK + Math.sin(this.t * 2.2) * 0.4 * f.restK; }
    if (drinking && dp > 0.2 && dp < 0.82) rot -= (flip ? -1 : 1) * 0.16 * Math.min(1, (dp - 0.2) / 0.15);
    const bx = x + Math.round(lx), by = y - z - Math.round(hop) + Math.round(ly) - Math.round(f.climbY);
    if (f.dashT > 0 || (f.guardT > 0 && f.isPlayer && Math.sin(this.t * 44) > 0)) ctx.globalAlpha = 0.72; // flickering: they cannot get a grip on you
    // scarf: interpolate between chain points so the cloth reads as one ribbon
    const sc = f.scarf, pal = LOOK_PAL[f.look][f.skin];
    const pts: number[] = [];
    let qx = f.x + (flip ? 4 : -4), qy = f.y - 5;
    for (let i = 0; i < 6; i += 2) {
      for (let k = 1; k <= 3; k++) pts.push(Math.round(qx + ((sc[i] - qx) * k) / 3) - this.cl, Math.round(qy + ((sc[i + 1] - qy) * k) / 3) - this.ct - z);
      qx = sc[i]; qy = sc[i + 1];
    }
    if (!pal.A) pts.length = 0; // no scarf on this outfit
    ctx.fillStyle = "#0a0a0f";
    for (let i = 0; i < pts.length; i += 2) ctx.fillRect(pts[i] - 2, pts[i + 1] - 2, 4, 4);
    for (let i = pts.length - 2; i >= 0; i -= 2) {
      ctx.fillStyle = i >= 12 ? pal.a : pal.A;
      ctx.fillRect(pts[i] - 1, pts[i + 1] - 1, 2, 2);
    }
    if (up && !drinking && !f.civ) this.drawWeapon(f, bx, by);
    ctx.save();
    ctx.translate(bx, by + 6);
    if (Math.abs(rot) > 0.04) ctx.rotate(rot);
    if (flip) ctx.scale(-1, 1);
    if (f.dashT > 0) ctx.scale(1.12, 0.9);
    if (sx !== 1 || sy !== 1) ctx.scale(sx, sy);
    this.drawBody(f.look, f.skin, f.hitFlash > 0, step, bob, f);
    ctx.restore();
    if (!up && !drinking && !f.civ) this.drawWeapon(f, bx, by);
    if (drinking) this.drawBottle(f, bx, by, flip, dp);
    ctx.globalAlpha = 1;
    if (f.hp < MAX_HP) {
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 7, y - 18 - z, 14, 3);
      ctx.fillStyle = f.isPlayer ? "#7dff9a" : TEAMS[f.team].color;
      ctx.fillRect(x - 6, y - 17 - z, Math.max(1, Math.round((f.hp / MAX_HP) * 12)), 1);
    }
    if (f.civ && !f.hid) {
      // a little heart over the one you are looking after
      const b = Math.round(Math.sin(this.t * 5 + 1) * 1.2) - (f.hp < MAX_HP ? 4 : 0) - z, hx = x - 3, hy = y - 23 + b;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(hx - 1, hy - 1, 9, 5); ctx.fillRect(hx, hy + 4, 7, 1); ctx.fillRect(hx + 1, hy + 5, 5, 1); ctx.fillRect(hx + 2, hy + 6, 3, 1);
      ctx.fillStyle = f.hp < 40 && Math.sin(this.t * 12) > 0 ? "#ffffff" : "#ff7ab0";
      ctx.fillRect(hx, hy, 3, 3); ctx.fillRect(hx + 4, hy, 3, 3); ctx.fillRect(hx + 1, hy + 1, 5, 3); ctx.fillRect(hx + 2, hy + 4, 3, 1); ctx.fillRect(hx + 3, hy + 5, 1, 1);
    }
    if (f.isPlayer) {
      const b = Math.round(Math.sin(this.t * 6) * 1.2) - (f.hp < MAX_HP ? 4 : 0) - z;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 3, y - 22 + b, 7, 2);
      ctx.fillRect(x - 2, y - 20 + b, 5, 1);
      ctx.fillRect(x - 1, y - 19 + b, 3, 1);
      ctx.fillStyle = "#fff0a8";
      ctx.fillRect(x - 2, y - 21 + b, 5, 1);
      ctx.fillRect(x - 1, y - 20 + b, 3, 1);
      ctx.fillRect(x, y - 19 + b, 1, 1);
    }
  }

  /** a water bottle: raised to the mouth, tipped back for a few gulps, lowered again */
  drawBottle(f: Fighter, bx: number, by: number, flip: boolean, p: number) {
    const ctx = this.ctx, dir = flip ? -1 : 1, hand = LOOK_PAL[f.look][f.skin].F;
    const up = p < 0.22 ? p / 0.22 : p > 0.8 ? (1 - p) / 0.2 : 1;
    const tilt = p > 0.22 && p < 0.8 ? Math.min(1, (p - 0.22) / 0.15) : 0, gulp = tilt > 0.9 ? Math.sin(p * 46) * 0.07 : 0;
    ctx.save();
    // held in front of the face and tipped back: the neck of the bottle points at the mouth, the bottom goes up
    ctx.translate(bx + dir * Math.round(8 - up * 3), by + Math.round(5 - up * 10));
    ctx.rotate(-dir * (tilt * 1.75 + gulp));
    const level = Math.max(1, Math.round(6 * (1 - p * 0.7)));
    ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-3, -5, 6, 11); ctx.fillRect(-2, -7, 4, 3);
    ctx.fillStyle = "#cfeeff"; ctx.fillRect(-2, -4, 4, 9);
    ctx.fillStyle = "#4aa8e8"; ctx.fillRect(-2, 5 - level, 4, level);
    ctx.fillStyle = "#ffffff"; ctx.fillRect(-2, -4, 1, 6);
    ctx.fillStyle = "#f5f5f5"; ctx.fillRect(-1, -6, 2, 2);
    ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-3, 0, 6, 3);
    ctx.fillStyle = hand; ctx.fillRect(-2, 1, 4, 1);
    ctx.restore();
  }

  /** tumbling / resting KO'd operator */
  drawCorpse(f: Fighter) {
    const ctx = this.ctx, sp = this.sp;
    const x = Math.round(f.x) - this.cl, y = Math.round(f.y) - this.ct;
    if (x < -40 || x > this.W + 40 || y < -60 || y > this.H + 40) return;
    const z = Math.round(f.z), fl = f.rest ? 0 : 1, white = f.deadT < 0.035;
    const sw = Math.max(4, 14 - z * 0.25);
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(Math.round(x - sw / 2), y + 3, Math.round(sw), z > 3 ? 2 : 3);
    const t = this.t, pal = LOOK_PAL[f.look][f.skin];
    ctx.save();
    ctx.translate(x, y - z);
    ctx.rotate(f.rot);
    // flailing limbs
    ctx.fillStyle = white ? "#ffffff" : pal.D;
    ctx.fillRect(-3 + fl * Math.round(Math.sin(t * 24 + f.id) * 2), 3, 2, 3 + fl * Math.round(Math.sin(t * 19) * 1));
    ctx.fillRect(1 + fl * Math.round(Math.cos(t * 21 + f.id) * 2), 3, 2, 3 + fl * Math.round(Math.cos(t * 23) * 1));
    ctx.fillStyle = white ? "#ffffff" : pal.B;
    ctx.fillRect(-9, -3 + fl * Math.round(Math.sin(t * 27 + f.id) * 2.4), 3, 2);
    ctx.fillRect(6, -3 + fl * Math.round(Math.cos(t * 25 + f.id) * 2.4), 3, 2);
    ctx.fillStyle = white ? "#ffffff" : LOOK_PAL[f.look][f.skin].F;
    ctx.fillRect(-10, -3 + fl * Math.round(Math.sin(t * 27 + f.id) * 2.4), 1, 2);
    ctx.fillRect(9, -3 + fl * Math.round(Math.cos(t * 25 + f.id) * 2.4), 1, 2);
    ctx.drawImage(white ? sp.torsoW[f.look][f.skin] : sp.torso[f.look][f.skin], -7, -3);
    ctx.drawImage(white ? sp.headW[f.look][f.skin] : sp.head[f.look][f.skin], -7 + fl * Math.round(Math.sin(t * 18 + f.id) * 1.4), -13);
    ctx.restore();
    if (f.rest && f.deadT < 5 && !f.down) {
      for (let i = 0; i < 3; i++) {
        const a = t * 5 + i * 2.094;
        ctx.fillStyle = i === 0 ? "#ffffff" : "#ffe45c";
        ctx.fillRect(x + Math.round(Math.cos(a) * 8), y - 10 + Math.round(Math.sin(a) * 2.5), 2, 2);
      }
    }
  }

  render(rdt: number) {
    const ctx = this.ctx, W = this.W, H = this.H, sp = this.sp, cam = this.cam;
    const cl = Math.round(cam.x - W / 2 + (rand() - 0.5) * 2 * cam.shake + cam.kx);
    const ct = Math.round(cam.y - H / 2 + (rand() - 0.5) * 2 * cam.shake + cam.ky);
    const dcx = cl - this.cl, dcy = ct - this.ct;
    this.cl = cl; this.ct = ct;
    const mw = MW * TILE, mh = MH * TILE, t = this.t;
    ctx.fillStyle = "#17121c";
    ctx.fillRect(0, 0, W, H);
    // floor
    const sx = Math.max(0, cl), ex = Math.min(mw, cl + W), sy = Math.max(0, ct), ey = Math.min(mh, ct + H);
    if (ex > sx && ey > sy) ctx.drawImage(this.art.floor, sx, sy, ex - sx, ey - sy, sx - cl, sy - ct, ex - sx, ey - sy);
    const fo0 = this.focus();
    this.skyNow = fo0 ? this.skyOf(houseAtPx(fo0.x, fo0.y)) : null;
    if (this.skyNow) this.drawBelow(this.skyNow);
    // buildings stand up from the ground: seen from above the camera target, they lean away from it
    const live = this.live3;
    live.length = 0;
    if (this.shells.length && !this.skyNow && this.game === "bugs") {
      const vx = fo0 ? fo0.x - cl : W / 2, vy = fo0 ? fo0.y - ct : H / 2;
      for (const s of this.shells) {
        s.a = 0;
        if (s.x - cl > W + 90 || s.x + s.w - cl < -90 || s.y - ct > H + 90 || s.y + s.h - ct < -90) continue;
        s.base = s.house >= 0 ? this.roofA[s.house] : 1;
        if (s.base < 0.02) continue;
        project(s, vx, vy, cl, ct);
        // whoever the camera follows is never lost behind a building: it turns see-through instead
        s.ghost = !!fo0 && s.base > 0.9 && covers(s, vx, vy + 2) && !(vx > s.gx && vx < s.gx + s.w && vy > s.gy && vy < s.gy + s.h);
        s.a = s.ghost ? 0.4 : s.base;
        live.push(s);
      }
      live.sort((p, q) => Math.hypot(q.gx + q.w / 2 - vx, q.gy + q.h / 2 - vy) - Math.hypot(p.gx + p.w / 2 - vx, p.gy + p.h / 2 - vy));
    }

    // ground layer: dropped weapons, resting ragdolls, shadows, team rings, dash ghosts, pickups
    for (const d of this.drops) {
      const x = Math.round(d.x) - cl, y = Math.round(d.y) - ct;
      if (x < -30 || x > W + 30 || y < -30 || y > H + 30) continue;
      const img = sp.weapon[d.team][d.wid];
      ctx.fillStyle = "rgba(0,0,0,0.22)";
      ctx.fillRect(x - 5, y + 2, 10, 2);
      ctx.save();
      ctx.translate(x, y - Math.round(d.z));
      ctx.rotate(d.rot);
      ctx.drawImage(img, -(img.width >> 1), -(img.height >> 1));
      ctx.restore();
    }
    for (const f of this.fighters) {
      if (f.gone) continue;
      if (!f.alive) { if (f.z <= 2) this.drawCorpse(f); continue; }
      const x = Math.round(f.x) - cl, y = Math.round(f.y) - ct;
      if (x < -30 || x > W + 30 || y < -30 || y > H + 30) continue;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x - 5, y + 4, 10, 2);
      ctx.fillStyle = TEAMS[f.team].color;
      ctx.fillRect(x - 5, y + 3, 10, 1);
      ctx.fillRect(x - 5, y + 6, 10, 1);
      ctx.fillRect(x - 6, y + 4, 1, 2);
      ctx.fillRect(x + 5, y + 4, 1, 2);
    }
    for (const g of this.ghosts) {
      ctx.globalAlpha = g.life * 2.2;
      ctx.save();
      ctx.translate(Math.round(g.x) - cl, Math.round(g.y) - ct + 6);
      if (g.flip) ctx.scale(-1, 1);
      this.drawBody(g.look, g.skin, true, 0, 0);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    for (const p of this.pickups) {
      const x = Math.round(p.x) - cl, y = Math.round(p.y) - ct;
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(x - 3, y + 3, 6, 2);
      ctx.drawImage(sp.heart, x - 3, y - 5 + Math.round(Math.sin(t * 5 + p.x) * 1.5));
    }

    if (this.game === "bugs") {
      const day = this.atmo.cur.day ?? 0;
      if (day > 0.05) for (const s of this.live3) if (s.base > 0.5) shellShadow(ctx, s, day); // the low sun throws long shadows off the buildings
      this.bug.drawGround();
      this.castShadows();
    }

    // y-sorted pass: wall rows interleaved with props, barrels, operators and airborne ragdolls
    const list: Sortable[] = [];
    for (const f of this.fighters) if (!f.gone && (f.alive || f.z > 2)) list.push({ y: f.y, f });
    if (this.game === "bugs") this.bug.addSortables(list);
    for (const b of this.barrels) if (b.alive) list.push({ y: b.y, b });
    for (const p of PALMS) if (p.x > cl - 30 && p.x < cl + W + 30) list.push({ y: p.y + 7.5, palm: p });
    for (const fl of FLAGS) if (fl.x > cl - 20 && fl.x < cl + W + 20) list.push({ y: fl.y, flag: fl });
    if (this.art.ny) nySortables(list, cl, ct, W, H); // New York: its buildings, trees, lamps and wrecks
    const nfo = this.art.ny ? this.focus() : null;
    list.sort((a, b) => a.y - b.y);
    const use3d = this.shells.length > 0 && !this.skyNow && this.game === "bugs", holes = this.live3.filter((s) => s.base > 0.98), front: Sortable[] = [];
    let idx = 0;
    const r0 = Math.floor(ct / TILE) - 1, r1 = Math.floor((ct + H + RAISE) / TILE) + 3;
    for (let r = r0; r <= r1; r++) {
      if (this.art.ny) {
        // New York: only the interiors below the city have walls of this kind
        if (r >= CH && r < MH && ex > sx) ctx.drawImage(this.art.walls, sx, (r - CH) * TILE, ex - sx, TILE + RAISE, sx - cl, r * TILE - RAISE - ct, ex - sx, TILE + RAISE);
      } else if (this.skyNow) {
        // an upper floor above the city: only this floor's own walls (its neighbours in the strip are not really next door)
        const B = this.skyNow.H, wx0 = Math.max(sx, B.x * TILE), wx1 = Math.min(ex, (B.x + B.w) * TILE);
        if (r >= B.y && r < B.y + B.h && wx1 > wx0) ctx.drawImage(this.art.walls, wx0, r * TILE, wx1 - wx0, TILE + RAISE, wx0 - cl, r * TILE - RAISE - ct, wx1 - wx0, TILE + RAISE);
      } else if (r >= 0 && r < MH && ex > sx) {
        // (the flat picture of a building is left out where the building stands as a box)
        if (holes.length) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(0, 0, W, H);
          for (const s of holes) ctx.rect(s.x - cl, s.y - RAISE - ct, s.w, s.h + RAISE);
          ctx.clip("evenodd");
        }
        ctx.drawImage(this.art.walls, sx, r * TILE, ex - sx, TILE + RAISE, sx - cl, r * TILE - RAISE - ct, ex - sx, TILE + RAISE);
        if (holes.length) ctx.restore();
      }
      if (this.art.roofs && !this.skyNow && !use3d)
        for (let i = 0; i < HOUSES.length; i++) {
          const h = HOUSES[i], a = this.roofA[i];
          if (a < 0.02 || r < h.y || r >= h.y + h.h) continue;
          ctx.globalAlpha = a;
          ctx.drawImage(this.art.roofs, h.x * TILE, r * TILE, h.w * TILE, TILE, h.x * TILE - cl, r * TILE - RAISE - ct, h.w * TILE, TILE);
          ctx.globalAlpha = 1;
        }
      const limit = r === r1 ? 1e9 : (r + 1) * TILE;
      while (idx < list.length && list[idx].y < limit) {
        const it = list[idx++];
        if (it.nyo) { nyDraw(ctx, it.nyo, cl, ct, t, nfo ? nfo.x : -1e9, nfo ? nfo.y : -1e9); continue; }
        const o = it.f ?? it.bug ?? it.tur ?? it.pod;
        if (o && this.hidden(o.x, o.y)) continue; // under a roof
        if (use3d) {
          const ax = o ? o.x : it.palm ? it.palm.x : it.b ? it.b.x : NaN, ay = o ? o.y : it.palm ? it.palm.y + 4 : it.b ? it.b.y : NaN;
          if (ax === ax) {
            if (this.behind(ax, ay)) continue;              // behind a building
            if (this.nearShell(ax, ay)) front.push(it);     // next to one: drawn again later, over its wall
          }
        }
        if (it.bug || it.tur || it.pod || it.truck || it.box || it.door !== undefined || it.win) this.bug.drawSortable(it);
        else if (it.f) { if (it.f.alive) this.drawFighter(it.f); else this.drawCorpse(it.f); }
        else if (it.b) {
          const b = it.b, x = Math.round(b.x) - cl, y = Math.round(b.y) - ct;
          ctx.fillStyle = "rgba(0,0,0,0.28)";
          ctx.fillRect(x - 5, y + 2, 10, 3);
          const sh = b.hp <= 0 ? Math.round(Math.sin(t * 60)) : 0;
          ctx.drawImage(b.flash > 0 || (b.hp <= 0 && Math.sin(t * 50) > 0) ? sp.barrelWhite : sp.barrel, x - 5 + sh, y - 8);
        } else if (it.palm) {
          const fr = [0, 1, 2, 1][Math.floor(t * 1.6 + it.palm.x * 0.05) % 4];
          ctx.drawImage(this.art.props[it.palm.k][fr], it.palm.x - 22 - cl, it.palm.y - RAISE - 40 - ct);
        } else if (it.flag) {
          const fl = it.flag, x = Math.round(fl.x) - cl, y = Math.round(fl.y) - ct, tc = TEAMS[fl.team];
          ctx.fillStyle = "rgba(0,0,0,0.25)";
          ctx.fillRect(x - 2, y, 5, 2);
          ctx.fillStyle = "#0a0a0f";
          ctx.fillRect(x - 1, y - 27, 3, 28);
          ctx.fillStyle = "#c9cdd9";
          ctx.fillRect(x, y - 26, 1, 26);
          ctx.fillStyle = "#f5c542";
          ctx.fillRect(x - 1, y - 28, 3, 2);
          const dir = fl.team === 0 ? 1 : -1;
          for (let i = 0; i < 12; i++) {
            const wv = Math.round(Math.sin(t * 6 - i * 0.7 + fl.y) * (i / 11) * 1.8);
            const cx = x + (dir > 0 ? 1 + i : -1 - i);
            ctx.fillStyle = "#0a0a0f";
            ctx.fillRect(cx, y - 27 + wv, 1, 9);
            ctx.fillStyle = i % 4 === 3 ? tc.dark : tc.color;
            ctx.fillRect(cx, y - 26 + wv, 1, 7);
            if (i > 3 && i < 8) { ctx.fillStyle = "#0a0a0f"; ctx.fillRect(cx, y - 24 + wv, 1, 3); }
          }
        }
      }
    }

    if (this.live3.length) {
      const opt = {
        day: this.atmo.cur.day ?? 0, shut: (k: number) => this.bug.shut.has(k),
        storey: (hi: number, lvl: number) => { const fl = HOUSES[hi].floors; return fl && fl[lvl - 1] !== undefined ? this.bug.storey(fl[lvl - 1]) : null; },
      };
      for (const s of this.live3) drawShell(ctx, s, opt);
      // whoever (and whatever) stands in front of a wall is drawn again, over it
      for (const it of front) {
        if (it.bug || it.tur || it.pod) this.bug.drawSortable(it);
        else if (it.f) { if (it.f.alive) this.drawFighter(it.f); else this.drawCorpse(it.f); }
        else if (it.palm) ctx.drawImage(this.art.props[it.palm.k][[0, 1, 2, 1][Math.floor(t * 1.6 + it.palm.x * 0.05) % 4]], it.palm.x - 22 - cl, it.palm.y - RAISE - 40 - ct);
      }
    }
    // sniper lasers
    ctx.save();
    ctx.translate(0.5, 0.5);
    ctx.lineWidth = 1;
    for (const f of this.fighters) {
      if (!f.alive || f.weapon !== "sniper" || f.reloadT > 0) continue;
      const ch = f.ai ? f.ai.charge / SNIPE_CHARGE : f.isPlayer && this.phase === "live" ? 0.35 : 0;
      if (ch <= 0.02) continue;
      const d = rayEnd(f.x, f.y + 1, f.aim, 460);
      ctx.globalAlpha = f.ai ? 0.25 + 0.7 * ch : 0.3;
      ctx.strokeStyle = TEAMS[f.team].color;
      ctx.beginPath();
      ctx.moveTo(f.x - cl + Math.cos(f.aim) * 20, f.y + 1 - ct + Math.sin(f.aim) * 20);
      ctx.lineTo(f.x - cl + Math.cos(f.aim) * d, f.y + 1 - ct + Math.sin(f.aim) * d);
      ctx.stroke();
    }
    for (const tr of this.tracers) {
      ctx.globalAlpha = tr.life * 3;
      ctx.strokeStyle = tr.color;
      ctx.lineWidth = tr.life > 0.15 ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(tr.x0 - cl, tr.y0 - ct);
      ctx.lineTo(tr.x1 - cl, tr.y1 - ct);
      ctx.stroke();
    }
    // melee arcs
    for (const s of this.slashes) {
      const p = 1 - s.life / s.max;
      if (s.kind === 2) {
        // overhead smash: a vertical arc from above the head down onto the target
        if (p < 0.4) continue;
        const k = Math.min(1, (p - 0.4) / 0.14), up = -Math.PI / 2, d = angDiff(up, s.ang), sg = d < 0 ? -1 : 1;
        const x = s.f.x - cl, y = s.f.y - ct - 5, a0 = up - sg * 0.6, a1 = a0 + sg * (Math.abs(d) + 0.75) * k;
        ctx.globalAlpha = 1 - ((p - 0.4) / 0.6) ** 2;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 5;
        ctx.beginPath(); ctx.arc(x, y, s.r - 3, a0, a1, sg < 0); ctx.stroke();
        ctx.strokeStyle = TEAMS[s.f.team].bullet;
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(x, y, s.r - 9, a0, a1, sg < 0); ctx.stroke();
        continue;
      }
      // crescent trail: the head sweeps through the arc, the tail catches up as it fades
      const bat = isBat(s.wid), x = s.f.x - cl, y = s.f.y - ct - 2;
      let pq = p;
      if (s.kind === 0) { pq = (p * 1.12 - 0.4) / 0.6; if (pq <= 0) continue; pq = Math.min(1, pq); } // the trail only appears when the blow lands
      const sw = Math.min(1, pq * 2.6 + 0.15), head = 1 - (1 - sw) * (1 - sw), tail = Math.max(0, head - (s.kind === 3 ? 0.5 : 0.7) + pq * 0.55);
      const base = s.ang - (s.dir * s.arc) / 2, a0 = base + s.dir * s.arc * tail, a1 = base + s.dir * s.arc * head;
      ctx.globalAlpha = 0.92 * (1 - pq * pq);
      this.crescent(x, y, s.r + 2, a0, a1, bat ? 15 : 10, "#ffffff");
      this.crescent(x, y, s.r - 1, a0, a1, bat ? 9 : 6, bat ? (s.f.bloody > 0 ? "#ff6b7a" : "#ffd75e") : "#8af0ff");
      ctx.globalAlpha = 0.35 * (1 - pq * pq);
      this.crescent(x, y, s.r + 5, a0, a1, bat ? 20 : 14, bat ? "#ffd75e" : "#5ff0e0");
      if (!bat) { ctx.globalAlpha = 0.65 * (1 - pq); this.crescent(x, y, s.r - 9, a0, a1, 3, "#ffffff"); }
      if (head > 0.05 && head < 0.98 && this.parts.length < 500) this.puff(s.f.x + Math.cos(a1) * (s.r + 1), s.f.y - 2 + Math.sin(a1) * (s.r + 1) * 0.88, 1, bat ? ["#ffe45c", "#ffffff"] : ["#8af0ff", "#ffffff"], 20, { z: 4, max: 0.18, size: 1, grav: 0, drag: 5 });
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(Math.round(x + Math.cos(a1) * (s.r + 1)) - 1, Math.round(y + Math.sin(a1) * (s.r + 1) * 0.88) - 1, 3, 3);
    }
    for (const b of this.bursts) {
      // blood burst: a fan of jets from the wound - mostly forwards, a little back - each ending in a fat drop
      const k = b.life / b.max, x = b.x - cl, y = b.y - ct, hv = (i: number) => Math.abs(Math.sin(b.seed + i * 12.9898) * 43758.5453) % 1;
      ctx.globalAlpha = 1 - k * k * 0.8;
      for (let i = 0; i < 9; i++) {
        const back = i >= 7, a = b.ang + (back ? Math.PI : 0) + (hv(i) - 0.5) * (back ? 1.2 : 1.5);
        const L = b.r * (back ? 0.45 : 0.55 + hv(i + 20) * 0.75) * (0.35 + 0.65 * Math.sqrt(k)), L0 = L * Math.max(0, k * 1.5 - 0.5);
        const ca = Math.cos(a), sa = Math.sin(a) * 0.8;
        ctx.strokeStyle = i % 3 === 0 ? "#e2404a" : i % 3 === 1 ? "#b01c2a" : "#7a0e1a";
        ctx.lineWidth = Math.max(1, (i % 3 === 0 ? 3 : 2) * (1 - k));
        ctx.beginPath(); ctx.moveTo(x + ca * L0, y + sa * L0); ctx.lineTo(x + ca * L, y + sa * L); ctx.stroke();
        const d = k < 0.6 ? 2 : 1;
        ctx.fillStyle = "#c8202e";
        ctx.fillRect(Math.round(x + ca * L) - (d >> 1), Math.round(y + sa * L) - (d >> 1), d, d);
      }
      if (k < 0.5) { ctx.fillStyle = "#ff6a6a"; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); }
    }
    ctx.globalAlpha = 1;
    if (this.flashes.length) {
      // impact flashes: added onto the picture, so they burn through whatever is behind them
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (const h of this.flashes) {
        const k = h.life / h.max, x = h.x - cl, y = h.y - ct, r = h.r * (0.55 + 0.75 * k), n = h.kind === 1 ? 8 : h.kind === 2 ? 2 : 4;
        ctx.globalAlpha = 1 - k;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.moveTo(x - r * 0.45, y); ctx.lineTo(x, y - r * 0.45); ctx.lineTo(x + r * 0.45, y); ctx.lineTo(x, y + r * 0.45); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = h.kind === 2 ? "#8af0ff" : h.kind === 1 ? "#ffe45c" : "#ffd27a";
        ctx.lineWidth = h.kind === 1 ? 2 : 1;
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
          const a = h.ang + (i * PI2) / n, L = r * (h.kind === 2 ? 2.4 : i % 2 ? 1 : 1.8);
          ctx.moveTo(x + Math.cos(a) * r * 0.3, y + Math.sin(a) * r * 0.3);
          ctx.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L);
        }
        ctx.stroke();
      }
      ctx.restore();
    }
    for (const c of this.cuts) {
      const k = c.life / 0.16, x = c.x - cl, y = c.y - ct;
      ctx.globalAlpha = k;
      if (c.star) {
        // blunt impact: a burst of spikes
        const r0 = 2 + (1 - k) * 5, r1 = 8 + (1 - k) * 9;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < 7; i++) {
          const a = c.ang + i * 0.898, r = r1 * (i % 2 ? 0.65 : 1);
          ctx.moveTo(x + Math.cos(a) * r0, y + Math.sin(a) * r0);
          ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
        }
        ctx.stroke();
        ctx.fillStyle = "#ffe45c";
        ctx.fillRect(Math.round(x) - 2, Math.round(y) - 2, 4, 4);
        continue;
      }
      const len = 8 + (1 - k) * 6, dx = Math.cos(c.ang) * len, dy = Math.sin(c.ang) * len;
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x - dx, y - dy); ctx.lineTo(x + dx, y + dy); ctx.stroke();
      ctx.strokeStyle = "#ff6b7a";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x - dx * 0.6, y - dy * 0.6 + 1); ctx.lineTo(x + dx * 0.6, y + dy * 0.6 + 1); ctx.stroke();
    }
    for (const r of this.rings) {
      const p = r.life / 0.3;
      ctx.globalAlpha = 1 - p;
      ctx.strokeStyle = p < 0.4 ? "#ffffff" : "#ffb347";
      ctx.lineWidth = Math.max(1, (r.r > 20 ? 4 : 2) - p * 2);
      ctx.beginPath();
      ctx.arc(r.x - cl, r.y - ct, r.r * (0.2 + p * 0.9), 0, PI2);
      ctx.stroke();
    }
    ctx.restore();
    // additive light from muzzle flashes and explosions
    ctx.globalCompositeOperation = "lighter";
    for (const g of this.glows) {
      const k = g.life / g.max;
      ctx.fillStyle = `rgba(255,${(190 + 40 * k) | 0},110,${(0.13 * k).toFixed(3)})`;
      for (let q = 1; q <= 4; q++) { ctx.beginPath(); ctx.arc(g.x - cl, g.y - ct, (g.r * q) / 4, 0, PI2); ctx.fill(); }
    }
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;

    // bullets: hot tracers that light up the night
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    for (const b of this.bullets) {
      if (b.wid === "bazooka") continue;
      const bx = b.x - cl, by = b.y - ct;
      if (bx < -60 || bx > W + 60 || by < -60 || by > H + 60) continue;
      const L = Math.min(WEAPONS[b.wid].tail * 2.5 + 7, b.trav + 2); // long, fast streaks
      ctx.strokeStyle = TEAMS[b.team].bullet;
      ctx.globalAlpha = 0.45;
      ctx.lineWidth = b.wid === "sniper" ? 4 : 3;
      ctx.beginPath(); ctx.moveTo(bx - b.dx * L, by - b.dy * L); ctx.lineTo(bx, by); ctx.stroke();
      ctx.strokeStyle = "#fff8dc";
      ctx.globalAlpha = 1;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(bx - b.dx * L * 0.55, by - b.dy * L * 0.55); ctx.lineTo(bx, by); ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(Math.round(bx) - 1, Math.round(by) - 1, 2, 2); // the white-hot head of the round
    }
    ctx.restore();
    for (const b of this.bullets) {
      if (b.wid !== "bazooka") continue;
      const bx = b.x - cl, by = b.y - ct;
      if (bx < -40 || bx > W + 40 || by < -40 || by > H + 40) continue;
      ctx.save();
      ctx.translate(Math.round(bx), Math.round(by));
      ctx.rotate(Math.atan2(b.dy, b.dx));
      ctx.fillStyle = Math.sin(t * 70) > 0 ? "#ffe45c" : "#ff9a3c";
      ctx.fillRect(-11, -1, 5, 3);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(-8, 0, 3, 1);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(-6, -3, 12, 7);
      ctx.fillStyle = "#d9dee8";
      ctx.fillRect(-5, -2, 7, 5);
      ctx.fillStyle = "#9aa3b5";
      ctx.fillRect(-5, 1, 7, 2);
      ctx.fillStyle = TEAMS[b.team].color;
      ctx.fillRect(-2, -2, 2, 5);
      ctx.fillStyle = "#e0483e";
      ctx.fillRect(2, -2, 3, 5);
      ctx.fillStyle = "#ff8a80";
      ctx.fillRect(2, -2, 2, 1);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(-6, -4, 2, 1); ctx.fillRect(-6, 4, 2, 1);
      ctx.restore();
    }
    if (this.game === "bugs") this.bug.drawTop();
    // impact stars
    for (const s of this.sparks) {
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct, n = s.life > 0.06 ? 4 : 2;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(x - n, y, n * 2 + 1, 1);
      ctx.fillRect(x, y - n, 1, n * 2 + 1);
      ctx.fillRect(x - 1, y - 1, 3, 3);
    }
    // particles
    for (const p of this.parts) {
      if (p.shell) {
        // a case tumbling through the air: it glints as it turns
        const px = Math.round(p.x - cl), py = Math.round(p.y - p.z - ct), fl = ((p.life * 22) | 0) & 1;
        ctx.fillStyle = p.shell === 3 ? "#3a3f4a" : p.shell === 2 ? "#e0524a" : "#f1cf6a";
        if (p.shell === 3) ctx.fillRect(px - 1, py - 2, 3, 4);
        else ctx.fillRect(px - 1, py, fl ? 3 : 1, fl ? 1 : 3);
        if (p.shell !== 3 && fl) { ctx.fillStyle = "#ffffff"; ctx.fillRect(px, py, 1, 1); }
        continue;
      }
      const s = p.life / p.max > 0.65 ? Math.max(1, p.size - 1) : p.size;
      ctx.fillStyle = p.color;
      ctx.fillRect(Math.round(p.x - cl - s / 2), Math.round(p.y - p.z - ct - s / 2), s, s);
    }
    // drifting dust motes
    ctx.fillStyle = this.art.theme ? "rgba(205,208,222,0.4)" : "rgba(255,246,220,0.55)";
    const m = this.motes;
    for (let i = 0; i < m.length; i += 3) {
      m[i] += (this.art.theme ? 6 : 14) * m[i + 2] * rdt - dcx;
      m[i + 1] += (this.art.theme ? 8 : 5) * m[i + 2] * rdt - dcy;
      m[i] = ((m[i] % W) + W) % W;
      m[i + 1] = ((m[i + 1] % H) + H) % H;
      ctx.fillRect(m[i] | 0, m[i + 1] | 0, m[i + 2] > 1 ? 2 : 1, 1);
    }
    if (this.game === "bugs") this.renderAtmo();
    for (const tx of this.texts) {
      if (tx.life > 0.7 && Math.sin(t * 60) > 0) continue;
      drawText(ctx, tx.text, tx.x - cl, tx.y - ct, tx.color);
    }
    // speech bubbles
    for (const b of this.talk.bubbles) {
      const f = b.f;
      if (f.gone || f.x < cl - 20 || f.x > cl + W + 20 || f.y < ct - 20 || f.y > ct + H + 30) continue; // out of sight: the chat log still has it
      const w = Math.max(...b.lines.map((l) => l.length)) * 4 + 5, h = b.lines.length * 7 + 3;
      const fx = Math.round(f.x) - cl, bx = clamp(fx - (w >> 1), 2, W - w - 2), by = clamp(Math.round(f.y) - ct - 28 - h, 2, H - h - 2);
      ctx.globalAlpha = Math.min(1, b.life * 4);
      ctx.fillStyle = b.col;
      ctx.fillRect(bx - 1, by - 1, w + 2, h + 2);
      ctx.fillRect(clamp(fx - 1, bx + 1, bx + w - 3), by + h + 1, 2, 2);
      ctx.fillStyle = "#0c0a10";
      ctx.fillRect(bx, by, w, h);
      b.lines.forEach((l, i) => drawText(ctx, l, bx + (w >> 1) + 1, by + 2 + i * 7, "#ffffff", "#0c0a10"));
      ctx.globalAlpha = 1;
    }
    if (this.vig) ctx.drawImage(this.vig, 0, 0);
    if (this.fat) {
      // a finisher: the frame narrows for a moment
      const k = Math.max(0, Math.min(1, this.fat.t / 0.12, (1.15 - this.fat.t) / 0.25)), bh = Math.round(H * 0.11 * k);
      ctx.fillStyle = "#07050c";
      ctx.fillRect(0, 0, W, bh);
      ctx.fillRect(0, H - bh, W, bh);
    }
    if (this.climb) {
      const ct2 = this.climb.t, a = ct2 < 0.5 ? Math.pow(Math.max(0, (ct2 - 0.16) / 0.34), 2) : 1 - Math.min(1, (ct2 - 0.5) / 0.42);
      ctx.fillStyle = `rgba(5,3,12,${Math.max(0, Math.min(1, a)).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.trans) {
      // the ride to the next district: fade out as the pickup pulls away, title card, fade in on the new streets
      const tt = this.trans.t, a = tt < 2.1 ? clamp((tt - 1) / 0.9, 0, 1) : 1 - clamp((tt - 3.6) / 1.3, 0, 1);
      ctx.fillStyle = `rgba(5,3,12,${a.toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
      const k = clamp(Math.min((tt - 1.8) / 0.4, (4.5 - tt) / 0.6), 0, 1);
      if (k > 0) {
        ctx.save();
        ctx.globalAlpha = k;
        ctx.translate(Math.round(W / 2), Math.round(H * 0.42));
        const ni = this.trans.swapped ? this.ri : this.ri + 1;
        drawText(ctx, MAP_NAME[this.route[ni]] ?? "", 0, 14, "#9fd8ff", "#0c0a10");
        ctx.scale(3, 3);
        drawText(ctx, `MAP ${ni + 1}`, 0, -5, "#fff0a8", "#0c0a10");
        ctx.restore();
      }
    }
    if (this.floorTitle.t > 0) {
      const ft = this.floorTitle, k = Math.min(1, ft.t / 0.5, (2.2 - ft.t) / 0.25);
      ctx.save();
      ctx.globalAlpha = Math.max(0, k);
      ctx.translate(Math.round(W / 2), Math.round(H * 0.3 + (1 - Math.max(0, k)) * -6));
      ctx.scale(2, 2);
      drawText(ctx, ft.text, 0, 0, "#fff0a8", "#0c0a10");
      ctx.restore();
    }
    if (this.fade > 0) {
      ctx.fillStyle = `rgba(5,3,12,${Math.min(1, this.fade * 5).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.whiteT > 0) {
      ctx.fillStyle = `rgba(255,244,214,${Math.min(0.3, this.whiteT * 3.2).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
    }

    if (this.mode === "play") this.renderOverlay();
    // tiny CSS zoom punch on kills
    const z = Math.round(this.zoom * 200) / 200;
    if (z !== this.lastZoom) {
      this.lastZoom = z;
      this.canvas.style.transform = z > 0 ? `scale(${1 + z})` : "";
    }
  }

  /** inside a house whose roof is still on */
  hidden(x: number, y: number) {
    const h = houseAtPx(x, y);
    return h >= 0 && this.roofA[h] > 0.6;
  }

  /** city night: fog and rain, then darkness with every light cut out of it. Walls block your flashlight, and indoors the street is out of sight. */
  renderAtmo() {
    const A = this.atmo, ctx = this.ctx, cl = this.cl, ct = this.ct, t = this.t;
    A.weather(ctx, cl, ct, t);
    A.indoor = this.inK;
    A.cozy = this.cozy;
    A.clear = this.clearK * this.inK;
    A.begin();
    const vis = 1 - 0.28 * Math.min(1, A.cur.fog) - 0.1 * Math.min(1, A.cur.rain / 2);
    for (const g of this.glows) A.light(g.x - cl, g.y - ct, g.r * 2.4, Math.min(1, (g.life / g.max) * 1.3));
    for (const b of this.bullets) A.light(b.x - cl, b.y - ct, b.wid === "bazooka" ? 36 : 11, b.wid === "bazooka" ? 1 : 0.6);
    for (const p of this.pickups) A.light(p.x - cl, p.y - ct, 15, 0.6);
    for (const b of this.barrels) if (b.alive && b.hp <= 0) A.light(b.x - cl, b.y - ct, 30, 0.8);
    const alarm = this.bug.alarm();
    const lampK = (l: Lamp) => {
      let k = l.house === undefined ? 1 : 1 - this.roofA[l.house];
      if (l.fx === 1) k *= Math.sin(t * 31 + l.x) > 0.5 || Math.sin(t * 5.3 + l.y) > 0.55 ? 0.2 : 1; // dying bulb
      else if (l.fx === 2) k *= Math.sin(t * 9) > 0 ? 1 : 0.04;                                      // police red...
      else if (l.fx === 3) k *= Math.sin(t * 9) > 0 ? 0.04 : 1;                                      // ...and blue
      else if (l.fx === 4) k *= Math.sin(t * 3 + l.x) > 0 ? 1 : 0.12;                                // blinking amber
      return k;
    };
    for (const l of this.lamps) {
      const k = lampK(l);
      if (k < 0.02) continue;
      if (l.a > 0) A.light(l.x - cl, l.y - ct, l.r * (l.house !== undefined ? 1 + 0.7 * Math.max(this.cozy, 0.6 * this.clearK) : 1), (l.house !== undefined ? 1 + 0.5 * Math.max(this.cozy, 0.6 * this.clearK) : 1) * l.a * k * (l.pad ? 0.7 + 0.3 * alarm : l.fx ? 1 : 0.85 + 0.15 * Math.sin(t * 2 + l.x)));
      if (l.beam !== undefined) A.beam(l.x - cl, l.y - ct, l.beam, 120, 0.7 * k);
    }
    this.bug.lights(A);
    if (this.art.ny) nyLamps((x, y, r) => A.light(x - cl, y - ct, r * 2.6, 0.85)); // the street lamps of New York still burn
    // indoors: everything outside this building goes black
    const H = this.inHouse >= 0 ? HOUSES[this.inHouse] : null;
    if (H && this.inK > 0.02) A.shade(H.x * TILE - cl, H.y * TILE - RAISE - ct, (H.x + H.w) * TILE - cl, (H.y + H.h) * TILE - ct, (this.art.ny ? 1 : this.skyNow ? 0.12 : 0.97) * this.inK); // (New York: the next interior is only a wall away - nothing of it may show)
    // flashlights are clipped against walls and tall furniture: every corner hides something until you point your light at it
    let torchPoly: number[] | null = null;
    const mates: { poly: number[]; x: number; y: number; ang: number; len: number }[] = [];
    for (const f of this.fighters) {
      if (!f.alive || f.gone) continue;
      if (f.civ) { if (!f.hid) A.light(f.x - cl, f.y - ct - 4, 28, 0.75); continue; } // no torch: they depend on yours
      const x = f.x - cl, y = f.y - ct, me = f.isPlayer, poly = this.visPoly(f.x, f.y, (me ? 186 : 128) * vis, me ? 120 : 72, f.id);
      if (me) torchPoly = poly;
      else if (x > -150 && x < this.W + 150 && y > -150 && y < this.H + 150) mates.push({ poly, x, y: y - 2, ang: f.aim, len: 125 * vis }); // what a friend's torch sweeps is seen as well
      A.clip(poly, () => {
        A.light(x, y - 4, (me ? 70 : 46) * vis, 1);
        A.beam(x, y - 2, f.aim, (me ? 180 : 125) * vis, 1);
        // where the beam ends on a wall, the wall lights up and throws some of it back into the room
        const re = rayEnd(f.x, f.y, f.aim, (me ? 172 : 118) * vis);
        if (re < (me ? 168 : 114) * vis) A.light(x + Math.cos(f.aim) * (re + 5), y - 2 + Math.sin(f.aim) * (re + 5), me ? 36 : 24, 0.8);
      });
    }
    // line of sight: walls hide what is behind them, indoors the outside world is gone, and the mouse area stays in focus
    const me = this.focus();
    if (me && this.mode === "play" && me.alive) {
      const R = 250 * vis, poly = this.visPoly(me.x, me.y, R, 160, -1);
      const aimed = !this.useTouch, ax = aimed ? this.mx : me.x - cl + Math.cos(me.aim) * 60, ay = aimed ? this.my : me.y - ct + Math.sin(me.aim) * 60;
      const room = H ? [H.x * TILE - cl, H.y * TILE - RAISE - ct, (H.x + H.w) * TILE - cl, (H.y + H.h) * TILE - ct] : null;
      A.focus(poly, me.x - cl, me.y - ct - 3, ax, ay, this.inK, (105 + 35 * this.inK) * vis, true, mates, room, 0.92 * this.clearK * this.inK, this.skyNow ? 0.9 * this.inK : 0, shellPolys(this.live3), 0.8 * (1 - this.inK));
    }
    if (this.live3.length && this.inK < 0.5 && (A.cur.day ?? 0) < 0.7) {
      // torches on walls: point your light at a building and its front comes out of the dark
      const torches: { x: number; y: number; aim: number; r: number }[] = [];
      for (const f of this.fighters) if (f.alive && !f.gone && !f.civ) torches.push({ x: f.x, y: f.y, aim: f.aim, r: f.isPlayer ? 190 : 130 });
      litWalls(this.live3, torches, cl, ct, (q, a) => A.lit(q, a));
    }
    A.end(ctx);
    // the beam itself hangs in the air: dust, rain, fog and snow catch it
    const pl = this.player;
    if (torchPoly && pl && pl.alive && !pl.gone) A.shaft(ctx, torchPoly, pl.x - cl, pl.y - ct - 2, pl.aim, 180 * vis, 0.045 + 0.08 * Math.min(1, A.cur.fog) + 0.045 * Math.min(1, A.cur.rain / 2) + 0.015 * (A.cur.snow ?? 0));
    // wet ground mirrors every lamp: a long smear of light below it
    const wet = Math.max(Math.min(1, A.cur.rain / 1.4), (A.cur.snow ?? 0) * 0.4) * (1 - this.inK);
    if (wet > 0.12) {
      for (const l of this.lamps) if (l.house === undefined && l.r >= 36 && l.a >= 0.4) A.streak(ctx, l.x - cl, l.y - ct + 5, 12, 46, l.col, 0.32 * wet * lampK(l));
      if (this.art.ny) nyLamps((x, y) => A.streak(ctx, x - cl, y - ct + 8, 12, 46, "w", 0.3 * wet));
    }
    // muzzle flashes and explosions throw warm light onto everything around them
    for (const g of this.glows) A.tint(ctx, g.x - cl, g.y - ct, g.r * 1.9, "o", 0.55 * Math.min(1, g.life / g.max));
    if (this.art.ny) nyLamps((x, y, r) => A.tint(ctx, x - cl, y - ct, r * 1.5, "w", 0.28));
    // glows on top of the dark: neon, alarm lamps, police lights, eyes
    for (const l of this.lamps) {
      if (H && this.inK > 0.5 && l.house !== this.inHouse) continue; // can't see street lights from indoors
      const k = lampK(l);
      if (l.pad && alarm > 0) A.tint(ctx, l.x - cl, l.y - ct, l.r * 0.9, "r", 0.25 + 0.45 * alarm);
      else A.tint(ctx, l.x - cl, l.y - ct, l.r * 0.8, l.col, (l.fx === 2 || l.fx === 3 ? 0.75 : l.fx === 4 ? 0.85 : 0.2 + 0.06 * Math.sin(t * 2 + l.x)) * k);
    }
    for (const f of this.fighters) if (f.alive && !f.civ && !f.gone) A.tint(ctx, f.x - cl + Math.cos(f.aim) * 8, f.y - ct - 2 + Math.sin(f.aim) * 8, 9, "w", 0.5);
    this.bug.glowPass(A);
    if (this.skyNow) this.drawExterior(this.skyNow);
  }

  /** arrow at the screen edge towards something off-screen */
  pointer(wx: number, wy: number, c1: string, c2: string, label = "") {
    const ctx = this.ctx, W = this.W, H = this.H, fo = this.focus();
    if (fo) {
      // directions are measured in the city, whatever floor either end is on
      const a = this.gpos(wx, wy), b = this.gpos(fo.x, fo.y);
      wx = fo.x + a[0] - b[0]; wy = fo.y + a[1] - b[1];
    }
    const x = wx - this.cl, y = wy - this.ct;
    if (x > 4 && x < W - 4 && y > 4 && y < H - 4) return;
    const a = Math.atan2(y - H / 2, x - W / 2);
    const k = Math.min((W / 2 - 9) / Math.abs(Math.cos(a) || 1e-6), (H / 2 - 9) / Math.abs(Math.sin(a) || 1e-6));
    ctx.save();
    ctx.translate(Math.round(W / 2 + Math.cos(a) * k), Math.round(H / 2 + Math.sin(a) * k));
    ctx.rotate(a);
    ctx.fillStyle = "#16060a";
    ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -5); ctx.lineTo(-4, 5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = Math.sin(this.t * 8) > 0 ? c1 : c2;
    ctx.beginPath(); ctx.moveTo(4, 0); ctx.lineTo(-3, -3); ctx.lineTo(-3, 3); ctx.closePath(); ctx.fill();
    ctx.restore();
    if (label) drawText(ctx, label, clamp(Math.round(W / 2 + Math.cos(a) * (k - 17)), 14, W - 14), clamp(Math.round(H / 2 + Math.sin(a) * (k - 13)) - 3, 6, H - 10), c1);
  }

  renderOverlay() {
    const ctx = this.ctx, W = this.W, H = this.H, p = this.player;
    if (!p) return;
    // off-screen enemy pointers
    for (const f of this.fighters) if (f.alive && f.team !== p.team) this.pointer(f.x, f.y, "#ff4d5e", "#ff9aa5");
    if (this.game === "bugs") this.bug.pointers();
    // radar: a window of the city that follows you (upper floors are shown at their house)
    const rx = 5, ry = 5, rw = Math.min(MW, 60), rh = Math.min(CH, 38), fo = this.focus() ?? p;
    const fg = this.gpos(fo.x, fo.y);
    const ox = clamp(Math.floor(fg[0] / TILE) - (rw >> 1), 0, MW - rw), oy = clamp(Math.floor(fg[1] / TILE) - (rh >> 1), 0, CH - rh);
    ctx.fillStyle = "#0a0a0f";
    ctx.fillRect(rx - 2, ry - 2, rw + 4, rh + 4);
    ctx.fillStyle = "#a97a1c";
    ctx.fillRect(rx - 1, ry - 1, rw + 2, rh + 2);
    ctx.fillStyle = "#17121c";
    ctx.fillRect(rx, ry, rw, rh);
    ctx.drawImage(this.art.mini, ox, oy, rw, rh, rx, ry, rw, rh);
    ctx.save();
    ctx.beginPath();
    ctx.rect(rx, ry, rw, rh);
    ctx.clip();
    ctx.translate(rx - ox, ry - oy);
    for (const f of this.fighters) {
      if (!f.alive || f.hid) continue;
      const q = this.gpos(f.x, f.y);
      ctx.fillStyle = f.isPlayer ? (Math.sin(this.t * 10) > 0 ? "#ffffff" : "#7dff9a") : f.civ ? "#ff9df0" : TEAMS[f.team].color;
      ctx.fillRect(Math.floor(q[0] / TILE) - 1, Math.floor(q[1] / TILE) - 1, 2, 2);
    }
    if (this.game === "bugs") {
      this.bug.drawRadar();
      // the pickup is always on the radar - pinned to the edge when it is out of range
      const vx = clamp(Math.floor(TRUCK.x / TILE), ox + 3, ox + rw - 4), vy = clamp(Math.floor(TRUCK.y / TILE), oy + 2, oy + rh - 3);
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(vx - 3, vy - 2, 7, 5);
      ctx.fillStyle = Math.sin(this.t * 6) > 0 ? "#5ff0e0" : "#ffffff"; ctx.fillRect(vx - 2, vy - 1, 5, 2);
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(vx - 1, vy + 1, 1, 1); ctx.fillRect(vx + 1, vy + 1, 1, 1);
    }
    ctx.restore();
    if (this.game === "bugs") this.bug.towerHud();
    if (this.skipT > 0.12) {
      // holding SPACE: the bar fills, then the search is skipped
      const bw = 90, bx = (W - bw) >> 1, by = H - 62;
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(bx - 2, by - 2, bw + 4, 9);
      ctx.fillStyle = "#3b3848"; ctx.fillRect(bx, by, bw, 5);
      ctx.fillStyle = "#f5c542"; ctx.fillRect(bx, by, Math.round(bw * Math.min(1, this.skipT)), 5);
      drawText(ctx, "TAHAN SPASI: LEWATI MISI", W / 2, by - 10, "#fff0a8");
    }
    // hurt / low hp vignette
    let a = Math.max(0, this.hurtT) * 1.1;
    if (p.alive && p.hp < 35) a = Math.max(a, 0.16 + 0.1 * Math.sin(this.t * 7));
    if (a > 0.01) {
      ctx.fillStyle = `rgba(255,40,70,${Math.min(0.5, a).toFixed(3)})`;
      ctx.fillRect(0, 0, W, 5); ctx.fillRect(0, H - 5, W, 5); ctx.fillRect(0, 5, 5, H - 10); ctx.fillRect(W - 5, 5, 5, H - 10);
      ctx.fillStyle = `rgba(255,40,70,${Math.min(0.25, a * 0.5).toFixed(3)})`;
      ctx.fillRect(5, 5, W - 10, 4); ctx.fillRect(5, H - 9, W - 10, 4); ctx.fillRect(5, 9, 4, H - 18); ctx.fillRect(W - 9, 9, 4, H - 18);
    }
    // crosshair
    if (!p.alive || this.paused || this.phase === "over") return;
    let cx = Math.round(this.mx), cy = Math.round(this.my);
    if (this.useTouch) {
      if (!this.tAim.active) return;
      cx = Math.round(p.x - this.cl + Math.cos(p.aim) * 46);
      cy = Math.round(p.y - this.ct + Math.sin(p.aim) * 46);
    }
    const w = WEAPONS[p.weapon];
    const gap = 3 + Math.round(w.spread * 14 + p.recoil * 4);
    const rect = (x: number, y: number, ww: number, hh: number) => {
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 1, y - 1, ww + 2, hh + 2);
    };
    const kill = this.killMark > 0, hit = this.hitMark > 0;
    rect(cx - gap - 3, cy, 3, 1); rect(cx + gap + 1, cy, 3, 1); rect(cx, cy - gap - 3, 1, 3); rect(cx, cy + gap + 1, 1, 3);
    ctx.fillStyle = kill ? "#ff4d5e" : p.reloadT > 0 ? "#9a9aa8" : "#ffffff";
    ctx.fillRect(cx - gap - 3, cy, 3, 1); ctx.fillRect(cx + gap + 1, cy, 3, 1); ctx.fillRect(cx, cy - gap - 3, 1, 3); ctx.fillRect(cx, cy + gap + 1, 1, 3);
    ctx.fillRect(cx, cy, 1, 1);
    if (hit || kill) {
      ctx.fillStyle = kill ? "#ff4d5e" : "#fff0a8";
      const n = kill ? 5 : 3;
      for (let i = 2; i < 2 + n; i++) {
        ctx.fillRect(cx - i, cy - i, 1, 1); ctx.fillRect(cx + i, cy - i, 1, 1);
        ctx.fillRect(cx - i, cy + i, 1, 1); ctx.fillRect(cx + i, cy + i, 1, 1);
      }
    }
  }
}

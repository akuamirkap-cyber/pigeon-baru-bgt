/**
 * Free conversation with the squad. The player types anything; we work out what they mean (an intent) and how they feel (a mood),
 * pick the friend who would answer best, and let the situation (health, zombies, weather, place) colour the reply.
 * Persona index: 0 JAKA (joker), 1 SARI (caring), 2 BIMO (veteran), 3 NADIA (smart & scared), 4 BARA (hot-headed).
 */
export interface ConvCtx {
  P: string; hp: number; near: number; place: "street" | "house" | "shop" | "upstairs"; sky: "rain" | "fog" | "clear";
  morale: number; items: number; downs: number; dir: string; alive: boolean[];
}
export interface Reply { skin: number; text: string; mood: "joy" | "sad" | "mad" | "fear" | "calm"; delay: number }

const RULES: [string, RegExp][] = [
  ["who", /siapa kamu|kamu siapa|namamu|nama kamu|tentang kamu|ceritain|ceritakan/],
  ["joke", /lelucon|hibur|garing|ceritain yang lucu|bercanda dong|lawak/],
  ["sad", /sedih|nangis|menangis|putus asa|nyerah|menyerah|kehilangan|kangen|rindu|sendirian|kesepian|gak kuat|ga kuat|nggak kuat|tidak kuat|nggak sanggup|ga sanggup|tidak sanggup|mau pulang|stres|stress|depresi|hancur|nggak tahan|ga tahan|capek hidup|trauma|bersalah|ga ada harapan|nggak ada harapan/],
  ["scared", /takut|ngeri|merinding|panik|khawatir|cemas|gemetar|deg.?degan|serem|horor|gelap banget|ga berani|nggak berani/],
  ["hurt", /luka|sakit|berdarah|darah|obat|medis|sekarat|pusing|ketembak|digigit/],
  ["tired", /capek|lelah|ngantuk|lemas|letih|pegel|istirahat/],
  ["angry", /marah|kesel|kesal|bete|sebel|benci|emosi|jengkel|sialan|anjir|bangsat|ngeselin/],
  ["sorry", /maaf|sorry|salahku|salah aku|ceroboh/],
  ["thanks", /makasih|terima kasih|thanks|thx|tengkyu|trims/],
  ["insult", /bodoh|goblok|payah|lemah|tolol|dungu|bego|cupu|beban|nggak berguna|ga berguna/],
  ["help", /tolong|bantu|help|bantuin|selamatkan|dikepung|kepung|bahaya/],
  ["hungry", /lapar|makan|haus|minum|bakso|cemilan|kopi|laper/],
  ["happy", /senang|seneng|bahagia|asik|asyik|seru|mantap|keren|hore|yeay|lega|puas|menang|berhasil|yes!/],
  ["laugh", /haha|hehe|wkwk|lol|lucu|ngakak|kocak|xixi/],
  ["love", /sayang|cinta|suka kamu|cantik|ganteng|manis|imut|lucu banget kamu/],
  ["compliment", /hebat|jago|pintar|pinter|kuat|terbaik|bagus|andalan|pahlawan/],
  ["where", /dimana|di mana|kemana|ke mana|arah|barang|misi|tujuan|rumah bertanda|cari apa|harus ngapain|ngapain|selanjutnya/],
  ["plan", /rencana|strategi|taktik|gimana caranya|sebaiknya|enaknya|saran|ide|bagusnya/],
  ["weapon", /senjata|peluru|tembak|pentungan|karambit|bazooka|shotgun|sniper|pistol|reload|amunisi/],
  ["zombie", /zombie|mayat|anjing|monster|bos|mutan|brutal|gerombolan/],
  ["weather", /hujan|petir|kabut|dingin|basah|cuaca|badai/],
  ["status", /apa kabar|kabar|gimana kondisi|kondisi|lagi apa|sehat|baik.?baik saja|kalian oke|kalian baik/],
  ["bye", /dadah|bye|sampai jumpa|pamit|aku pergi dulu/],
  ["greet", /\b(halo|hai|hei|hey|hallo|pagi|siang|malam|woi|oi|p|assalamualaikum|permisi)\b/],
];

/** who answers first for each intent (most fitting friend first) */
const PREF: Record<string, number[]> = {
  sad: [1, 2, 0, 3, 4], scared: [2, 1, 4, 0, 3], hurt: [1, 2, 3, 0, 4], tired: [1, 0, 2, 3, 4], angry: [4, 2, 0, 1, 3], sorry: [1, 2, 0, 3, 4],
  thanks: [1, 0, 3, 2, 4], insult: [4, 0, 2, 1, 3], help: [2, 4, 1, 0, 3], hungry: [0, 1, 4, 2, 3], happy: [0, 4, 1, 3, 2], laugh: [0, 4, 1, 3, 2],
  love: [0, 3, 1, 4, 2], compliment: [0, 3, 1, 4, 2], where: [3, 2, 1, 0, 4], plan: [2, 3, 1, 4, 0], weapon: [2, 4, 0, 3, 1], zombie: [3, 2, 4, 0, 1],
  weather: [3, 1, 0, 2, 4], status: [1, 0, 2, 3, 4], bye: [0, 1, 2, 3, 4], greet: [0, 1, 4, 3, 2], who: [0, 3, 1, 2, 4], joke: [0, 4, 1, 3, 2], other: [0, 1, 2, 3, 4],
};
const EMO: Record<string, Reply["mood"]> = { sad: "sad", scared: "fear", hurt: "sad", tired: "calm", angry: "mad", insult: "mad", happy: "joy", laugh: "joy", love: "joy", compliment: "joy", thanks: "joy", joke: "joy", greet: "joy", sorry: "calm" };

/** [JAKA, SARI, BIMO, NADIA, BARA] x variants */
const R: Record<string, string[][]> = {
  greet: [["Yo {P}! Kota mati, tapi semangat jangan ikut mati.", "Halo juga! Lagi cari barang, bukan cari jodoh ya."], ["Halo, {P}. Kamu baik-baik saja? Bilang kalau butuh apa-apa.", "Hai {P}! Senang lihat kamu masih tegak."], ["Halo. Mata tetap terbuka.", "Hm. Siap, {P}."], ["H-halo, {P}... aku lagi pantau sekitar. Ssst.", "Hai... pelan-pelan ya ngomongnya, mereka bisa dengar."], ["Apa? Ada zombie? Oh cuma nyapa. Halo.", "Halo. Cepat, aku nggak sabaran."]],
  sad: [["{P}, sini duduk dulu, nggak usah sok kuat. Aku di sebelahmu, oke?", "Kamu boleh sedih. Tapi jangan sendirian. Aku temani, walau lawakanku garing."], ["Peluk dulu, {P}. Kamu nggak harus kuat setiap saat. Aku di sini.", "Aku dengar kamu. Capek itu wajar. Kita jalan pelan-pelan, bareng aku."], ["Berduka itu tanda kamu masih manusia, {P}. Tarik napas. Satu langkah, lalu satu lagi.", "Aku pernah di posisimu. Yang menolong: orang di sampingku. Aku di sampingmu."], ["{P}... aku juga takut dan sedih. Tapi kalau bareng kamu, rasanya nggak seberat itu.", "Kamu nggak sendirian. Aku di sini, walau gemetar."], ["Heh, {P}. Aku nggak jago menghibur. Tapi siapa pun yang bikin kamu begini, kuhajar. Dan aku nggak ke mana-mana.", "Sedih boleh. Menyerah nggak. Aku jagain kamu."]],
  scared: [["Takut itu normal, {P}. Aku juga, cuma pandai menyembunyikannya pakai lawakan.", "Pegang bahuku kalau perlu. Kita hadapi bareng-bareng."], ["Tarik napas dalam-dalam, {P}. Hitung sampai empat. Aku di dekatmu.", "Takut artinya kamu peduli pada hidupmu. Ayo kita jaga bersama."], ["Takut itu alat. Pakai untuk waspada, bukan untuk lari. Aku di belakangmu.", "Dengar aku: pola mereka bisa dibaca. Tenang, lalu bidik."], ["A-aku juga takut! Tapi kita jadi lebih berani kalau saling jaga, kan?", "Kita bareng, {P}. Dan tadi aku sudah hitung rute kaburnya."], ["Takut? Pakai jadi marah! Marah itu bahan bakar!", "Ada aku di sini. Mereka harus lewati aku dulu."]],
  hurt: [["Wah, {P}, darahmu! Jangan banyak gaya dulu, cari tempat aman.", "Obat itu penting. Nanti kucari di saku zombie, pasti ada."], ["{P}, sini dekat aku, biar kubalut. Jangan banyak gerak ya.", "Lukamu harus ditekan dulu. Tahan, aku datang."], ["Tekan lukanya. Mundur ke sudut aman. Aku tutup depan.", "Luka kecil jangan diremehkan. Bersihkan dulu."], ["D-darahmu... cari lemari obat di rumah bertanda, kemungkinan besar ada.", "Tolong hati-hati {P}, aku nggak sanggup lihat kamu terluka."], ["Masih bisa berdiri? Bagus. Mundur, biar aku yang pukul.", "Jangan mati dulu, aku belum menang taruhan."]],
  tired: [["Capek? Sama! Kakiku sudah minta cuti dari tadi.", "Istirahat lima detik. Hitung ya. Satu... eh sudah."], ["Istirahat sebentar saja, {P}. Aku jagain. Minum kalau ada.", "Kamu sudah berjuang keras. Tarik napas dulu."], ["Istirahat di tempat tertutup. Jangan tengah jalan.", "Tidur setengah mata. Itu trik tentara."], ["A-aku juga lelah. Cari sudut aman yuk.", "Kalau capek, jangan paksakan. Lambat tapi selamat."], ["Capek? Lemah. ...Bercanda. Istirahat, nanti kuhajar semuanya.", "Duduk sana. Biar aku jaga."]],
  angry: [["Kesel? Lampiaskan ke zombie, mereka nggak bakal protes.", "Santai... atau hajar dulu, baru santai. Pilihan ada di kamu."], ["Wajar kamu marah, {P}. Keluarkan dulu perasaannya, aku dengar.", "Tarik napas, {P}. Jangan sampai amarah memilih langkahmu."], ["Amarah boleh. Kendalikan. Fokus ke target.", "Salurkan ke bidikan, bukan ke teman."], ["I-iya, aku ngerti kamu kesal... tapi jangan berisik, mereka dengar.", "Aku juga kesal, sebenarnya. Cuma lebih sering takut."], ["NAH! Akhirnya ada yang sepikiran! Ayo hajar!", "Marah itu bagus. Marah itu bahan bakar! Ayo!"]],
  sorry: [["Santai, {P}. Kita semua salah tiap hari. Yang penting masih hidup.", "Udah, udah. Anggap saja hiburan buat zombie."], ["Nggak apa-apa, {P}. Aku nggak marah. Kita belajar, ya.", "Terima kasih sudah jujur. Kita lanjut bareng."], ["Terima. Ambil pelajaran, lanjut.", "Tidak ada yang sempurna. Fokus lagi."], ["E-eh, nggak apa-apa kok... aku juga sering salah.", "Maaf diterima. Tapi lain kali pelan-pelan ya."], ["Cih. Udah. Lupakan. ...Jangan diulang.", "Aku nggak dendam. Cuma ingat. Bercanda."]],
  thanks: [["Sama-sama, bos! Bayarannya bakso dua mangkok.", "Santai! Teman ya buat itu."], ["Sama-sama, {P}. Itu gunanya kita saling menjaga.", "Aku senang bisa membantu."], ["Tidak masalah.", "Itu tugas. Kamu juga sudah melakukannya."], ["S-sama-sama... aku senang berguna.", "Tidak apa-apa, {P}. Kita tim."], ["Hmph. Jangan sering-sering bilang gitu, nanti aku geer.", "Iya iya. Sama-sama."]],
  insult: [["Wah, kejam! Tapi aku maafkan. Sedang stres ya?", "Aduh... kata-katamu lebih nyakitin dari gigitan zombie."], ["{P}, aku tahu kamu sedang tertekan. Aku nggak marah, tapi aku sedih mendengarnya.", "Aku akan tetap di sini. Meski kamu marah padaku."], ["Boleh marah. Jangan ke tim sendiri. Itu kesalahan fatal.", "Emosimu kuterima. Tapi fokus."], ["A-aku... kalau salah, bilang baik-baik ya... aku sakit hati.", "Kamu lagi tertekan ya... aku paham, tapi tolong jangan begitu."], ["HEH! Bilang sekali lagi, kupukul pakai bat!... tapi iya, kita semua stres.", "Ngomong begitu ke aku? Berani juga. Fokus dulu, urusan kita nanti."]],
  help: [["Siap! Tunjuk lawannya! Aku maju!", "Dikepung? Bagus, jadi nggak perlu cari-cari!"], ["Aku datang, {P}! Bertahan!", "Tenang, aku di dekatmu. Mundur ke arahku!"], ["Mundur ke belakangku. Aku tutup. Tembak yang dekat.", "Posisi bertahan. Pakai dinding sebagai pelindung."], ["Aku bantu! Mundur ke pintu, cuma satu jalur masuk di sana!", "Tolong... aku datang! A-aku cuma bawa pistol, tapi aku datang!"], ["MINGGIR! Biar aku yang hajar!", "Tahan di sana! Aku sedang ke sana!"]],
  hungry: [["Lapar? Sama! Aku sudah ngebayangin bakso dari tadi. Nanti kutraktir!", "Mie instan zombie? Skip. Tunggu misi selesai."], ["Cari makan di rumah-rumah, ya. Aku juga lapar. Nanti kubagi.", "Jaga tenaga, {P}. Minum air kalau ada."], ["Perut kosong itu musuh. Cari ransum di rak mart.", "Makan setelah aman. Itu aturan."], ["A-ada minimarket di kota ini. Mungkin masih ada makanan kaleng...", "Aku punya biskuit satu... nanti kubagi."], ["Makan nanti. Hajar dulu. ...tapi aku juga lapar.", "Tunggu, kita ambil dari mart. Bawa pentungan."]],
  happy: [["Nah gitu dong! Semangat kamu menular! Ayo kita pesta zombie!", "Seneng deh lihat kamu begini. Hidup itu seru kalau ada teman!"], ["Aku senang kamu senang, {P}. Itu menghangatkan hati.", "Bagus. Simpan perasaan itu, kita butuh."], ["Bagus. Semangat itu aset. Pertahankan.", "Hm. Senang dengarnya."], ["Syukurlah... aku jadi tenang dengarnya.", "Aku juga senang! ...pelan-pelan senangnya, ya."], ["Hahaha! Ayo lampiaskan semuanya!", "Bagus! Ayo, siapa dulu yang kena?"]],
  laugh: [["WKWKWK! Aku catat. Tertawa itu obat paling murah di kiamat.", "Hehe, tuh kan. Aku selalu lucu. Ngaku saja."], ["Hehe, senang dengar tawamu, {P}.", "Tawamu bikin suasananya lebih ringan."], ["Hm. Lucu. Jangan terlalu keras.", "Tawa itu bagus. Tapi pelan-pelan."], ["Hihi... eh, pelan-pelan, nanti mereka dengar...", "Aku ikut ketawa. Sedikit."], ["Haha! Oke, itu lumayan.", "Ketawa terus. Zombie bisa tunggu."]],
  love: [["Aduh {P}, aku salah tingkah. Fokus, fokus, ini kiamat zombie!", "Cieee. Kalau selamat, aku traktir kamu bakso. Anggap kencan."], ["Aduh... {P}, jangan membuatku malu. Tapi terima kasih ya.", "Aku juga menyayangi kalian semua. Kamu keluarga kami."], ["Hm. Kita teman. Dan itu cukup berharga.", "Terima kasih. Sekarang fokus."], ["E-eh?! A-apa?! ... a-aku... terima kasih, {P}.", "J-jangan bilang begitu tiba-tiba... jantungku!"], ["Hah?! A-apaan sih! Fokus woi!", "...Jangan bahas itu di depan zombie."]],
  compliment: [["Ya iyalah! Tapi kamu juga top, {P}.", "Catat tanggalnya: hari ini {P} muji aku."], ["Terima kasih, {P}. Kamu juga hebat. Kita ini tim yang baik.", "Kamu membuatku percaya diri. Terima kasih."], ["Tidak perlu memuji. Tapi... terima kasih.", "Kamu juga bukan pemula, {P}."], ["Eh... makasih, {P}. A-aku belum yakin, tapi makasih.", "Aku cuma beruntung kok..."], ["Pastilah. Aku yang terbaik. ...Kamu juga lumayan, {P}.", "Hmph. Kamu juga nggak buruk."]],
  where: [["Cari barang di rumah bertanda, {P}. Kalau bingung, ikuti Nadia, dia punya peta.", "Tujuan kita: baterai, bensin, suar. Hobi: cari ribut."], ["Cari tanda di rumah-rumah itu, {P}. Dan jangan terpisah, ya.", "Kita cari tiga barang dulu. Jangan lupa lemari obat kalau lewat."], ["Rumah bertanda dulu. Bersihkan dari pintu. Satu-satu, tutup sudut.", "Misi: tiga barang, balik ke zona evac. Jangan improvisasi."], ["Menurut peta, rumah bertanda ada di arah {D}. Kita ikuti dinding, hindari lapangan.", "Aku hitung: {D} lebih aman. Tapi hati-hati di persimpangan."], ["Ke arah yang ada zombienya! Itu pasti tempatnya.", "Cari rumah bertanda lalu bantai semua. Simpel."]],
  plan: [["Rencana: jangan mati. Rencana cadangan: lari.", "Aku sih ikut kamu. Kamu pemimpinnya hari ini."], ["Kita jangan berpencar, {P}. Aku jaga yang luka, kamu atur ritmenya.", "Bertahap saja. Aman dulu, cepat belakangan."], ["Masuk dari pintu, bersihkan ruangan satu per satu. Di luar, pakai dinding. Jangan lari lurus dari anjing.", "Pentungan di dalam rumah, tembakan di luar. Sederhana."], ["Hindari lapangan terbuka, pakai senter dari arah dinding. Anjing itu cepat, jadi kita harus berdua.", "Aku hitung: kalau mereka mengejar, naik tangga. Cuma satu pintu masuk di sana."], ["Serbu! Itu rencananya!", "Yang gede tanganku. Yang kecil tanganmu. Beres."]],
  weapon: [["Shotgun jarak dekat, pistol jarak jauh, pentungan kalau hemat. Dan lelucon kalau habis peluru.", "Bazooka? Aku saranin nggak di dalam rumah. Atap kita sendiri nanti jatuh."], ["Pentungan buat dalam rumah, ya. Tembakan memanggil mereka.", "Hati-hati dengan bazooka, {P}. Sekutu juga bisa kena."], ["Sniper untuk yang besar, pentungan di dalam rumah, shotgun di lorong. Pilih alat sesuai tempat.", "Isi ulang di tempat terlindung, bukan di tengah jalan."], ["Aku baca, tembakan membangunkan zombie yang tidur di rumah. Jadi pakai senjata sunyi di dalam.", "Karambit itu senyap. Tapi dekat. Hati-hati."], ["Bazooka! Selalu bazooka!", "Pentungan itu seni. Kamu harus coba lagi."]],
  zombie: [["Zombie itu kayak mantan: lambat tapi nempel terus.", "Anjing zombie itu yang paling nyebelin. Lari nggak lurus ya!"], ["Mereka dulu manusia juga, {P}. Tapi sekarang kita harus selamat dulu.", "Hati-hati ya. Kita jaga satu sama lain."], ["Anjing: cepat, pelan-pelan tembak. Brutal: serang dari samping. Mutan: pakai rudal. Hafalkan.", "Kepala itu titik lemah. Bidik di situ."], ["Mereka tertarik suara. Dan aku benci bagian itu, soalnya aku sering menjerit.", "Anjingnya... aku nggak mau lihat. Tolong jangan biarkan dia dekat."], ["Biar datang! Semuanya!", "Yang gede itu buat aku. Jangan rebut."]],
  weather: [["Hujan itu enak buat tidur. Sayang kita lagi nggak tidur.", "Petir? Santai. Kalau sampai kesamber, ya sudah. Bercanda."], ["Pakai jaket kalau ada, ya. Jangan sampai masuk angin.", "Hujan itu menutup suara langkah kita, tapi juga tembakan mereka."], ["Hujan menurunkan jarak pandang. Dekat-dekat, jangan terpencar.", "Dingin itu bikin refleks lambat. Gerak terus."], ["P-petir... aku benci petir. Tapi suaranya menutupi langkah kita, jadi... bagus?", "Dingin banget... tanganku gemetar."], ["Hujan? Bagus. Darahnya terbilas.", "Biar basah. Aku nggak peduli."]],
  status: [["Aku? Baik! Kecuali kaki, perut, dan mental. Selain itu prima!", "Masih hidup, masih ganteng. Kabar baik kan?"], ["Aku baik, {P}. Yang aku khawatirkan itu kamu. Gimana perasaanmu?", "Kami baik-baik saja. Tapi kamu yang paling kami jaga."], ["Siap. Sehat. Amunisi cukup.", "Aman. Terus waspada."], ["A-aku baik-baik saja... hampir. Jantung agak cepat.", "Aku... bertahan. Karena ada kalian."], ["Bagus. Siap hajar.", "Aku baik. Kamu?"]],
  bye: [["Mau ke mana? Jangan jauh-jauh, nanti dimakan!", "Jangan lama-lama, ya. Aku kangen lawakanku sendiri."], ["Hati-hati, {P}. Kembali dengan selamat.", "Jangan terlalu jauh dari kami, ya."], ["Jangan pergi sendirian. Itu aturan nomor satu.", "Kembali ke formasi dalam semenit."], ["J-jangan jauh-jauh, {P}... aku takut.", "Hati-hati! Aku tunggu."], ["Pergi? Baik. Jangan mati duluan.", "Hmph. Sana."]],
  who: [["Aku Jaka! Pelawak kota ini. Spesialisasi: bikin zombie ketawa sebelum mati.", "Aku Jaka. Aku bercanda supaya nggak nangis. Rahasia ya."], ["Aku Sari. Dulu perawat. Sekarang tukang balut dan teman kalian.", "Sari. Aku suka menjaga orang. Itu hobi sekaligus beban."], ["Bimo. Mantan tentara. Sedikit omong, banyak peluru.", "Aku sudah melihat banyak. Dan aku ingin kalian selamat."], ["Aku Nadia. Aku pintar, tapi penakut. Kombinasi yang menyebalkan.", "Nadia. Aku suka peta dan angka. Aku benci petir dan anjing."], ["BARA. Cukup. Jangan tanya-tanya.", "Aku Bara. Tinju, bat, dan mood jelek. Itu aku."]],
  joke: [["Kenapa zombie nggak pernah kesepian? Karena selalu ada yang 'menggigit' persahabatannya. ...Jangan dilempar bat dulu.", "Apa bedanya zombie dan mantan? Zombie masih mau ngejar."], ["Aku bukan pelawak, tapi: kenapa zombie nggak suka sayur? Karena mereka maunya yang berdarah... eh itu nggak lucu, ya.", "Hehe, aku payah melawak. Tapi senang kamu minta."], ["Aku nggak punya lelucon. Aku punya satu: peluru habis.", "Lucu itu tugas Jaka."], ["A-aku tahu satu: kenapa petir selalu di belakang? Karena dia malu. ...maaf, garing.", "Aku coba: kenapa anjing zombie nggak bisa jadi detektif? ...karena mereka cuma mengendus."], ["Lelucon? Itu jab kiri.", "Aku lucu kalau lagi memukul."]],
  other: [["Hmm, aku nggak sepenuhnya paham, tapi aku dengar kamu, {P}. Lanjut, ceritain lagi.", "Haha, bisa jadi! Terus gimana menurutmu?"], ["Aku dengar kamu, {P}. Ceritakan lebih banyak kalau mau.", "Hm, begitu ya. Kamu sendiri gimana?"], ["Dicatat. Lanjut.", "Hm. Jelaskan lebih detail kalau penting."], ["E-eh, begitu ya... aku coba paham. Ceritain lagi?", "Menarik... tapi pelan-pelan ya, jangan teriak."], ["Hmph. Terserah. Tapi ya, aku dengar.", "Ngomong yang jelas, {P}."]],
};

const cnt = (c: ConvCtx) => (c.near >= 5 ? "banyak" : ["", "satu", "dua", "tiga", "empat"][c.near] || String(c.near));
const SITU: Record<string, (c: ConvCtx) => string>[] = [
  // JAKA
  { zombie: (c) => `Eh, ada ${cnt(c)} zombie nongol nih, ngobrolnya sambil mukul ya!`, hurt: () => "Eh, darahmu bocor, {P}. Tutup dulu ya.", rain: () => "Ini hujan atau zombie lagi cuci muka?", shop: () => "Eh, minimarket! Jangan sampai ada yang jarah jajanan duluan.", house: () => "Rumah orang lho, jangan lupa permisi.", low: () => "Aku coba tetap ceria... demi kamu." },
  // SARI
  { zombie: (c) => `Tapi sekarang ada ${cnt(c)} yang mendekat... ayo bergerak dulu.`, hurt: () => "Lukamu juga, {P}. Sini, biar aku obati begitu aman.", rain: () => "Hujannya dingin, jangan sampai demam ya.", shop: () => "Di rak belakang mart biasanya ada obat.", house: () => "Pelan-pelan ya, di sini rumah orang.", low: () => "Kita sudah kehilangan banyak... tolong jangan paksakan dirimu." },
  // BIMO
  { zombie: (c) => `Kontak, ${cnt(c)} target mendekat. Bicara nanti.`, hurt: () => "Lukamu harus diobati. Jangan abaikan.", rain: () => "Jarak pandang turun. Tetap rapat.", shop: () => "Lorong sempit. Awas sudut mati.", house: () => "Periksa tiap sudut.", low: () => "Fokus. Itu cara kita menghormati yang sudah pergi." },
  // NADIA
  { zombie: (c) => `A-awas, ${cnt(c)} zombie dekat... aku dengar langkahnya!`, hurt: () => "D-darahmu banyak... cari obat dulu ya.", rain: () => "Hujannya makin deras... suara kita tersamar, tapi pandangan juga.", shop: () => "Minimarket... banyak tempat sembunyi. Ih.", house: () => "A-aku jaga pintu saja ya.", low: () => "Aku... masih takut. Tapi kita tetap lanjut." },
  // BARA
  { zombie: (c) => `Tuh ada ${cnt(c)} zombie! Cukup ngobrolnya, ayo hajar!`, hurt: () => "Tahan sedikit, jangan lembek!", rain: () => "Biar hujan. Aku tetap maju.", shop: () => "Aku ambil minuman energi dulu, nanti.", house: () => "Kalau ada yang bangun di sini, kuhajar.", low: () => "Aku marah. Tapi kita tetap bersama." },
];

export function parse(text: string): { intent: string; names: number[] } {
  const t = ` ${text.toLowerCase().normalize("NFKD").replace(/[^a-z0-9?!\s']/g, " ").replace(/\s+/g, " ").trim()} `;
  const names: number[] = [];
  ["jaka", "sari", "bimo", "nadia", "bara"].forEach((n, i) => { if (t.includes(` ${n} `) || t.includes(` ${n}?`) || t.includes(` ${n}!`)) names.push(i); });
  let intent = "other";
  for (const [k, re] of RULES) if (re.test(t.trim()) || re.test(t)) { intent = k; break; }
  if (intent === "other" && /\?\s*$/.test(t.trim())) intent = "status";
  return { intent, names };
}

const rand = Math.random;
const pickOf = <T,>(a: T[]) => a[(rand() * a.length) | 0];

/** build the answers: the best friend replies now, another may chime in a moment later */
export function respond(text: string, c: ConvCtx): { intent: string; replies: Reply[] } {
  const { intent, names } = parse(text);
  const pref = PREF[intent] ?? PREF.other;
  const order = [...names, ...pref.filter((s) => !names.includes(s))].filter((s) => c.alive[s]);
  if (!order.length) return { intent, replies: [] };
  const mood = EMO[intent] ?? "calm";
  const build = (skin: number, second: boolean): string => {
    const set = (R[intent] ?? R.other)[skin];
    let line = second && set.length > 1 ? set[1] : pickOf(set);
    // the situation colours the answer
    const S = SITU[skin];
    let extra = "";
    if (c.near > 0 && rand() < 0.9) extra = S.zombie(c);
    else if (c.hp < 40 && intent !== "hurt" && rand() < 0.7) extra = S.hurt(c);
    else if (c.morale < 0.4 && (intent === "sad" || intent === "status" || intent === "other") && rand() < 0.8) extra = S.low(c);
    else if (c.sky === "rain" && rand() < 0.3) extra = S.rain(c);
    else if (c.place === "shop" && rand() < 0.3) extra = S.shop(c);
    else if (c.place === "house" && rand() < 0.2) extra = S.house(c);
    if (extra) line = `${line} ${extra}`;
    return line.split("{P}").join(c.P).split("{D}").join(c.dir || "UTARA");
  };
  const replies: Reply[] = [{ skin: order[0], text: build(order[0], false), mood, delay: 0.7 + rand() * 0.5 }];
  // a second friend chimes in on feelings, jokes and insults
  if (order.length > 1 && ["sad", "scared", "happy", "laugh", "joke", "insult", "angry", "hurt", "love", "thanks"].includes(intent) && rand() < 0.75)
    replies.push({ skin: order[1], text: build(order[1], true), mood, delay: 2.3 + rand() * 0.8 });
  return { intent, replies };
}

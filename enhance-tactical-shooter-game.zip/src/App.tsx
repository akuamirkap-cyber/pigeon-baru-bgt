import { useEffect, useMemo, useRef, useState } from "react";
import "@fontsource/press-start-2p/400.css";
import { Hud } from "./components/Hud";
import { Menu } from "./components/Menu";
import { ChatBox } from "./components/ChatBox";
import { NewYork } from "./ny/NewYork";
import { Pause, Results, TouchControls } from "./components/Overlays";
import { audio } from "./game/audio";
import type { DiffId, GameMode, WeatherId } from "./game/defs";
import { Game } from "./game/engine";
import { HOUSES, WINDOWS } from "./game/map";
import type { HudState, MatchResult } from "./game/engine";

type Screen = "menu" | "game" | "result";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [hud, setHud] = useState<HudState | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [skin, setSkin] = useState(2);
  const [diff, setDiff] = useState<DiffId>("normal");
  const [mode, setMode] = useState<GameMode>("pvp");
  const [weather, setWeather] = useState<WeatherId>("auto");
  const [chatOpen, setChatOpen] = useState(false);
  const [lvl, setLvl] = useState(1);
  const [loading, setLoading] = useState(false);
  const [ny, setNy] = useState<"" | "peace" | "zombie">("");
  useEffect(() => { if (game) game.halt = !!ny; }, [ny, game]);
  const coarse = useMemo(() => typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches, []);

  useEffect(() => {
    const g = new Game(canvasRef.current!, {
      onHud: setHud,
      onChat: setChatOpen,
      onMatchEnd: (r) => {
        setResult(r);
        setScreen("result");
      },
    });
    g.startDemo();
    setGame(g);
    // debug handle for testing from the console
    (window as unknown as { __chibi?: Game; __chibiHouses?: () => unknown }).__chibi = g;
    (window as unknown as { __chibiHouses?: () => unknown }).__chibiHouses = () => HOUSES;
    (window as unknown as { __chibiWins?: () => unknown }).__chibiWins = () => WINDOWS;
    return () => g.destroy();
  }, []);

  const click = () => {
    audio.unlock();
    audio.play("click");
  };
  /** level 1 = the usual maps; level 3 = the co-op zombie game on the streets of New York (the city has to be built first) */
  const start = (m: GameMode, level: number) => {
    click();
    setResult(null);
    setLvl(level);
    if (level === 3) {
      setLoading(true);
      setTimeout(() => {
        game?.startMatch(skin, diff, "bugs", weather, 3);
        setScreen("game");
        setLoading(false);
      }, 80);
    } else {
      setScreen("game");
      game?.startMatch(m === "pvp" ? Math.min(skin, 4) : skin, diff, m, weather, level); // the four costumes exist only in the zombie modes
    }
  };
  const play = () => start(mode, 1);
  const toMenu = () => {
    click();
    setResult(null);
    setChatOpen(false);
    game?.closeChat();
    setScreen("menu");
    game?.startDemo();
  };

  const inPlay = screen === "game" && hud?.mode === "play";
  const showTouch = inPlay && (coarse || hud.touch) && !hud.paused;

  return (
    <div className={`fixed inset-0 select-none overflow-hidden bg-[#0b0910] ${inPlay && !hud.paused && !showTouch ? "cursor-none" : ""}`}>
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
        <canvas ref={canvasRef} className="game" />
      </div>

      {inPlay && game && showTouch && <TouchControls game={game} />}
      {inPlay && game && (
        <Hud hud={hud} onSelect={(i) => game.selectWeapon(i)} onPause={() => game.togglePause()} onMute={() => game.toggleMute()} onStrat={(n) => game.action(n === 0 ? "strat1" : "strat2")} />
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.openChat()} className="btn btn-dark absolute left-2 top-[98px] z-20 px-2 py-1.5 font-pixel text-[7px]">[T] OBROL DENGAN TIM</button>
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.toggleRest()} className={`btn absolute left-2 top-[128px] z-20 px-2 py-1.5 font-pixel text-[7px] ${hud.resting ? "btn-on" : "btn-dark"}`}>[C] {hud.resting ? "BERDIRI" : "ISTIRAHAT"} · [SHIFT] LARI</button>
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.skipMission()} className="btn btn-dark absolute left-2 top-[158px] z-20 px-2 py-1.5 font-pixel text-[7px]">[F] LEWATI MISI</button>
      )}
      {inPlay && game && !hud.paused && (
        <button onClick={() => game.toggleMusic()} className={`btn absolute right-2 top-[44px] z-20 px-2 py-1.5 font-pixel text-[7px] ${hud.music ? "btn-on" : "btn-dark"}`}>[N] MUSIK {hud.music ? "ON" : "OFF"}</button>
      )}
      {inPlay && game && hud.game === "bugs" && hud.safe > 0 && !hud.paused && (
        <div className="ts pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap px-2 py-1 font-pixel text-[7px]" style={{ top: hud.boss >= 0 ? 118 : 78, background: "rgba(12,10,16,0.88)", color: hud.safe === 3 ? "#7dff9a" : hud.safe === 2 ? "#ff6b7a" : "#f5c542", boxShadow: `0 0 0 2px #0a0a0f, 0 0 0 3px ${hud.safe === 3 ? "#7dff9a" : hud.safe === 2 ? "#ff6b7a" : "#f5c542"}` }}>
          {hud.safe === 3 ? "TEMPAT AMAN - [C] ISTIRAHAT SAMPAI PULIH" : hud.safe === 2 ? "PINTU TERTUTUP - MASIH ADA ZOMBIE DI DALAM!" : "[E] TUTUP PINTU - JADIKAN TEMPAT BERLINDUNG"}
        </div>
      )}
      {screen === "menu" && game && !ny && (
        <button onClick={() => { audio.unlock(); game.toggleMusic(); }} className={`btn absolute right-3 top-3 z-30 px-3 py-2 font-pixel text-[8px] ${hud?.music ? "btn-on" : "btn-dark"}`}>MUSIK {hud?.music ? "ON" : "OFF"}</button>
      )}
      {inPlay && game && chatOpen && <ChatBox onSend={(t) => game.talk.hear(t)} onClose={() => game.closeChat()} />}
      {inPlay && game && hud.paused && (
        <Pause muted={hud.muted} onResume={() => { click(); game.togglePause(false); }} onMute={() => game.toggleMute()} onQuit={toMenu} />
      )}

      {screen === "menu" && (
        <Menu
          skin={skin}
          setSkin={(s) => { click(); setSkin(s); }}
          diff={diff}
          setDiff={(d) => { click(); setDiff(d); }}
          mode={mode}
          setMode={(m) => { click(); setMode(m); }}
          weather={weather}
          setWeather={(w) => { click(); setWeather(w); }}
          onPlay={play}
          onNY={() => { click(); setNy("peace"); }}
          onNYZ={() => start("bugs", 3)}
        />
      )}
      {loading && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-[#0b0910]/90 font-pixel">
          <div className="ts-big text-2xl text-[#f5c542] sm:text-4xl">NEW YORK</div>
          <div className="ts blink text-[9px] text-white sm:text-xs">MEMBANGUN KOTA...</div>
        </div>
      )}
      {ny && <NewYork key={ny} zombie={ny === "zombie"} onExit={() => setNy("")} />}
      {screen === "result" && result && <Results result={result} onAgain={() => start(lvl === 3 ? "bugs" : mode, lvl)} onMenu={toMenu} />}
    </div>
  );
}

import { useEffect, useRef, useState } from "react";

const CHIPS = ["Halo semua!", "Aku takut...", "Aku capek banget", "Gimana kondisi kalian?", "Kita ke mana sekarang?", "Ada strategi?", "Ceritain lelucon dong", "Makasih ya, kalian hebat"];

interface Props { onSend: (text: string) => void; onClose: () => void }

/** free chat with the squad: type anything, or tap a suggestion */
export function ChatBox({ onSend, onClose }: Props) {
  const [text, setText] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  const send = (t: string) => {
    if (t.trim()) onSend(t.trim());
    onClose();
  };
  return (
    <div className="pointer-events-auto absolute bottom-24 left-1/2 z-30 w-[min(620px,94vw)] -translate-x-1/2 font-pixel">
      <div className="panel p-3">
        <div className="mb-2 flex flex-wrap gap-1.5">
          {CHIPS.map((c) => (
            <button key={c} onClick={() => send(c)} className="btn btn-dark px-2 py-1.5 text-[7px]">{c}</button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] text-[#f5c542]">KAMU:</span>
          <input
            ref={ref}
            value={text}
            maxLength={140}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              e.stopPropagation();
              e.nativeEvent.stopImmediatePropagation();
              if (e.key === "Enter") { e.preventDefault(); send(text); }
              else if (e.key === "Escape") { e.preventDefault(); onClose(); }
            }}
            placeholder="Ceritakan perasaanmu, tanya sesuatu, atau bercanda..."
            className="min-w-0 flex-1 bg-[#0a0a0f] px-2 py-2 text-[9px] text-[#e9e2d2] outline-none ring-2 ring-[#a97a1c] placeholder:text-[#6b6676]"
          />
          <button onClick={() => send(text)} className="btn px-3 py-2 text-[8px]">KIRIM</button>
        </div>
        <div className="mt-1.5 text-[6px] text-[#8a8496]">ENTER = kirim · ESC = tutup · teman paham perasaan &amp; situasimu</div>
      </div>
    </div>
  );
}

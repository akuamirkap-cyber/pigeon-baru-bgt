import { useEffect, useRef, useState } from "react";
import { Game, type GameState, type HudData } from "./game/game";

const RANK_LABEL: Record<string, string> = {
  D: "Tumpul",
  C: "Cukup",
  B: "Tajam",
  A: "Master",
  S: "Legenda",
  SS: "MUSOU!",
};

function Key({ k }: { k: string }) {
  return <span className="keycap">{k}</span>;
}

function ControlRow({ keys, label }: { keys: string[]; label: string }) {
  return (
    <div className="flex items-center gap-2 py-1">
      <span className="flex items-center gap-1 min-w-[86px]">
        {keys.map((k) => (
          <Key key={k} k={k} />
        ))}
      </span>
      <span className="text-[13px] text-paper-dim">{label}</span>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [state, setState] = useState<GameState>("idle");
  const [hud, setHud] = useState<HudData>({ score: 0, combo: 0, best: 0, cuts: 0, time: 0, rank: "D" });
  const [toast, setToast] = useState<{ rank: string; key: number } | null>(null);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas, {
      onHud: setHud,
      onRankUp: (rank) => setToast({ rank, key: Date.now() }),
      onState: setState,
    });
    gameRef.current = game;
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.code === "KeyM") {
        setMuted((m) => {
          const n = !m;
          gameRef.current?.sfx.setMuted(n);
          return n;
        });
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 1950);
    return () => clearTimeout(id);
  }, [toast]);

  const fmtTime = (s: number) =>
    `${Math.floor(s / 60).toString().padStart(2, "0")}:${Math.floor(s % 60).toString().padStart(2, "0")}`;

  const inGame = state === "running" || state === "paused";

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink-950 font-ui text-paper">
      <canvas ref={canvasRef} className="absolute inset-0 cursor-crosshair" />

      {/* ================= HUD ================= */}
      {inGame && (
        <>
          {/* top-left: rank + score */}
          <div className="panel-ink pointer-events-none absolute left-4 top-4 flex items-center gap-3 px-4 py-2.5">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-full border-2 border-blood bg-[radial-gradient(circle_at_35%_30%,#3a110c,#160705)]">
              <span className="font-display text-2xl leading-none text-blood drop-shadow-[0_0_10px_rgba(194,47,35,0.8)]">
                {hud.rank}
              </span>
              <span className="absolute -bottom-1 rounded-sm bg-ink-950 px-1 text-[8px] font-bold tracking-widest text-gold">
                {RANK_LABEL[hud.rank]}
              </span>
            </div>
            <div className="leading-tight">
              <div className="text-[10px] font-semibold tracking-[0.22em] text-paper-dim">SKOR</div>
              <div className="font-display text-xl text-paper">{hud.score.toLocaleString("id-ID")}</div>
              <div className="text-[11px] text-paper-dim">
                <span className="text-leaf font-semibold">{hud.cuts}</span> potongan · kombo terbaik{" "}
                <span className="text-gold font-semibold">×{hud.best}</span>
              </div>
            </div>
          </div>

          {/* top-right: timer + mute */}
          <div className="absolute right-4 top-4 flex items-center gap-2">
            <div className="panel-ink pointer-events-none px-3.5 py-2 text-right">
              <div className="text-[10px] font-semibold tracking-[0.22em] text-paper-dim">LATIHAN</div>
              <div className="font-display text-lg leading-none text-paper tabular-nums">{fmtTime(hud.time)}</div>
            </div>
            <button
              onMouseDown={(e) => e.stopPropagation()}
              onClick={() => {
                setMuted((m) => {
                  const n = !m;
                  gameRef.current?.sfx.setMuted(n);
                  return n;
                });
              }}
              className="panel-ink flex h-[42px] w-[42px] cursor-pointer items-center justify-center text-paper-dim transition-colors hover:text-paper"
              aria-label="Suara"
              title="Suara (M)"
            >
              {muted ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M11 5 6 9H2v6h4l5 4V5z" />
                  <line x1="23" y1="9" x2="17" y2="15" />
                  <line x1="17" y1="9" x2="23" y2="15" />
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M11 5 6 9H2v6h4l5 4V5z" />
                  <path d="M15.5 8.5a5 5 0 0 1 0 7" />
                  <path d="M19 5a9 9 0 0 1 0 14" />
                </svg>
              )}
            </button>
          </div>

          {/* combo popup */}
          {hud.combo >= 2 && state === "running" && (
            <div
              key={hud.combo}
              className="anim-pop pointer-events-none absolute right-[8%] top-[30%] text-right"
            >
              <div
                className={`font-display leading-none drop-shadow-[0_2px_12px_rgba(0,0,0,0.8)] ${
                  hud.combo >= 6 ? "text-gold text-6xl" : "text-paper text-5xl"
                }`}
              >
                ×{hud.combo}
              </div>
              <div className="mt-1 text-xs font-bold tracking-[0.4em] text-blood">KOMBO</div>
            </div>
          )}

          {/* rank up toast */}
          {toast && (
            <div key={toast.key} className="pointer-events-none absolute inset-x-0 top-[18%] flex justify-center">
              <div className="anim-rank text-center">
                <div className="font-display text-6xl text-blood drop-shadow-[0_0_24px_rgba(194,47,35,0.9)]">
                  {toast.rank}
                </div>
                <div className="mt-1 text-sm font-bold tracking-[0.5em] text-gold">
                  PERINGKAT NAIK — {RANK_LABEL[toast.rank]}
                </div>
              </div>
            </div>
          )}

          {/* bottom control strip */}
          <div className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center">
            <div className="panel-ink flex flex-wrap items-center justify-center gap-x-5 gap-y-1 px-5 py-2 text-[11px] text-paper-dim opacity-90">
              <span className="flex items-center gap-1.5"><Key k="A" /><Key k="D" /> jalan</span>
              <span className="flex items-center gap-1.5"><Key k="SHIFT" /> lari</span>
              <span className="flex items-center gap-1.5"><Key k="SPASI" /> lompat</span>
              <span className="flex items-center gap-1.5"><Key k="KLIK" /> tebas (kombo)</span>
              <span className="flex items-center gap-1.5"><Key k="K" /> berat</span>
              <span className="flex items-center gap-1.5"><Key k="L" /> iaido</span>
              <span className="flex items-center gap-1.5"><Key k="Q" /> putaran</span>
              <span className="flex items-center gap-1.5"><Key k="S" />+<Key k="KLIK" /> menukik</span>
              <span className="flex items-center gap-1.5 text-gold">mouse = arah ayunan</span>
              <span className="flex items-center gap-1.5 font-semibold text-blood">auto-lock · nebas sambil lari</span>
            </div>
          </div>
        </>
      )}

      {/* ================= START SCREEN ================= */}
      {state === "idle" && (
        <div className="ink-grain absolute inset-0 flex items-center justify-center bg-[linear-gradient(180deg,rgba(4,6,12,0.88),rgba(7,9,15,0.94))]">
          <div className="mx-4 flex max-w-3xl flex-col items-center text-center">
            <div className="anim-sun relative mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-[radial-gradient(circle_at_38%_32%,#d4553f,#8e241a_75%)]">
              <span className="font-display text-6xl text-[#2a0805] opacity-80" style={{ fontFamily: "'Shojumaru', serif" }}>
                刀
              </span>
              <span className="absolute inset-0 rounded-full border border-[#e8a08f]/30" />
            </div>

            <h1 className="anim-rise font-display text-5xl leading-none text-paper drop-shadow-[0_4px_0_rgba(126,29,21,0.9)] md:text-7xl">
              KATANA <span className="text-blood">DOJO</span>
            </h1>
            <p className="anim-rise-1 mt-3 text-sm font-semibold tracking-[0.35em] text-gold md:text-base">
              SIMULASI KENJUTSU 2D · TANPA MUSUH — HANYA KAU DAN BILAHMU
            </p>

            <div className="anim-rise-2 panel-ink mt-8 grid w-full grid-cols-1 gap-x-10 px-8 py-5 text-left sm:grid-cols-2">
              <div>
                <div className="mb-1.5 text-[11px] font-bold tracking-[0.3em] text-blood">GERAKAN</div>
                <ControlRow keys={["A", "D"]} label="jalan ke kiri / kanan" />
                <ControlRow keys={["SHIFT"]} label="lari (tahan)" />
                <ControlRow keys={["SPASI"]} label="lompat" />
                <ControlRow keys={["S"]} label="tahan di udara → menukik" />
              </div>
              <div>
                <div className="mb-1.5 text-[11px] font-bold tracking-[0.3em] text-blood">TEKNIK PEDANG</div>
                <ControlRow keys={["KLIK"]} label="tebas — rantai jadi kombo 3" />
                <ControlRow keys={["K"]} label="tebasan berat (jeda dulu)" />
                <ControlRow keys={["L"]} label="iaido — dash kilat" />
                <ControlRow keys={["Q"]} label="tebasan berputar 360°" />
                <div className="mt-1 flex items-center gap-2 py-1">
                  <span className="min-w-[86px] font-display text-[10px] leading-tight text-blood">
                    AUTO-LOCK
                  </span>
                  <span className="text-[13px] font-semibold text-gold">
                    tebasan otomatis menerjang sasaran terdekat
                  </span>
                </div>
              </div>
              <p className="mt-3 text-[12px] leading-relaxed text-paper-dim sm:col-span-2">
                Gerakkan <span className="text-gold font-semibold">mouse</span> untuk mengarahkan ayunan katana ke
                segala arah. <span className="text-blood font-semibold">Tebas sambil lari</span> — momentummu terjaga,
                dan tiap serangan <span className="text-blood font-semibold">mengunci + menerjang</span> sasaran
                terdekat ala Ninja Gaiden; rantai kombo untuk melompat dari satu sasaran ke sasaran lain. Diam 5 detik →
                pedang tersarung; serangan berikutnya otomatis menjadi cabutan iaido.
              </p>
            </div>

            <button
              onClick={() => gameRef.current?.start()}
              className="btn-slash anim-rise-3 mt-8 cursor-pointer border-2 border-blood bg-[linear-gradient(180deg,#a3271c,#7e1d15)] px-12 py-4 font-display text-xl tracking-wide text-paper shadow-[0_6px_0_#3a0d09,0_14px_40px_rgba(194,47,35,0.4)] transition-all hover:-translate-y-0.5 hover:brightness-110 active:translate-y-1 active:shadow-[0_2px_0_#3a0d09]"
            >
              MULAI BERLATIH
            </button>
            <div className="anim-blink mt-3 text-[12px] tracking-[0.25em] text-paper-dim">
              atau tekan ENTER — suara: <Key k="M" /> · jeda: <Key k="ESC" />
            </div>
          </div>
        </div>
      )}

      {/* ================= PAUSE ================= */}
      {state === "paused" && (
        <div className="absolute inset-0 flex items-center justify-center bg-[rgba(4,6,12,0.72)] backdrop-blur-[2px]">
          <div className="panel-ink ink-grain mx-4 flex w-full max-w-md flex-col items-center px-10 py-8 text-center">
            <h2 className="font-display text-4xl text-paper">JEDA</h2>
            <p className="mt-1 text-xs tracking-[0.3em] text-paper-dim">PEDANGMU BERISTIRAHAT</p>
            <div className="mt-6 flex w-full flex-col gap-3">
              <button
                onClick={() => gameRef.current?.resume()}
                className="btn-slash cursor-pointer border-2 border-blood bg-[linear-gradient(180deg,#a3271c,#7e1d15)] px-6 py-3 font-display text-base text-paper shadow-[0_4px_0_#3a0d09] transition-all hover:brightness-110 active:translate-y-0.5"
              >
                LANJUTKAN
              </button>
              <button
                onClick={() => gameRef.current?.restart()}
                className="cursor-pointer border-2 border-ink-600 bg-ink-800 px-6 py-3 font-display text-base text-paper-dim transition-all hover:border-paper-dim hover:text-paper active:translate-y-0.5"
              >
                ULANGI SESI
              </button>
            </div>
            <div className="mt-5 text-[11px] leading-relaxed text-paper-dim">
              <Key k="ESC" /> lanjut · <Key k="R" /> ulangi · <Key k="M" /> suara
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

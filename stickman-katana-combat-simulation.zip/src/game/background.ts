/* Parallax night-dojo backdrop, fully procedural. Screen-space draw. */

function sr(n: number): number {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}

function ridgeY(wx: number, seed: number, amp: number, base: number): number {
  return (
    base -
    Math.abs(Math.sin(wx * 0.0021 + seed)) * amp * 0.7 -
    Math.abs(Math.sin(wx * 0.00063 + seed * 2.7)) * amp * 1.35
  );
}

function drawRidge(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  par: number,
  camX: number,
  seed: number,
  amp: number,
  base: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(-30, H + 60);
  for (let sx = -30; sx <= W + 30; sx += 12) {
    const wx = sx + camX * par;
    ctx.lineTo(sx, ridgeY(wx, seed, amp, base));
  }
  ctx.lineTo(W + 30, H + 60);
  ctx.closePath();
  ctx.fill();
}

function drawPagoda(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string) {
  ctx.fillStyle = color;
  const tiers = 4;
  let w = 64 * s;
  let ty = y;
  for (let i = 0; i < tiers; i++) {
    const h = 13 * s;
    // roof
    ctx.beginPath();
    ctx.moveTo(x - w / 2, ty);
    ctx.quadraticCurveTo(x - w * 0.28, ty - h * 0.55, x, ty - h);
    ctx.quadraticCurveTo(x + w * 0.28, ty - h * 0.55, x + w / 2, ty);
    ctx.quadraticCurveTo(x, ty - h * 0.28, x - w / 2, ty);
    ctx.fill();
    // body
    ctx.fillRect(x - w * 0.27, ty - h - 10 * s, w * 0.54, 10 * s);
    ty -= h + 10 * s;
    w *= 0.82;
  }
  // spire
  ctx.fillRect(x - 1.5 * s, ty - 16 * s, 3 * s, 16 * s);
}

function drawToriiFar(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(x - 34 * s, y - 74 * s, 7 * s, 74 * s);
  ctx.fillRect(x + 27 * s, y - 74 * s, 7 * s, 74 * s);
  ctx.fillRect(x - 28 * s, y - 52 * s, 56 * s, 5 * s);
  ctx.beginPath();
  ctx.moveTo(x - 46 * s, y - 74 * s);
  ctx.quadraticCurveTo(x, y - 82 * s, x + 46 * s, y - 74 * s);
  ctx.lineTo(x + 42 * s, y - 68 * s);
  ctx.quadraticCurveTo(x, y - 75 * s, x - 42 * s, y - 68 * s);
  ctx.closePath();
  ctx.fill();
}

export function drawSky(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  camX: number,
  t: number,
  horizonY: number
) {
  // sky gradient
  const g = ctx.createLinearGradient(0, -40, 0, Math.max(horizonY + 40, H));
  g.addColorStop(0, "#04060c");
  g.addColorStop(0.42, "#0a101d");
  g.addColorStop(0.75, "#151b2b");
  g.addColorStop(1, "#2c221c");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  // stars
  ctx.save();
  for (let i = 0; i < 110; i++) {
    const x = ((((sr(i * 3.71) * 1900 - camX * 0.03) % W) + W) % W);
    const y = sr(i * 9.13) * Math.max(80, horizonY * 0.62);
    const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * (0.6 + sr(i) * 1.4) + i));
    ctx.globalAlpha = tw * (0.25 + sr(i * 5.3) * 0.55);
    ctx.fillStyle = sr(i * 7.7) < 0.12 ? "#ffd9a0" : "#dfe8f2";
    const s = sr(i * 2.2) < 0.15 ? 1.8 : 1.1;
    ctx.fillRect(x, y, s, s);
  }
  ctx.restore();

  // blood moon
  const mx = W * 0.74 - camX * 0.012;
  const my = Math.max(90, horizonY * 0.34);
  const mr = Math.min(W, H) * 0.105;
  ctx.save();
  const glow = ctx.createRadialGradient(mx, my, mr * 0.4, mx, my, mr * 3.4);
  glow.addColorStop(0, "rgba(198,52,38,0.4)");
  glow.addColorStop(0.5, "rgba(198,52,38,0.12)");
  glow.addColorStop(1, "rgba(198,52,38,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(mx - mr * 3.5, my - mr * 3.5, mr * 7, mr * 7);
  const mg = ctx.createRadialGradient(mx - mr * 0.3, my - mr * 0.35, mr * 0.1, mx, my, mr);
  mg.addColorStop(0, "#d4553f");
  mg.addColorStop(0.65, "#b93527");
  mg.addColorStop(1, "#8e241a");
  ctx.fillStyle = mg;
  ctx.beginPath();
  ctx.arc(mx, my, mr, 0, Math.PI * 2);
  ctx.fill();
  // moon texture
  ctx.fillStyle = "rgba(80,16,10,0.25)";
  for (let i = 0; i < 7; i++) {
    const a = sr(i * 3.3) * Math.PI * 2;
    const rr = sr(i * 8.8) * mr * 0.6;
    ctx.beginPath();
    ctx.arc(mx + Math.cos(a) * rr, my + Math.sin(a) * rr, mr * (0.06 + sr(i * 4.4) * 0.12), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // drifting cloud bands
  ctx.save();
  ctx.fillStyle = "rgba(8,11,19,0.55)";
  for (let i = 0; i < 5; i++) {
    const span = W + 700;
    const x = (((sr(i * 17.3) * span + t * (5 + i * 2.2) - camX * 0.05) % span) + span) % span - 350;
    const y = Math.max(40, horizonY * (0.16 + sr(i * 6.1) * 0.4));
    const w = 220 + sr(i * 2.9) * 260;
    ctx.beginPath();
    ctx.ellipse(x, y, w, 13 + sr(i * 4.7) * 12, 0, 0, Math.PI * 2);
    ctx.ellipse(x + w * 0.4, y + 8, w * 0.6, 10, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // mountain ridges
  drawRidge(ctx, W, H, 0.07, camX, 1.7, 74, horizonY + 14, "#0a1120");
  // pagodas + far torii on far ridge
  const farPar = 0.07;
  for (const px of [900, 3400, 6100]) {
    const sx = px - camX * farPar;
    if (sx > -120 && sx < W + 120) {
      drawPagoda(ctx, sx, ridgeY(px, 1.7, 74, horizonY + 14) + 4, 1.15, "#0a1120");
    }
  }
  drawRidge(ctx, W, H, 0.16, camX, 4.2, 46, horizonY + 18, "#0d1526");
  for (const px of [1800, 4600]) {
    const sx = px - camX * 0.16;
    if (sx > -120 && sx < W + 120) {
      drawToriiFar(ctx, sx, ridgeY(px, 4.2, 46, horizonY + 18) + 10, 1, "#0d1526");
    }
  }

  // mid bamboo silhouettes
  ctx.save();
  const par = 0.42;
  for (let i = 0; i < 64; i++) {
    const wx = i * 92 + sr(i * 3.1) * 54;
    const sx = wx - camX * par;
    if (sx < -60 || sx > W + 60) continue;
    const h = 130 + sr(i * 7.7) * 170;
    const sway = Math.sin(t * 0.7 + i * 1.7) * 5;
    const topY = horizonY + 26 - h;
    ctx.strokeStyle = "rgba(9,16,14,0.9)";
    ctx.lineWidth = 3 + sr(i * 5.9) * 3;
    ctx.beginPath();
    ctx.moveTo(sx, horizonY + 30);
    ctx.quadraticCurveTo(sx + sway * 0.4, horizonY + 26 - h * 0.55, sx + sway, topY);
    ctx.stroke();
    // leaf flicks
    ctx.lineWidth = 2;
    for (let k = 0; k < 3; k++) {
      const ly = topY + k * 18;
      const sd = sr(i * 9.1 + k);
      ctx.beginPath();
      ctx.moveTo(sx + sway * (1 - k * 0.2), ly);
      ctx.quadraticCurveTo(
        sx + sway + (sd - 0.5) * 40,
        ly - 8,
        sx + sway + (sd - 0.5) * 66,
        ly + 4
      );
      ctx.stroke();
    }
  }
  ctx.restore();

  // mist band at horizon
  const mist = ctx.createLinearGradient(0, horizonY - 90, 0, horizonY + 30);
  mist.addColorStop(0, "rgba(17,22,34,0)");
  mist.addColorStop(0.7, "rgba(17,22,34,0.55)");
  mist.addColorStop(1, "rgba(13,17,27,0.85)");
  ctx.fillStyle = mist;
  ctx.fillRect(0, horizonY - 90, W, 120);
}

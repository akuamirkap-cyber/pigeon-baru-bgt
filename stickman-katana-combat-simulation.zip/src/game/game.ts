/* Katana Dojo — game orchestrator: loop, input, camera, world, scoring. */

import { SFX } from "./audio";
import { FX } from "./effects";
import { drawSky } from "./background";
import { Bamboo, StrawTarget, drawPlatform, type Platform } from "./entities";
import { Player, HOMING_MOVES, type InputFrame } from "./player";

export type GameState = "idle" | "running" | "paused";

export interface HudData {
  score: number;
  combo: number;
  best: number;
  cuts: number;
  time: number;
  rank: string;
}

interface Callbacks {
  onHud: (h: HudData) => void;
  onRankUp: (rank: string) => void;
  onState: (s: GameState) => void;
}

interface Debris {
  kind: "bamboo" | "straw";
  x: number;
  y: number;
  len: number;
  w: number;
  ang: number;
  vx: number;
  vy: number;
  va: number;
  rest: number;
  fade: number;
}

interface Floater {
  x: number;
  y: number;
  txt: string;
  color: string;
  age: number;
  max: number;
}

const RANKS: [string, number][] = [
  ["D", 0],
  ["C", 800],
  ["B", 2200],
  ["A", 4500],
  ["S", 8000],
  ["SS", 13000],
];

function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}
function hash(n: number): number {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}
function ptSegDist(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const dx = bx - ax;
  const dy = by - ay;
  const l2 = dx * dx + dy * dy;
  let t = l2 === 0 ? 0 : ((px - ax) * dx + (py - ay) * dy) / l2;
  t = clamp(t, 0, 1);
  return Math.hypot(px - (ax + dx * t), py - (ay + dy * t));
}

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: Callbacks;
  private W = 960;
  private H = 600;
  private dpr = 1;

  sfx = new SFX();
  private fx = new FX();
  private player = new Player();

  state: GameState = "idle";
  private worldW = 5200;
  private groundY = 620;
  private platforms: Platform[] = [];
  private bamboos: Bamboo[] = [];
  private straws: StrawTarget[] = [];
  private debris: Debris[] = [];
  private floaters: Floater[] = [];
  private lanterns = [480, 1650, 2700, 3700, 4650];

  private t = 0;
  private time = 0;
  private camX = 0;
  private camY = 0;
  private hitstop = 0;
  private zoom = 1;
  private zoomTarget = 1;
  private flash = 0;
  private timeScale = 1;
  private hudT = 0;
  private petalT = 0;
  private flyT = 0;

  private score = 0;
  private combo = 0;
  private comboT = 0;
  private best = 0;
  private cuts = 0;
  private rank = "D";
  private recentMoves: string[] = [];

  private keys = new Set<string>();
  private jumpQueued = false;
  private mouse = { x: 480, y: 300 };
  private raf = 0;
  private lastTs = 0;
  private destroyed = false;

  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onMouseMove: (e: MouseEvent) => void;
  private onMouseDown: (e: MouseEvent) => void;
  private onResize: () => void;
  private onBlur: () => void;
  private onVis: () => void;
  private onCtx: (e: Event) => void;

  constructor(canvas: HTMLCanvasElement, cb: Callbacks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no 2d context");
    this.ctx = ctx;
    this.cb = cb;

    this.onResize = () => this.resize();
    this.onKeyDown = (e) => this.keyDown(e);
    this.onKeyUp = (e) => {
      this.keys.delete(e.code);
    };
    this.onMouseMove = (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    };
    this.onMouseDown = (e) => {
      if (e.button === 0 && this.state === "running") this.attack("light");
    };
    this.onBlur = () => {
      if (this.state === "running") this.pause();
    };
    this.onVis = () => {
      if (document.hidden && this.state === "running") this.pause();
    };
    this.onCtx = (e) => e.preventDefault();

    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);
    canvas.addEventListener("contextmenu", this.onCtx);

    this.buildWorld();
    this.resize();
    this.player.reset(260, this.groundY);
    this.camY = this.groundY - this.H * 0.8;
    this.lastTs = performance.now();
    this.raf = requestAnimationFrame((ts) => this.loop(ts));
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    this.canvas.removeEventListener("contextmenu", this.onCtx);
  }

  private buildWorld() {
    this.platforms = [
      { x: 880, y: 512, w: 230, h: 14 },
      { x: 1420, y: 505, w: 180, h: 14 },
      { x: 2560, y: 512, w: 250, h: 14 },
      { x: 3380, y: 505, w: 200, h: 14 },
      { x: 4250, y: 512, w: 240, h: 14 },
    ];
    this.bamboos = [];
    const clusters: [number, number][] = [
      [600, 1350],
      [1850, 2450],
      [2900, 3580],
      [3850, 4750],
    ];
    for (const [a, b] of clusters) {
      let x = a;
      let i = 0;
      while (x < b) {
        this.bamboos.push(
          new Bamboo(
            x + hash(x) * 26,
            this.groundY,
            150 + hash(x * 1.3) * 120,
            7 + hash(x * 2.1) * 4
          )
        );
        x += 64 + hash(x * 0.7 + i++) * 78;
      }
    }
    this.straws = [1650, 2720, 3720, 4830].map(
      (x) => new StrawTarget(x, this.groundY - 150, 46)
    );
  }

  // ------------------------------------------------------------- controls

  start() {
    this.sfx.ensure();
    this.resetSession();
    this.setState("running");
  }

  pause() {
    if (this.state === "running") this.setState("paused");
  }

  resume() {
    this.sfx.ensure();
    if (this.state === "paused") this.setState("running");
  }

  restart() {
    this.sfx.ensure();
    this.resetSession();
    this.setState("running");
  }

  private setState(s: GameState) {
    this.state = s;
    this.cb.onState(s);
  }

  private resetSession() {
    this.score = 0;
    this.combo = 0;
    this.comboT = 0;
    this.best = 0;
    this.cuts = 0;
    this.rank = "D";
    this.time = 0;
    this.recentMoves = [];
    this.debris = [];
    this.floaters = [];
    this.hitstop = 0;
    this.buildWorld();
    this.player.reset(260, this.groundY);
    this.camX = 0;
    this.camY = this.groundY - this.H * 0.8;
    this.emitHud();
  }

  private attack(kind: "light" | "heavy" | "iaido" | "spin") {
    // build input without consuming the queued jump edge
    const k = this.keys;
    const down = k.has("ArrowDown") || k.has("KeyS");
    this.player.tryAttack(
      kind,
      { left: false, right: false, run: false, jump: false, jumpPressed: false, down, aimWX: 0, aimWY: 0 },
      this.sfx
    );
  }

  private keyDown(e: KeyboardEvent) {
    const code = e.code;
    if (
      ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(code)
    ) {
      e.preventDefault();
    }
    if (code === "Enter" && this.state === "idle") {
      this.start();
      return;
    }
    if (code === "Escape" || code === "KeyP") {
      if (this.state === "running") this.pause();
      else if (this.state === "paused") this.resume();
      return;
    }
    if (code === "KeyR" && this.state !== "idle") {
      this.restart();
      return;
    }
    if (this.keys.has(code)) {
      if (code === "Space" || code === "ArrowUp" || code === "KeyW") this.jumpQueued = true;
      return;
    }
    this.keys.add(code);
    if (this.state !== "running") return;
    if (code === "Space" || code === "ArrowUp" || code === "KeyW") this.jumpQueued = true;
    else if (code === "KeyJ") this.attack("light");
    else if (code === "KeyK") this.attack("heavy");
    else if (code === "KeyL") this.attack("iaido");
    else if (code === "KeyQ") this.attack("spin");
  }

  private readInput(): InputFrame {
    const k = this.keys;
    const left = k.has("ArrowLeft") || k.has("KeyA");
    const right = k.has("ArrowRight") || k.has("KeyD");
    const run = k.has("ShiftLeft") || k.has("ShiftRight");
    const jump = k.has("Space") || k.has("ArrowUp") || k.has("KeyW");
    const down = k.has("ArrowDown") || k.has("KeyS");
    const jp = this.jumpQueued;
    this.jumpQueued = false;
    return {
      left,
      right,
      run,
      jump,
      jumpPressed: jp,
      down,
      aimWX: this.mouse.x + this.camX,
      aimWY: this.mouse.y + this.camY,
    };
  }

  // ------------------------------------------------------------- loop

  private resize() {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.W = window.innerWidth;
    this.H = window.innerHeight;
    this.canvas.width = Math.round(this.W * this.dpr);
    this.canvas.height = Math.round(this.H * this.dpr);
    this.canvas.style.width = this.W + "px";
    this.canvas.style.height = this.H + "px";
  }

  private loop(ts: number) {
    if (this.destroyed) return;
    const dt = Math.min(0.033, (ts - this.lastTs) / 1000);
    this.lastTs = ts;
    this.t += dt;

    if (this.state !== "paused") {
      // juice values always recover in real time
      this.zoom += (this.zoomTarget - this.zoom) * Math.min(1, dt * 16);
      this.zoomTarget += (1 - this.zoomTarget) * Math.min(1, dt * 6.5);
      this.flash = Math.max(0, this.flash - dt * 3.1);
      this.timeScale += (1 - this.timeScale) * Math.min(1, dt * (this.timeScale < 0.6 ? 2.6 : 8));
      if (this.hitstop > 0) {
        this.hitstop -= dt;
      } else {
        this.update(dt * this.timeScale, dt);
      }
      this.fx.updateShake(dt);
    }

    this.render();
    this.raf = requestAnimationFrame((t2) => this.loop(t2));
  }

  private update(dt: number, realDt: number) {
    if (this.state === "running") {
      this.time += realDt;
      this.updatePlayerAndWorld(dt, this.readInput());
      this.updateCombat(dt);
    } else {
      // attract mode: gentle idle
      this.updatePlayerAndWorld(dt, {
        left: false,
        right: false,
        run: false,
        jump: false,
        jumpPressed: false,
        down: false,
        aimWX: this.player.x + 200,
        aimWY: this.player.y - 90,
      });
    }

    // camera
    let targetX: number;
    if (this.state === "running") {
      targetX = clamp(
        this.player.x + this.player.facing * 60 - this.W * 0.5,
        0,
        Math.max(0, this.worldW - this.W)
      );
    } else {
      targetX = clamp(
        140 + (Math.sin(this.t * 0.09) * 0.5 + 0.5) * 420,
        0,
        Math.max(0, this.worldW - this.W)
      );
    }
    this.camX += (targetX - this.camX) * (1 - Math.pow(0.002, dt));
    const baseCamY = this.groundY - this.H * 0.8;
    const airH = Math.max(0, this.groundY - this.player.y - 90);
    const targetY = Math.min(baseCamY, baseCamY - airH * 0.5);
    this.camY += (targetY - this.camY) * (1 - Math.pow(0.01, dt));

    // ambient particles
    this.petalT -= dt;
    if (this.petalT <= 0) {
      this.petalT = 0.22;
      this.fx.petal(this.camX + Math.random() * this.W, this.camY - 20 + Math.random() * this.H * 0.3);
    }
    this.flyT -= dt;
    if (this.flyT <= 0) {
      this.flyT = 1.1;
      this.fx.firefly(
        this.camX + Math.random() * this.W,
        this.groundY - 30 - Math.random() * 150
      );
    }

    // hud emit
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.12;
      this.emitHud();
    }
  }

  private updatePlayerAndWorld(dt: number, input: InputFrame) {
    this.player.update(dt, input, this.groundY, this.platforms, this.t, this.sfx, this.fx);
    this.player.x = clamp(this.player.x, 30, this.worldW - 30);
    for (const b of this.bamboos) b.update(dt);
    for (const s of this.straws) s.update(dt);
    this.fx.update(dt, this.t);

    // debris physics
    for (let i = this.debris.length - 1; i >= 0; i--) {
      const d = this.debris[i];
      if (d.rest <= 0) {
        d.vy += 1250 * dt;
        d.x += d.vx * dt;
        d.y += d.vy * dt;
        d.ang += d.va * dt;
        const half = d.len / 2;
        const e1y = d.y + Math.sin(d.ang) * half;
        const e2y = d.y - Math.sin(d.ang) * half;
        const e3y = d.y + Math.cos(d.ang) * half;
        const e4y = d.y - Math.cos(d.ang) * half;
        const low = Math.max(e1y, e2y, e3y, e4y);
        if (low > this.groundY) {
          d.y -= low - this.groundY;
          if (Math.abs(d.vy) > 130) {
            d.vy *= -0.34;
            d.va *= -0.55;
            d.vx *= 0.7;
            this.fx.dust(d.x, this.groundY, 3, 40);
          } else {
            d.vy = 0;
            d.vx *= 0.86;
            d.va *= 0.8;
            d.rest = 2.4;
          }
        }
      } else {
        d.rest -= dt;
        d.fade = Math.min(1, d.rest / 0.8);
        if (d.rest <= 0) this.debris.splice(i, 1);
      }
    }

    // floaters
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.age += dt;
      f.y -= 44 * dt;
      if (f.age > f.max) this.floaters.splice(i, 1);
    }

    // combo decay
    if (this.combo > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }
  }

  // ------------------------------------------------------------- combat

  /** nearest live target in lock range — forward targets strongly preferred */
  private findLock(): { x: number; y: number } | null {
    const px = this.player.x;
    const py = this.player.y;
    const f = this.player.facing;
    const RANGE = 450;
    let best: { x: number; y: number } | null = null;
    let bestScore = Infinity;
    for (const b of this.bamboos) {
      if (b.state === 1) continue;
      const dx = b.x - px;
      const adx = Math.abs(dx);
      if (adx > RANGE) continue;
      const forward = dx * f >= -20 ? 1 : 2;
      const score = adx * forward;
      if (score < bestScore) {
        bestScore = score;
        best = { x: b.x, y: Math.max(b.topY() + 26, py - 120) };
      }
    }
    for (const s of this.straws) {
      if (s.state !== 0) continue;
      const pos = s.bodyPos();
      const dx = pos.x - px;
      const adx = Math.abs(dx);
      if (adx > RANGE * 1.2) continue;
      const forward = dx * f >= -20 ? 1 : 2;
      const score = adx * forward - 40; // straw bundles are prized targets
      if (score < bestScore) {
        bestScore = score;
        best = { x: pos.x, y: pos.y };
      }
    }
    return best;
  }

  private updateCombat(dt: number) {
    void dt;

    // acquire a homing lock for the current technique
    const mv = this.player.move;
    if (
      mv &&
      HOMING_MOVES.has(mv.id) &&
      !this.player.lockTarget &&
      this.player.moveT < mv.dur * mv.end
    ) {
      const lock = this.findLock();
      if (lock) {
        this.player.lockTarget = lock;
        this.sfx.lock();
      }
    }

    const info = this.player.getHitInfo();
    if (info) {
      for (const b of this.bamboos) {
        if (b.state === 1 || b.hitSwing === info.swingId) continue;
        if (b.x < this.camX - 300 || b.x > this.camX + this.W + 300) continue;
        const topY = b.topY();
        let cutY: number | null = null;
        if (info.kind === "seg") {
          const d = ptSegDist(b.x, clamp((info.gy + info.ty) / 2, topY, b.baseY), info.gx, info.gy, info.tx, info.ty);
          const d2 = ptSegDist(b.x, topY, info.gx, info.gy, info.tx, info.ty);
          const d3 = ptSegDist(b.x, b.baseY, info.gx, info.gy, info.tx, info.ty);
          if (Math.min(d, d2, d3) < b.th / 2 + 8) {
            cutY = clamp((info.gy + info.ty) / 2, topY + 12, b.baseY - 14);
          }
        } else if (info.kind === "radial") {
          if (Math.abs(b.x - info.cx) < info.range && topY < info.cy + 36) {
            cutY = clamp(info.cy - 6, topY + 12, b.baseY - 14);
          }
        } else {
          if (b.x > info.gx && b.x < info.tx && topY < info.ty && b.baseY > info.gy) {
            cutY = clamp(info.cy + 4, topY + 12, b.baseY - 14);
          }
        }
        if (cutY !== null) {
          b.hitSwing = info.swingId;
          this.cutBamboo(b, cutY, info);
        }
      }
      for (const s of this.straws) {
        if (s.state !== 0 || s.hitSwing === info.swingId) continue;
        const pos = s.bodyPos();
        let hit = false;
        if (info.kind === "seg") {
          hit = ptSegDist(pos.x, pos.y, info.gx, info.gy, info.tx, info.ty) < 30;
        } else if (info.kind === "radial") {
          hit = Math.hypot(pos.x - info.cx, pos.y - info.cy) < info.range + 18;
        } else {
          hit = pos.x > info.gx && pos.x < info.tx && pos.y > info.gy && pos.y < info.ty;
        }
        if (hit) {
          s.hitSwing = info.swingId;
          this.cutStraw(s, info);
        }
      }
    }

    // dive slam shockwave
    if (this.player.consumeDiveLand()) {
      const px = this.player.x;
      const py = this.player.y;
      this.sfx.land(true);
      this.punch({ power: 3, moveId: "dive" });
      this.sfx.cut(this.combo);
      this.fx.ring(px, py, 130, "#ffd9a0");
      this.fx.addShake(10);
      this.fx.dust(px, py, 14, 160);
      this.hitstop = Math.max(this.hitstop, 0.08);
      const dir = this.player.facing;
      for (const b of this.bamboos) {
        if (b.state === 1) continue;
        const topY = b.topY();
        if (Math.abs(b.x - px) < 118 && topY < py + 10) {
          b.hitSwing = -2;
          this.cutBamboo(b, clamp(py - 30, topY + 12, b.baseY - 14), {
            power: 3,
            moveId: "dive",
            swingId: -2,
          });
        }
      }
      for (const s of this.straws) {
        if (s.state !== 0) continue;
        const pos = s.bodyPos();
        if (Math.hypot(pos.x - px, pos.y - py) < 130) {
          this.cutStraw(s, { power: 3, moveId: "dive", swingId: -2 });
        }
      }
      void dir;
    }
  }

  /** camera zoom punch + hit flash + finisher slow-mo */
  private punch(info: { power: number; moveId: string }) {
    const finisher =
      info.moveId === "combo3" ||
      info.moveId === "heavy" ||
      info.moveId === "dive" ||
      info.moveId === "spin";
    this.flash = Math.min(0.42, 0.07 + info.power * 0.035 + (finisher ? 0.13 : 0));
    this.zoomTarget = Math.min(1.09, 1.012 + info.power * 0.012 + (finisher ? 0.022 : 0));
    if (finisher) {
      this.timeScale = info.moveId === "heavy" || info.moveId === "dive" ? 0.3 : 0.42;
    }
  }

  private addScore(base: number, x: number, y: number, moveId: string) {
    this.combo++;
    this.comboT = 1.7;
    this.best = Math.max(this.best, this.combo);
    const mult = 1 + (this.combo - 1) * 0.25;
    let pts = Math.round(base * mult);
    let variety = false;
    if (!this.recentMoves.includes(moveId)) {
      variety = this.recentMoves.length >= 1;
      pts += variety ? 50 : 0;
    }
    this.recentMoves.push(moveId);
    if (this.recentMoves.length > 4) this.recentMoves.shift();
    this.score += pts;
    this.floaters.push({
      x,
      y,
      txt: "+" + pts + (variety ? " gaya!" : ""),
      color: variety ? "#c9a227" : "#efe6cf",
      age: 0,
      max: 0.9,
    });
    // rank
    let newRank = "D";
    for (const [r, min] of RANKS) {
      if (this.score >= min) newRank = r;
    }
    if (RANKS.findIndex((r) => r[0] === newRank) > RANKS.findIndex((r) => r[0] === this.rank)) {
      this.rank = newRank;
      this.cb.onRankUp(newRank);
      this.sfx.rankUp();
    }
  }

  private cutBamboo(
    b: Bamboo,
    cutY: number,
    info: { power: number; moveId: string; swingId: number }
  ) {
    const topY = b.topY();
    const len = Math.max(18, cutY - topY);
    const dir = this.player.facing;
    b.cut(cutY);
    this.debris.push({
      kind: "bamboo",
      x: b.x,
      y: (cutY + topY) / 2,
      len,
      w: b.th,
      ang: -Math.PI / 2 + (Math.random() - 0.5) * 0.2,
      vx: dir * (180 + info.power * 75) * (1 + Math.min(10, this.combo) * 0.05) + this.player.vx * 0.25,
      vy: -140 - Math.random() * 90,
      va: dir * (2.6 + Math.random() * 3.2),
      rest: 0,
      fade: 1,
    });
    this.fx.sparks(b.x, cutY, dir, info.power);
    this.fx.leafBits(b.x, cutY, dir, 8 + info.power * 3);
    this.punch(info);
    this.sfx.cut(this.combo);
    this.player.onHitConfirmed();
    this.hitstop = Math.max(this.hitstop, 0.03 + info.power * 0.014);
    this.fx.addShake(2.4 + info.power * 1.7 + Math.min(6, this.combo) * 0.3);
    this.cuts++;
    this.addScore(100, b.x, cutY - 14, info.moveId);
  }

  private cutStraw(s: StrawTarget, info: { power: number; moveId: string; swingId: number }) {
    const pos = s.bodyPos();
    const dir = this.player.facing;
    s.cut();
    this.debris.push({
      kind: "straw",
      x: pos.x,
      y: pos.y,
      len: s.bodyH,
      w: s.bodyW,
      ang: s.ang,
      vx: dir * (200 + info.power * 70) * (1 + Math.min(10, this.combo) * 0.05) + this.player.vx * 0.2,
      vy: -130 - Math.random() * 70,
      va: dir * (3 + Math.random() * 4),
      rest: 0,
      fade: 1,
    });
    this.fx.strawBits(pos.x, pos.y, dir);
    this.sfx.thock();
    this.punch(info);
    this.sfx.cut(this.combo);
    this.player.onHitConfirmed();
    this.hitstop = Math.max(this.hitstop, 0.05 + info.power * 0.012);
    this.fx.addShake(3 + info.power * 1.5 + Math.min(6, this.combo) * 0.3);
    this.cuts++;
    this.addScore(250, pos.x, pos.y - 26, info.moveId);
  }

  private emitHud() {
    this.cb.onHud({
      score: this.score,
      combo: this.combo,
      best: this.best,
      cuts: this.cuts,
      time: this.time,
      rank: this.rank,
    });
  }

  // ------------------------------------------------------------- render

  private render() {
    const ctx = this.ctx;
    const { W, H, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawSky(ctx, W, H, this.camX, this.t, this.groundY - this.camY);

    ctx.save();
    // smooth sub-pixel camera + zoom punch around the player
    const shX = this.fx.shakeX;
    const shY = this.fx.shakeY;
    const spx = this.player.x - (this.camX + shX);
    const spy = this.player.y - 50 - (this.camY + shY);
    ctx.translate(spx, spy);
    ctx.scale(this.zoom, this.zoom);
    ctx.translate(-spx, -spy);
    ctx.translate(-(this.camX + shX), -(this.camY + shY));

    this.drawGround(ctx);
    this.drawTorii(ctx, 300, 1.1);
    this.drawTorii(ctx, 4950, 1.35);
    for (const lx of this.lanterns) this.drawLantern(ctx, lx, this.t);
    for (const p of this.platforms) drawPlatform(ctx, p, this.groundY);
    for (const s of this.straws) s.drawFrame(ctx, this.groundY);

    const x0 = this.camX - 320;
    const x1 = this.camX + this.W + 320;
    for (const b of this.bamboos) {
      if (b.x > x0 && b.x < x1) b.draw(ctx, this.t);
    }
    for (const s of this.straws) {
      if (s.x > x0 && s.x < x1) s.draw(ctx);
    }

    // homing lock reticle on the target being dashed at
    const lock = this.player.lockTarget;
    if (lock && this.player.move) {
      const m = this.player.move;
      const ph = this.player.moveT / m.dur;
      const a = ph < m.end ? 1 : Math.max(0, 1 - (ph - m.end) / 0.12);
      if (a > 0) {
        ctx.save();
        ctx.translate(lock.x, lock.y);
        ctx.globalCompositeOperation = "lighter";
        ctx.rotate(this.t * 2.6);
        ctx.strokeStyle = "rgba(194,47,35," + (0.85 * a).toFixed(3) + ")";
        ctx.lineWidth = 2;
        const r = 13 + Math.sin(this.t * 10) * 2;
        for (let k = 0; k < 4; k++) {
          ctx.rotate(Math.PI / 2);
          ctx.beginPath();
          ctx.moveTo(r, r * 0.35);
          ctx.lineTo(r, r);
          ctx.lineTo(r * 0.35, r);
          ctx.stroke();
        }
        ctx.globalAlpha = 0.5 * a;
        ctx.fillStyle = "#c22f23";
        ctx.beginPath();
        ctx.arc(0, 0, 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    this.player.draw(ctx);
    this.player.drawFx(ctx, this.t);

    // debris over player
    for (const d of this.debris) this.drawDebris(ctx, d);

    this.fx.draw(ctx);

    // floaters
    ctx.save();
    ctx.textAlign = "center";
    ctx.font = "700 14px 'Chakra Petch', sans-serif";
    for (const f of this.floaters) {
      const a = 1 - f.age / f.max;
      ctx.globalAlpha = Math.min(1, a * 2);
      ctx.fillStyle = f.color;
      ctx.fillText(f.txt, f.x, f.y);
    }
    ctx.restore();

    ctx.restore();

    // hit flash
    if (this.flash > 0.006) {
      ctx.fillStyle = "rgba(255,246,228," + Math.min(0.5, this.flash).toFixed(3) + ")";
      ctx.fillRect(0, 0, W, H);
    }

    // vignette
    const vg = ctx.createRadialGradient(
      W / 2,
      H * 0.46,
      Math.min(W, H) * 0.36,
      W / 2,
      H * 0.5,
      Math.max(W, H) * 0.78
    );
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(2,3,6,0.62)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
  }

  private drawGround(ctx: CanvasRenderingContext2D) {
    const gy = this.groundY;
    const bottom = this.camY + this.H + 60;
    const g = ctx.createLinearGradient(0, gy, 0, gy + 260);
    g.addColorStop(0, "#241c15");
    g.addColorStop(0.25, "#171210");
    g.addColorStop(1, "#0a0808");
    ctx.fillStyle = g;
    ctx.fillRect(this.camX - 40, gy, this.W + 80, bottom - gy);
    // edge
    ctx.fillStyle = "#322720";
    ctx.fillRect(this.camX - 40, gy, this.W + 80, 5);
    ctx.fillStyle = "rgba(239,230,207,0.09)";
    ctx.fillRect(this.camX - 40, gy, this.W + 80, 1.6);
    // grass tufts + pebbles
    const i0 = Math.floor((this.camX - 60) / 22);
    const i1 = Math.floor((this.camX + this.W + 60) / 22);
    ctx.lineCap = "round";
    for (let i = i0; i <= i1; i++) {
      const x = i * 22 + hash(i * 3.3) * 14;
      const hgt = 4 + hash(i * 7.7) * 7;
      ctx.strokeStyle = hash(i * 1.9) < 0.82 ? "rgba(46,66,40,0.85)" : "rgba(70,88,52,0.5)";
      ctx.lineWidth = 1.6;
      const sway = Math.sin(this.t * 1.4 + i) * 1.4;
      ctx.beginPath();
      ctx.moveTo(x, gy + 2);
      ctx.quadraticCurveTo(x + sway, gy - hgt * 0.6, x + sway * 1.6, gy - hgt);
      ctx.stroke();
      if (hash(i * 5.1) < 0.14) {
        ctx.fillStyle = "rgba(90,92,102,0.5)";
        ctx.beginPath();
        ctx.ellipse(x + 8, gy + 5, 3.4, 1.8, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  private drawTorii(ctx: CanvasRenderingContext2D, x: number, s: number) {
    const gy = this.groundY;
    ctx.save();
    ctx.translate(x, gy);
    ctx.scale(s, s);
    ctx.fillStyle = "#6e241b";
    ctx.fillRect(-58, -172, 13, 172);
    ctx.fillRect(45, -172, 13, 172);
    ctx.fillStyle = "#571b14";
    ctx.fillRect(-58, -172, 4, 172);
    ctx.fillRect(45, -172, 4, 172);
    // nuki (lower beam)
    ctx.fillStyle = "#6e241b";
    ctx.fillRect(-74, -128, 148, 10);
    // gakuzuka (strut)
    ctx.fillRect(-5, -152, 10, 24);
    // shimagi + kasagi (top beams)
    ctx.fillRect(-82, -158, 164, 10);
    ctx.beginPath();
    ctx.moveTo(-96, -158);
    ctx.quadraticCurveTo(0, -172, 96, -158);
    ctx.lineTo(96, -168);
    ctx.quadraticCurveTo(0, -183, -96, -168);
    ctx.closePath();
    ctx.fillStyle = "#7e2a20";
    ctx.fill();
    ctx.fillStyle = "rgba(239,230,207,0.1)";
    ctx.fillRect(-82, -158, 164, 2);
    ctx.restore();
  }

  private drawLantern(ctx: CanvasRenderingContext2D, x: number, t: number) {
    const gy = this.groundY;
    const flick = 0.75 + 0.25 * Math.sin(t * 7.3 + x) * Math.sin(t * 3.1 + x * 0.5);
    // glow
    const g = ctx.createRadialGradient(x, gy - 52, 4, x, gy - 52, 78);
    g.addColorStop(0, "rgba(255,190,90," + (0.3 * flick).toFixed(3) + ")");
    g.addColorStop(1, "rgba(255,190,90,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - 80, gy - 132, 160, 160);
    // stone body
    ctx.fillStyle = "#333842";
    ctx.fillRect(x - 10, gy - 40, 20, 40);
    ctx.fillRect(x - 14, gy - 46, 28, 8);
    ctx.fillRect(x - 16, gy - 66, 32, 20);
    // window
    ctx.fillStyle = "rgba(255,199,107," + (0.55 + 0.45 * flick).toFixed(3) + ")";
    ctx.fillRect(x - 8, gy - 62, 16, 12);
    // roof
    ctx.fillStyle = "#2b303a";
    ctx.beginPath();
    ctx.moveTo(x - 24, gy - 66);
    ctx.quadraticCurveTo(x, gy - 86, x + 24, gy - 66);
    ctx.closePath();
    ctx.fill();
    ctx.fillRect(x - 3, gy - 92, 6, 8);
  }

  private drawDebris(ctx: CanvasRenderingContext2D, d: Debris) {
    ctx.save();
    ctx.globalAlpha = d.fade;
    ctx.translate(d.x, d.y);
    ctx.rotate(d.ang + Math.PI / 2);
    if (d.kind === "bamboo") {
      const half = d.len / 2;
      ctx.fillStyle = "#2f6b3d";
      ctx.fillRect(-d.w * 0.32, -half, d.w * 0.64, d.len);
      ctx.fillStyle = "rgba(16,42,24,0.5)";
      ctx.fillRect(0, -half, d.w * 0.32, d.len);
      // cut face at bottom end
      ctx.fillStyle = "#d9e8b8";
      ctx.beginPath();
      ctx.ellipse(0, half, d.w * 0.36, d.w * 0.18, 0, 0, Math.PI * 2);
      ctx.fill();
      // leaves at top end
      ctx.strokeStyle = "#3f7d46";
      ctx.lineWidth = 2.2;
      ctx.lineCap = "round";
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        ctx.moveTo(0, -half);
        ctx.quadraticCurveTo((k - 1) * 10, -half - 10, (k - 1) * 16, -half - 4);
        ctx.stroke();
      }
    } else {
      const w = d.w;
      const h = d.len;
      ctx.fillStyle = "#b98f3e";
      ctx.beginPath();
      ctx.roundRect(-w / 2, -h / 2, w, h, 8);
      ctx.fill();
      ctx.strokeStyle = "rgba(122,92,38,0.8)";
      ctx.lineWidth = 1.2;
      for (let i = -3; i <= 3; i++) {
        ctx.beginPath();
        ctx.moveTo(i * 3.4, -h / 2 + 4);
        ctx.lineTo(i * 3.4, h / 2 - 4);
        ctx.stroke();
      }
      ctx.fillStyle = "#43301f";
      ctx.fillRect(-w / 2 - 1.5, -h / 2 + 8, w + 3, 5);
      ctx.fillRect(-w / 2 - 1.5, h / 2 - 13, w + 3, 5);
    }
    ctx.restore();
  }
}

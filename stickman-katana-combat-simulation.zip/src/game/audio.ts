/* Procedural WebAudio SFX — no assets, all synthesized. */

export class SFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private stepAlt = false;
  muted = false;

  /** Must be called from a user gesture. */
  ensure() {
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.5;
      this.master.connect(this.ctx.destination);
      this.noiseBuf = this.makeNoise();
      this.startWind();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.02);
    }
  }

  private makeNoise(): AudioBuffer {
    const len = this.ctx!.sampleRate;
    const buf = this.ctx!.createBuffer(1, len, this.ctx!.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  /** Faint looping wind for atmosphere. */
  private startWind() {
    const c = this.ctx!;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 300;
    f.Q.value = 0.6;
    const g = c.createGain();
    g.gain.value = 0.035;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.11;
    const lg = c.createGain();
    lg.gain.value = 130;
    lfo.connect(lg);
    lg.connect(f.frequency);
    src.connect(f);
    f.connect(g);
    g.connect(this.master!);
    src.start();
    lfo.start();
  }

  private env(dur: number, peak: number, delay = 0): GainNode {
    const g = this.ctx!.createGain();
    const t = this.ctx!.currentTime + delay;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    g.connect(this.master!);
    return g;
  }

  private noise(
    dur: number,
    peak: number,
    type: BiquadFilterType,
    f0: number,
    f1: number,
    q = 1,
    delay = 0
  ) {
    if (!this.ctx || this.muted) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.75 + Math.random() * 0.5;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    const t = this.ctx.currentTime + delay;
    f.frequency.setValueAtTime(Math.max(40, f0), t);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
    const g = this.env(dur, peak, delay);
    src.connect(f);
    f.connect(g);
    src.start(t);
    src.stop(t + dur + 0.05);
  }

  private tone(
    type: OscillatorType,
    f0: number,
    f1: number,
    dur: number,
    peak: number,
    delay = 0
  ) {
    if (!this.ctx || this.muted) return;
    const o = this.ctx.createOscillator();
    o.type = type;
    const t = this.ctx.currentTime + delay;
    o.frequency.setValueAtTime(Math.max(30, f0), t);
    o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
    const g = this.env(dur, peak, delay);
    o.connect(g);
    g.connect(this.master!);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  whoosh(kind: "light" | "heavy" | "spin" | "air" | "dive", pitch = 1) {
    switch (kind) {
      case "light":
        this.noise(0.16, 0.5, "bandpass", 900 * pitch, 2600 * pitch, 1.1);
        break;
      case "heavy":
        this.noise(0.3, 0.7, "bandpass", 280 * pitch, 1500 * pitch, 0.8);
        this.tone("sine", 150, 55, 0.22, 0.16, 0.02);
        break;
      case "spin":
        this.noise(0.42, 0.55, "bandpass", 450 * pitch, 2300 * pitch, 0.9);
        break;
      case "air":
        this.noise(0.22, 0.5, "bandpass", 700 * pitch, 2500 * pitch, 1);
        break;
      case "dive":
        this.noise(0.34, 0.6, "bandpass", 1700, 280, 1);
        break;
    }
  }

  cut(step = 0) {
    const p = 1 + Math.min(9, step) * 0.09;
    this.noise(0.07, 0.6, "highpass", 1900 * p, 1900 * p, 0.8);
    this.tone("triangle", 230 * p, 68 * p, 0.14, 0.3);
    this.tone("square", 2400 * p, 1700 * p, 0.025, 0.1);
  }

  thock() {
    // straw target hit — duller
    this.tone("sine", 160, 50, 0.18, 0.35);
    this.noise(0.1, 0.3, "lowpass", 900, 300, 0.8);
  }

  iaido() {
    this.tone("sine", 2600, 1350, 0.24, 0.11);
    this.tone("sine", 3900, 2050, 0.3, 0.06, 0.012);
    this.noise(0.2, 0.38, "bandpass", 2500, 650, 1.4, 0.05);
  }

  lock() {
    this.tone("sine", 1500, 2200, 0.06, 0.07);
    this.tone("sine", 3000, 3000, 0.03, 0.03, 0.02);
  }

  sheathe() {
    this.tone("sine", 1200, 500, 0.16, 0.07);
    this.noise(0.12, 0.16, "bandpass", 1400, 500, 1.2);
  }

  jump() {
    this.tone("sine", 270, 560, 0.12, 0.1);
  }

  land(hard: boolean) {
    this.noise(0.09, hard ? 0.4 : 0.2, "lowpass", 520, 120, 0.8);
    this.tone("sine", 115, 52, 0.1, hard ? 0.2 : 0.1);
  }

  step(run: boolean) {
    this.stepAlt = !this.stepAlt;
    this.noise(0.045, run ? 0.08 : 0.05, "bandpass", this.stepAlt ? 430 : 540, 300, 1);
  }

  rankUp() {
    const notes = [440, 523.25, 587.33, 659.25, 880];
    notes.forEach((f, i) => {
      this.tone("square", f, f, 0.1, 0.07, i * 0.06);
      this.tone("sine", f * 2, f * 2, 0.14, 0.05, i * 0.06);
    });
  }
}

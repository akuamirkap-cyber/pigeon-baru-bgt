/* Practice targets: bamboo stalks (tameshigiri) + hanging straw bundles, and platforms. */

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
}

export function drawPlatform(ctx: CanvasRenderingContext2D, p: Platform, groundY: number) {
  // legs
  ctx.fillStyle = "#241a13";
  ctx.fillRect(p.x + 8, p.y + p.h, 9, groundY - p.y - p.h);
  ctx.fillRect(p.x + p.w - 17, p.y + p.h, 9, groundY - p.y - p.h);
  // deck
  ctx.fillStyle = "#3b2c1f";
  ctx.fillRect(p.x, p.y, p.w, p.h);
  ctx.fillStyle = "#4a3827";
  ctx.fillRect(p.x, p.y, p.w, 4);
  // planks
  ctx.strokeStyle = "rgba(20,13,8,0.7)";
  ctx.lineWidth = 1.5;
  for (let x = p.x + 18; x < p.x + p.w; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, p.y + 1);
    ctx.lineTo(x, p.y + p.h - 1);
    ctx.stroke();
  }
  // edge highlight
  ctx.fillStyle = "rgba(239,230,207,0.12)";
  ctx.fillRect(p.x, p.y, p.w, 1.5);
}

export class Bamboo {
  x: number;
  baseY: number;
  fullH: number;
  th: number;
  h: number;
  /** 0 alive, 1 cut stump, 2 regrowing */
  state: 0 | 1 | 2 = 0;
  regrowT = 0;
  hitSwing = -1;
  seed: number;

  constructor(x: number, baseY: number, h: number, th: number) {
    this.x = x;
    this.baseY = baseY;
    this.fullH = h;
    this.h = h;
    this.th = th;
    this.seed = Math.random() * 10;
  }

  topY(): number {
    return this.baseY - this.h;
  }

  cut(cutY: number) {
    this.state = 1;
    this.h = Math.max(18, this.baseY - cutY);
    this.regrowT = 7 + Math.random() * 5;
    this.hitSwing = -1;
  }

  update(dt: number) {
    if (this.state === 1) {
      this.regrowT -= dt;
      if (this.regrowT <= 0) this.state = 2;
    } else if (this.state === 2) {
      this.h += (this.fullH - this.h) * Math.min(1, dt * 2.4);
      if (this.fullH - this.h < 1.2) {
        this.h = this.fullH;
        this.state = 0;
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D, t: number) {
    const lean = Math.sin(t * 0.9 + this.seed * 6) * (this.h / this.fullH) * 5;
    const topY = this.topY();
    const th = this.th;

    // stalk
    ctx.beginPath();
    ctx.moveTo(this.x - th / 2, this.baseY + 2);
    ctx.quadraticCurveTo(this.x - th * 0.3 + lean * 0.4, this.baseY - this.h * 0.55, this.x - th * 0.32 + lean, topY);
    ctx.lineTo(this.x + th * 0.32 + lean, topY);
    ctx.quadraticCurveTo(this.x + th * 0.3 + lean * 0.4, this.baseY - this.h * 0.55, this.x + th / 2, this.baseY + 2);
    ctx.closePath();
    ctx.fillStyle = "#2f6b3d";
    ctx.fill();
    // shaded side
    ctx.beginPath();
    ctx.moveTo(this.x + th * 0.1, this.baseY + 2);
    ctx.quadraticCurveTo(this.x + th * 0.35 + lean * 0.4, this.baseY - this.h * 0.55, this.x + th * 0.3 + lean, topY);
    ctx.lineTo(this.x + th * 0.32 + lean, topY);
    ctx.quadraticCurveTo(this.x + th * 0.3 + lean * 0.4, this.baseY - this.h * 0.55, this.x + th / 2, this.baseY + 2);
    ctx.closePath();
    ctx.fillStyle = "rgba(16,42,24,0.55)";
    ctx.fill();

    // node rings
    ctx.strokeStyle = "rgba(14,36,20,0.85)";
    for (let yy = this.baseY - 26; yy > topY + 8; yy -= 34) {
      const f = (this.baseY - yy) / this.h;
      const lx = this.x + lean * f;
      const w = th * (1 - f * 0.32);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(lx - w / 2, yy);
      ctx.lineTo(lx + w / 2, yy);
      ctx.stroke();
      ctx.strokeStyle = "rgba(140,200,140,0.25)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(lx - w / 2, yy + 2);
      ctx.lineTo(lx + w / 2, yy + 2);
      ctx.stroke();
      ctx.strokeStyle = "rgba(14,36,20,0.85)";
    }

    // cut face
    if (this.state !== 0 || this.h < this.fullH - 1) {
      const f = 1;
      const lx = this.x + lean * f;
      ctx.save();
      ctx.translate(lx, topY + 1);
      ctx.rotate(0.5);
      ctx.fillStyle = "#d9e8b8";
      ctx.strokeStyle = "#1d3a24";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.ellipse(0, 0, th * 0.42, th * 0.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // leaves at top
    if (this.h > this.fullH * 0.55) {
      ctx.strokeStyle = "#3f7d46";
      ctx.lineWidth = 2.4;
      ctx.lineCap = "round";
      const lx = this.x + lean;
      for (let k = 0; k < 4; k++) {
        const a = -Math.PI / 2 + (k - 1.5) * 0.65 + Math.sin(t * 1.3 + this.seed + k) * 0.08;
        const L = 16 + (k % 2) * 10;
        ctx.beginPath();
        ctx.moveTo(lx, topY + 4);
        ctx.quadraticCurveTo(
          lx + Math.cos(a) * L * 0.6,
          topY + 4 + Math.sin(a) * L * 0.6 - 6,
          lx + Math.cos(a) * L,
          topY + 4 + Math.sin(a) * L
        );
        ctx.stroke();
      }
    }
  }
}

export class StrawTarget {
  x: number;
  barY: number;
  rope: number;
  bodyW = 26;
  bodyH = 48;
  ang = 0;
  av = 0;
  /** 0 hung, 1 gone (respawning) */
  state: 0 | 1 = 0;
  respawnT = 0;
  dropIn = 0;
  hitSwing = -1;
  seed = Math.random() * 10;

  constructor(x: number, barY: number, rope: number) {
    this.x = x;
    this.barY = barY;
    this.rope = rope;
  }

  bodyPos(): { x: number; y: number } {
    const r = Math.max(6, this.rope - (this.dropIn > 0 ? this.dropIn * this.dropIn * 240 : 0));
    return {
      x: this.x + Math.sin(this.ang) * r,
      y: this.barY + Math.cos(this.ang) * r + this.bodyH / 2,
    };
  }

  cut() {
    this.state = 1;
    this.respawnT = 6.5;
    this.hitSwing = -1;
  }

  nudge(dirX: number) {
    this.av += dirX * 1.6;
  }

  update(dt: number) {
    if (this.state === 0) {
      this.av += (-Math.sin(this.ang) * 3.2 - this.av * 0.55) * dt;
      this.ang += this.av * dt;
      if (this.dropIn > 0) this.dropIn = Math.max(0, this.dropIn - dt);
    } else {
      this.respawnT -= dt;
      if (this.respawnT <= 0) {
        this.state = 0;
        this.ang = 0;
        this.av = (Math.random() - 0.5) * 3;
        this.dropIn = 0.55;
      }
    }
  }

  drawFrame(ctx: CanvasRenderingContext2D, groundY: number) {
    ctx.fillStyle = "#241a13";
    ctx.fillRect(this.x - 34, this.barY - 6, 8, groundY - this.barY + 6);
    ctx.fillRect(this.x + 26, this.barY - 6, 8, groundY - this.barY + 6);
    ctx.fillStyle = "#3b2c1f";
    ctx.fillRect(this.x - 44, this.barY - 8, 88, 8);
    ctx.fillStyle = "rgba(239,230,207,0.1)";
    ctx.fillRect(this.x - 44, this.barY - 8, 88, 1.5);
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.state === 1) {
      // dangling cut rope
      const sway = Math.sin(this.ang * 2 + this.respawnT * 4) * 4;
      ctx.strokeStyle = "#7a6a4f";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(this.x, this.barY);
      ctx.quadraticCurveTo(this.x + sway, this.barY + 10, this.x + sway * 1.4, this.barY + 18);
      ctx.stroke();
      return;
    }
    const pos = this.bodyPos();
    const topY = pos.y - this.bodyH / 2;
    // rope
    ctx.strokeStyle = "#7a6a4f";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(this.x, this.barY);
    ctx.lineTo(pos.x, topY + 2);
    ctx.stroke();

    ctx.save();
    ctx.translate(pos.x, pos.y);
    ctx.rotate(this.ang * 0.9);
    const w = this.bodyW;
    const h = this.bodyH;
    // bundle
    ctx.fillStyle = "#b98f3e";
    ctx.beginPath();
    ctx.roundRect(-w / 2, -h / 2, w, h, 8);
    ctx.fill();
    // straw texture
    ctx.strokeStyle = "rgba(122,92,38,0.8)";
    ctx.lineWidth = 1.2;
    for (let i = -3; i <= 3; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 3.4, -h / 2 + 4);
      ctx.lineTo(i * 3.4 + (i % 2) * 2, h / 2 - 4);
      ctx.stroke();
    }
    // binding bands
    ctx.fillStyle = "#43301f";
    ctx.fillRect(-w / 2 - 1.5, -h / 2 + 8, w + 3, 5);
    ctx.fillRect(-w / 2 - 1.5, h / 2 - 13, w + 3, 5);
    // highlight
    ctx.fillStyle = "rgba(239,230,207,0.16)";
    ctx.fillRect(-w / 2 + 3, -h / 2 + 2, 3, h - 4);
    ctx.restore();
  }
}

/* Particle system + screen shake. All particles live in world space. */

export type PType =
  | "spark"
  | "leaf"
  | "dust"
  | "petal"
  | "ring"
  | "chunk"
  | "glow"
  | "fly";

export interface Particle {
  type: PType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  g: number;
  drag: number;
  life: number;
  max: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  seed: number;
}

export class FX {
  list: Particle[] = [];
  shakeX = 0;
  shakeY = 0;
  private mag = 0;

  add(p: Partial<Particle> & { x: number; y: number; type: PType }) {
    if (this.list.length > 700) this.list.shift();
    this.list.push({
      vx: 0,
      vy: 0,
      g: 0,
      drag: 1,
      life: 1,
      max: 1,
      size: 3,
      rot: Math.random() * Math.PI * 2,
      vr: 0,
      color: "#efe6cf",
      seed: Math.random() * 100,
      ...p,
    });
  }

  sparks(x: number, y: number, dirX: number, power: number) {
    const n = 8 + power * 5;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 90 + Math.random() * (180 + power * 90);
      this.add({
        type: "spark",
        x, y,
        vx: Math.cos(a) * sp + dirX * 120,
        vy: Math.sin(a) * sp - 60,
        g: 700,
        drag: 0.985,
        life: 0.25 + Math.random() * 0.3,
        max: 0.55,
        size: 1.5 + Math.random() * 2,
        color: Math.random() < 0.4 ? "#ffd9a0" : "#fff6e0",
      });
    }
    this.add({ type: "glow", x, y, life: 0.18, max: 0.18, size: 46 + power * 16, color: "#fff2d8" });
  }

  leafBits(x: number, y: number, dirX: number, n = 10) {
    for (let i = 0; i < n; i++) {
      this.add({
        type: "leaf",
        x: x + (Math.random() - 0.5) * 14,
        y: y - Math.random() * 30,
        vx: dirX * (60 + Math.random() * 160) + (Math.random() - 0.5) * 90,
        vy: -60 - Math.random() * 160,
        g: 520,
        drag: 0.99,
        life: 0.9 + Math.random() * 0.9,
        max: 1.8,
        size: 3 + Math.random() * 4,
        vr: (Math.random() - 0.5) * 14,
        color: Math.random() < 0.5 ? "#3f7d46" : "#6fae5c",
      });
    }
  }

  strawBits(x: number, y: number, dirX: number) {
    for (let i = 0; i < 16; i++) {
      this.add({
        type: "leaf",
        x: x + (Math.random() - 0.5) * 20,
        y: y + (Math.random() - 0.5) * 30,
        vx: dirX * (80 + Math.random() * 190),
        vy: -80 - Math.random() * 200,
        g: 640,
        drag: 0.988,
        life: 1 + Math.random(),
        max: 2,
        size: 2.5 + Math.random() * 3.5,
        vr: (Math.random() - 0.5) * 18,
        color: Math.random() < 0.6 ? "#c9a227" : "#a8862c",
      });
    }
  }

  dust(x: number, y: number, n = 6, spread = 60) {
    for (let i = 0; i < n; i++) {
      this.add({
        type: "dust",
        x: x + (Math.random() - 0.5) * 16,
        y: y - Math.random() * 4,
        vx: (Math.random() - 0.5) * spread * 2,
        vy: -14 - Math.random() * 34,
        g: -18,
        drag: 0.96,
        life: 0.5 + Math.random() * 0.5,
        max: 1,
        size: 3 + Math.random() * 5,
        color: "#8b7f66",
      });
    }
  }

  ring(x: number, y: number, size = 90, color = "#fff2d8") {
    this.add({ type: "ring", x, y, life: 0.32, max: 0.32, size, color });
  }

  petal(x: number, y: number) {
    this.add({
      type: "petal",
      x, y,
      vx: -18 - Math.random() * 22,
      vy: 16 + Math.random() * 22,
      g: 6,
      drag: 1,
      life: 9 + Math.random() * 5,
      max: 14,
      size: 2.6 + Math.random() * 2.4,
      vr: (Math.random() - 0.5) * 4,
      color: Math.random() < 0.75 ? "#d96a55" : "#e8a08f",
    });
  }

  firefly(x: number, y: number) {
    this.add({
      type: "fly",
      x, y,
      vx: 0,
      vy: 0,
      life: 6 + Math.random() * 5,
      max: 11,
      size: 1.6 + Math.random() * 1.2,
      color: "#ffe9a3",
    });
  }

  update(dt: number, t: number) {
    const L = this.list;
    for (let i = L.length - 1; i >= 0; i--) {
      const p = L[i];
      p.life -= dt;
      if (p.life <= 0) {
        L.splice(i, 1);
        continue;
      }
      if (p.type === "petal") {
        p.x += (p.vx + Math.sin(t * 1.7 + p.seed) * 26) * dt;
        p.y += (p.vy + Math.cos(t * 1.3 + p.seed) * 10) * dt;
        p.rot += p.vr * dt;
      } else if (p.type === "fly") {
        p.x += Math.sin(t * 0.9 + p.seed) * 22 * dt + Math.sin(p.seed * 7) * 8 * dt;
        p.y += Math.cos(t * 0.7 + p.seed * 2) * 18 * dt;
      } else {
        p.vy += p.g * dt;
        p.vx *= Math.pow(p.drag, dt * 60);
        p.vy *= Math.pow(p.drag, dt * 60);
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vr * dt;
      }
    }
  }

  addShake(m: number) {
    this.mag = Math.min(22, Math.max(this.mag, m));
  }

  updateShake(dt: number) {
    this.mag = Math.max(0, this.mag - dt * 26 - this.mag * 6 * dt);
    this.shakeX = (Math.random() * 2 - 1) * this.mag;
    this.shakeY = (Math.random() * 2 - 1) * this.mag * 0.7;
  }

  draw(ctx: CanvasRenderingContext2D) {
    for (const p of this.list) {
      const a = Math.max(0, Math.min(1, p.life / p.max));
      ctx.save();
      switch (p.type) {
        case "spark": {
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = a;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size;
          ctx.lineCap = "round";
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03);
          ctx.stroke();
          break;
        }
        case "glow": {
          ctx.globalCompositeOperation = "lighter";
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
          g.addColorStop(0, "rgba(255,244,216," + (0.5 * a).toFixed(3) + ")");
          g.addColorStop(1, "rgba(255,244,216,0)");
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "ring": {
          ctx.globalCompositeOperation = "lighter";
          const r = (1 - a) * p.size + 8;
          ctx.globalAlpha = a * 0.8;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 3 + a * 5;
          ctx.beginPath();
          ctx.ellipse(p.x, p.y, r, r * 0.38, 0, 0, Math.PI * 2);
          ctx.stroke();
          break;
        }
        case "leaf":
        case "chunk": {
          ctx.globalAlpha = Math.min(1, a * 1.6);
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
          break;
        }
        case "dust": {
          ctx.globalAlpha = a * 0.35;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (1.6 - a * 0.6), 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "petal": {
          ctx.globalAlpha = Math.min(1, a * 3) * 0.85;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.ellipse(0, 0, p.size, p.size * 0.55, 0, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "fly": {
          const tw = 0.5 + 0.5 * Math.sin(p.seed * 40 + p.life * 5);
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = a * tw;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = a * tw * 0.35;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 4, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
      }
      ctx.restore();
    }
  }
}

/* Stickman kenjutsu animation state machine: procedural skeleton + katana. */

import type { SFX } from "./audio";
import type { FX } from "./effects";
import type { Platform } from "./entities";

export interface InputFrame {
  left: boolean;
  right: boolean;
  run: boolean;
  jump: boolean; // held
  jumpPressed: boolean; // edge this frame
  down: boolean;
  aimWX: number;
  aimWY: number;
}

interface V2 {
  x: number;
  y: number;
}

export type MoveId =
  | "draw"
  | "combo1"
  | "combo2"
  | "combo3"
  | "heavy"
  | "spin"
  | "air"
  | "iaido"
  | "dive";

interface MoveDef {
  id: MoveId;
  dur: number;
  windup: number; // fraction before sweep starts
  end: number; // fraction where hit window closes
  range: number;
  power: number;
  hitstop: number; // ms
  shake: number;
  impulse: number;
  from: number;
  to: number;
  whoosh: "light" | "heavy" | "spin" | "air" | "dive";
  radial?: boolean;
  world?: boolean;
}

/** moves that auto-dash toward a locked target, Ninja Gaiden style */
export const HOMING_MOVES: ReadonlySet<MoveId> = new Set([
  "draw",
  "combo1",
  "combo2",
  "combo3",
  "heavy",
  "air",
  "iaido",
]);

const MOVES: Record<MoveId, MoveDef> = {
  draw: { id: "draw", dur: 0.24, windup: 0.1, end: 0.72, range: 118, power: 2, hitstop: 60, shake: 4, impulse: 150, from: 2.85, to: 0.05, whoosh: "light" },
  combo1: { id: "combo1", dur: 0.26, windup: 0.13, end: 0.75, range: 100, power: 1, hitstop: 45, shake: 3.5, impulse: 185, from: -2.15, to: 1.2, whoosh: "light" },
  combo2: { id: "combo2", dur: 0.26, windup: 0.12, end: 0.75, range: 100, power: 1, hitstop: 45, shake: 3.5, impulse: 165, from: 2.35, to: -1.05, whoosh: "light" },
  combo3: { id: "combo3", dur: 0.36, windup: 0.11, end: 0.8, range: 112, power: 2, hitstop: 60, shake: 6, impulse: 260, from: 2.9, to: -2.9, whoosh: "spin" },
  heavy: { id: "heavy", dur: 0.46, windup: 0.4, end: 0.74, range: 124, power: 3, hitstop: 95, shake: 9, impulse: 250, from: -2.5, to: 1.6, whoosh: "heavy" },
  spin: { id: "spin", dur: 0.5, windup: 0.09, end: 0.86, range: 98, power: 2, hitstop: 55, shake: 5, impulse: 70, from: 2.6, to: -3.75, whoosh: "spin", radial: true, world: true },
  air: { id: "air", dur: 0.3, windup: 0.12, end: 0.76, range: 104, power: 2, hitstop: 55, shake: 4, impulse: 110, from: -2.05, to: 2.1, whoosh: "air" },
  iaido: { id: "iaido", dur: 0.34, windup: 0.16, end: 0.62, range: 62, power: 2, hitstop: 70, shake: 6, impulse: 0, from: 3.1, to: 0, whoosh: "light" },
  dive: { id: "dive", dur: 999, windup: 0, end: 1, range: 112, power: 3, hitstop: 90, shake: 10, impulse: 0, from: 1.35, to: 1.6, whoosh: "dive" },
};

export interface HitInfo {
  kind: "seg" | "radial" | "line";
  gx: number;
  gy: number;
  tx: number;
  ty: number;
  cx: number;
  cy: number;
  range: number;
  power: number;
  swingId: number;
  moveId: MoveId;
}

interface TrailPt {
  x: number;
  y: number;
  age: number;
  max: number;
}

interface After {
  pts: number[];
  blade: number[];
  age: number;
  max: number;
}

interface RibbonPt {
  x: number;
  y: number;
  px: number;
  py: number;
}

const BLADE = 66;
const THIGH = 22;
const SHIN = 22;
const UARM = 14;
const FARM = 13;

function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}
function approach(v: number, target: number, delta: number): number {
  return v < target ? Math.min(v + delta, target) : Math.max(v - delta, target);
}
function normAng(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}
function lerpAng(a: number, b: number, t: number): number {
  return a + normAng(b - a) * t;
}
function easeOutPow(t: number, p: number): number {
  return 1 - Math.pow(1 - clamp(t, 0, 1), p);
}

function ik(ax: number, ay: number, bx: number, by: number, l1: number, l2: number, bend: number): V2 {
  let dx = bx - ax;
  let dy = by - ay;
  let d = Math.hypot(dx, dy);
  const maxd = (l1 + l2) * 0.999;
  if (d > maxd) {
    dx *= maxd / d;
    dy *= maxd / d;
    d = maxd;
  }
  const mind = Math.abs(l1 - l2) + 0.6;
  if (d < mind) {
    const s = mind / Math.max(d, 0.001);
    dx *= s;
    dy *= s;
    d = mind;
  }
  const a1 = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
  const base = Math.atan2(dy, dx);
  const ang = base + bend * a1;
  return { x: ax + Math.cos(ang) * l1, y: ay + Math.sin(ang) * l1 };
}

export class Player {
  x = 260;
  y = 0; // feet
  vx = 0;
  vy = 0;
  facing = 1;
  grounded = true;
  private coyote = 0;
  animT = 0;
  private walkPh = 0;
  private squash = 0;
  private stepT = 0;

  state: "idle" | "move" | "jump" | "slash" = "idle";
  move: MoveDef | null = null;
  moveT = 0;
  swingId = 0;
  /** world point of the target being homed onto (set by game) */
  lockTarget: { x: number; y: number } | null = null;
  private whooshed = false;
  private comboIdx = 0;
  private comboTimer = 0;
  private buffered: MoveId | null = null;
  private idleTime = 0;
  sheathed = true;
  private dashStartX = 0;
  private diveLanded = false;
  private glintT = 0;
  private trailRecT = 0;
  private afterRecT = 0;
  private bladeStartAng = 0;
  private ghosts: { gx: number; gy: number; tx: number; ty: number; s: number }[] = [];

  private aimW = 0;
  private bladeAngLocal = 0.5;
  private bladeScale = 1;

  // local pose (facing right, origin at feet)
  private hipX = 0;
  private hipY = -42;
  private neckX = 3;
  private neckY = -72;
  private headX = 5;
  private headY = -81;
  private eB: V2 = { x: 0, y: 0 };
  private hB: V2 = { x: 0, y: 0 };
  private eF: V2 = { x: 0, y: 0 };
  private hF: V2 = { x: 0, y: 0 };
  private kB: V2 = { x: 0, y: 0 };
  private fB: V2 = { x: -8, y: 0 };
  private kF: V2 = { x: 0, y: 0 };
  private fF: V2 = { x: 10, y: 0 };
  private gripX = 14;
  private gripY = -54;

  private headband: RibbonPt[] = [];
  private sashA: RibbonPt[] = [];
  private sashB: RibbonPt[] = [];
  private trail: TrailPt[] = [];
  private after: After[] = [];

  constructor() {
    this.initRibbons();
  }

  private initRibbons() {
    this.headband = [];
    this.sashA = [];
    this.sashB = [];
    for (let i = 0; i < 10; i++) {
      this.headband.push({ x: this.x - 6 - i * 6, y: this.y - 82, px: this.x - 6 - i * 6, py: this.y - 82 });
    }
    for (let i = 0; i < 6; i++) {
      this.sashA.push({ x: this.x - 4 - i * 5, y: this.y - 42, px: this.x - 4 - i * 5, py: this.y - 42 });
      this.sashB.push({ x: this.x - 4 - i * 5, y: this.y - 40, px: this.x - 4 - i * 5, py: this.y - 40 });
    }
  }

  reset(x: number, groundY: number) {
    this.x = x;
    this.y = groundY;
    this.vx = 0;
    this.vy = 0;
    this.facing = 1;
    this.grounded = true;
    this.state = "idle";
    this.move = null;
    this.sheathed = true;
    this.comboIdx = 0;
    this.comboTimer = 0;
    this.buffered = null;
    this.trail = [];
    this.after = [];
    this.squash = 0;
    this.aimW = 0;
    this.idleTime = 0;
    this.initRibbons();
  }

  private nextCombo(): MoveId {
    if (this.comboTimer > 0 && this.comboIdx >= 1 && this.comboIdx <= 2) {
      return ("combo" + (this.comboIdx + 1)) as MoveId;
    }
    return "combo1";
  }

  tryAttack(kind: "light" | "heavy" | "iaido" | "spin", input: InputFrame, sfx: SFX) {
    if (this.state === "slash" && this.move) {
      const ph = this.moveT / this.move.dur;
      if (kind === "light" && ph > 0.5) this.buffered = this.nextCombo();
      else if (kind === "spin" && ph > 0.6) this.buffered = "spin";
      return;
    }
    if (this.sheathed) {
      this.startMove("draw");
      sfx.iaido();
      return;
    }
    if (!this.grounded) {
      if (input.down) {
        this.startMove("dive");
        this.vy = Math.max(this.vy, 720);
        return;
      }
      this.startMove("air");
      return;
    }
    if (kind === "light") this.startMove(this.nextCombo());
    else if (kind === "heavy") this.startMove("heavy");
    else if (kind === "iaido") this.startMove("iaido");
    else this.startMove("spin");
  }

  private startMove(id: MoveId) {
    this.move = MOVES[id];
    // capture current blade angle so the swing eases out of it (no teleport)
    this.bladeStartAng = this.move.world
      ? this.facing === 1
        ? this.bladeAngLocal
        : Math.PI - this.bladeAngLocal
      : this.bladeAngLocal;
    this.moveT = 0;
    this.state = "slash";
    this.whooshed = false;
    this.swingId++;
    this.buffered = null;
    this.idleTime = 0;
    this.trailRecT = 0;
    this.afterRecT = 0;
    this.ghosts = [];
    this.lockTarget = null;
    if (id === "draw") this.sheathed = false;
    if (id === "iaido") this.dashStartX = this.x;
    if (id === "dive") this.diveLanded = false;
    if (id === "combo1") this.comboIdx = 1;
    else if (id === "combo2") this.comboIdx = 2;
    else if (id === "combo3") this.comboIdx = 3;
    else this.comboIdx = 0;
  }

  /** called by game when a dive-slam touched ground */
  notifyGrounded() {
    if (this.move && this.move.id === "dive") this.diveLanded = true;
  }

  consumeDiveLand(): boolean {
    if (this.diveLanded) {
      this.diveLanded = false;
      return true;
    }
    return false;
  }

  onHitConfirmed() {
    this.glintT = 0.18;
  }

  getHitInfo(): HitInfo | null {
    const m = this.move;
    if (!m || m.id === "dive" || !this.whooshed) return null;
    const ph = this.moveT / m.dur;
    if (ph < m.windup * 0.6 || ph > m.end) return null;
    const chest = { x: this.x, y: this.y - 56 };
    if (m.radial) {
      return { kind: "radial", gx: 0, gy: 0, tx: 0, ty: 0, cx: chest.x, cy: chest.y, range: m.range, power: m.power, swingId: this.swingId, moveId: m.id };
    }
    if (m.id === "iaido") {
      // hit rect swept by the dash: gx..tx horizontally, gy..ty vertically
      const x0 = Math.min(this.dashStartX, this.x) - 10;
      const x1 = Math.max(this.dashStartX, this.x) + this.facing * 44;
      return {
        kind: "line",
        gx: Math.min(x0, x1),
        gy: chest.y - 52,
        tx: Math.max(x0, x1),
        ty: chest.y + 52,
        cx: chest.x,
        cy: chest.y,
        range: m.range,
        power: m.power,
        swingId: this.swingId,
        moveId: m.id,
      };
    }
    const b = this.bladeWorld();
    return { kind: "seg", gx: b.gx, gy: b.gy, tx: b.tx, ty: b.ty, cx: chest.x, cy: chest.y, range: m.range, power: m.power, swingId: this.swingId, moveId: m.id };
  }

  private bladeWorld(): { gx: number; gy: number; tx: number; ty: number; ang: number } {
    const f = this.facing;
    const m = this.move;
    let ang: number;
    if (m && m.world) ang = this.bladeAngLocal; // already world
    else ang = f === 1 ? this.bladeAngLocal : Math.PI - this.bladeAngLocal;
    const gx = this.x + this.gripX * f;
    const gy = this.y + this.gripY;
    const len = BLADE * this.bladeScale;
    return { gx, gy, tx: gx + Math.cos(ang) * len, ty: gy + Math.sin(ang) * len, ang };
  }

  update(
    dt: number,
    input: InputFrame,
    groundY: number,
    platforms: Platform[],
    t: number,
    sfx: SFX,
    fx: FX
  ) {
    this.animT += dt;
    this.glintT = Math.max(0, this.glintT - dt);

    // ------- move progression -------
    if (this.state === "slash" && this.move) {
      const m = this.move;
      this.moveT += dt;
      const ph = this.moveT / m.dur;
      if (!this.whooshed && ph >= m.windup) {
        this.whooshed = true;
        sfx.whoosh(m.whoosh, 1 + this.comboIdx * 0.1);
        if (m.id === "iaido") {
          this.vx = this.facing * 740;
        } else {
          this.vx += this.facing * m.impulse;
        }
        this.vx = clamp(this.vx, -960, 960);
      }
      if (m.id === "dive" && this.diveLanded) {
        this.endMove();
      } else if (ph >= 1 && m.id !== "dive") {
        this.endMove();
        if (this.buffered) {
          const b = this.buffered;
          this.startMove(b);
        }
      }
    }

    // ------- horizontal movement -------
    const attacking = this.state === "slash";
    const dir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    const run = input.run && dir !== 0;
    const crouching = input.down && this.grounded && !attacking;
    if (!attacking || (this.move && (this.move.id === "air" || this.move.id === "spin"))) {
      if (dir !== 0) {
        const maxV = crouching ? 84 : run ? 335 : 168;
        this.vx = approach(this.vx, dir * maxV, (this.grounded ? 2400 : 1300) * dt);
        if (!attacking) this.facing = dir;
      } else if (!attacking) {
        this.vx = approach(this.vx, 0, (this.grounded ? 2100 : 350) * dt);
      }
    } else if (attacking && this.grounded && this.move && this.move.id !== "iaido") {
      // slashing keeps your momentum — you can fight at full sprint
      if (dir !== 0) {
        this.vx = approach(this.vx, dir * (run ? 320 : 160), 1100 * dt);
      } else if (!this.lockTarget) {
        this.vx = approach(this.vx, 0, 620 * dt); // gentle glide, not a skid
      }
    }

    // ------- homing dash toward locked target (Ninja Gaiden style) -------
    if (attacking && this.move && this.lockTarget && HOMING_MOVES.has(this.move.id)) {
      const m = this.move;
      const ph = this.moveT / m.dur;
      const winStart = m.windup * 0.4;
      if (ph >= winStart && ph <= m.end) {
        const dxRaw = this.lockTarget.x - this.x;
        const reach = m.id === "iaido" ? 6 : 60;
        const dx = dxRaw - Math.sign(dxRaw) * Math.min(reach, Math.abs(dxRaw));
        const timeLeft = Math.max(0.05, (m.end - ph) * m.dur);
        const v = clamp(dx / timeLeft, -960, 960);
        const accel = this.grounded ? 5600 : 2800;
        this.vx = approach(this.vx, v, accel * dt);
        if (Math.abs(dxRaw) > 14) this.facing = dxRaw >= 0 ? 1 : -1;
      }
    }

    // ------- jump -------
    this.coyote = this.grounded ? 0.09 : Math.max(0, this.coyote - dt);
    if (input.jumpPressed && !attacking && (this.grounded || this.coyote > 0)) {
      this.vy = -(run ? 665 : 605);
      this.grounded = false;
      this.coyote = 0;
      sfx.jump();
      fx.dust(this.x, this.y, 5, 40);
    }
    if (!input.jump && this.vy < -230) this.vy = -230;

    // ------- gravity & integrate -------
    const wasGrounded = this.grounded;
    const prevY = this.y;
    this.vy = Math.min(1250, this.vy + 1500 * dt);
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    // ground
    this.grounded = false;
    if (this.y >= groundY) {
      this.y = groundY;
      if (this.vy > 0) this.vy = 0;
      this.grounded = true;
    }
    // one-way platforms
    for (const p of platforms) {
      if (
        this.vy >= 0 &&
        prevY <= p.y + 0.5 &&
        this.y >= p.y &&
        this.x > p.x - 8 &&
        this.x < p.x + p.w + 8
      ) {
        this.y = p.y;
        this.vy = 0;
        this.grounded = true;
      }
    }
    if (this.grounded && !wasGrounded) {
      const impact = Math.abs(this.vy);
      this.squash = clamp(impact / 850, 0.25, 1);
      sfx.land(impact > 420);
      if (impact > 320) fx.dust(this.x, this.y, 7, 70);
      if (this.move && this.move.id === "dive") this.notifyGrounded();
    }

    // walk cycle + footsteps
    const speed = Math.abs(this.vx);
    this.walkPh += speed * dt * 0.052;
    if (this.grounded && !attacking && speed > 110) {
      this.stepT -= dt;
      if (this.stepT <= 0) {
        this.stepT = run ? 0.24 : 0.38;
        sfx.step(run);
        fx.dust(this.x - this.facing * 8, this.y, 2, 24);
      }
    }

    this.squash = Math.max(0, this.squash - dt * 4.2);
    this.comboTimer = Math.max(0, this.comboTimer - dt);
    if (this.comboTimer === 0 && this.state !== "slash") this.comboIdx = 0;

    // resheathe after long idle
    if (!this.sheathed && !attacking && speed < 20) {
      this.idleTime += dt;
      if (this.idleTime > 5) {
        this.sheathed = true;
        sfx.sheathe();
      }
    } else if (speed >= 20 || attacking) {
      this.idleTime = 0;
    }

    // ------- aim -------
    const targetAim = Math.atan2(input.aimWY - (this.y - 58), input.aimWX - this.x);
    this.aimW = lerpAng(this.aimW, targetAim, 1 - Math.pow(0.0001, dt));

    // ------- pose & blade -------
    this.computePose(input, run, attacking, t);

    // ------- trail recording -------
    for (const tp of this.trail) tp.age += dt;
    this.trail = this.trail.filter((tp) => tp.age < tp.max);
    if (attacking && this.move && this.whooshed) {
      const m = this.move;
      const ph = this.moveT / m.dur;
      if (ph <= m.end + 0.06) {
        this.trailRecT -= dt;
        if (this.trailRecT <= 0) {
          this.trailRecT = 0.01;
          const b = this.bladeWorld();
          this.trail.push({ x: b.tx, y: b.ty, age: 0, max: 0.42 });
          this.ghosts.push({ gx: b.gx, gy: b.gy, tx: b.tx, ty: b.ty, s: this.bladeScale });
          if (this.ghosts.length > 6) this.ghosts.shift();
        }
      } else if (this.ghosts.length > 0) {
        this.ghosts.shift();
      }
    } else if (this.ghosts.length > 0) {
      this.ghosts.shift();
    }

    // ------- afterimages -------
    for (const a of this.after) a.age += dt;
    this.after = this.after.filter((a) => a.age < a.max);
    const homingDash = !!(this.lockTarget && this.move && HOMING_MOVES.has(this.move.id));
    if (attacking && this.move && (homingDash || this.move.id === "iaido" || this.move.id === "spin" || this.move.id === "combo3" || this.move.id === "draw")) {
      this.afterRecT -= dt;
      if (this.afterRecT <= 0) {
        this.afterRecT = 0.034;
        const f = this.facing;
        const M = (lx: number, ly: number) => [this.x + lx * f, this.y + ly] as number[];
        const b = this.bladeWorld();
        this.after.push({
          pts: [
            ...M(this.hipX, this.hipY), ...M(this.neckX, this.neckY), ...M(this.headX, this.headY),
            ...M(this.eF.x, this.eF.y), ...M(this.hF.x, this.hF.y), ...M(this.kF.x, this.kF.y), ...M(this.fF.x, this.fF.y),
          ],
          blade: [b.gx, b.gy, b.tx, b.ty],
          age: 0,
          max: 0.3,
        });
      }
    }

    // ------- ribbons (verlet) -------
    this.updateRibbon(this.headband, this.x + this.headX * this.facing - this.facing * 6, this.y + this.headY - 1, 6.2, t, 1);
    this.updateRibbon(this.sashA, this.x + this.hipX * this.facing - this.facing * 3, this.y + this.hipY + 2, 5, t, 0.8);
    this.updateRibbon(this.sashB, this.x + this.hipX * this.facing - this.facing * 2, this.y + this.hipY + 3, 5, t + 2, 0.7);
  }

  private endMove() {
    if (this.move) this.comboTimer = 0.95;
    this.move = null;
    this.lockTarget = null;
    this.state = this.grounded ? (Math.abs(this.vx) > 40 ? "move" : "idle") : "jump";
  }

  private updateRibbon(r: RibbonPt[], ax: number, ay: number, seg: number, t: number, windK: number) {
    if (r.length === 0) return;
    r[0].x = ax;
    r[0].y = ay;
    r[0].px = ax;
    r[0].py = ay;
    const windX = -this.facing * (10 + Math.abs(this.vx) * 0.28) * windK + Math.sin(t * 2.6) * 12;
    const windY = Math.sin(t * 3.4 + 1) * 8 - 4;
    for (let i = 1; i < r.length; i++) {
      const p = r[i];
      const vx = (p.x - p.px) * 0.88 + windX * 0.016;
      const vy = (p.y - p.py) * 0.88 + windY * 0.016 + 0.14;
      p.px = p.x;
      p.py = p.y;
      p.x += vx;
      p.y += vy;
    }
    for (let k = 0; k < 3; k++) {
      for (let i = 1; i < r.length; i++) {
        const a = r[i - 1];
        const b = r[i];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.max(0.001, Math.hypot(dx, dy));
        const diff = (d - seg) / d;
        b.x -= dx * diff;
        b.y -= dy * diff;
      }
    }
  }

  private computePose(input: InputFrame, run: boolean, attacking: boolean, t: number) {
    const m = this.move;
    let hipX = 0;
    let hipY = -42;
    let neckX = 3;
    let neckY = -72;
    let footF: V2 = { x: 10, y: 0 };
    let footB: V2 = { x: -9, y: 0 };
    let handF: V2 | null = null;
    let handB: V2 | null = null;

    const bob = Math.sin(this.animT * 2.1) * 1.4;
    const crouching = !attacking && input.down && this.grounded;

    if (!attacking) {
      if (!this.grounded) {
        // jump
        this.state = "jump";
        if (this.vy < 0) {
          footF = { x: 11, y: -13 };
          footB = { x: -9, y: -6 };
        } else {
          footF = { x: 13, y: -5 };
          footB = { x: -11, y: -9 };
        }
        hipY = -44;
        neckX = 5;
        neckY = -73;
      } else if (crouching) {
        // low guard stance
        this.state = "move";
        hipY = -30 + bob * 0.4;
        neckX = 9;
        neckY = -51 + bob * 0.6;
        footF = { x: 16, y: 0 };
        footB = { x: -13, y: 0 };
      } else if (Math.abs(this.vx) > 40) {
        // walk ↔ run blended by speed (smooth transition)
        this.state = "move";
        const ph = this.walkPh;
        const sp = Math.abs(this.vx);
        const runK = clamp((sp - 150) / 180, 0, 1);
        const stride = 13 + runK * 8;
        const lift = 5.5 + runK * 5;
        footF = { x: Math.sin(ph) * stride, y: -Math.max(0, Math.cos(ph)) * lift };
        footB = { x: Math.sin(ph + Math.PI) * stride, y: -Math.max(0, Math.cos(ph + Math.PI)) * lift };
        const lean = clamp(sp * 0.032, 0, 5 + runK * 9);
        hipY = -42 - Math.abs(Math.cos(ph)) * (1.8 + runK * 2);
        neckX = 3 + lean;
        neckY = hipY - 30;
        hipX = lean * 0.3;
      } else {
        // idle — weight shifting side to side
        this.state = "idle";
        const sway = Math.sin(this.animT * 1.15) * 1.3;
        hipY = -42 + bob * 0.5;
        hipX = sway * 0.7;
        neckX = 3 + bob * 0.25 + sway;
        neckY = -72 + bob;
        footF = { x: 11, y: 0 };
        footB = { x: -9, y: 0 };
      }
    } else if (m) {
      const ph = clamp(this.moveT / m.dur, 0, 1);
      const sw = clamp((ph - m.windup) / Math.max(0.001, m.end - m.windup), 0, 1);
      const e = easeOutPow(sw, 2.6);

      if (m.id === "iaido") {
        hipY = -40;
        neckX = 15 * e;
        neckY = -70;
        footF = { x: 25, y: 0 };
        footB = { x: -19, y: 0 };
        hipX = 4 * e;
      } else if (m.id === "spin") {
        hipY = -43;
        neckX = 2;
        neckY = -73;
        footF = { x: 9, y: -9 };
        footB = { x: -9, y: -5 };
      } else if (m.id === "dive") {
        hipY = -44;
        neckX = 8;
        neckY = -71;
        footF = { x: 7, y: -15 };
        footB = { x: -5, y: -11 };
      } else if (!this.grounded) {
        footF = { x: 12, y: -10 };
        footB = { x: -10, y: -6 };
        hipY = -44;
        neckX = 4 + 6 * e;
        neckY = -73;
      } else {
        // grounded slashes — each move gets its own stance & footwork
        let lean: number;
        if (ph < m.windup) lean = -9 * (ph / m.windup);
        else lean = -9 + 21 * e;
        if (ph > m.end) {
          // follow-through settle with a little rebound
          const r = (ph - m.end) / Math.max(0.001, 1 - m.end);
          lean = 12 - 6 * r + Math.sin(r * Math.PI * 1.4) * 2.5;
        }
        let hipDrop = 0;
        let fFx = 12 + 7 * e;
        let fBx = -10 - 6 * e;
        switch (m.id) {
          case "combo1": // stepping diagonal cut
            hipDrop = 1.5;
            fFx = 15 + 9 * e;
            fBx = -7 - 5 * e;
            break;
          case "combo2": // rising cut — weight low, torso leans back
            hipDrop = 6 + 2 * e;
            lean -= 5 * (1 - e * 0.6);
            fFx = 5 - 2 * e;
            fBx = -17 - 6 * e;
            break;
          case "combo3": // wide spinning sweep from a horse stance
            hipDrop = 4;
            fFx = 20;
            fBx = -20;
            lean = -14 + 32 * e;
            hipX = -5 + 11 * e;
            break;
          case "heavy": // deep crouch windup, explosive drop
            if (ph < m.windup) {
              const w = ph / m.windup;
              hipDrop = 9 * w;
              lean = -12 * w;
              fFx = 13;
              fBx = -15;
            } else {
              hipDrop = 9 - 4 * e;
              lean = -12 + 29 * e;
              fFx = 16 + 7 * e;
              fBx = -15 - 5 * e;
            }
            break;
        }
        neckX = 3 + lean;
        if (m.id !== "combo3") hipX = -2 + 7 * e;
        neckY = -72 + hipDrop * 0.9 - (ph < m.windup ? 3 * (ph / m.windup) : 3 * (1 - e));
        hipY = -42 + hipDrop;
        footF = { x: fFx, y: 0 };
        footB = { x: fBx, y: 0 };
      }

      // hands follow the blade during swings
      this.bladeLocal(m, ph, sw, e, input);
      const shX = neckX - 1;
      const shY = neckY + 5;
      const ang = this.bladeAngLocal;
      const gx = shX + Math.cos(ang) * 13;
      const gy = shY + Math.sin(ang) * 13;
      handF = { x: gx, y: gy };
      handB = { x: gx - Math.cos(ang) * 6.5, y: gy - Math.sin(ang) * 6.5 };
      this.gripX = gx;
      this.gripY = gy;
    }

    // idle / move hands
    if (!attacking) {
      if (this.sheathed) {
        handF = { x: 9 + bob * 0.3, y: -44 };
        handB = { x: -7, y: -32 + bob * 0.5 };
        this.gripX = handF.x;
        this.gripY = handF.y;
        const target = 2.62;
        this.bladeAngLocal = lerpAng(this.bladeAngLocal, target, 1 - Math.pow(0.001, 0.016));
        this.bladeScale = 1;
      } else if (this.state === "move") {
        // carried low while running
        const sway = Math.sin(this.walkPh) * 0.1;
        handF = { x: 6 + Math.sin(this.walkPh + Math.PI) * 6, y: -40 };
        handB = { x: -6 + Math.sin(this.walkPh) * 6, y: -38 };
        this.gripX = handF.x;
        this.gripY = handF.y;
        const f = this.facing;
        const target = f === 1 ? 2.45 + sway : 2.45 + sway;
        this.bladeAngLocal = lerpAng(this.bladeAngLocal, target, 1 - Math.pow(0.002, 0.016));
        this.bladeScale = 0.95;
      } else {
        // aim at mouse — chudan stance
        const f = this.facing;
        const local = f === 1 ? this.aimW : normAng(Math.PI - this.aimW);
        this.bladeAngLocal = lerpAng(this.bladeAngLocal, local, 1 - Math.pow(0.0005, 0.016));
        this.bladeScale = 1;
        const ang = this.bladeAngLocal;
        const shX = neckX - 1;
        const shY = neckY + 5;
        const gx = shX + Math.cos(ang) * 12;
        const gy = shY + Math.sin(ang) * 12;
        handF = { x: gx + Math.cos(ang) * 3, y: gy + Math.sin(ang) * 3 };
        handB = { x: gx - Math.cos(ang) * 4, y: gy - Math.sin(ang) * 4 };
        this.gripX = gx;
        this.gripY = gy;
      }
    }

    // squash (landing compression)
    hipY += 5 * this.squash;
    neckY += 10 * this.squash;

    this.hipX = hipX;
    this.hipY = hipY;
    this.neckX = neckX;
    this.neckY = neckY;
    this.headX = neckX + 2.5;
    this.headY = neckY - 9.5;
    this.fF = footF;
    this.fB = footB;
    this.kF = ik(hipX, hipY, footF.x, footF.y, THIGH, SHIN, -1);
    this.kB = ik(hipX, hipY, footB.x, footB.y, THIGH, SHIN, -1);

    const shBX = neckX - 3;
    const shBY = neckY + 4;
    const shFX = neckX + 1;
    const shFY = neckY + 4;
    if (handF && handB) {
      this.eF = ik(shFX, shFY, handF.x, handF.y, UARM, FARM, 1);
      this.eB = ik(shBX, shBY, handB.x, handB.y, UARM, FARM, 1);
      this.hF = handF;
      this.hB = handB;
    }
    void run;
    void t;
  }

  private bladeLocal(m: MoveDef, ph: number, sw: number, e: number, input: InputFrame) {
    void input;
    if (m.id === "iaido") {
      this.bladeAngLocal = 0.02;
      this.bladeScale = 0.14 + 0.86 * easeOutPow(clamp(sw * 1.35, 0, 1), 3.2);
      void ph;
      void e;
      return;
    }
    if (m.id === "dive") {
      this.bladeAngLocal = 1.5;
      this.bladeScale = 0.9;
      return;
    }
    if (m.world) {
      // spin: world-space angle, no mirror
      this.bladeAngLocal = m.from + (m.to - m.from) * (ph < m.windup ? 0 : e);
      this.bladeScale = 0.66 + 0.34 * Math.abs(Math.sin(sw * Math.PI * 1.2));
      return;
    }
    if (ph < m.windup) {
      // ease-in from wherever the blade was — no snap, the swing accelerates out
      const wt = ph / m.windup;
      const we = wt * wt;
      this.bladeAngLocal = this.bladeStartAng + normAng(m.from - this.bladeStartAng) * we;
      this.bladeScale = 0.82;
    } else {
      this.bladeAngLocal = m.from + (m.to - m.from) * e;
      // foreshortening mid-swing sells the 3D sweep
      this.bladeScale = 0.58 + 0.42 * Math.sin(Math.PI * sw);
    }
  }

  // ------------------------------------------------------------------ draw

  private M(lx: number, ly: number): [number, number] {
    return [this.x + lx * this.facing, this.y + ly];
  }

  draw(ctx: CanvasRenderingContext2D) {
    const f = this.facing;

    // afterimages
    for (const a of this.after) {
      const al = 1 - a.age / a.max;
      ctx.save();
      ctx.globalAlpha = al * 0.4;
      ctx.strokeStyle = "#c22f23";
      ctx.lineWidth = 3;
      ctx.lineCap = "round";
      ctx.beginPath();
      const P = a.pts;
      ctx.moveTo(P[0], P[1]);
      ctx.lineTo(P[2], P[3]);
      ctx.lineTo(P[4], P[5]); // hip -> neck -> head
      ctx.moveTo(P[0], P[1]);
      ctx.lineTo(P[10], P[11]);
      ctx.lineTo(P[12], P[13]); // hip -> kneeF -> footF
      ctx.moveTo(P[2], P[3]);
      ctx.lineTo(P[6], P[7]);
      ctx.lineTo(P[8], P[9]); // neck -> elbowF -> handF
      ctx.stroke();
      ctx.globalAlpha = al * 0.55;
      ctx.strokeStyle = "#f2ede0";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(a.blade[0], a.blade[1]);
      ctx.lineTo(a.blade[2], a.blade[3]);
      ctx.stroke();
      ctx.restore();
    }

    // sash ribbons
    this.drawRibbon(ctx, this.sashA, 4.5, "#a3271c");
    this.drawRibbon(ctx, this.sashB, 3.5, "#7e1d15");

    // ------- body -------
    const pass = (color: string, lw: number) => {
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = lw;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      const M = (lx: number, ly: number): [number, number] => [this.x + lx * f, this.y + ly];
      const seg = (a: [number, number], b: [number, number]) => {
        ctx.beginPath();
        ctx.moveTo(a[0], a[1]);
        ctx.lineTo(b[0], b[1]);
        ctx.stroke();
      };
      const hip = M(this.hipX, this.hipY);
      const neck = M(this.neckX, this.neckY);
      const head = M(this.headX, this.headY);
      // back limbs
      seg(neck, M(this.eB.x, this.eB.y));
      seg(M(this.eB.x, this.eB.y), M(this.hB.x, this.hB.y));
      seg(hip, M(this.kB.x, this.kB.y));
      seg(M(this.kB.x, this.kB.y), M(this.fB.x, this.fB.y));
      // torso
      seg(hip, neck);
      // head
      ctx.beginPath();
      ctx.arc(head[0], head[1], 7.6, 0, Math.PI * 2);
      ctx.fill();
      // front leg
      seg(hip, M(this.kF.x, this.kF.y));
      seg(M(this.kF.x, this.kF.y), M(this.fF.x, this.fF.y));
      // front arm
      seg(neck, M(this.eF.x, this.eF.y));
      seg(M(this.eF.x, this.eF.y), M(this.hF.x, this.hF.y));
    };
    pass("rgba(222,210,182,0.3)", 8.4); // rim light
    pass("#141922", 4.8); // body

    // face details
    const head = this.M(this.headX, this.headY);
    ctx.strokeStyle = "#c22f23";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(head[0] - 5.5 * f, head[1] - 2.6);
    ctx.lineTo(head[0] + 6 * f, head[1] - 2.6);
    ctx.stroke();
    ctx.strokeStyle = "#efe6cf";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(head[0] + 1.5 * f, head[1] - 0.4);
    ctx.lineTo(head[0] + 5.8 * f, head[1] - 0.6);
    ctx.stroke();

    // ------- katana -------
    this.drawKatana(ctx);

    // fists over the grip
    ctx.fillStyle = "#141922";
    const hf = this.M(this.hF.x, this.hF.y);
    const hb = this.M(this.hB.x, this.hB.y);
    ctx.beginPath();
    ctx.arc(hf[0], hf[1], 3.4, 0, Math.PI * 2);
    ctx.arc(hb[0], hb[1], 3.2, 0, Math.PI * 2);
    ctx.fill();

    // headband on top
    this.drawRibbon(ctx, this.headband, 5, "#c22f23");
  }

  private drawRibbon(ctx: CanvasRenderingContext2D, r: RibbonPt[], w: number, color: string) {
    if (r.length < 2) return;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineCap = "round";
    for (let i = 1; i < r.length; i++) {
      ctx.lineWidth = Math.max(0.6, w * (1 - i / r.length));
      ctx.beginPath();
      ctx.moveTo(r[i - 1].x, r[i - 1].y);
      ctx.lineTo(r[i].x, r[i].y);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawKatana(ctx: CanvasRenderingContext2D) {
    const f = this.facing;

    // sheathed: saya at hip + hilt poking forward
    if (this.sheathed) {
      const hipW = this.M(this.hipX - 2, this.hipY + 2);
      const a = f === 1 ? 2.62 : Math.PI - 2.62;
      const dx = Math.cos(a);
      const dy = Math.sin(a);
      ctx.save();
      ctx.lineCap = "round";
      ctx.strokeStyle = "#241318";
      ctx.lineWidth = 5.4;
      ctx.beginPath();
      ctx.moveTo(hipW[0] - dx * 6, hipW[1] - dy * 6);
      ctx.lineTo(hipW[0] + dx * 52, hipW[1] + dy * 52);
      ctx.stroke();
      ctx.strokeStyle = "rgba(239,230,207,0.14)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(hipW[0] - dx * 5, hipW[1] - dy * 5 - 1.6);
      ctx.lineTo(hipW[0] + dx * 50, hipW[1] + dy * 50 - 1.6);
      ctx.stroke();
      // hilt
      ctx.strokeStyle = "#2b303c";
      ctx.lineWidth = 4.6;
      ctx.beginPath();
      ctx.moveTo(hipW[0] - dx * 4, hipW[1] - dy * 4);
      ctx.lineTo(hipW[0] - dx * 20, hipW[1] - dy * 20);
      ctx.stroke();
      ctx.fillStyle = "#c9a227";
      ctx.beginPath();
      ctx.arc(hipW[0] - dx * 5, hipW[1] - dy * 5, 3.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    const b = this.bladeWorld();
    const dx = Math.cos(b.ang);
    const dy = Math.sin(b.ang);
    const px = -dy;
    const py = dx;
    const len = BLADE * this.bladeScale;
    const baseX = b.gx + dx * 2;
    const baseY = b.gy + dy * 2;
    const tipX = b.gx + dx * (len + 2);
    const tipY = b.gy + dy * (len + 2);
    const bow = 4.5 * this.bladeScale;
    const halfW = 1.1 + 1.9 * this.bladeScale;

    ctx.save();
    ctx.lineCap = "round";

    // tsuka (handle)
    ctx.strokeStyle = "#23262f";
    ctx.lineWidth = 4.6;
    ctx.beginPath();
    ctx.moveTo(b.gx - dx * 15, b.gy - dy * 15);
    ctx.lineTo(b.gx + dx * 2, b.gy + dy * 2);
    ctx.stroke();
    // tsuka wrap ticks
    ctx.strokeStyle = "rgba(239,230,207,0.5)";
    ctx.lineWidth = 1;
    for (let k = 1; k <= 3; k++) {
      const wx = b.gx - dx * (k * 4);
      const wy = b.gy - dy * (k * 4);
      ctx.beginPath();
      ctx.moveTo(wx - px * 2.4, wy - py * 2.4);
      ctx.lineTo(wx + px * 2.4, wy + py * 2.4);
      ctx.stroke();
    }
    // tsuba
    ctx.fillStyle = "#c9a227";
    ctx.strokeStyle = "#6e5614";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(b.gx + dx * 1, b.gy + dy * 1, 4.4, 3.4, b.ang + Math.PI / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // blade — slight curve, gradient steel
    const midX = (baseX + tipX) / 2 + px * bow;
    const midY = (baseY + tipY) / 2 + py * bow;
    const grad = ctx.createLinearGradient(baseX, baseY, tipX, tipY);
    grad.addColorStop(0, "#f4f7fa");
    grad.addColorStop(0.55, "#c6d0de");
    grad.addColorStop(1, "#93a5bb");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(baseX + px * halfW, baseY + py * halfW);
    ctx.quadraticCurveTo(midX + px * halfW * 0.7, midY + py * halfW * 0.7, tipX + px * 1.1, tipY + py * 1.1);
    ctx.lineTo(tipX - px * 0.9, tipY - py * 0.9);
    ctx.lineTo(baseX - px * halfW, baseY - py * halfW);
    ctx.closePath();
    ctx.fill();
    // cutting edge highlight
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(baseX - px * halfW, baseY - py * halfW);
    ctx.lineTo(tipX - px * 0.9, tipY - py * 0.9);
    ctx.stroke();
    // spine shade
    ctx.strokeStyle = "rgba(70,86,110,0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(baseX + px * halfW, baseY + py * halfW);
    ctx.quadraticCurveTo(midX + px * halfW * 0.7, midY + py * halfW * 0.7, tipX + px * 1.1, tipY + py * 1.1);
    ctx.stroke();

    // glint on confirmed hit
    if (this.glintT > 0) {
      const ga = this.glintT / 0.18;
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = "rgba(255,250,230," + (ga * 0.9).toFixed(3) + ")";
      ctx.lineWidth = 1.6;
      const s = 5 + (1 - ga) * 9;
      ctx.beginPath();
      ctx.moveTo(tipX - s, tipY);
      ctx.lineTo(tipX + s, tipY);
      ctx.moveTo(tipX, tipY - s);
      ctx.lineTo(tipX, tipY + s);
      ctx.stroke();
    }
    ctx.restore();
  }

  // transparent slash crescent — drawn after world & player
  drawFx(ctx: CanvasRenderingContext2D, t: number) {
    void t;
    const m = this.move;
    const sweeping =
      m && this.state === "slash" && this.whooshed && !m.radial && m.id !== "iaido" && m.id !== "dive";

    if (sweeping && this.trail.length > 2) {
      const ph = this.moveT / m.dur;
      const sw = clamp((ph - m.windup) / Math.max(0.001, m.end - m.windup), 0, 1);
      const fade = ph < m.end ? 1 : Math.max(0, 1 - (ph - m.end) / 0.14);
      const alpha = (0.26 + this.comboIdx * 0.05) * Math.sin(Math.PI * Math.min(1, sw)) * fade;
      if (alpha > 0.01) {
        const palette: Record<string, [string, string]> = {
          combo1: ["255,244,222", "255,214,170"],
          combo2: ["255,244,222", "255,196,107"],
          combo3: ["255,224,178", "194,47,35"],
          heavy: ["255,214,170", "194,47,35"],
          air: ["226,238,255", "194,47,35"],
          draw: ["255,244,222", "255,196,107"],
        };
        const [cIn, cOut] = palette[m.id] ?? palette.combo1;

        // pivot follows the hand, so the arc stays attached to the swing
        const f = this.facing;
        const cx = this.x + this.gripX * f;
        const cy = this.y + this.gripY;

        ctx.save();
        ctx.globalCompositeOperation = "lighter";

        // broad see-through crescent: outer arc follows the tip, inner arc at 45%
        for (let i = 1; i < this.trail.length; i++) {
          const p0 = this.trail[i - 1];
          const p1 = this.trail[i];
          const a = (1 - p1.age / p1.max) * alpha * 1.6;
          if (a <= 0) continue;
          ctx.fillStyle = "rgba(" + cIn + "," + Math.min(0.42, a).toFixed(3) + ")";
          ctx.beginPath();
          ctx.moveTo(p0.x, p0.y);
          ctx.lineTo(p1.x, p1.y);
          ctx.lineTo(cx + (p1.x - cx) * 0.45, cy + (p1.y - cy) * 0.45);
          ctx.lineTo(cx + (p0.x - cx) * 0.45, cy + (p0.y - cy) * 0.45);
          ctx.closePath();
          ctx.fill();
        }

        // thin hot core line right along the blade's path
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        for (let i = 1; i < this.trail.length; i++) {
          const p0 = this.trail[i - 1];
          const p1 = this.trail[i];
          const a = (1 - p1.age / p1.max) * alpha * 2.4;
          if (a <= 0) continue;
          ctx.strokeStyle = "rgba(255,255,255," + Math.min(0.6, a).toFixed(3) + ")";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(p0.x, p0.y);
          ctx.lineTo(p1.x, p1.y);
          ctx.stroke();
        }

        // colored rim on the outer edge — the visible "cut line"
        ctx.lineWidth = 1.6;
        for (let i = 1; i < this.trail.length; i++) {
          const p0 = this.trail[i - 1];
          const p1 = this.trail[i];
          const a = (1 - p1.age / p1.max) * alpha * 2;
          if (a <= 0) continue;
          ctx.strokeStyle = "rgba(" + cOut + "," + Math.min(0.75, a).toFixed(3) + ")";
          ctx.beginPath();
          ctx.moveTo(p0.x, p0.y);
          ctx.lineTo(p1.x, p1.y);
          ctx.stroke();
        }

        // faint ghost blades inside the arc — reads as motion, not a tail
        ctx.lineCap = "round";
        for (let i = 0; i < this.ghosts.length - 1; i++) {
          const g = this.ghosts[i];
          const a = ((i + 1) / this.ghosts.length) * alpha * 0.9;
          ctx.strokeStyle = "rgba(" + cIn + "," + a.toFixed(3) + ")";
          ctx.lineWidth = 1.6 + 2 * g.s;
          ctx.beginPath();
          ctx.moveTo(g.gx, g.gy);
          ctx.lineTo(g.tx, g.ty);
          ctx.stroke();
        }
        ctx.restore();
      }
    }
  }
}

import { SURVIVORS, TILE } from "./defs";
import { HOUSES, houseAtPx } from "./map";
import type { Fighter, Game } from "./engine";
import { respond } from "./converse";

/** the five survivors: index = skin */
export const PERSONA = [
  { name: "JAKA", col: "#ff8a6a", trait: "PELAWAK" },
  { name: "SARI", col: "#ffd75e", trait: "PENYAYANG" },
  { name: "BIMO", col: "#7dff9a", trait: "VETERAN" },
  { name: "NADIA", col: "#8af0ff", trait: "PINTAR PENAKUT" },
  { name: "BARA", col: "#ff9df0", trait: "PEMARAH" },
  { name: "HAZMAT", col: "#f5d85a", trait: "KOSTUM" },
  { name: "GASMASK", col: "#8ad8c0", trait: "KOSTUM" },
  { name: "HOODIE", col: "#c9cdd9", trait: "KOSTUM" },
  { name: "HOKI", col: "#ff8a8a", trait: "KOSTUM" },
  { name: "MILLER", col: "#ffb36a", trait: "PEMADAM" },
  { name: "SWAT", col: "#7ad0ff", trait: "TAKTIS" },
];
export interface ChatLine { id: number; who: string; col: string; text: string; t: number }
export interface Bubble { f: Fighter; lines: string[]; life: number; col: string }

/**
 * What each survivor says in each situation: [JAKA, SARI, BIMO, NADIA, BARA].
 * {P} = the player's name, {M} = a team mate, {N} = a number, {D} = a direction.
 */
const L: Record<string, string[][]> = {
  start: [
    ["Oke tim, liburan ke kota mati dimulai!", "Siapa takut? ...aku sih, dikit."],
    ["Jangan ada yang jauh-jauh ya. Kita pulang bareng.", "{P}, kalau luka bilang aku ya."],
    ["Fokus. Cari barangnya, lalu pergi.", "Hemat peluru. Jangan sok jago."],
    ["T-tiga barang... baterai, bensin, suar. Oke.", "Aku sudah hitung peluang kita... jangan tanya."],
    ["Akhirnya! Tanganku sudah gatal.", "Taruhan, aku yang paling banyak bunuh."],
  ],
  idle: [
    ["Kalau selamat, aku traktir bakso semua.", "Zombie tadi mirip dosen pembimbingku.", "Ada yang bawa cemilan? Enggak? Oke."],
    ["Kalian sudah minum? Jangan sampai lemas.", "Aku kangen suara pasar pagi...", "{P}, kamu kelihatan capek. Kuat?"],
    ["Dulu jalan ini macet tiap sore. Sekarang sunyi.", "Jangan lengah. Sepi itu bohong.", "Hmph."],
    ["Menurut petaku, lubang di jalan itu sarangnya.", "Aku baca, zombie tertarik suara keras.", "Dingin... atau cuma aku yang gemetar?"],
    ["Sepi amat. Mana zombienya?", "Bosan. {P}, cari ribut yuk.", "Otot ini bukan pajangan."],
  ],
  idleLow: [
    ["...Nggak lucu lagi ya.", "Aku kehabisan lelucon."],
    ["Kita harus kuat. Demi yang sudah pergi.", "Aku nggak mau kehilangan siapa pun lagi."],
    ["Jalan terus. Berduka nanti.", "Fokus. Itu cara kita menghormati mereka."],
    ["Aku mau pulang...", "K-kenapa harus kita..."],
    ["Mereka bakal bayar.", "Aku nggak akan diam saja."],
  ],
  reply: [
    ["Haha, bener juga.", "Catat ya!", "Setuju, bos."],
    ["Hehe, iya.", "Semoga saja.", "Kalian ini..."],
    ["Banyak omong.", "Hm.", "Simpan tenagamu."],
    ["E-eh, iya...", "Jangan bikin takut dong.", "A-aku setuju."],
    ["Halah.", "Terserah.", "Buktikan."],
  ],
  enterHouse: [
    ["Permisi! Ada orang? ...atau mayat?", "Rumah orang nih. Lepas sepatu?"],
    ["Pelan-pelan. Bisa ada yang tidur di dalam.", "Cari lemari obat ya."],
    ["Pakai pisau. Tembakan bikin mereka bangun.", "Periksa tiap sudut."],
    ["A-aku jaga pintu saja ya...", "Gelap banget di dalam..."],
    ["Ketuk dulu? Enggak lah. Dobrak!", "Semoga ada yang bisa dihajar."],
  ],
  sleepers: [[], [], [], ["Sst... aku dengar napas. Ada {N} di dalam.", "H-hati-hati, {N} zombie tidur di rumah ini."], []],
  enterShop: [
    ["Diskon akhir zaman! Semua gratis!", "Aku ambil keripik dulu ya."],
    ["Cari obat di rak belakang.", "Jangan terpisah di lorong."],
    ["Lorongnya sempit. Awas sudut mati.", "Jangan berisik di sini."],
    ["Minimarket... banyak tempat sembunyi. Ih.", "K-kulkasnya masih nyala?"],
    ["Aku ambil minuman energi dulu.", "Belanja pakai pentungan!"],
  ],
  twoFloor: [
    ["Wah, dua lantai! Orang kaya nih.", "Rumah gedong! Ada tangga di pojok."],
    ["Ada tangga di pojok. Cek lantai atas juga ya.", "Dua lantai. Jangan ada yang ketinggalan di bawah."],
    ["Dua lantai. Bersihkan bawah dulu, baru naik.", "Tangga di pojok. Satu-satunya jalan naik."],
    ["A-atasnya pasti lebih gelap lagi...", "Barangnya bisa saja di lantai atas..."],
    ["Lantai atas punyaku!", "Atas bawah, kubersihkan semua."],
  ],
  upstairs: [
    ["Capek naik tangga. Nggak ada lift?", "Lantai dua! Pemandangannya... gelap."],
    ["Pelan-pelan, lantainya berderit.", "Di atas sini cuma ada satu jalan turun. Hati-hati."],
    ["Jangan sampai terjebak di atas.", "Jaga tangga. Mereka bisa ikut naik."],
    ["K-kalau mereka naik, kita lari ke mana?", "S-sempit... aku nggak suka."],
    ["Biar mereka naik. Kutendang turun.", "Bagus, mereka cuma bisa datang dari tangga."],
  ],
  knockdown: [
    ["Jatuh dia! Hajar selagi rebahan!", "Wih, terpental!"],
    ["Dia jatuh! Sekarang!", "Belum mati, awas dia bangun lagi."],
    ["Jatuh. Habisi sebelum bangun.", "Tembak yang di lantai."],
    ["D-dia bangun lagi?!", "Masih gerak... masih gerak!"],
    ["Rebahan kau! Jangan bangun!", "Lembek!"],
  ],
  wake: [
    ["Ups. Mereka bangun!", "Selamat pagi, mayat-mayat!"],
    ["Mereka bangun! Mundur ke pintu!", "Awas, mereka sadar!"],
    ["Kontak! Tahan posisi!", "Mereka bangun. Tembak kepala."],
    ["Kyaa! Mereka gerak!", "M-mereka lihat kita!"],
    ["Bangun juga! Sini maju!", "Nah, ini baru seru!"],
  ],
  loud: [
    ["Halus banget, {P}. Kayak gajah.", "Sekalian saja pasang musik dangdut."],
    ["{P}, pakai pentungan saja, lebih senyap.", "Tembakan itu membangunkan seisi rumah..."],
    ["Sst! Suaramu kedengaran sekampung!", "Di dalam rumah, pakai pisau."],
    ["T-tembakan itu... mereka pasti dengar.", "A-aku dengar langkah dari kamar sebelah!"],
    ["Biarin! Makin ramai makin seru.", "Bagus, panggil semuanya sekalian!"],
  ],
  headshot: [
    ["Wih, kepalanya copot! Sadis, {P}!", "Itu kepala apa bola?"],
    ["Tembakan bagus, {P}!", "Tepat sekali!"],
    ["Bidikan bersih.", "Begitu caranya."],
    ["T-tepat di kepala... keren.", "Wow, {P}..."],
    ["Lumayan. Tapi aku lebih jago.", "Oke, yang itu keren. Dikit."],
  ],
  combo: [
    ["{P} ngamuk! Kasih jalan!", "Santai, {P}, sisakan buat cerita!"],
    ["Hebat! Tapi jangan memaksakan diri.", "{P}, kamu luar biasa!"],
    ["Kerja bagus. Terus begitu.", "Itu baru prajurit."],
    ["S-sepuluh sekaligus?!", "{P} serem banget..."],
    ["Oi, sisakan buat aku!", "Jangan serakah, {P}!"],
  ],
  smash: [
    ["Home run! Bolanya... eh, kepalanya.", "Aduh, itu pasti sakit. Eh, sudah mati."],
    ["Aduh... aku nggak lihat, aku nggak lihat.", "{P}... itu berlebihan."],
    ["Efektif.", "Hemat peluru. Bagus."],
    ["Iuh... otaknya...", "A-aku mual."],
    ["ITU baru pukulan!", "Hahaha! Lagi, {P}!"],
  ],
  hurt: [
    ["{P}, kamu bocor tuh! Mundur dulu!", "{P}, darahmu ke mana-mana!"],
    ["{P}, kamu berdarah! Sini dekat aku!", "{P}, jangan dipaksa, kamu terluka!"],
    ["{P} terluka. Aku tutup depan.", "{P}, mundur. Biar aku."],
    ["{P}, d-darahmu banyak banget...", "{P}, tolong hati-hati..."],
    ["Masih kuat kan, {P}? Jangan mati dulu.", "{P}, jangan lembek!"],
  ],
  healed: [
    ["Segar lagi! Kayak iklan.", "Obat ketemu, hidup lanjut!"],
    ["Nah, mendingan kan?", "Syukurlah ada obat."],
    ["Bagus. Lanjut.", "Balut yang rapat."],
    ["Syukurlah...", "A-aku lega."],
    ["Sudah? Ayo lanjut hajar.", "Jangan manja lama-lama."],
  ],
  selfHurt: [
    ["Aduh aduh, aku digigit! Dikit!", "Oke, itu sakit beneran."],
    ["Aku... aku nggak apa-apa. Fokus saja.", "Jangan khawatirkan aku."],
    ["Cuma goresan.", "Masih bisa tembak."],
    ["Sakit... tolong, aku takut...", "A-aku berdarah!"],
    ["Cih. Nggak kerasa!", "Itu doang?!"],
  ],
  playerDown: [
    ["{P}! Jangan bercanda, bangun!", "{P} jatuh! Aku ke sana!"],
    ["{P}! Bertahan, aku datang!", "Tidak! {P}, lihat aku, tetap sadar!"],
    ["{P} jatuh! Lindungi dia!", "Tutup {P}! Sekarang!"],
    ["{P}!! Tidak, tidak, tidak!", "{P}! Jangan tinggalin aku!"],
    ["Minggir semua! {P}, tunggu aku!", "{P}! Berani-beraninya kau jatuh!"],
  ],
  revive: [
    ["Hup! Ayo bangun, jagoan.", "Bangun, tidur siangnya nanti."],
    ["Pelan-pelan... aku pegang kamu.", "Nah, kamu aman sekarang."],
    ["Berdiri. Masih ada kerjaan.", "Kamu belum boleh mati."],
    ["K-kamu bikin aku takut tahu!", "Syukurlah... syukurlah..."],
    ["Utang nyawa satu ya.", "Bangun! Malu-maluin."],
  ],
  mateDown: [
    ["{M} jatuh! Tolongin!", "{M}! Tahan, bro!"],
    ["{M}! Aku ke sana!", "{M} terluka parah!"],
    ["{M} jatuh. Tutup dia.", "Lindungi {M}!"],
    ["{M}! Jangan mati!", "{M} jatuh! G-gimana ini?!"],
    ["{M} tumbang! Dasar ceroboh!", "{M}! Bangun, payah!"],
  ],
  thanks: [
    ["Makasih, {P}! Aku traktir dua mangkok.", "Wah, kukira aku tamat. Makasih!"],
    ["Terima kasih... aku berutang padamu.", "{P}... terima kasih sudah kembali."],
    ["...Makasih. Aku ingat ini.", "Kerja bagus, {P}."],
    ["K-kamu balik buat aku... makasih.", "{P}... aku kira aku bakal mati..."],
    ["Aku nggak minta tolong! ...tapi makasih.", "Cih. Makasih, {P}."],
  ],
  mateDead: [
    ["{M}... nggak mungkin...", "{M}... bro..."],
    ["{M}... maafkan aku...", "Tidak... {M}..."],
    ["{M} gugur. Jangan sia-siakan.", "Selamat jalan, {M}."],
    ["{M}... hiks...", "I-ini salahku..."],
    ["{M}!! Sialan kalian semua!", "Mereka bakal bayar buat {M}!"],
  ],
  rage: [[], [], [], [], ["SEKARANG AKU MARAH!", "KALIAN SEMUA MATI!"]],
  item1: [
    ["Dapat satu! Dua lagi, gampang.", "Satu ketemu! Siapa hebat? Kita!"],
    ["Bagus! Tapi suaranya... dengar itu?", "Satu dapat. Hati-hati, mereka datang."],
    ["Satu. Mereka pasti datang. Siap.", "Barang pertama. Bentuk formasi."],
    ["S-satu dari tiga! Tapi... gerombolan!", "Dapat! T-tapi mereka dengar kita!"],
    ["Datang juga gerombolannya. Bagus!", "Satu! Sekarang hajar yang datang!"],
  ],
  item2: [
    ["Dua! Tinggal satu, jangan kendor!", "Dua dari tiga! Hampir pulang!"],
    ["Tinggal satu lagi. Kita bisa!", "Sedikit lagi, semuanya!"],
    ["Satu lagi. Rapatkan barisan.", "Dua. Jangan lengah sekarang."],
    ["Dua pertiga selesai!", "T-tinggal satu..."],
    ["Satu lagi terus kita pesta.", "Cepat cari yang terakhir!"],
  ],
  itemAll: [
    ["Lengkap! Ayo ke helikopter!", "Tiga-tiganya! Bakso menanti!"],
    ["Semua dapat! Kembali ke zona evac!", "Kita bisa pulang! Ayo!"],
    ["Selesai. Balik ke evac. Sekarang.", "Misi cari beres. Mundur teratur."],
    ["K-kita beneran bisa pulang?!", "Semua dapat! Ke zona evac!"],
    ["Sudah? Yah, baru panas.", "Oke, sekarang lari sambil nembak!"],
  ],
  empty: [
    ["Kosong. Kayak dompetku.", "Zonk!"],
    ["Tidak ada apa-apa di sini.", "Sudah dijarah orang."],
    ["Kosong. Lanjut.", "Buang waktu."],
    ["K-kosong...", "Coba yang lain..."],
    ["Zonk!", "Sampah semua."],
  ],
  breach: [
    ["Dari bawah?! Curang!", "Jalannya jebol!"],
    ["Tanahnya retak! Menjauh!", "Awas kaki kalian!"],
    ["Mereka gali dari bawah. Mundur.", "Retakan! Jaga jarak!"],
    ["T-tanahnya bergerak!", "D-dari bawah tanah?!"],
    ["Keluar kalian semua!", "Bagus, antar nyawa!"],
  ],
  dog: [
    ["Anjing! Bukan maki, beneran anjing!", "Guguknya nggak lucu sama sekali!"],
    ["Anjing zombie... kasihan, tapi awas!", "Awas, dia lompat!"],
    ["Anjing. Cepat. Tembak saat dia jongkok.", "Anjing di depan. Jangan lari lurus."],
    ["A-aku takut anjing! Apalagi yang mati!", "Kyaa! Anjing!"],
    ["Guguk sini guguk!", "Anjing kampung! Sini!"],
  ],
  brute: [
    ["Yang gede datang! Jangan dari depan!", "Itu polisi apa kulkas?"],
    ["Si brutal! Hindari serudukannya!", "Minggir kalau dia lari!"],
    ["Brutal. Serang dari samping.", "Armornya di depan. Putari dia."],
    ["A-armornya tebal di depan!", "D-dia mau nyeruduk!"],
    ["Yang ini lawanku!", "Sini, gendut!"],
  ],
  boss: [
    ["Itu... itu gede banget, woy.", "Oke, yang itu aku nggak bisa bercanda."],
    ["Ya Tuhan... semua tetap bersama!", "Jangan dekat-dekat makhluk itu!"],
    ["Mutan. Pakai rudal. Semua tembak.", "Target besar. Fokus tembakan."],
    ["M-mustahil... itu masih manusia?", "A-aku nggak mau lihat..."],
    ["AKHIRNYA lawan sepadan!", "Yang itu punyaku!"],
  ],
  bossDead: [
    ["TUMBANG! Kita legenda!", "Ada yang rekam nggak tadi?!"],
    ["Kita berhasil... kita berhasil!", "Syukurlah!"],
    ["Bagus. Belum selesai. Fokus.", "Satu masalah beres."],
    ["K-kita ngalahin itu?!", "Aku nggak percaya..."],
    ["HAHA! Gampang!", "Cuma segitu?!"],
  ],
  rain: [
    ["Hujan. Pas banget, aku belum mandi.", "Sedia payung sebelum zombie."],
    ["Hujan... hati-hati licin.", "Jangan sampai masuk angin ya."],
    ["Hujan menutupi suara. Untung dan rugi.", "Jarak pandang turun. Rapat."],
    ["D-dingin... petirnya jangan dong...", "Aku basah kuyup..."],
    ["Hujan? Bodo amat.", "Bagus, darahnya kecuci."],
  ],
  fog: [
    ["Kabutnya kayak film horor. Oh iya.", "Siapa nyalain mesin asap?"],
    ["Jangan sampai terpisah di kabut.", "Pegang tangan kalau perlu."],
    ["Jarak pandang nol. Dengar radarnya.", "Kabut. Tembak yang bergerak."],
    ["A-aku nggak lihat apa-apa...", "Ada yang gerak di kabut..."],
    ["Kabut nggak bisa sembunyiin mereka dariku.", "Keluar kalian!"],
  ],
  thunder: [
    ["Waduh! Jantungku!", "Itu petir atau perutku?"],
    ["Tenang, cuma petir.", "Nggak apa-apa, {P}."],
    [],
    ["KYAA! ...m-maaf, kaget.", "P-petir! Aku benci petir!"],
    ["Cuma petir, penakut.", "Berisik."],
  ],
  evacCall: [
    ["Bertahan semenit? Itu lama banget tahu!", "Helinya nggak bisa ngebut?"],
    ["Bertahan! Sebentar lagi kita pulang!", "Semua tetap di zona!"],
    ["Formasi. Jangan ada yang keluar zona.", "Tahan sampai heli tiba."],
    ["Helikopter datang... tolong cepat...", "S-semenit lagi..."],
    ["Semua maju sini! Aku tunggu!", "Pesta terakhir!"],
  ],
  heli: [
    ["Itu dia tumpangan kita!", "Taksi udara datang!"],
    ["Helikopternya! Ayo naik, cepat!", "Kita pulang!"],
    ["Naik. Sekarang. Aku terakhir.", "Heli tiba. Bergerak!"],
    ["Kita selamat... kita selamat!", "A-akhirnya!"],
    ["Cih, pas lagi seru.", "Yah, sudah selesai?"],
  ],
  far: [
    ["{P}! Jangan pisah, nanti dimakan!", "{P}, tungguin dong!"],
    ["{P}, tunggu! Jangan sendirian!", "{P}, kita harus tetap bersama!"],
    ["{P}. Balik ke formasi.", "{P}, jangan jadi pahlawan."],
    ["{P}, j-jangan tinggalin aku!", "{P}? Kamu di mana?"],
    ["Oi {P}, sok jagoan?", "{P}! Jangan ambil semua sendiri!"],
  ],
  idlePlayer: [
    ["{P}? Halo? Bengong?", "Kita nungguin apa nih?"],
    ["{P}, kamu baik-baik saja?", "Kalau capek, bilang ya."],
    ["Jangan diam. Diam itu mati.", "Bergerak, {P}."],
    ["K-kita nunggu apa?", "A-aku nggak suka diam di sini..."],
    ["Ayo gerak! Lambat!", "Bosan!"],
  ],
  surrounded: [
    ["{P} dikepung! Bantu!", "Wah, {P} lagi populer!"],
    ["Aku bantu, {P}! Jangan panik!", "{P}, ke arahku!"],
    ["{P}, mundur ke arahku!", "Tembak yang dekat {P}!"],
    ["T-terlalu banyak!", "{P}! Di belakangmu!"],
    ["Pesta di tempat {P}! Ikut!", "Sisakan, {P}!"],
  ],
  streak: [
    ["Enam! Hitung ya, enam!", "Aku lagi panas nih!"],
    ["Maaf... maaf... maaf...", "Aku harus melakukannya..."],
    ["Bersih.", "Sektor aman."],
    ["A-aku bisa! Aku bisa!", "Aku kena semua?!"],
    ["Hahaha! Siapa lagi?!", "Ayo! Lagi!"],
  ],
  grat: [
    ["Eh {P}, makasih ya tadi. Serius.", "{P}, kalau bukan kamu, aku sudah jadi bakso."],
    ["{P}, aku masih ingat kamu menolongku.", "{P}, aku senang kamu di tim ini."],
    ["{P}. Soal tadi... aku berutang.", "Kamu bisa diandalkan, {P}."],
    ["{P}... kalau nggak ada kamu, aku...", "{P}, a-aku percaya sama kamu."],
    ["Jangan besar kepala soal tadi, {P}.", "...Kamu lumayan juga, {P}."],
  ],
  tease: [
    ["{P}, hobi rebahan ya?", "{P}, lantainya enak?"],
    ["{P}, tolong lebih hati-hati... aku khawatir.", "{P}, jangan bikin aku takut lagi ya."],
    ["{P}, perhatikan belakangmu.", "Jangan jatuh lagi, {P}."],
    ["{P}, a-aku nggak kuat lihat kamu jatuh lagi.", "{P}, tetap dekat aku ya..."],
    ["Jatuh mulu. Latihan lagi, {P}.", "{P}, kau ini beban atau teman?"],
  ],
  healGive: [
    ["Nih, perban. Jangan tanya dapat dari mana.", "Tahan, {P}! Kubalut sambil lari!"],
    ["Sini, {P}. Tahan sedikit ya.", "Jangan gerak, kubalut dulu lukamu."],
    ["Diam. Kututup lukamu.", "Perban. Tekan. Lanjut."],
    ["I-ini obatnya, {P}! Cepat!", "A-aku bawa perban... sini!"],
    ["Jangan cengeng. Sini kubalut.", "Tahan. Sakit dikit."],
  ],
  gift: [["Nih {P}, nemu obat di saku zombie. Bersih kok.", "{P}, tangkap! Oleh-oleh dari mayat."], [], [], [], []],
  spot: [[], [], [], ["{P}, rumah bertanda ada di arah {D}.", "Petaku bilang: barangnya di {D}."], []],
  cover: [[], [], ["Aku jaga punggungmu, {P}.", "Belakangmu aman, {P}."], [], []],
  civFound: [
    ["Wah, ada orang hidup! Halo, kami bukan zombie, sumpah!", "Ketemu! Ayo ikut, tur keliling kota mati gratis."],
    ["Ya Tuhan, kamu selamat... sini, dekat aku. Kamu aman sekarang.", "Pelan-pelan. Kami jaga kamu, ya."],
    ["Warga sipil. Semua, lindungi dia. Dia jalan di tengah formasi.", "Tetap di belakang {P}. Jangan lari sendiri."],
    ["A-ada yang masih hidup! Syukurlah...", "Dia gemetaran... sama kayak aku."],
    ["Hei! Tempel terus di belakang kami. Yang ganggu kamu, kuhajar.", "Bagus, masih hidup. Jangan jauh-jauh."],
  ],
  civHear: [[], [], [], ["Sst... aku dengar orang minta tolong. Arah {D}.", "{P}, ada yang masih hidup di arah {D}. Aku dengar tangisannya."], []],
  civHurt: [
    ["Woi, jangan sentuh dia!", "{P}! Dia diserang!"],
    ["Lindungi dia! Dia nggak bisa melawan!", "Jangan biarkan mereka mendekatinya!"],
    ["Sipil dalam bahaya. Tutup dia!", "Bentuk lingkaran di sekitar dia!"],
    ["D-dia digigit! Tolong dia!", "Kyaa! Mereka mengincar dia!"],
    ["LEPASKAN DIA!", "Sini lawan aku, bukan dia!"],
  ],
  truck: [
    ["Bus sekolah kuning! Aku duduk depan!", "Ada kuncinya? Ada! Keajaiban!"],
    ["Semua naik. Pelan-pelan, bantu dia dulu.", "Ayo, kita tinggalkan tempat ini."],
    ["Naik. Aku yang jaga belakang.", "Bensin cukup sampai distrik sebelah."],
    ["K-kita beneran bisa pergi dari sini?", "Cepat naik, cepat..."],
    ["Aku di bak belakang. Biar bisa nembak.", "Gas! Sebelum mereka nyusul."],
  ],
  safe: [
    ["Pintu dikunci, zombie di luar. Akhirnya bisa selonjoran!", "Rumah aman! Ada yang mau main kartu?"],
    ["Kita aman di sini. Istirahat dulu, obati luka kalian.", "Pintunya tertutup rapat. Tarik napas dulu, semuanya."],
    ["Perimeter aman. Istirahat bergiliran.", "Pintu tertutup. Mereka tidak bisa masuk. Pulihkan tenaga."],
    ["A-akhirnya... tempat yang tenang.", "Mereka cuma bisa gedor pintu, kan? ...kan?"],
    ["Cih, sembunyi. ...oke, sebentar saja.", "Biarkan mereka gedor. Kita isi tenaga dulu."],
  ],
  levelNY: [
    ["New York! Dulu macetnya parah, sekarang... yah, masih ramai sih.", "Kota yang tak pernah tidur. Zombienya juga."],
    ["Kota sebesar ini... pasti masih ada yang hidup. Kita cari mereka.", "Tetap dekat mobil kalau terdesak, ya."],
    ["Kota besar, sudut mati di mana-mana. Subway bisa jadi jalan pintas.", "Senapan di bus jaga parkiran. Ingat posisinya."],
    ["G-gedungnya tinggi-tinggi... banyak banget tempat mereka sembunyi.", "Peta bilang ada stasiun subway di dekat sini."],
    ["Kota besar, zombie banyak. Akhirnya!", "Parkir, turun, hajar. Gampang."],
  ],
  levelCity: [
    ["Kota berikutnya! Semoga yang ini ada baksonya.", "Turun, turun! Kaki kesemutan di bak belakang."],
    ["Semua turun pelan-pelan. Yang baru diselamatkan aman di mobil.", "Kota baru. Tetap bersama, ya."],
    ["Lokasi baru. Aturan sama: cari, selamatkan, kembali ke bus.", "Ingat posisi mobil. Itu jalan pulang kita."],
    ["K-kota ini lebih sepi... aku nggak suka sepi.", "Busnya kelihatan di radar, kan? Jangan sampai lupa."],
    ["Bumper-nya masih berdarah. Bagus.", "Kota baru, zombie baru."],
  ],
  level2: [
    ["Brr! Kota tua. Dingin, sepi, dan pasti banyak zombienya.", "Salju! Siapa mau bikin boneka salju zombie?"],
    ["Dingin sekali... rapatkan jaket kalian.", "Tempat baru. Tetap bersama, ya."],
    ["Distrik baru. Aturan sama: cari, selamatkan, pergi.", "Jejak di salju. Kita tidak sendirian."],
    ["S-salju... jejak kaki mereka kelihatan jelas.", "Kota tua... bangunannya rapat, banyak sudut gelap."],
    ["Dingin? Hajar zombie, nanti hangat.", "Tempat baru, zombie baru. Bagus."],
  ],
  day: [
    ["Pagi! Mataharinya cantik, sayang kotanya penuh mayat.", "Akhirnya terang. Sekarang kelihatan betapa kacaunya kota ini."],
    ["Sudah pagi... syukurlah. Kita masih utuh.", "Cahaya pagi bikin sedikit lebih tenang, ya."],
    ["Terang. Mereka lebih gampang dilihat - kita juga.", "Pagi. Manfaatkan jarak pandangnya."],
    ["P-pagi... setidaknya aku bisa lihat mereka datang.", "Matahari terbit. Aku kira nggak bakal lihat ini lagi."],
    ["Siang bolong juga kuhajar.", "Terang begini, nggak ada alasan meleset."],
  ],
  snow: [
    ["Salju pertama sejak kiamat. Romantis juga.", "Hidungku beku. Masih bisa buat lucu-lucuan?"],
    ["Hati-hati licin. Dan jaga badan tetap hangat.", "Salju menutup semuanya... seperti selimut."],
    ["Salju meredam langkah. Langkah mereka juga.", "Lihat jejaknya. Baca arahnya."],
    ["D-dingin... jariku kaku.", "Cantik... kalau saja nggak ada mayat."],
    ["Dingin begini enaknya berantem.", "Salju merah sebentar lagi."],
  ],
  checkin: [
    ["Hei {P}, udah mendingan? Aku masih punya lelucon cadangan kalau perlu.", "Gimana perasaanmu sekarang, {P}? Aku masih di sini."],
    ["{P}, tadi kamu bilang sedang tidak baik. Sekarang gimana? Aku nggak lupa.", "Masih kepikiran yang tadi, {P}? Kita ngobrol lagi kalau mau."],
    ["{P}, bagaimana perasaanmu? Jangan dipendam.", "Sudah lebih tenang, {P}?"],
    ["{P}... kamu sudah tenang? Aku masih kepikiran tadi.", "A-aku cuma mau memastikan kamu baik-baik saja."],
    ["Heh {P}. Udah mendingan belum? Jangan bikin khawatir.", "Kalau masih berat, bilang. Aku nggak keberatan dengar."],
  ],
  win: [
    ["Bakso! Aku traktir! Janji!", "Kita selamat! Aku mau nangis!"],
    ["Kita pulang... semuanya, terima kasih.", "Kalian keluargaku sekarang."],
    ["Kerja bagus, tim.", "Misi selesai."],
    ["Aku... aku nggak nyangka kita bisa.", "K-kita hidup!"],
    ["Lain kali, lebih banyak zombie.", "Gampang."],
  ],
};

const rand = Math.random;
function wrap(text: string, n: number): string[] {
  const out: string[] = [];
  let cur = "";
  for (const w of text.split(" ")) {
    if (cur && cur.length + 1 + w.length > n) { out.push(cur); cur = w; }
    else cur = cur ? `${cur} ${w}` : w;
  }
  if (cur) out.push(cur);
  return out;
}

interface SayOpt { who?: Fighter | null; near?: { x: number; y: number }; cd?: number; force?: boolean; vars?: Record<string, string | number>; reply?: string; not?: Fighter | null }

/**
 * Makes the squad feel alive: they react to what happens, to how the player is doing and to each other,
 * remember who saved whom, lose heart when a friend dies - and each has a small thing they do for the team.
 */
export class Chatter {
  log: ChatLine[] = [];
  bubbles: Bubble[] = [];
  /** 0..1: jokes when high, fear and grief when low */
  morale = 1;
  /** Bara hits harder while a friend is down */
  rageT = 0;
  private g: Game;
  private gap = 0;
  private at: Record<string, number> = {};
  private later: { t: number; ev: string; not: Fighter | null; who: Fighter | null }[] = [];
  private lastWho: Fighter | null = null;
  private idleT = 10;
  private scanT = 1;
  private healT = 14;
  private giftT = 45;
  private spotT = 18;
  private still = 0;
  private px = 0;
  private py = 0;
  private sky = "";
  private inHouse = -1;
  private saved: number[] = [];
  private thanked: number[] = [];
  private downs = 0;
  private teased = false;
  private streaks: Record<number, { n: number; t: number }> = {};
  private heads = 0;
  private queue: { t: number; skin: number; text: string; mood: string }[] = [];

  constructor(g: Game) {
    this.g = g;
  }

  reset() {
    this.log = []; this.bubbles = []; this.later = []; this.at = {}; this.morale = 1; this.rageT = 0; this.gap = 0; this.lastWho = null;
    this.idleT = 10; this.healT = 14; this.giftT = 45; this.spotT = 18; this.still = 0; this.sky = ""; this.inHouse = -1;
    this.saved = []; this.thanked = []; this.downs = 0; this.teased = false; this.streaks = {}; this.heads = 0; this.queue = [];
  }

  private on() {
    return this.g.game === "bugs" && this.g.mode === "play";
  }
  private bots() {
    return this.g.fighters.filter((f) => f.ai && f.alive && !f.civ);
  }

  /** who should say it: someone who has a line for this, preferably not whoever spoke last */
  private pick(ev: string, near?: { x: number; y: number }, not?: Fighter | null): Fighter | null {
    const c = this.bots().filter((f) => f !== not && (L[ev]?.[f.skin]?.length ?? 0) > 0);
    if (!c.length) return null;
    if (near) return c.reduce((a, b) => (Math.hypot(a.x - near.x, a.y - near.y) < Math.hypot(b.x - near.x, b.y - near.y) ? a : b));
    const fresh = c.filter((f) => f !== this.lastWho);
    const pool = fresh.length ? fresh : c;
    return pool[(rand() * pool.length) | 0];
  }

  /** something happened: maybe somebody comments on it */
  say(ev: string, o: SayOpt = {}): boolean {
    if (!this.on() || !ev) return false;
    const g = this.g, now = g.t;
    if (now - (this.at[ev] ?? -99) < (o.cd ?? 14)) return false;
    if (!o.force && this.gap > 0) return false;
    const f = o.who !== undefined ? (o.who && o.who.alive && o.who.ai && o.who !== o.not ? o.who : null) : this.pick(ev, o.near, o.not);
    const opts = f ? L[ev]?.[f.skin] : null;
    if (!f || !opts || !opts.length) return false;
    let text = opts[(rand() * opts.length) | 0];
    const vars: Record<string, string | number> = { P: g.player ? SURVIVORS[g.player.skin] : "KAMU", ...o.vars };
    for (const k in vars) text = text.split(`{${k}}`).join(String(vars[k]));
    this.at[ev] = now;
    this.gap = o.force ? 1.3 : 2.5;
    this.lastWho = f;
    const col = PERSONA[f.skin].col;
    this.log.push({ id: g.ids++, who: f.name, col, text, t: now });
    if (this.log.length > 24) this.log.shift();
    this.bubbles = this.bubbles.filter((b) => b.f !== f);
    this.bubbles.push({ f, lines: wrap(text.toUpperCase(), 24), life: 2.4 + text.length * 0.05, col });
    g.snd("click", f.x, f.y, 0.45);
    g.hudDirty = true;
    if (o.reply) this.later.push({ t: 1.8 + rand() * 0.7, ev: o.reply, not: f, who: null });
    return true;
  }

  /** the player typed something: friends understand what it means and how it feels, and answer in character */
  hear(raw: string) {
    const g = this.g, p = g.player;
    if (!p || !this.on()) return;
    const text = raw.trim().slice(0, 140);
    if (!text) return;
    const push = (f: Fighter | null, who: string, col: string, line: string) => {
      this.log.push({ id: g.ids++, who, col, text: line, t: g.t });
      if (this.log.length > 24) this.log.shift();
      if (f) {
        this.bubbles = this.bubbles.filter((b) => b.f !== f);
        this.bubbles.push({ f, lines: wrap(line.toUpperCase(), 24), life: 2.6 + line.length * 0.05, col });
      }
    };
    push(p, "KAMU", "#ffffff", text);
    const bots = this.bots(), B = g.bug;
    let near = 0;
    for (const z of B.bugs) if (z.state !== "sleep" && Math.hypot(z.x - p.x, z.y - p.y) < 160) near++;
    const h = p.alive ? houseAtPx(p.x, p.y) : -1;
    const place = h < 0 ? "street" : HOUSES[h].shop ? "shop" : HOUSES[h].under !== undefined ? "upstairs" : "house";
    const sn = g.atmo.cur.name, sky = /HUJAN|BADAI/.test(sn) ? "rain" : /KABUT/.test(sn) ? "fog" : "clear";
    let dir = "UTARA", bd = 1e9;
    B.objHouses.forEach((hi, i) => {
      if (B.found[i]) return;
      const H = HOUSES[hi], dx = (H.x + H.w / 2) * TILE - p.x, dy = (H.y + H.h / 2) * TILE - p.y, d = Math.hypot(dx, dy);
      if (d < bd) { bd = d; dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "TIMUR" : "BARAT") : dy > 0 ? "SELATAN" : "UTARA"; }
    });
    const alive = [0, 1, 2, 3, 4].map((s) => bots.some((f) => f.skin === s));
    const out = respond(text, { P: SURVIVORS[p.skin], hp: p.hp, near, place, sky, morale: this.morale, items: B.found.filter(Boolean).length, downs: this.downs, dir, alive });
    for (const r of out.replies) this.queue.push({ t: r.delay, skin: r.skin, text: r.text, mood: r.mood });
    this.gap = Math.max(this.gap, 5);
    this.idleT = Math.max(this.idleT, 18);
    if (["happy", "laugh", "thanks", "love", "compliment", "joke"].includes(out.intent)) this.morale = Math.min(1, this.morale + 0.08);
    if (["sad", "scared", "tired", "hurt"].includes(out.intent)) {
      this.later = this.later.filter((q) => q.ev !== "checkin");
      this.later.push({ t: 32 + rand() * 12, ev: "checkin", not: null, who: null });
    }
  }

  /** the rescued civilian speaks: a bubble over their head and a line in the chat log */
  civSay(f: Fighter, text: string) {
    if (!this.on()) return;
    const col = "#ff9df0";
    this.log.push({ id: this.g.ids++, who: f.name, col, text, t: this.g.t });
    if (this.log.length > 24) this.log.shift();
    this.bubbles = this.bubbles.filter((b) => b.f !== f);
    this.bubbles.push({ f, lines: wrap(text.toUpperCase(), 24), life: 2.6 + text.length * 0.05, col });
    f.talkT = 1.4 + text.length * 0.04;
    this.g.hudDirty = true;
  }

  /** a queued answer is spoken: the speaker's face shows how they feel about what you said */
  private speak(q: { skin: number; text: string; mood: string }) {
    const f = this.bots().find((b) => b.skin === q.skin);
    if (!f) return;
    const col = PERSONA[f.skin].col;
    this.log.push({ id: this.g.ids++, who: f.name, col, text: q.text, t: this.g.t });
    if (this.log.length > 24) this.log.shift();
    this.bubbles = this.bubbles.filter((b) => b.f !== f);
    this.bubbles.push({ f, lines: wrap(q.text.toUpperCase(), 24), life: 2.8 + q.text.length * 0.055, col });
    if (q.mood === "joy") f.joy = Math.max(f.joy, 1.8);
    else if (q.mood === "sad") f.sad = 3.5;
    else if (q.mood === "mad") f.mad = 2.6;
    else if (q.mood === "fear") f.fear = Math.max(f.fear, 2);
    f.talkT = 1.5 + q.text.length * 0.05;
    this.g.snd("click", f.x, f.y, 0.5);
    this.g.hudDirty = true;
  }

  /* ───────────── things the game tells us about ───────────── */
  down(f: Fighter) {
    if (!this.on()) return;
    if (f.isPlayer) {
      this.downs++;
      this.morale -= 0.15;
      this.say("playerDown", { force: true, cd: 4, near: f });
    } else this.say("mateDown", { force: true, cd: 6, vars: { M: f.name }, not: f });
    const bara = this.bots().find((b) => b.skin === 4 && b !== f);
    if (bara) {
      this.rageT = 12;
      this.later.push({ t: 1.6, ev: "rage", not: null, who: bara });
    }
  }
  revived(f: Fighter, helper: Fighter) {
    if (!this.on()) return;
    this.morale = Math.min(1, this.morale + 0.1);
    if (f.isPlayer) this.say("revive", { who: helper, force: true, cd: 3 });
    else if (helper.isPlayer) {
      if (!this.saved.includes(f.id)) this.saved.push(f.id);
      this.say("thanks", { who: f, force: true, cd: 3 });
    }
  }
  dead(f: Fighter) {
    if (!this.on()) return;
    this.morale = Math.max(0, this.morale - 0.5);
    this.say("mateDead", { force: true, cd: 3, vars: { M: f.name }, not: f });
  }
  item(k: number) {
    this.morale = Math.min(1, this.morale + 0.2);
    this.say(k >= 3 ? "itemAll" : k === 2 ? "item2" : "item1", { force: true, cd: 0 });
  }
  /** a squad mate killed something: brag when on a roll; Bimo calls it when he covers you */
  kill(by: Fighter, x: number, y: number) {
    if (!this.on() || !by.ai) return;
    const s = (this.streaks[by.id] ??= { n: 0, t: -9 }), now = this.g.t;
    s.n = now - s.t < 6 ? s.n + 1 : 1;
    s.t = now;
    if (s.n >= 6) { s.n = 0; this.say("streak", { who: by, cd: 30 }); }
    const p = this.g.player;
    if (by.skin === 2 && p && p.alive && Math.hypot(p.x - x, p.y - y) < 42) this.say("cover", { who: by, cd: 45 });
  }
  /** the player took a head off */
  headshot(smash: boolean) {
    if (smash) this.say("smash", { cd: 22 });
    else if (++this.heads % 4 === 0) this.say("headshot", { cd: 18 });
  }

  update(dt: number) {
    if (!this.on()) { this.bubbles.length = 0; return; }
    const g = this.g;
    for (let i = this.queue.length - 1; i >= 0; i--) if ((this.queue[i].t -= dt) <= 0) { const q = this.queue.splice(i, 1)[0]; this.speak(q); }
    this.gap -= dt;
    this.rageT -= dt;
    this.morale = Math.min(1, this.morale + dt * 0.008);
    for (let i = this.bubbles.length - 1; i >= 0; i--) if ((this.bubbles[i].life -= dt) <= 0 || !this.bubbles[i].f.alive) this.bubbles.splice(i, 1);
    for (let i = this.later.length - 1; i >= 0; i--) {
      const q = this.later[i];
      if ((q.t -= dt) > 0) continue;
      this.later.splice(i, 1);
      this.say(q.ev, { force: true, cd: 0, not: q.not, ...(q.who ? { who: q.who } : {}) });
    }
    const p = g.player;
    if (g.phase !== "live" || !g.bug.live || !p) return;
    this.healT -= dt; this.giftT -= dt; this.spotT -= dt;
    if ((this.scanT -= dt) <= 0) { this.scanT = 0.5; this.scan(p); }
  }

  /** twice a second: look at how everyone is doing and what is around */
  private scan(p: Fighter) {
    const g = this.g, B = g.bug, bots = this.bots();
    // walking into a building
    const h = p.alive ? houseAtPx(p.x, p.y) : -1;
    if (h !== this.inHouse) {
      this.inHouse = h;
      if (h >= 0) {
        const sl = B.bugs.filter((z) => z.state === "sleep" && houseAtPx(z.x, z.y) === h).length, nadia = bots.find((f) => f.skin === 3);
        if (!(sl > 0 && nadia && rand() < 0.65 && this.say("sleepers", { who: nadia, vars: { N: sl }, cd: 8 }))) this.say(HOUSES[h].up !== undefined ? "twoFloor" : HOUSES[h].under !== undefined ? "upstairs" : HOUSES[h].shop ? "enterShop" : "enterHouse", { cd: 18 });
      }
    }
    // the weather turned
    const sky = g.atmo.cur.name;
    if (sky !== this.sky) {
      // keep trying until somebody has had the chance to say it
      const ev = /PAGI/.test(sky) ? "day" : /SALJU/.test(sky) ? "snow" : /HUJAN|BADAI/.test(sky) ? "rain" : /KABUT/.test(sky) ? "fog" : "";
      if (!ev || !bots.length || this.say(ev, { cd: 20 })) this.sky = sky;
    }
    // fear shows on their faces: Nadia panics at the first zombie, Bara never does
    for (const f of g.fighters) {
      if (!f.alive) continue;
      let n = 0;
      for (const z of B.bugs) if (z.state !== "sleep" && Math.abs(z.x - f.x) < 80 && Math.abs(z.y - f.y) < 80) n++;
      if (n >= (f.skin === 4 ? 99 : f.skin === 3 ? 1 : 4)) f.fear = 0.8;
    }
    if (!p.alive) return;
    let near = 0, calm = true;
    for (const z of B.bugs) {
      if (z.state === "sleep") continue;
      const d = Math.hypot(z.x - p.x, z.y - p.y);
      if (d < 75) near++;
      if (d < 160) calm = false;
    }
    if (near >= 6) this.say("surrounded", { cd: 25, near: p });
    if (p.hp < 40) this.say("hurt", { cd: 22, near: p });
    for (const f of bots) if (f.hp < 35) this.say("selfHurt", { who: f, cd: 20 });
    if (bots.length && Math.min(...bots.map((f) => Math.hypot(f.x - p.x, f.y - p.y))) > 250) this.say("far", { cd: 28 });
    // standing around
    if (Math.hypot(p.x - this.px, p.y - this.py) > 12) { this.px = p.x; this.py = p.y; this.still = 0; }
    else if ((this.still += 0.5) > 16 && calm) { this.say("idlePlayer", { cd: 45 }); this.still = 6; }

    // ── what each friend does for you ──
    const dist = (f: Fighter) => Math.hypot(f.x - p.x, f.y - p.y);
    // whoever is close patches you up (Sari first, when she is there)
    const sari = bots.filter((f) => dist(f) < 120).sort((a, b) => (a.skin === 1 ? 0 : 1) - (b.skin === 1 ? 0 : 1) || dist(a) - dist(b))[0];
    if (sari && this.healT <= 0 && p.hp < 55) {
      // Sari patches you up
      p.hp = Math.min(100, p.hp + 40);
      this.healT = 26;
      g.say(p.x, p.y - 22, "+40", "#7dff9a");
      g.snd("pick", p.x, p.y, 1);
      this.say("healGive", { who: sari, force: true, cd: 0 });
      g.hudDirty = true;
    }
    const jaka = bots.find((f) => f.skin === 0);
    if (jaka && this.giftT <= 0 && p.hp < 80 && calm && dist(jaka) < 120) {
      // Jaka always finds something in a pocket
      g.pickups.push({ x: p.x + (jaka.x > p.x ? 10 : -10), y: p.y + 6, t: 0.2 });
      this.giftT = 75;
      this.say("gift", { who: jaka, force: true, cd: 0 });
    }
    const nadia = bots.find((f) => f.skin === 3);
    if (nadia && this.spotT <= 0 && B.stage === 0 && calm && h < 0) {
      // Nadia reads the map
      let best = -1, bd = 1e9;
      B.objHouses.forEach((hi, i) => {
        if (B.found[i]) return;
        const H = HOUSES[hi], d = Math.hypot((H.x + H.w / 2) * TILE - p.x, (H.y + H.h / 2) * TILE - p.y);
        if (d < bd) { bd = d; best = hi; }
      });
      if (best >= 0 && bd > 150) {
        const H = HOUSES[best], dx = (H.x + H.w / 2) * TILE - p.x, dy = (H.y + H.h / 2) * TILE - p.y;
        const D = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "TIMUR" : "BARAT") : dy > 0 ? "SELATAN" : "UTARA";
        if (this.say("spot", { who: nadia, vars: { D }, cd: 0 })) this.spotT = 55;
      }
    }
    // quiet moments: small talk that depends on the mood and on what happened before
    if ((this.idleT -= 0.5) <= 0 && calm) {
      this.idleT = 13 + rand() * 10;
      const owe = bots.find((f) => this.saved.includes(f.id) && !this.thanked.includes(f.id));
      if (this.morale < 0.5) this.say("idleLow", { cd: 20 });
      else if (owe && this.say("grat", { who: owe, cd: 20 })) this.thanked.push(owe.id);
      else if (this.downs >= 2 && !this.teased && this.say("tease", { cd: 20 })) this.teased = true;
      else this.say("idle", { cd: 10, reply: rand() < 0.65 ? "reply" : undefined });
    }
  }
}

import { MAX_HP, WEAPONS, WEAPON_ORDER } from "./defs";
import type { Fighter, Game } from "./engine";
import { drawText } from "./sprites";
import { audio } from "./audio";
import { BUS_WIN, drawBus } from "./bus";

/**
 * The road between two maps: everybody is on the school bus, the country rolls by, and for once nothing is trying to eat you.
 * Time to look after yourself: dress wounds, service the guns, fill the magazines, pick what to carry, sleep a little.
 * The bus drives until it gets there and then waits: you get off when you are ready.
 */
export interface RideHud {
  prog: number; busy: string; busyK: number; meds: number; tuned: boolean; loaded: boolean; napped: boolean;
  weapon: string; next: string; ready: boolean; hp: number;
}
interface Bit { x: number; y: number; vx: number; vy: number; life: number; max: number; col: string; k: number }

const hash = (n: number) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const mod = (a: number, m: number) => ((a % m) + m) % m;
const LABEL: Record<string, string> = { med: "MERAWAT LUKA...", fix: "MENYERVIS SENJATA...", load: "MENGISI SEMUA MAGASIN...", nap: "TIDUR SEBENTAR..." };
const WRECK = ["#b3262a", "#3f6a8a", "#d9c23a", "#c9cdd9", "#4a7a4a"];

export class Ride {
  t = 0; prog = 0; done = false; leaving = 0; off = 0; speed = 0;
  busy = ""; busyT = 0; busyDur = 1;
  meds = 3; tuned = false; loaded = false; napped = false;
  note = ""; noteT = 0; noteCol = "#fff0a8";
  private humT = 0.2; private hudT = 0; private fxT = 0;
  private bits: Bit[] = [];
  /** the last frame: the size of the view, and where your window is */
  private W = 480; private H = 270; private px = 240; private py = 150;
  private g: Game;
  next: string;

  constructor(g: Game, next: string) {
    this.g = g;
    this.next = next;
  }

  /** everybody on the bus: you first, then the squad, then the people you found */
  private crew(): Fighter[] {
    const list = this.g.fighters.filter((f) => f.team === 0 && !(f.civ && f.hid));
    return list.sort((a, b) => (a.isPlayer ? 0 : a.civ ? 2 : 1) - (b.isPlayer ? 0 : b.civ ? 2 : 1));
  }

  private say(text: string, col: string) { this.note = text; this.noteT = 2.6; this.noteCol = col; }
  private bit(k: number, col: string, x = this.px, y = this.py, vx = 0, vy = -26, max = 1) {
    if (this.bits.length < 90) this.bits.push({ x, y, vx, vy, life: max, max, col, k });
  }

  key(c: string) {
    if (c === "Digit1" || c === "KeyH") this.act("med");
    else if (c === "Digit2") this.act("fix");
    else if (c === "Digit3" || c === "KeyR") this.act("load");
    else if (c === "Digit4" || c === "KeyQ") this.act("gun");
    else if (c === "Digit5" || c === "KeyC") this.act("nap");
    else if (c === "Enter" || c === "NumpadEnter") this.act("go"); // (not Space: that one is pressed out of habit)
  }

  act(id: string) {
    const g = this.g, p = g.player;
    if (this.leaving > 0 || this.t < 0.8) return;
    if (id === "go") { this.leaving = 0.01; audio.play("door"); return; }
    if (this.busy || !p) return;
    if (id === "gun") { g.cycle(1); audio.play("click"); this.say(`BAWA: ${WEAPONS[p.weapon].name}`, "#9fd8ff"); g.hudDirty = true; return; }
    if (id === "med") {
      const hurt = this.crew().some((f) => f.alive && f.hp < MAX_HP - 1);
      if (this.meds <= 0 || !hurt) { audio.play("click"); this.say(this.meds <= 0 ? "OBAT SUDAH HABIS" : "SEMUA ORANG SEHAT", "#ffb347"); return; }
      this.meds--;
      this.busyDur = 2.4;
    } else if (id === "fix") {
      if (this.tuned) { audio.play("click"); this.say("SENJATA SUDAH PRIMA", "#ffb347"); return; }
      this.busyDur = 3.2;
    } else if (id === "load") this.busyDur = 2;
    else if (id === "nap") this.busyDur = 4;
    else return;
    this.busy = id; this.busyT = 0; this.fxT = 0;
    audio.play("pick");
    g.hudDirty = true;
  }

  private finish() {
    const g = this.g, p = g.player, crew = this.crew();
    if (this.busy === "med") {
      for (const f of crew) if (f.alive) { f.hp = Math.min(MAX_HP, f.hp + 45); f.joy = 2; }
      this.say("LUKA DIRAWAT: +45 HP UNTUK SEMUA", "#7dff9a");
      audio.play("win", 0.6);
    } else if (this.busy === "fix") {
      this.tuned = true; g.tune = 1;
      this.say("SENJATA PRIMA: +15% DAMAGE DI KOTA BERIKUTNYA", "#ffe45c");
      audio.play("win", 0.6);
    } else if (this.busy === "load") {
      for (const f of crew) { for (const id of WEAPON_ORDER) f.ammo[id] = WEAPONS[id].mag; f.reloadT = 0; }
      this.loaded = true;
      this.say("SEMUA MAGASIN PENUH", "#9fd8ff");
      audio.play("click");
    } else if (this.busy === "nap") {
      for (const f of crew) if (f.alive) { f.hp = Math.min(MAX_HP, f.hp + 20); f.stam = 100; f.exh = false; }
      this.napped = true;
      this.say("SEGAR KEMBALI: +20 HP, TENAGA PENUH", "#8af0ff");
      audio.play("win", 0.5);
    }
    if (p) p.joy = 2;
    this.busy = "";
    g.hudDirty = true;
  }

  update(dt: number) {
    const g = this.g;
    this.t += dt;
    const going = this.prog < 1 && this.leaving <= 0;
    this.speed += ((going ? 175 : 0) - this.speed) * Math.min(1, dt * (going ? 1.4 : 1.1)); // it pulls over when it gets there
    this.off += this.speed * dt;
    this.prog = Math.min(1, this.prog + dt / 42);
    // on the road everybody gets their breath back, and the worst wounds stop bleeding
    for (const f of this.crew()) if (f.alive) { f.stam = Math.min(100, f.stam + 18 * dt); if (f.hp < 55) f.hp = Math.min(55, f.hp + 1.5 * dt); }
    if (this.noteT > 0) this.noteT -= dt;
    if (this.busy) {
      this.busyT += dt;
      if ((this.fxT -= dt) <= 0) {
        this.fxT = this.busy === "nap" ? 0.6 : this.busy === "med" ? 0.2 : 0.14;
        const r = () => Math.random() - 0.5;
        if (this.busy === "med") this.bit(1, "#7dff9a", this.px + r() * 22, this.py + 6, r() * 10, -28, 1);
        else if (this.busy === "fix") { for (let i = 0; i < 3; i++) this.bit(2, i ? "#ffe45c" : "#ffffff", this.px + r() * 10, this.py + 14, r() * 110, -40 - Math.random() * 70, 0.4); if (Math.random() < 0.45) audio.play(Math.random() < 0.5 ? "click" : "thunk", 0.35); }
        else if (this.busy === "load") { this.bit(3, "#f1cf6a", this.px + r() * 12, this.py + 14, r() * 60, -70 - Math.random() * 40, 0.6); audio.play("click", 0.4); }
        else this.bit(4, "#bfe2ff", this.px + 8, this.py - 2, 9, -16, 1.6);
      }
      if (this.busyT >= this.busyDur) this.finish();
    }
    if (this.speed > 30 && (this.humT -= dt) <= 0) { this.humT = 2.3; audio.play("engine", 0.3); }
    // exhaust
    if (this.speed > 30 && Math.random() < dt * 16) {
      const S = this.W >= 380 && this.H >= 220 ? 3 : 2;
      this.bit(0, Math.random() < 0.5 ? "#d9d4c8" : "#a9a498", this.W * 0.47 - 43 * S, this.H * 0.7 - 2 * S, -50 - Math.random() * 40, -8 - Math.random() * 10, 0.9);
    }
    for (let i = this.bits.length - 1; i >= 0; i--) {
      const b = this.bits[i];
      b.life -= dt;
      if (b.life <= 0) { this.bits.splice(i, 1); continue; }
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.k === 2 || b.k === 3) b.vy += 260 * dt;
    }
    if (this.leaving > 0) { this.leaving += dt; if (this.leaving > 0.75) this.done = true; }
    if ((this.hudT -= dt) <= 0) { this.hudT = 0.2; g.hudDirty = true; }
  }

  hud(): RideHud {
    const p = this.g.player;
    return {
      prog: this.prog, busy: this.busy ? LABEL[this.busy] : "", busyK: this.busy ? Math.min(1, this.busyT / this.busyDur) : 0,
      meds: this.meds, tuned: this.tuned, loaded: this.loaded, napped: this.napped,
      weapon: p ? WEAPONS[p.weapon].name : "", next: this.next, ready: this.prog >= 1, hp: p ? Math.max(0, Math.ceil(p.hp)) : 0,
    };
  }

  render(ctx: CanvasRenderingContext2D, W: number, H: number) {
    const g = this.g, t = this.t, off = this.off;
    this.W = W; this.H = H;
    const hz = Math.round(H * 0.44), road = Math.round(H * 0.52), gy = Math.round(H * 0.7);
    const S = W >= 380 && H >= 220 ? 3 : 2;
    const R = (c: string, x: number, y: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
    const ell = (c: string, x: number, y: number, rx: number, ry: number) => { ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 6.2832); ctx.fill(); };
    ctx.save();
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    // a bright day: blue sky, big white clouds
    const sky = ctx.createLinearGradient(0, 0, 0, hz);
    sky.addColorStop(0, "#5aa6e8"); sky.addColorStop(0.7, "#bfe3fc"); sky.addColorStop(1, "#ecf8ff");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, hz + 1);
    ell("rgba(255,252,225,0.35)", W * 0.8, H * 0.13, 22, 22);
    ell("#fffbe0", W * 0.8, H * 0.13, 10, 10);
    for (let i = 0; i < 8; i++) {
      const sp = 4 + (i % 3) * 3, r = 13 + (i % 4) * 6, x = mod(i * 113 + 30 - off * 0.02 - t * sp, W + 200) - 100, y = 12 + ((i * 41) % Math.max(20, hz - 54));
      ell("rgba(190,208,230,0.8)", x, y + r * 0.22, r * 1.5, r * 0.34);
      ell("#ffffff", x, y, r * 1.6, r * 0.46); ell("#ffffff", x - r * 0.6, y - r * 0.24, r * 0.75, r * 0.42); ell("#ffffff", x + r * 0.5, y - r * 0.34, r * 0.85, r * 0.5);
    }
    const layer = (par: number, gap: number, fn: (i: number, x: number) => void) => {
      const o = off * par, i0 = Math.floor(o / gap) - 1, i1 = Math.floor((o + W) / gap) + 1;
      for (let i = i0; i <= i1; i++) fn(i, Math.round(i * gap + hash(i * 7 + gap) * gap * 0.5 - o));
    };
    // far away: the towers of a city
    layer(0.05, 34, (i, x) => {
      const h = Math.round(12 + hash(i) * 40), w = Math.round(12 + hash(i + 90) * 14);
      R("#9db9d6", x, hz - h, w, h); R("#b6cee6", x, hz - h, 2, h);
      for (let yy = hz - h + 3; yy < hz - 3; yy += 5) for (let xx = x + 4; xx < x + w - 2; xx += 4) if (hash(i * 31 + yy * 7 + xx) < 0.5) R("#86a5c6", xx, yy, 2, 2);
    });
    for (let i = 0; i < 6; i++) ell(i % 2 ? "#7fb878" : "#8cc283", mod(i * 190 - off * 0.1, 1140) - 220, hz + 8, 150, 20 + (i % 3) * 8);
    R("#7cb56a", 0, hz, W, road - hz);
    R("#8fc77c", 0, hz, W, 2);
    // the middle distance: trees, farmhouses, a water tower, a billboard, bushes
    layer(0.3, 64, (i, x) => {
      const k = Math.floor(hash(i + 3) * 7), by = Math.round(road - 5 - hash(i + 9) * 6);
      if (k < 3) { R("#6a4a30", x + 5, by - 12, 3, 12); ell(k === 1 ? "#3f8a44" : "#4f9d4c", x + 6, by - 17, 9, 9); ell("#66b55c", x + 4, by - 20, 5, 5); }
      else if (k === 3) { R("#0b0b10", x - 1, by - 15, 26, 16); R("#d6c19a", x, by - 14, 24, 14); R("#9c4a3a", x - 2, by - 20, 28, 6); R("#b8604c", x - 2, by - 20, 28, 1); R("#3a5878", x + 4, by - 10, 5, 5); R("#3a5878", x + 15, by - 10, 5, 5); R("#5a3a26", x + 10, by - 8, 4, 8); }
      else if (k === 4) { R("#5a5f6a", x + 4, by - 26, 2, 26); R("#5a5f6a", x + 14, by - 26, 2, 26); R("#0b0b10", x - 1, by - 39, 22, 15); R("#8a6844", x, by - 38, 20, 13); R("#a8845c", x, by - 38, 20, 2); }
      else if (k === 5) { R("#3a3f4a", x + 14, by - 22, 2, 22); R("#0b0b10", x - 1, by - 37, 34, 16); R("#f2ead8", x, by - 36, 32, 14); drawText(ctx, "AMAN >", x + 16, by - 32, "#b3262a", "#f2ead8"); }
      else { ell("#5aa552", x + 6, by - 3, 8, 4); ell("#6fbb62", x + 12, by - 4, 6, 4); }
    });
    // the road
    R("#3b3e49", 0, road, W, H - road); R("#5a5e6b", 0, road, W, 2); R("#e9e3c9", 0, road + 5, W, 1);
    const yc = Math.round(road + (gy - road) * 0.42);
    for (let x = -mod(off, 44); x < W; x += 44) R("#f5c542", x, yc, 22, 2);
    for (let i = 0; i < 26; i++) R("rgba(0,0,0,0.13)", mod(i * 53 - off, W + 40) - 20, road + 8 + ((i * 29) % Math.max(8, H - road - 16)), 5 + (i % 4) * 3, 1);
    // along the kerb: lamp posts, wrecks, signs - and the dead, reaching for the bus as it goes by
    layer(1, 132, (i, x) => {
      const k = Math.floor(hash(i + 17) * 8), by = road + 4;
      if (k <= 1) { R("#2c2f38", x, by - 36, 2, 36); R("#2c2f38", x, by - 36, 11, 2); R("#fff3c0", x + 9, by - 34, 3, 2); }
      else if (k === 2) { R("#0b0b10", x - 1, by - 11, 36, 12); R(WRECK[Math.abs(i) % WRECK.length], x, by - 10, 34, 8); R("#0b0b10", x + 6, by - 17, 20, 7); R("#132238", x + 7, by - 16, 18, 6); R("#0b0b10", x + 4, by - 4, 7, 5); R("#0b0b10", x + 23, by - 4, 7, 5); R("rgba(0,0,0,0.3)", x + 12, by - 22 - (Math.sin(t * 2 + i) > 0 ? 1 : 0), 4, 5); }
      else if (k === 3 || k === 4) {
        const sw = Math.round(Math.sin(t * 5 + i) * 1.5);
        R("#0b0b10", x - 1, by - 18, 9, 19); R(k === 3 ? "#8fae7a" : "#9ab08a", x, by - 17, 7, 6); R("#ff3030", x + 3, by - 15, 1, 1); R("#ff3030", x + 5, by - 15, 1, 1);
        R(k === 3 ? "#4a5670" : "#6a4a50", x, by - 11, 7, 7); R("#2c3446", x, by - 4, 3, 4); R("#2c3446", x + 4, by - 4, 3, 4);
        R("#0b0b10", x + 6, by - 12 + sw, 6, 4); R("#8fae7a", x + 7, by - 11 + sw, 4, 2);
      } else if (k === 5) { R("#5a5f6a", x + 6, by - 22, 2, 22); R("#0b0b10", x - 1, by - 34, 16, 13); R("#2f8a4a", x, by - 33, 14, 11); R("#ffffff", x + 2, by - 28, 9, 1); R("#ffffff", x + 9, by - 30, 1, 5); R("#ffffff", x + 10, by - 29, 1, 3); }
      else if (k === 6) { R("#0b0b10", x - 1, by - 9, 7, 9); R("#e8742b", x, by - 8, 5, 8); R("#ffffff", x, by - 5, 5, 1); R("#0b0b10", x + 9, by - 9, 7, 9); R("#e8742b", x + 10, by - 8, 5, 8); R("#ffffff", x + 10, by - 5, 5, 1); }
    });
    // the bus
    const bump = this.speed > 60 && mod(off, 330) < 12 ? -2 : 0;
    const bx = Math.round(W * 0.47), byy = gy + Math.round(Math.sin(t * 8.5) * (this.speed > 30 ? 0.8 : 0)) + bump;
    for (const b of this.bits) if (b.k === 0) { const k = 1 - b.life / b.max; ctx.globalAlpha = 0.55 * (1 - k); ell(b.col, b.x, b.y, 3 + k * 8, 2.5 + k * 6); }
    ctx.globalAlpha = 1;
    ctx.save();
    ctx.translate(bx, byy);
    ctx.scale(S, S);
    drawBus(ctx, 0, 0, { t, moving: this.speed > 20, smooth: true, stop: this.speed < 8, flash: this.speed < 8 && this.prog >= 1 });
    ctx.restore();
    // everybody at their window: you sit behind the door, a friend drives
    const crew = this.crew(), seats = [4, 5, 3, 2, 1, 0];
    for (let i = 0; i < Math.min(6, crew.length); i++) {
      const f = crew[i], wi = seats[i], head = g.sp.head[f.look]?.[f.skin];
      const gx0 = bx + (BUS_WIN[wi] + 1) * S, gy0 = byy - 27 * S, cx = gx0 + 3.5 * S;
      if (head) {
        const asleep = (this.busy === "nap" || !f.alive) && i !== 1, nod = asleep ? 3 + Math.round(Math.sin(t * 1.4 + i)) : Math.round(Math.sin(t * 2 + i * 1.7) * 0.8);
        ctx.save();
        ctx.beginPath(); ctx.rect(gx0, gy0, 7 * S, 10 * S); ctx.clip();
        ctx.drawImage(head, Math.round(cx - head.width / 2), Math.round(gy0 + 5 * S - head.height / 2 + nod + (S === 2 ? 2 : 1)));
        ctx.restore();
        R("rgba(255,255,255,0.16)", gx0, gy0, 7 * S, 2 * S);
      }
      if (i === 0) {
        this.px = cx; this.py = gy0;
        // that one is you
        const b = Math.round(Math.sin(t * 6) * 1.5), ay = byy - 38 * S - 8 + b;
        R("#0a0a0f", cx - 4, ay, 9, 3); R("#0a0a0f", cx - 3, ay + 3, 7, 2); R("#0a0a0f", cx - 1, ay + 5, 3, 2);
        R("#fff0a8", cx - 3, ay + 1, 7, 2); R("#fff0a8", cx - 2, ay + 3, 5, 1); R("#fff0a8", cx, ay + 4, 1, 2);
      }
    }
    // what you are busy with, flying out of your window
    for (const b of this.bits) {
      if (b.k === 0) continue;
      ctx.globalAlpha = Math.min(1, (b.life / b.max) * 2);
      if (b.k === 1) { R("#0a0a0f", b.x - 3, b.y - 3, 7, 7); R(b.col, b.x - 2, b.y - 1, 5, 1); R(b.col, b.x, b.y - 2, 1, 5); R(b.col, b.x - 1, b.y - 2, 3, 5); R(b.col, b.x - 2, b.y - 1, 5, 3); }
      else if (b.k === 2) R(b.col, b.x, b.y, 2, 2);
      else if (b.k === 3) { R("#0a0a0f", b.x - 1, b.y - 1, 5, 4); R(b.col, b.x, b.y, 3, 2); }
      else drawText(ctx, "Z", b.x, b.y, b.col, "#0c0a10");
    }
    ctx.globalAlpha = 1;
    // right up close: the guard rail, flashing past
    R("#22252d", 0, H - 12, W, 2); R("#c9cdd9", 0, H - 12, W, 1);
    for (let x = -mod(off * 1.7, 96); x < W; x += 96) R("#22252d", x, H - 12, 5, 12);
    // where to, and how far still
    ctx.save();
    ctx.translate(Math.round(W / 2), 9);
    ctx.scale(2, 2);
    drawText(ctx, `MENUJU ${this.next}`, 0, 0, "#fff0a8", "#0c0a10");
    ctx.restore();
    const bw = Math.min(230, W - 70), bx0 = Math.round((W - bw) / 2), by0 = 27, tip = bx0 + Math.round(bw * this.prog);
    R("#0c0a10", bx0 - 2, by0 - 2, bw + 4, 8); R("#2a2c36", bx0, by0, bw, 4); R("#f5c542", bx0, by0, bw * this.prog, 4);
    R("#0b0b10", tip - 6, by0 - 4, 13, 8); R("#f6b91c", tip - 5, by0 - 3, 11, 5); R("#132238", tip - 3, by0 - 2, 6, 2); R("#0b0b10", tip - 4, by0 + 2, 3, 2); R("#0b0b10", tip + 2, by0 + 2, 3, 2);
    drawText(ctx, this.prog >= 1 ? "SUDAH SAMPAI!" : `${Math.max(1, Math.ceil((1 - this.prog) * 14))} KM LAGI - MODE ISTIRAHAT`, Math.round(W / 2), by0 + 10, "#ffffff", "#0c0a10");
    if (this.busy) {
      const w2 = 120, x2 = Math.round((W - w2) / 2), y2 = gy + 22;
      drawText(ctx, LABEL[this.busy], Math.round(W / 2), y2 - 10, "#8af0ff", "#0c0a10");
      R("#0c0a10", x2 - 2, y2 - 2, w2 + 4, 7); R("#2a2c36", x2, y2, w2, 3); R("#7dff9a", x2, y2, w2 * Math.min(1, this.busyT / this.busyDur), 3);
    } else if (this.noteT > 0) {
      ctx.globalAlpha = Math.min(1, this.noteT * 2);
      drawText(ctx, this.note, Math.round(W / 2), gy + 15 - Math.round((2.6 - this.noteT) * 2), this.noteCol, "#0c0a10");
      ctx.globalAlpha = 1;
    } else if (this.prog >= 1 && Math.sin(t * 5) > -0.3) drawText(ctx, "TEKAN [ENTER] UNTUK TURUN", Math.round(W / 2), gy + 15, "#7dff9a", "#0c0a10");
    // in and out through a blink of darkness
    const a = this.leaving > 0 ? Math.min(1, this.leaving / 0.6) : Math.max(0, 1 - t / 0.7);
    if (a > 0) { ctx.fillStyle = `rgba(5,3,12,${a.toFixed(3)})`; ctx.fillRect(0, 0, W, H); }
    ctx.restore();
  }
}

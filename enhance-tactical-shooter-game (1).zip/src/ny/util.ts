export const T = 16;
export const MW = 176;
export const MH = 224;

export type Rng = () => number;
export type G = CanvasRenderingContext2D;

export interface Board {
  x: number;
  y: number;
  w: number;
  h: number;
  kind: number;
  seed: number;
}

/** Sprite: canvas + optional night data */
export interface Tier3D {
  x: number;
  w: number;
  top: number;
  h: number;
  d: number;
  z0: number;
}

export interface Spr {
  c: HTMLCanvasElement;
  /** the colour of its walls (buildings) */
  wall?: string;
  /** stacked setback tiers for skyscrapers */
  tiers?: Tier3D[];
  /** crown / spire height above the top tier */
  spireY?: number;
  /** special 3D landmark kind */
  kind3d?: 'arena' | 'cathedral';
  /** lit windows: x,y,w,h,colorIdx (flat) */
  lights?: number[];
  /** regions that stay bright at night: x,y,w,h (flat) */
  glows?: number[];
  /** animated billboards */
  boards?: Board[];
  /** lamp glows: x,y,radius (flat) */
  lamps?: number[];
}

export function mulberry32(a: number): Rng {
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const ri = (r: Rng, a: number, b: number) => a + Math.floor(r() * (b - a + 1));

export function pick<X>(r: Rng, arr: readonly X[]): X {
  return arr[Math.floor(r() * arr.length) % arr.length];
}

export function hash2(x: number, y: number): number {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return (h ^ (h >>> 16)) >>> 0;
}

/** multiply a #rrggbb colour's brightness */
export function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v * f)));
  const r = c(n >> 16);
  const g = c((n >> 8) & 255);
  const b = c(n & 255);
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

export function mixc(a: string, b: string, t: number): string {
  const x = parseInt(a.slice(1), 16);
  const y = parseInt(b.slice(1), 16);
  const m = (s: number) => Math.round(((x >> s) & 255) * (1 - t) + ((y >> s) & 255) * t);
  return '#' + ((1 << 24) | (m(16) << 16) | (m(8) << 8) | m(0)).toString(16).slice(1);
}

export function mkCanvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  const g = c.getContext('2d')!;
  g.imageSmoothingEnabled = false;
  return { c, g };
}

export function R(g: G, col: string, x: number, y: number, w: number, h: number) {
  if (w <= 0 || h <= 0) return;
  g.fillStyle = col;
  g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

/** filled ellipse (scanlines) */
export function ell(g: G, col: string, cx: number, cy: number, rx: number, ry: number) {
  g.fillStyle = col;
  for (let dy = -ry; dy <= ry; dy++) {
    const hw = Math.round(rx * Math.sqrt(Math.max(0, 1 - (dy * dy) / (ry * ry + 0.001))));
    g.fillRect(Math.round(cx - hw), Math.round(cy + dy), hw * 2 + 1, 1);
  }
}

/** filled triangle, apex on top */
export function tri(g: G, col: string, cx: number, top: number, halfW: number, h: number) {
  g.fillStyle = col;
  for (let i = 0; i < h; i++) {
    const hw = Math.max(1, Math.round((halfW * (i + 1)) / h));
    g.fillRect(Math.round(cx - hw), Math.round(top + i), hw * 2, 1);
  }
}

export function line(g: G, col: string, x0: number, y0: number, x1: number, y1: number) {
  g.fillStyle = col;
  x0 = Math.round(x0);
  y0 = Math.round(y0);
  x1 = Math.round(x1);
  y1 = Math.round(y1);
  const dx = Math.abs(x1 - x0);
  const dy = -Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  for (let i = 0; i < 2000; i++) {
    g.fillRect(x0, y0, 1, 1);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) {
      err += dy;
      x0 += sx;
    }
    if (e2 <= dx) {
      err += dx;
      y0 += sy;
    }
  }
}

/** draw a pixel map: rows of chars, palette maps char -> colour ('.' = transparent) */
export function pix(g: G, x: number, y: number, rows: string[], pal: Record<string, string>) {
  for (let j = 0; j < rows.length; j++) {
    const row = rows[j];
    for (let i = 0; i < row.length; i++) {
      const c = pal[row[i]];
      if (c) {
        g.fillStyle = c;
        g.fillRect(x + i, y + j, 1, 1);
      }
    }
  }
}

/** add a 1px outline around all opaque pixels */
export function outline(c: HTMLCanvasElement, col = '#1b1b26') {
  const g = c.getContext('2d')!;
  const w = c.width;
  const h = c.height;
  const im = g.getImageData(0, 0, w, h);
  const d = im.data;
  const src = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) src[i] = d[i * 4 + 3] > 40 ? 1 : 0;
  const n = parseInt(col.slice(1), 16);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      if (src[i]) continue;
      if ((x > 0 && src[i - 1]) || (x < w - 1 && src[i + 1]) || (y > 0 && src[i - w]) || (y < h - 1 && src[i + w])) {
        d[i * 4] = n >> 16;
        d[i * 4 + 1] = (n >> 8) & 255;
        d[i * 4 + 2] = n & 255;
        d[i * 4 + 3] = 255;
      }
    }
  }
  g.putImageData(im, 0, 0);
}

// ---------------------------------------------------------------- 3x5 font
const FONT: Record<string, string> = {
  A: '010101111101101',
  B: '110101110101110',
  C: '011100100100011',
  D: '110101101101110',
  E: '111100110100111',
  F: '111100110100100',
  G: '011100101101011',
  H: '101101111101101',
  I: '111010010010111',
  J: '001001001101010',
  K: '101101110101101',
  L: '100100100100111',
  M: '101111111101101',
  N: '110101101101101',
  O: '010101101101010',
  P: '110101110100100',
  Q: '010101101110011',
  R: '110101110101101',
  S: '011100010001110',
  T: '111010010010010',
  U: '101101101101111',
  V: '101101101101010',
  W: '101101111111101',
  X: '101101010101101',
  Y: '101101010010010',
  Z: '111001010100111',
  '0': '111101101101111',
  '1': '010110010010111',
  '2': '110001010100111',
  '3': '110001010001110',
  '4': '101101111001001',
  '5': '111100110001110',
  '6': '011100111101111',
  '7': '111001010010010',
  '8': '111101111101111',
  '9': '111101111001110',
  '.': '000000000000010',
  ',': '000000000010100',
  '!': '010010010000010',
  '?': '110001010000010',
  "'": '010010000000000',
  '-': '000000111000000',
  ':': '000010000010000',
  '+': '000010111010000',
  '/': '001001010100100',
  '&': '010101010101011',
  $: '011110010011110',
  '{': '000101111111010', // heart
  '}': '011011010110110', // music note
  '*': '000101010101000',
};

export function drawText(g: G, s: string, x: number, y: number, col: string) {
  g.fillStyle = col;
  let cx = Math.round(x);
  const yy = Math.round(y);
  const u = s.toUpperCase();
  for (let k = 0; k < u.length; k++) {
    const d = FONT[u[k]];
    if (d) for (let i = 0; i < 15; i++) if (d[i] === '1') g.fillRect(cx + (i % 3), yy + ((i / 3) | 0), 1, 1);
    cx += 4;
  }
}

export const textW = (s: string) => s.length * 4 - 1;

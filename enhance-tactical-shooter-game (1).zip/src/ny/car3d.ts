import { shade } from './util';

/**
 * True 3D oblique-perspective vehicle renderer for New York & City vehicles.
 * Draws sedans, NYC yellow cabs, NYPD cruisers, city transit buses, delivery vans,
 * street-food trucks, and the armored Yellow School Bus at any yaw angle `ang`.
 */
type G = CanvasRenderingContext2D;

export interface Car3DOpt {
  /** center position on screen (worldX - cl, worldY - ct) */
  x: number;
  y: number;
  /** yaw in radians (0 = East, PI/2 = South, PI = West, -PI/2 = North) */
  ang: number;
  /** 0 sedan, 1 taxi, 2 police, 3 city bus, 4 van, 6 food truck, 7 school bus */
  kind: number;
  body: string;
  len?: number;
  sign?: string;
  /** viewport center for 3D perspective parallax */
  vx: number;
  vy: number;
  night?: boolean;
  /** animated clock */
  t?: number;
  moving?: boolean;
  /** abandoned wreck in zombie mode */
  wreck?: boolean;
  /** school bus options */
  ram?: boolean;
  riders?: number;
  stop?: boolean;
  flash?: boolean;
  gunA?: number;
  gunFlash?: boolean;
}

const P3 = (wx: number, wy: number, z: number, vx: number, vy: number): [number, number] => {
  const e = z <= 0 ? 0 : 0.14 * (1 - Math.exp(-z / 65));
  return [
    vx + (wx - vx) * (1 + e),
    vy + (wy - vy) * (1 + e * 0.45) - z * 0.88,
  ];
};

/** draw a 3D oriented box [u0..u1] (along car forward) x [v0..v1] (right) x [z0..z1] */
function drawBox(
  g: G,
  cx: number, cy: number, ca: number, sa: number,
  u0: number, u1: number, v0: number, v1: number, z0: number, z1: number,
  vx: number, vy: number,
  topCol: string, frontCol: string, rearCol: string, rightCol: string, leftCol: string,
  outline = '#0b0b10',
  onFace?: (face: number, P: (u: number, v: number, z: number) => [number, number]) => void,
) {
  const world = (u: number, v: number): [number, number] => [cx + u * ca - v * sa, cy + u * sa + v * ca];
  const pt = (u: number, v: number, z: number): [number, number] => {
    const [wx, wy] = world(u, v);
    return P3(wx, wy, z, vx, vy);
  };
  const b = [pt(u0, v0, z0), pt(u1, v0, z0), pt(u1, v1, z0), pt(u0, v1, z0)];
  const tp = [pt(u0, v0, z1), pt(u1, v0, z1), pt(u1, v1, z1), pt(u0, v1, z1)];

  // 4 side faces: 0=left(v0, u0->u1), 1=front(u1, v0->v1), 2=right(v1, u1->u0), 3=rear(u0, v1->v0)
  // Notice: in screen coords (y down), clockwise winding in top-down (u=x, v=y) has bottom-normal visible when cross((p1-p0), (pt0-p0)) > 0 or < 0.
  const faces: { idx: number; a: number; b: number; col: string; fn: (u: number, v: number, z: number) => [number, number] }[] = [
    { idx: 0, a: 0, b: 1, col: leftCol, fn: (t, _v, z) => pt(u0 + (u1 - u0) * t, v0, z0 + (z1 - z0) * z) },
    { idx: 1, a: 1, b: 2, col: frontCol, fn: (_u, t, z) => pt(u1, v0 + (v1 - v0) * t, z0 + (z1 - z0) * z) },
    { idx: 2, a: 2, b: 3, col: rightCol, fn: (t, _v, z) => pt(u1 + (u0 - u1) * t, v1, z0 + (z1 - z0) * z) },
    { idx: 3, a: 3, b: 0, col: rearCol, fn: (_u, t, z) => pt(u0, v1 + (v0 - v1) * t, z0 + (z1 - z0) * z) },
  ];

  // sort faces back-to-front by midpoint Y on screen, cull back-facing using signed 2D normal against camera
  const vis = faces.filter((f) => {
    const p0 = b[f.a], p1 = b[f.b], q0 = tp[f.a];
    // outer normal check: cross of edge (p1-p0) and up-edge (q0-p0)
    const cross = (p1[0] - p0[0]) * (q0[1] - p0[1]) - (p1[1] - p0[1]) * (q0[0] - p0[0]);
    return cross > 0;
  });
  vis.sort((p, q) => (b[p.a][1] + b[p.b][1]) - (b[q.a][1] + b[q.b][1]));

  for (const f of vis) {
    const p0 = b[f.a], p1 = b[f.b], q1 = tp[f.b], q0 = tp[f.a];
    g.fillStyle = f.col;
    g.beginPath();
    g.moveTo(p0[0], p0[1]); g.lineTo(p1[0], p1[1]); g.lineTo(q1[0], q1[1]); g.lineTo(q0[0], q0[1]);
    g.closePath();
    g.fill();
    if (onFace) onFace(f.idx, f.fn);
    if (outline) {
      g.strokeStyle = outline;
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(p0[0], p0[1]); g.lineTo(p1[0], p1[1]); g.lineTo(q1[0], q1[1]); g.lineTo(q0[0], q0[1]);
      g.closePath();
      g.stroke();
    }
  }

  // top face
  g.fillStyle = topCol;
  g.beginPath();
  g.moveTo(tp[0][0], tp[0][1]); g.lineTo(tp[1][0], tp[1][1]); g.lineTo(tp[2][0], tp[2][1]); g.lineTo(tp[3][0], tp[3][1]);
  g.closePath();
  g.fill();
  if (outline) {
    g.strokeStyle = outline;
    g.lineWidth = 1;
    g.stroke();
  }
  return { pt, tp };
}

function drawQuad(g: G, col: string, pts: [number, number][]) {
  g.fillStyle = col;
  g.beginPath();
  g.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
  g.closePath();
  g.fill();
}

export function drawCar3D(g: G, o: Car3DOpt) {
  const { x, y, ang, kind, body, vx, vy } = o;
  const ca = Math.cos(ang), sa = Math.sin(ang);
  const t = o.t ?? 0;
  const len = o.len ?? (kind === 3 ? 52 : kind === 6 ? 40 : kind === 4 ? 36 : 32);
  const hl = len * 0.5 - 1;
  const hw = kind >= 3 ? 8.2 : 7.4;

  // contact shadow under vehicle (with slight westward sunlight offset)
  const sh = [
    P3(x + (-hl - 2) * ca - (-hw - 1) * sa, y + (-hl - 2) * sa + (-hw - 1) * ca, 0, vx, vy),
    P3(x + (hl + 2) * ca - (-hw - 1) * sa, y + (hl + 2) * sa + (-hw - 1) * ca, 0, vx, vy),
    P3(x + (hl + 2) * ca - (hw + 1) * sa, y + (hl + 2) * sa + (hw + 1) * ca, 0, vx, vy),
    P3(x + (-hl - 2) * ca - (hw + 1) * sa, y + (-hl - 2) * sa + (hw + 1) * ca, 0, vx, vy),
  ];
  drawQuad(g, 'rgba(0,0,0,0.34)', sh);

  // 4 tires (drawn as compact dark boxes at corners)
  const wheelU = kind === 3 ? [hl - 10, -hl + 10] : [hl - 6.5, -hl + 6.5];
  for (const wu of wheelU) {
    for (const wv of [-hw - 0.6, hw - 1.6]) {
      drawBox(g, x, y, ca, sa, wu - 3.2, wu + 3.2, wv, wv + 2.2, 0, 3.6, vx, vy, '#1a1c24', '#14151b', '#14151b', '#262832', '#262832', '#090a0e');
    }
  }

  const wreckF = o.wreck ? 0.84 : 1;
  const cTop = shade(body, 1.15 * wreckF);
  const cFront = shade(body, 0.92 * wreckF);
  const cRear = shade(body, 0.72 * wreckF);
  const cRight = shade(body, 0.86 * wreckF);
  const cLeft = shade(body, 0.76 * wreckF);
  const glass = o.wreck ? '#18212e' : '#24364e';
  const glassHi = o.wreck ? '#2c3c52' : '#5e88b8';
  const hlCol = o.wreck ? '#8f8872' : o.night ? '#fff8cc' : '#ffefaa';
  const tlCol = o.wreck ? '#6e2222' : '#e03a3a';

  if (kind === 3 || kind === 4 || kind === 6) {
    // Tall boxy vehicles: City Bus (3), Delivery Van (4), Food Truck (6)
    const hTop = kind === 3 ? 17 : kind === 6 ? 15.5 : 13.5;
    const bounce = o.moving ? Math.sin(t * 28) * 0.3 : 0;
    const res = drawBox(g, x, y, ca, sa, -hl, hl, -hw, hw, 2 + bounce, hTop + bounce, vx, vy, cTop, cFront, cRear, cRight, cLeft, '#0b0b10', (face, P) => {
      if (face === 1) {
        // Front: windshield + grille + headlights
        drawQuad(g, glass, [P(0, 0.1, 0.52), P(0, 0.9, 0.52), P(0, 0.9, 0.9), P(0, 0.1, 0.9)]);
        drawQuad(g, glassHi, [P(0, 0.14, 0.78), P(0, 0.45, 0.78), P(0, 0.45, 0.88), P(0, 0.14, 0.88)]);
        drawQuad(g, '#20242e', [P(0, 0.25, 0.12), P(0, 0.75, 0.12), P(0, 0.75, 0.34), P(0, 0.25, 0.34)]);
        drawQuad(g, hlCol, [P(0, 0.08, 0.16), P(0, 0.24, 0.16), P(0, 0.24, 0.3), P(0, 0.08, 0.3)]);
        drawQuad(g, hlCol, [P(0, 0.76, 0.16), P(0, 0.92, 0.16), P(0, 0.92, 0.3), P(0, 0.76, 0.3)]);
      } else if (face === 3) {
        // Rear: taillights + rear door/window
        drawQuad(g, tlCol, [P(0, 0.08, 0.22), P(0, 0.24, 0.22), P(0, 0.24, 0.38), P(0, 0.08, 0.38)]);
        drawQuad(g, tlCol, [P(0, 0.76, 0.22), P(0, 0.92, 0.22), P(0, 0.92, 0.38), P(0, 0.76, 0.38)]);
        if (kind === 3) drawQuad(g, glass, [P(0, 0.2, 0.58), P(0, 0.8, 0.58), P(0, 0.8, 0.84), P(0, 0.2, 0.84)]);
      } else {
        // Side faces
        const rev = face === 2;
        const u = (a: number) => (rev ? 1 - a : a);
        if (kind === 3) {
          // City transit bus stripe + row of passenger windows
          drawQuad(g, '#2a5fb8', [P(0, 0, 0.22), P(1, 0, 0.22), P(1, 0, 0.34), P(0, 0, 0.34)]);
          for (let i = 0; i < 6; i++) {
            const a0 = u(0.08 + i * 0.145), a1 = u(0.08 + i * 0.145 + 0.11);
            drawQuad(g, glass, [P(a0, 0, 0.5), P(a1, 0, 0.5), P(a1, 0, 0.84), P(a0, 0, 0.84)]);
          }
        } else if (kind === 6) {
          // Food truck: cab window + serving hatch
          const sign = o.sign ?? '#c0392b';
          drawQuad(g, glass, [P(u(0.72), 0, 0.48), P(u(0.94), 0, 0.48), P(u(0.94), 0, 0.84), P(u(0.72), 0, 0.84)]);
          drawQuad(g, '#16263a', [P(u(0.18), 0, 0.44), P(u(0.62), 0, 0.44), P(u(0.62), 0, 0.82), P(u(0.18), 0, 0.82)]);
          drawQuad(g, '#fff3c0', [P(u(0.21), 0, 0.52), P(u(0.59), 0, 0.52), P(u(0.59), 0, 0.72), P(u(0.21), 0, 0.72)]);
          for (let s = 0; s < 5; s++) {
            const x0 = u(0.16 + s * 0.095), x1 = u(0.16 + (s + 1) * 0.095);
            drawQuad(g, s % 2 ? '#ffffff' : sign, [P(x0, 0, 0.82), P(x1, 0, 0.82), P(x1, 0, 0.96), P(x0, 0, 0.96)]);
          }
        } else {
          // Delivery van: cab window + cargo panel
          drawQuad(g, glass, [P(u(0.68), 0, 0.48), P(u(0.94), 0, 0.48), P(u(0.94), 0, 0.84), P(u(0.68), 0, 0.84)]);
          drawQuad(g, shade(body, 0.72), [P(u(0.1), 0, 0.36), P(u(0.6), 0, 0.36), P(u(0.6), 0, 0.72), P(u(0.1), 0, 0.72)]);
        }
      }
    });

    // Roof details
    if (kind === 3) {
      drawBox(g, x, y, ca, sa, -hl + 8, -hl + 18, -4.5, 4.5, hTop + bounce, hTop + 2.2 + bounce, vx, vy, '#d4dae2', '#9ea6b2', '#828a96', '#b2bac4', '#8e96a2', '#1a1e26');
      drawBox(g, x, y, ca, sa, hl - 20, hl - 10, -4.5, 4.5, hTop + bounce, hTop + 2.2 + bounce, vx, vy, '#d4dae2', '#9ea6b2', '#828a96', '#b2bac4', '#8e96a2', '#1a1e26');
    } else if (kind === 6) {
      const sign = o.sign ?? '#c0392b';
      drawBox(g, x, y, ca, sa, -8, 6, -4.5, 4.5, hTop + bounce, hTop + 3.8 + bounce, vx, vy, sign, shade(sign, 0.9), shade(sign, 0.7), shade(sign, 0.85), shade(sign, 0.75), '#0b0b10');
    } else {
      drawQuad(g, shade(body, 1.24), [res.pt(-hl + 4, -hw + 2, hTop + bounce), res.pt(hl - 6, -hw + 2, hTop + bounce), res.pt(hl - 6, hw - 2, hTop + bounce), res.pt(-hl + 4, hw - 2, hTop + bounce)]);
    }
    return;
  }

  // Sedans (0), NYC Taxis (1), NYPD Police Cruisers (2): 2-tier 3D silhouette (lower chassis + inset cabin)
  const hCh = 7.4, hCab = 12.6;
  drawBox(g, x, y, ca, sa, -hl, hl, -hw, hw, 2, hCh, vx, vy, cTop, cFront, cRear, cRight, cLeft, '#0b0b10', (face, P) => {
    if (face === 1) {
      // Front bumper, grille, headlights
      drawQuad(g, '#222630', [P(0, 0.26, 0.2), P(0, 0.74, 0.2), P(0, 0.74, 0.58), P(0, 0.26, 0.58)]);
      drawQuad(g, hlCol, [P(0, 0.07, 0.34), P(0, 0.25, 0.34), P(0, 0.25, 0.65), P(0, 0.07, 0.65)]);
      drawQuad(g, hlCol, [P(0, 0.75, 0.34), P(0, 0.93, 0.34), P(0, 0.93, 0.65), P(0, 0.75, 0.65)]);
    } else if (face === 3) {
      drawQuad(g, tlCol, [P(0, 0.08, 0.38), P(0, 0.26, 0.38), P(0, 0.26, 0.68), P(0, 0.08, 0.68)]);
      drawQuad(g, tlCol, [P(0, 0.74, 0.38), P(0, 0.92, 0.38), P(0, 0.92, 0.68), P(0, 0.74, 0.68)]);
      drawQuad(g, '#dfe3ea', [P(0, 0.38, 0.32), P(0, 0.62, 0.32), P(0, 0.62, 0.54), P(0, 0.38, 0.54)]);
    } else {
      // Door seam + taxi checker / police stripe
      drawQuad(g, shade(body, 0.68), [P(0.49, 0, 0.1), P(0.51, 0, 0.1), P(0.51, 0, 0.92), P(0.49, 0, 0.92)]);
      if (kind === 1) {
        for (let i = 0; i < 7; i++) {
          drawQuad(g, i % 2 ? '#ffffff' : '#1c1d24', [P(0.15 + i * 0.1, 0, 0.45), P(0.15 + (i + 1) * 0.1, 0, 0.45), P(0.15 + (i + 1) * 0.1, 0, 0.68), P(0.15 + i * 0.1, 0, 0.68)]);
        }
      } else if (kind === 2) {
        drawQuad(g, '#2a4fb0', [P(0, 0, 0.36), P(1, 0, 0.36), P(1, 0, 0.66), P(0, 0, 0.66)]);
      }
    }
  });

  // Inset cabin greenhouse (leaves front hood and rear trunk!)
  const cabTop = shade(body, 1.26 * wreckF);
  drawBox(g, x, y, ca, sa, -hl + 5.5, hl - 7.5, -hw + 1.2, hw - 1.2, hCh, hCab, vx, vy, cabTop, glass, glass, cRight, cLeft, '#0b0b10', (face, P) => {
    if (face === 1 || face === 3) {
      drawQuad(g, glassHi, [P(0, 0.12, 0.55), P(0, 0.42, 0.55), P(0, 0.42, 0.82), P(0, 0.12, 0.82)]);
    } else {
      drawQuad(g, glass, [P(0.1, 0, 0.14), P(0.46, 0, 0.14), P(0.46, 0, 0.82), P(0.1, 0, 0.82)]);
      drawQuad(g, glass, [P(0.54, 0, 0.14), P(0.9, 0, 0.14), P(0.9, 0, 0.82), P(0.54, 0, 0.82)]);
    }
  });

  // Roof beacon: Taxi light or NYPD flashing lightbar
  if (kind === 1) {
    drawBox(g, x, y, ca, sa, -2.5, 1.5, -2.8, 2.8, hCab, hCab + 2.4, vx, vy, '#fff8c8', '#ffe45c', '#d8b838', '#ffe45c', '#e6c848', '#15151c');
  } else if (kind === 2) {
    const fl = !o.wreck && Math.floor(t * 7) % 2 === 0;
    drawBox(g, x, y, ca, sa, -2.2, 1.4, -4.4, 0, hCab, hCab + 2.2, vx, vy, fl ? '#ff5a5a' : '#b82828', fl ? '#ff5a5a' : '#a02020', '#8a1c1c', '#a02020', '#8a1c1c', '#0b0b10');
    drawBox(g, x, y, ca, sa, -2.2, 1.4, 0, 4.4, hCab, hCab + 2.2, vx, vy, !fl ? '#6aa8ff' : '#2a58b8', !fl ? '#6aa8ff' : '#224898', '#1e3d82', '#224898', '#1e3d82', '#0b0b10');
  }
}

/**
 * Full 3D Yellow School Bus ("SCHOOL BUS") with armored plates, toothed front ram,
 * rooftop supply rack, flashing beacons, stop arm, riders in windows, and roof gun turret.
 */
export function drawSchoolBus3D(g: G, o: Car3DOpt) {
  const { x, y, ang, vx, vy } = o;
  const ca = Math.cos(ang), sa = Math.sin(ang);
  const t = o.t ?? 0;
  const bounce = o.moving ? Math.sin(t * 36) * 0.45 : 0;

  const Y = '#f6b91c', YH = '#ffd95e', YD = '#c78c0c', YS = '#dca014';
  const GLASS = '#16283e', GHI = '#4774a6';
  const hw = 9.2;
  const uRear = -31, uCab = 17, uNose = 29;

  // ground contact shadow
  const sh = [
    P3(x + (uRear - 2) * ca - (-hw - 1.5) * sa, y + (uRear - 2) * sa + (-hw - 1.5) * ca, 0, vx, vy),
    P3(x + (uNose + 6) * ca - (-hw - 1.5) * sa, y + (uNose + 6) * sa + (-hw - 1.5) * ca, 0, vx, vy),
    P3(x + (uNose + 6) * ca - (hw + 1.5) * sa, y + (uNose + 6) * sa + (hw + 1.5) * ca, 0, vx, vy),
    P3(x + (uRear - 2) * ca - (hw + 1.5) * sa, y + (uRear - 2) * sa + (hw + 1.5) * ca, 0, vx, vy),
  ];
  drawQuad(g, 'rgba(0,0,0,0.36)', sh);

  // 4 chunky wheels with yellow hubs
  for (const wu of [-20, 20]) {
    for (const wv of [-hw - 0.8, hw - 1.8]) {
      drawBox(g, x, y, ca, sa, wu - 4.2, wu + 4.2, wv, wv + 2.6, 0, 5.2, vx, vy, '#1c1e26', '#14151c', '#14151c', '#2b2e3a', '#2b2e3a', '#090a0e');
    }
  }

  // Main long bus body (uRear..uCab, z=2.5..19.5)
  const main = drawBox(g, x, y, ca, sa, uRear, uCab, -hw, hw, 2.5 + bounce, 19.5 + bounce, vx, vy, YH, Y, YD, YS, YD, '#0b0b10', (face, P) => {
    if (face === 1) {
      // Front windscreen above hood
      drawQuad(g, GLASS, [P(0, 0.1, 0.5), P(0, 0.9, 0.5), P(0, 0.9, 0.88), P(0, 0.1, 0.88)]);
      drawQuad(g, GHI, [P(0, 0.14, 0.74), P(0, 0.45, 0.74), P(0, 0.45, 0.86), P(0, 0.14, 0.86)]);
      drawQuad(g, '#16161c', [P(0, 0.49, 0.5), P(0, 0.51, 0.5), P(0, 0.51, 0.88), P(0, 0.49, 0.88)]);
    } else if (face === 3) {
      // Rear emergency door, window & taillights
      drawQuad(g, '#16161c', [P(0, 0.28, 0.08), P(0, 0.72, 0.08), P(0, 0.72, 0.84), P(0, 0.28, 0.84)]);
      drawQuad(g, YD, [P(0, 0.31, 0.1), P(0, 0.69, 0.1), P(0, 0.69, 0.82), P(0, 0.31, 0.82)]);
      drawQuad(g, GLASS, [P(0, 0.36, 0.5), P(0, 0.64, 0.5), P(0, 0.64, 0.76), P(0, 0.36, 0.76)]);
      drawQuad(g, '#e03a3a', [P(0, 0.07, 0.22), P(0, 0.22, 0.22), P(0, 0.22, 0.36), P(0, 0.07, 0.36)]);
      drawQuad(g, '#e03a3a', [P(0, 0.78, 0.22), P(0, 0.93, 0.22), P(0, 0.93, 0.36), P(0, 0.78, 0.36)]);
    } else {
      // Side walls: black rub rails, row of 6 windows, steel armor plate over rear wheel, riders!
      const rev = face === 2;
      const u = (a: number) => (rev ? 1 - a : a);
      drawQuad(g, '#15151c', [P(0, 0, 0.18), P(1, 0, 0.18), P(1, 0, 0.24), P(0, 0, 0.24)]);
      drawQuad(g, '#15151c', [P(0, 0, 0.44), P(1, 0, 0.44), P(1, 0, 0.5), P(0, 0, 0.5)]);
      // armor plate over rear wheel
      drawQuad(g, '#5d6470', [P(u(0.05), 0, 0.06), P(u(0.45), 0, 0.06), P(u(0.45), 0, 0.28), P(u(0.05), 0, 0.28)]);
      // windows
      const HATS = ['#c0392b', '#f5c542', '#3f7a4a', '#ff7ab0', '#4a8fd8'];
      for (let i = 0; i < 6; i++) {
        const a0 = u(0.07 + i * 0.142), a1 = u(0.07 + i * 0.142 + 0.105);
        drawQuad(g, GLASS, [P(a0, 0, 0.53), P(a1, 0, 0.53), P(a1, 0, 0.86), P(a0, 0, 0.86)]);
        drawQuad(g, GHI, [P(a0, 0, 0.78), P(a1, 0, 0.78), P(a1, 0, 0.86), P(a0, 0, 0.86)]);
        if (i < (o.riders ?? 0)) {
          const m0 = u(0.085 + i * 0.142), m1 = u(0.085 + i * 0.142 + 0.075);
          drawQuad(g, '#e0ac7e', [P(m0, 0, 0.54), P(m1, 0, 0.54), P(m1, 0, 0.72), P(m0, 0, 0.72)]);
          drawQuad(g, HATS[i % HATS.length], [P(m0, 0, 0.7), P(m1, 0, 0.7), P(m1, 0, 0.8), P(m0, 0, 0.8)]);
        }
      }
      // stop arm on left side (face === 0)
      if (face === 0 && o.stop) {
        drawQuad(g, '#d8433b', [P(0.68, 0, 0.34), P(0.79, 0, 0.34), P(0.79, 0, 0.52), P(0.68, 0, 0.52)]);
      }
    }
  });

  // Hood / engine nose (uCab..uNose, z=2.5..12)
  drawBox(g, x, y, ca, sa, uCab, uNose, -hw + 0.8, hw - 0.8, 2.5 + bounce, 11.8 + bounce, vx, vy, Y, '#383c46', YD, YS, YD, '#0b0b10', (face, P) => {
    if (face === 1) {
      drawQuad(g, '#20242c', [P(0, 0.22, 0.2), P(0, 0.78, 0.2), P(0, 0.78, 0.76), P(0, 0.22, 0.76)]);
      const hl = o.night ? '#fff8cc' : '#fff3b8';
      drawQuad(g, hl, [P(0, 0.06, 0.26), P(0, 0.2, 0.26), P(0, 0.2, 0.54), P(0, 0.06, 0.54)]);
      drawQuad(g, hl, [P(0, 0.8, 0.26), P(0, 0.94, 0.26), P(0, 0.94, 0.54), P(0, 0.8, 0.54)]);
    }
  });

  // Armored spiked ram welded to front bumper (uNose..uNose+5)
  drawBox(g, x, y, ca, sa, uNose, uNose + 3.5, -hw - 0.5, hw + 0.5, 2 + bounce, 9.5 + bounce, vx, vy, '#aeb6c4', '#7f8794', '#555b66', '#6b727e', '#6b727e', '#0b0b10');
  for (const tv of [-6.5, -2.2, 2.2, 6.5]) {
    drawBox(g, x, y, ca, sa, uNose + 3.5, uNose + 6.5, tv - 1.1, tv + 1.1, 3.2 + bounce, 8.2 + bounce, vx, vy, o.ram ? '#b82530' : '#dce2ec', '#eef3fa', '#5d6470', '#8d949e', '#8d949e', '#0b0b10');
  }

  // Roof cargo rack: ammo box, red jerrycan, wooden crate
  drawBox(g, x, y, ca, sa, uRear + 3, uRear + 11, -6, 6, 19.5 + bounce, 22.8 + bounce, vx, vy, '#5d7042', '#4a5a34', '#384626', '#4a5a34', '#3e4d2b', '#0b0b10');
  drawBox(g, x, y, ca, sa, uRear + 12, uRear + 18, -5.5, 0.5, 19.5 + bounce, 22.8 + bounce, vx, vy, '#e85a48', '#c0392b', '#96281c', '#c0392b', '#a83226', '#0b0b10');
  drawBox(g, x, y, ca, sa, uRear + 12, uRear + 23, 1.2, 6.5, 19.5 + bounce, 22.5 + bounce, vx, vy, '#9e6d4a', '#7a4a30', '#5e3822', '#7a4a30', '#683f28', '#0b0b10');

  // Flashing roof warning beacons
  const fl = !!o.flash && Math.sin(t * 10) > 0;
  for (const lu of [uRear + 1.5, uCab - 2.5]) {
    drawBox(g, x, y, ca, sa, lu - 1.2, lu + 1.2, -6.5, -3.8, 19.5 + bounce, 21.4 + bounce, vx, vy, fl ? '#ff5a4a' : '#a8322c', '#8a221c', '#8a221c', '#8a221c', '#8a221c', '#0b0b10');
    drawBox(g, x, y, ca, sa, lu - 1.2, lu + 1.2, 3.8, 6.5, 19.5 + bounce, 21.4 + bounce, vx, vy, !fl && o.flash ? '#ffd75e' : '#b9831a', '#8f6410', '#8f6410', '#8f6410', '#8f6410', '#0b0b10');
  }

  // Roof pintle machine gun (when gunA is provided)
  if (o.gunA !== undefined) {
    const gp = P3(x + 4 * ca, y + 4 * sa, 20.5 + bounce, vx, vy);
    g.save();
    g.translate(Math.round(gp[0]), Math.round(gp[1]));
    g.fillStyle = '#0b0b10'; g.fillRect(-3, -2, 6, 4);
    g.rotate(o.gunA);
    g.fillStyle = '#0b0b10'; g.fillRect(-5, -2.5, 19, 5);
    g.fillStyle = '#3a3f4a'; g.fillRect(-4, -1.5, 9, 3);
    g.fillStyle = '#8d949e'; g.fillRect(5, -1.5, 8, 1.5);
    g.fillStyle = '#5d6470'; g.fillRect(5, 0, 8, 1.5);
    g.fillStyle = '#4a5a34'; g.fillRect(-3, 2, 4, 2);
    if (o.gunFlash) {
      g.fillStyle = '#ffd75e'; g.fillRect(14, -3, 7, 6);
      g.fillStyle = '#ffffff'; g.fillRect(14, -1.5, 4, 3);
    }
    g.restore();
    void main;
  }
}

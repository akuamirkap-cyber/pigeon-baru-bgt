/* ===== Sound FX 8-bit pakai Web Audio API (tanpa file eksternal) ===== */

let ctx: AudioContext | null = null;

function getCtx(): AudioContext {
  if (!ctx) {
    ctx = new (window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext)();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

type Step = {
  freq: number;
  dur: number; // detik
  type?: OscillatorType;
  vol?: number;
  slide?: number; // frekuensi tujuan (glide)
  gap?: number; // jeda setelah nada
};

function playSteps(steps: Step[], startGap = 0) {
  const ac = getCtx();
  let t = ac.currentTime + startGap;
  for (const s of steps) {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = s.type ?? "square";
    osc.frequency.setValueAtTime(s.freq, t);
    if (s.slide) osc.frequency.linearRampToValueAtTime(s.slide, t + s.dur);
    const v = s.vol ?? 0.18;
    gain.gain.setValueAtTime(v, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + s.dur);
    osc.connect(gain).connect(ac.destination);
    osc.start(t);
    osc.stop(t + s.dur + 0.02);
    t += s.dur + (s.gap ?? 0);
  }
}

function playNoise(dur: number, vol = 0.2, fromFreq = 1800, toFreq = 200, delay = 0) {
  const ac = getCtx();
  const size = Math.floor(ac.sampleRate * dur);
  const buf = ac.createBuffer(1, size, ac.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < size; i++) data[i] = Math.random() * 2 - 1;
  const src = ac.createBufferSource();
  src.buffer = buf;
  const gain = ac.createGain();
  const t = ac.currentTime + delay;
  gain.gain.setValueAtTime(vol, t);
  gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
  const filter = ac.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(fromFreq, t);
  filter.frequency.exponentialRampToValueAtTime(Math.max(toFreq, 40), t + dur);
  src.connect(filter).connect(gain).connect(ac.destination);
  src.start(t);
}

/* ===== Suara khusus perhitungan skor ===== */
export function playTick(pitch = 1) {
  playSteps([{ freq: 900 * pitch, dur: 0.035, vol: 0.07 }]);
}

export function playTallyDone() {
  playSteps([
    { freq: 988, dur: 0.09, vol: 0.16 },
    { freq: 1319, dur: 0.12, vol: 0.16 },
    { freq: 1760, dur: 0.3, vol: 0.18 },
  ]);
}

export type SoundId =
  | "gameover"
  | "coin"
  | "jump"
  | "click"
  | "splat"
  | "win"
  | "powerup"
  | "laser"
  | "explosion"
  | "hit"
  | "hurt"
  | "pickup"
  | "levelup"
  | "oneup"
  | "alarm"
  | "swoosh"
  | "teleport"
  | "shield"
  | "bomb"
  | "step"
  | "splash"
  | "chirp"
  | "honk"
  | "train"
  | "heart"
  | "unlock"
  | "error"
  | "combo"
  | "magic"
  | "fanfare";

export const SOUNDS: { id: SoundId; label: string; emoji: string }[] = [
  { id: "gameover", label: "GAME OVER", emoji: "💀" },
  { id: "coin", label: "COIN", emoji: "🪙" },
  { id: "jump", label: "JUMP", emoji: "🐤" },
  { id: "click", label: "CLICK", emoji: "👆" },
  { id: "splat", label: "SPLAT", emoji: "💥" },
  { id: "win", label: "WIN", emoji: "🏆" },
  { id: "powerup", label: "POWER UP", emoji: "⚡" },
  { id: "laser", label: "LASER", emoji: "🔫" },
  { id: "explosion", label: "EXPLOSION", emoji: "🧨" },
  { id: "hit", label: "HIT", emoji: "🥊" },
  { id: "hurt", label: "HURT", emoji: "🤕" },
  { id: "pickup", label: "PICK UP", emoji: "🎁" },
  { id: "levelup", label: "LEVEL UP", emoji: "📈" },
  { id: "oneup", label: "1-UP", emoji: "🍄" },
  { id: "alarm", label: "ALARM", emoji: "🚨" },
  { id: "swoosh", label: "SWOOSH", emoji: "🌪️" },
  { id: "teleport", label: "TELEPORT", emoji: "🌀" },
  { id: "shield", label: "SHIELD", emoji: "🛡️" },
  { id: "bomb", label: "BOMB", emoji: "💣" },
  { id: "step", label: "STEP", emoji: "👟" },
  { id: "splash", label: "SPLASH", emoji: "💧" },
  { id: "chirp", label: "CHIRP", emoji: "🐥" },
  { id: "honk", label: "HONK", emoji: "🚗" },
  { id: "train", label: "TRAIN", emoji: "🚂" },
  { id: "heart", label: "HEART", emoji: "❤️" },
  { id: "unlock", label: "UNLOCK", emoji: "🔓" },
  { id: "error", label: "ERROR", emoji: "❌" },
  { id: "combo", label: "COMBO", emoji: "🔥" },
  { id: "magic", label: "MAGIC", emoji: "✨" },
  { id: "fanfare", label: "FANFARE", emoji: "🎺" },
];

export function playSound(id: SoundId) {
  switch (id) {
    case "gameover":
      playSteps([
        { freq: 523, dur: 0.16 },
        { freq: 494, dur: 0.16 },
        { freq: 440, dur: 0.16 },
        { freq: 392, dur: 0.22 },
        { freq: 330, dur: 0.3, type: "triangle", vol: 0.22 },
        { freq: 262, dur: 0.45, type: "triangle", vol: 0.22 },
      ]);
      break;
    case "coin":
      playSteps([
        { freq: 988, dur: 0.08, vol: 0.15 },
        { freq: 1319, dur: 0.25, vol: 0.15 },
      ]);
      break;
    case "jump":
      playSteps([{ freq: 300, dur: 0.18, slide: 700, vol: 0.2 }]);
      break;
    case "click":
      playSteps([{ freq: 900, dur: 0.05, vol: 0.12 }]);
      break;
    case "splat":
      playNoise(0.35, 0.3);
      playSteps([{ freq: 180, dur: 0.25, slide: 60, type: "sawtooth", vol: 0.2 }]);
      break;
    case "win":
      playSteps([
        { freq: 523, dur: 0.12 },
        { freq: 659, dur: 0.12 },
        { freq: 784, dur: 0.12 },
        { freq: 1047, dur: 0.3, vol: 0.2 },
        { freq: 784, dur: 0.12 },
        { freq: 1047, dur: 0.4, vol: 0.2 },
      ]);
      break;
    case "powerup":
      playSteps([
        { freq: 220, dur: 0.07, slide: 440 },
        { freq: 440, dur: 0.07, slide: 660 },
        { freq: 660, dur: 0.07, slide: 880 },
        { freq: 880, dur: 0.18, slide: 1320, vol: 0.16 },
      ]);
      break;
    case "laser":
      playSteps([{ freq: 1400, dur: 0.22, slide: 120, type: "sawtooth", vol: 0.15 }]);
      break;
    case "explosion":
      playNoise(0.6, 0.35, 2500, 60);
      playSteps([{ freq: 120, dur: 0.5, slide: 30, type: "sawtooth", vol: 0.25 }]);
      break;
    case "hit":
      playNoise(0.12, 0.25, 3000, 400);
      playSteps([{ freq: 350, dur: 0.1, slide: 100, vol: 0.2 }]);
      break;
    case "hurt":
      playSteps([
        { freq: 500, dur: 0.08, slide: 300, vol: 0.2 },
        { freq: 300, dur: 0.15, slide: 150, vol: 0.2 },
      ]);
      break;
    case "pickup":
      playSteps([
        { freq: 660, dur: 0.07, vol: 0.15 },
        { freq: 880, dur: 0.07, vol: 0.15 },
        { freq: 1175, dur: 0.15, vol: 0.15 },
      ]);
      break;
    case "levelup":
      playSteps([
        { freq: 392, dur: 0.1 },
        { freq: 523, dur: 0.1 },
        { freq: 659, dur: 0.1 },
        { freq: 784, dur: 0.1 },
        { freq: 1047, dur: 0.35, vol: 0.2 },
      ]);
      break;
    case "oneup":
      playSteps([
        { freq: 330, dur: 0.1 },
        { freq: 392, dur: 0.1 },
        { freq: 659, dur: 0.1 },
        { freq: 523, dur: 0.1 },
        { freq: 587, dur: 0.1 },
        { freq: 784, dur: 0.25, vol: 0.2 },
      ]);
      break;
    case "alarm":
      playSteps([
        { freq: 880, dur: 0.18, vol: 0.15 },
        { freq: 660, dur: 0.18, vol: 0.15 },
        { freq: 880, dur: 0.18, vol: 0.15 },
        { freq: 660, dur: 0.18, vol: 0.15 },
      ]);
      break;
    case "swoosh":
      playNoise(0.3, 0.2, 400, 4000);
      break;
    case "teleport":
      playSteps([
        { freq: 200, dur: 0.06, slide: 1600, vol: 0.14 },
        { freq: 1600, dur: 0.06, slide: 200, vol: 0.14 },
        { freq: 200, dur: 0.06, slide: 1600, vol: 0.14 },
        { freq: 1600, dur: 0.12, slide: 100, vol: 0.14 },
      ]);
      break;
    case "shield":
      playSteps([
        { freq: 600, dur: 0.3, type: "triangle", vol: 0.2 },
        { freq: 900, dur: 0.3, type: "triangle", vol: 0.14 },
      ]);
      break;
    case "bomb":
      // sumbu mendesis lalu meledak
      playNoise(0.4, 0.08, 5000, 3000);
      playNoise(0.5, 0.35, 2000, 50, 0.45);
      playSteps([{ freq: 100, dur: 0.4, slide: 25, type: "sawtooth", vol: 0.25 }], 0.45);
      break;
    case "step":
      playNoise(0.07, 0.15, 900, 300);
      break;
    case "splash":
      playNoise(0.35, 0.25, 1200, 150);
      playSteps([{ freq: 500, dur: 0.2, slide: 150, type: "sine", vol: 0.15 }]);
      break;
    case "chirp":
      playSteps([
        { freq: 2200, dur: 0.06, slide: 2800, vol: 0.1, gap: 0.05 },
        { freq: 2400, dur: 0.06, slide: 3000, vol: 0.1, gap: 0.05 },
        { freq: 2000, dur: 0.08, slide: 2600, vol: 0.1 },
      ]);
      break;
    case "honk":
      playSteps([
        { freq: 330, dur: 0.18, type: "sawtooth", vol: 0.18, gap: 0.06 },
        { freq: 330, dur: 0.3, type: "sawtooth", vol: 0.18 },
      ]);
      break;
    case "train":
      playSteps([
        { freq: 311, dur: 0.5, type: "sawtooth", vol: 0.12 },
      ]);
      playSteps([
        { freq: 392, dur: 0.5, type: "sawtooth", vol: 0.12 },
      ]);
      playSteps([
        { freq: 466, dur: 0.5, type: "sawtooth", vol: 0.12 },
      ]);
      break;
    case "heart":
      playSteps([
        { freq: 523, dur: 0.1, type: "sine", vol: 0.22, gap: 0.08 },
        { freq: 659, dur: 0.22, type: "sine", vol: 0.22 },
      ]);
      break;
    case "unlock":
      playSteps([
        { freq: 700, dur: 0.05, vol: 0.12, gap: 0.04 },
        { freq: 700, dur: 0.05, vol: 0.12, gap: 0.1 },
        { freq: 1047, dur: 0.25, vol: 0.18 },
      ]);
      break;
    case "error":
      playSteps([
        { freq: 220, dur: 0.15, type: "sawtooth", vol: 0.18, gap: 0.05 },
        { freq: 185, dur: 0.3, type: "sawtooth", vol: 0.18 },
      ]);
      break;
    case "combo":
      playSteps([
        { freq: 523, dur: 0.07, vol: 0.15 },
        { freq: 659, dur: 0.07, vol: 0.15 },
        { freq: 784, dur: 0.07, vol: 0.15 },
        { freq: 1047, dur: 0.07, vol: 0.15 },
        { freq: 1319, dur: 0.07, vol: 0.15 },
        { freq: 1568, dur: 0.15, vol: 0.15 },
      ]);
      break;
    case "magic":
      playSteps([
        { freq: 1047, dur: 0.07, type: "triangle", vol: 0.15 },
        { freq: 1319, dur: 0.07, type: "triangle", vol: 0.15 },
        { freq: 1760, dur: 0.07, type: "triangle", vol: 0.15 },
        { freq: 2093, dur: 0.07, type: "triangle", vol: 0.15 },
        { freq: 2637, dur: 0.2, type: "triangle", vol: 0.12 },
      ]);
      break;
    case "fanfare":
      playSteps([
        { freq: 392, dur: 0.14, vol: 0.18, gap: 0.02 },
        { freq: 392, dur: 0.07, vol: 0.18, gap: 0.02 },
        { freq: 392, dur: 0.07, vol: 0.18, gap: 0.02 },
        { freq: 523, dur: 0.3, vol: 0.2, gap: 0.05 },
        { freq: 659, dur: 0.14, vol: 0.18, gap: 0.02 },
        { freq: 784, dur: 0.45, vol: 0.22 },
      ]);
      break;
  }
}

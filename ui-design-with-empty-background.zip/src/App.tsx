import { useState } from "react";

/* ================= Ikon koin pixel ================= */
function CoinIcon({ size = 18 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 12 12"
      shapeRendering="crispEdges"
      aria-hidden
    >
      {/* lingkaran koin gaya pixel */}
      <rect x="3" y="0" width="6" height="12" fill="#f6b000" />
      <rect x="1" y="1" width="10" height="10" fill="#f6b000" />
      <rect x="0" y="3" width="12" height="6" fill="#f6b000" />
      {/* highlight */}
      <rect x="3" y="1" width="3" height="2" fill="#ffe14d" />
      <rect x="1" y="3" width="2" height="3" fill="#ffe14d" />
      {/* bagian dalam */}
      <rect x="4" y="3" width="4" height="6" fill="#c97f00" />
      <rect x="5" y="4" width="2" height="4" fill="#f6b000" />
    </svg>
  );
}

/* ================= Ikon podium leaderboard pixel ================= */
function PodiumIcon() {
  return (
    <svg
      width="58"
      height="48"
      viewBox="0 0 30 24"
      shapeRendering="crispEdges"
      aria-hidden
    >
      {/* podium 2 (kiri) */}
      <rect x="1" y="10" width="9" height="13" fill="#ffffff" />
      <rect x="1" y="10" width="9" height="2" fill="#e8f8ff" />
      {/* podium 1 (tengah, paling tinggi) */}
      <rect x="10" y="4" width="10" height="19" fill="#ffffff" />
      <rect x="10" y="4" width="10" height="2" fill="#e8f8ff" />
      {/* podium 3 (kanan) */}
      <rect x="20" y="14" width="9" height="9" fill="#ffffff" />
      <rect x="20" y="14" width="9" height="2" fill="#e8f8ff" />

      {/* angka 2 */}
      <g fill="#1e9ec9">
        <rect x="3" y="14" width="5" height="1.6" />
        <rect x="6.4" y="15.6" width="1.6" height="1.6" />
        <rect x="3" y="17.2" width="5" height="1.6" />
        <rect x="3" y="18.8" width="1.6" height="1.6" />
        <rect x="3" y="20.4" width="5" height="1.6" />
      </g>
      {/* angka 1 */}
      <g fill="#1e9ec9">
        <rect x="14" y="8" width="2" height="1.8" />
        <rect x="13" y="9.8" width="3" height="1.8" />
        <rect x="14" y="9.8" width="2" height="8" />
        <rect x="12.5" y="17.8" width="5" height="1.8" />
      </g>
      {/* angka 3 */}
      <g fill="#1e9ec9">
        <rect x="22" y="16.5" width="5" height="1.4" />
        <rect x="25.6" y="17.9" width="1.4" height="1.2" />
        <rect x="23" y="19.1" width="4" height="1.4" />
        <rect x="25.6" y="20.5" width="1.4" height="1.2" />
        <rect x="22" y="21.7" width="5" height="1.4" />
      </g>
    </svg>
  );
}

/* ================= Tombol pixel biru ================= */
function PixelButton({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className="group relative h-[86px] w-[128px] cursor-pointer select-none outline-none transition-transform duration-75 active:translate-y-[4px]"
    >
      {/* bayangan bawah */}
      <span className="pixel-corners-sm absolute inset-0 translate-y-[6px] bg-[#0f7fa8] transition-transform duration-75 group-active:translate-y-[2px]" />
      {/* badan tombol */}
      <span className="pixel-corners-sm absolute inset-0 bg-[#39c1ea]">
        {/* highlight atas */}
        <span className="absolute left-[10px] right-[10px] top-[6px] h-[12px] bg-[#8fe3ff]" />
        <span className="absolute left-[6px] top-[10px] h-[26px] w-[8px] bg-[#8fe3ff]" />
        {/* shading bawah */}
        <span className="absolute bottom-[5px] left-[10px] right-[10px] h-[8px] bg-[#1fa3cf]" />
      </span>
      {/* isi ikon */}
      <span className="relative z-10 flex h-full w-full items-center justify-center">
        {children}
      </span>
    </button>
  );
}

/* ================= Pita GAME OVER ================= */
function GameOverRibbon() {
  return (
    <div className="anim-pop relative flex w-full justify-center">
      {/* ujung pita kiri */}
      <div className="ribbon-end-left absolute left-[2px] top-[23px] h-[62px] w-[92px] bg-[#c0272d]">
        <div className="absolute inset-x-0 top-0 h-[8px] bg-[#d8363c]" />
      </div>
      {/* ujung pita kanan */}
      <div className="ribbon-end-right absolute right-[2px] top-[23px] h-[62px] w-[92px] bg-[#c0272d]">
        <div className="absolute inset-x-0 top-0 h-[8px] bg-[#d8363c]" />
      </div>

      {/* lipatan segitiga bawah */}
      <div className="absolute left-[62px] top-[72px] h-0 w-0 border-l-[18px] border-t-[15px] border-l-transparent border-t-[#8c1b20]" />
      <div className="absolute right-[62px] top-[72px] h-0 w-0 border-r-[18px] border-t-[15px] border-r-transparent border-t-[#8c1b20]" />

      {/* badan utama pita */}
      <div className="pixel-corners relative z-10 mx-[62px] w-full bg-[#e8403f] px-2 py-5 text-center">
        {/* highlight atas */}
        <div className="absolute inset-x-[8px] top-[5px] h-[8px] bg-[#f2635c]" />
        {/* shading bawah */}
        <div className="absolute inset-x-[8px] bottom-[5px] h-[8px] bg-[#c9302f]" />
        <h1 className="pixel-outline-sm whitespace-nowrap text-[21px] leading-none tracking-[1px] text-white sm:text-[24px]">
          GAME OVER
        </h1>
      </div>
    </div>
  );
}

/* ================= Bagian skor (tanpa panel) ================= */
function ScorePanel() {
  return (
    <div className="anim-slide relative w-[88%] max-w-[330px] px-2 pb-2 pt-2 text-center [animation-delay:0.15s]">
      <p className="pixel-outline-sm text-[16px] tracking-[2px] text-white sm:text-[17px]">
        SCORE
      </p>

      <p className="anim-score pixel-outline mt-4 text-[52px] leading-none text-[#ffcc00] [animation-delay:0.3s] sm:text-[58px]">
        5,748
      </p>

      <div className="mt-6 flex items-center justify-center gap-4">
        <span className="pixel-outline-sm whitespace-nowrap text-[16px] text-white sm:text-[17px]">
          BEST 7,451
        </span>
        <span className="flex items-center gap-2">
          <CoinIcon size={24} />
          <span className="pixel-outline-sm text-[16px] text-[#ffcc00] sm:text-[17px]">
            +72
          </span>
        </span>
      </div>
    </div>
  );
}

export default function App() {
  const [replayKey, setReplayKey] = useState(0);

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-b from-[#9aa7b6] via-[#8d9aa9] to-[#7e8b9a]">
      {/* bingkai layar ponsel */}
      <div
        key={replayKey}
        className="relative flex min-h-screen w-full max-w-[420px] flex-col items-center overflow-hidden px-3 pt-[90px]"
      >
        <GameOverRibbon />

        <div className="mt-8 flex w-full justify-center">
          <ScorePanel />
        </div>

        {/* tombol aksi */}
        <div className="anim-slide mt-12 flex w-[88%] max-w-[330px] items-center justify-between [animation-delay:0.3s]">
          <PixelButton label="Main lagi" onClick={() => setReplayKey((k) => k + 1)}>
            {/* segitiga play pixel */}
            <svg
              width="40"
              height="44"
              viewBox="0 0 10 11"
              shapeRendering="crispEdges"
              aria-hidden
            >
              <g fill="#ffffff">
                <rect x="0" y="0" width="2" height="11" />
                <rect x="2" y="1" width="2" height="9" />
                <rect x="4" y="2.5" width="2" height="6" />
                <rect x="6" y="4" width="2" height="3" />
                <rect x="8" y="5" width="1.4" height="1" />
              </g>
            </svg>
          </PixelButton>

          <PixelButton label="Papan peringkat">
            <PodiumIcon />
          </PixelButton>
        </div>
      </div>
    </div>
  );
}
